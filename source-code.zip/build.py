#!/usr/bin/env python3
"""合併 src/ 成單一 HTML：dist/index.html（Artifact 用，冇 doctype）同 dist/standalone.html（瀏覽器用）。"""
import os
R=os.path.dirname(os.path.abspath(__file__)); S=os.path.join(R,'src')
order=[l.strip() for l in open(os.path.join(S,'ORDER'),encoding='utf8') if l.strip()]
js='\n'.join(open(os.path.join(S,f),encoding='utf8').read() for f in order)
css='\n'.join(open(os.path.join(S,f),encoding='utf8').read() for f in ['p_base.css','p_sandbox.css','p_game.css','p_new.css'])
shell=open(os.path.join(S,'shell.html'),encoding='utf8').read()
page=shell.replace('/*CSS*/',css).replace('/*JS*/',js)
os.makedirs(os.path.join(R,'dist'),exist_ok=True)
open(os.path.join(R,'dist','index.html'),'w',encoding='utf8').write(page)
head,body=page.split('<div id="title"',1)
sa='<!doctype html>\n<html lang="zh-HK">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'+head+'</head>\n<body>\n<div id="title"'+body+'\n</body>\n</html>\n'
open(os.path.join(R,'dist','standalone.html'),'w',encoding='utf8').write(sa)
import shutil
shutil.copytree(os.path.join(S,'audio'),os.path.join(R,'dist','audio'),dirs_exist_ok=True)
print('built',len(page)//1024,'KB')
