"""特殊客 2D 立繪（用戶提供嘅圖）：去背、裁邊、縮細，輸出 src/p_spimg.js（data URI）。
用法：python3 tools/make_spimg.py"""
import base64, io, os
from collections import deque
from PIL import Image
D=os.path.join(os.path.dirname(__file__),'..','src','img','sp')
WHITE=['cheems','swole','bonk','doge','samurai','dogebread']
GREEN=['orange0','orange1','sadcat','huh']
PHOTO=['pop0','pop1']
def flood_white(im,tol=30):
    im=im.convert('RGBA');w,h=im.size;px=im.load();seen=bytearray(w*h);q=deque()
    for x in range(w):q.append((x,0));q.append((x,h-1))
    for y in range(h):q.append((0,y));q.append((w-1,y))
    while q:
        x,y=q.popleft();i=y*w+x
        if seen[i]:continue
        seen[i]=1;r,g,b,a=px[x,y]
        if min(r,g,b)<255-tol and a>0:continue
        px[x,y]=(r,g,b,0)
        for nx,ny in((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
            if 0<=nx<w and 0<=ny<h and not seen[ny*w+nx]:q.append((nx,ny))
    return im
def key_green(im):
    im=im.convert('RGBA');px=im.load();w,h=im.size
    for y in range(h):
        for x in range(w):
            r,g,b,a=px[x,y];m=max(r,b);d=g-m
            if d>45:px[x,y]=(r,g,b,0)
            elif d>18:px[x,y]=(r,m+8,b,int(255*(45-d)/27))
            elif d>0:px[x,y]=(r,m+4,b,a)
    return im
out={}
for name in WHITE+GREEN+PHOTO:
    im=Image.open(os.path.join(D,name+'.png'))
    if name=='bonk':  # 原圖外圍有圓角框，先清走邊緣 16px
        im=im.convert('RGBA');px=im.load();w,h=im.size
        for y in range(h):
            for x in range(w):
                if x<16 or y<16 or x>=w-16 or y>=h-16:px[x,y]=(255,255,255,255)
    im=flood_white(im) if name in WHITE else key_green(im) if name in GREEN else im.convert('RGBA')
    bb=im.getbbox()
    if bb:im=im.crop(bb)
    if im.height>420:im=im.resize((round(im.width*420/im.height),420),Image.LANCZOS)
    b=io.BytesIO();im.save(b,'WEBP',quality=82,method=6);out[name]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
    print(name,im.size,len(b.getvalue())//1024,'KB')
# 動畫角色：src/img/sp/<名>/ 入面 stand.png 同其他幀（OIIA 貓轉圈、Happy 貓跳），由用戶影片抽出；同一個資料夾用同一個裁剪框，郁嘅時候位置唔會跳
for AD in ['oiia','happy']:
    OD=os.path.join(D,AD)
    if not os.path.isdir(OD):continue
    names=['stand']+sorted(f[:-4] for f in os.listdir(OD) if f.endswith('.png') and f!='stand.png')
    ims={n:key_green(Image.open(os.path.join(OD,n+'.png'))) for n in names}
    bx=[im.getbbox() for im in ims.values() if im.getbbox()]
    U=(min(b[0] for b in bx),min(b[1] for b in bx),max(b[2] for b in bx),max(b[3] for b in bx))
    for n,im in ims.items():
        im=im.crop(U);h=300 if AD=='oiia' else 360;im=im.resize((round(im.width*h/im.height),h),Image.LANCZOS)
        b=io.BytesIO();im.save(b,'WEBP',quality=80,method=6);out[AD+'_'+n]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
    print(AD,'frames',len(names),U)
snd={}
for k in ['oiia','happy','pop']:  # 角色聲（由用戶提供嘅片／錄音剪出），會嵌入 p_spimg.js
    AP=os.path.join(os.path.dirname(__file__),'..','src','audio',k+'.mp3')
    if os.path.exists(AP):snd[k]='data:audio/mpeg;base64,'+base64.b64encode(open(AP,'rb').read()).decode()
js='/* p_spimg：特殊客 2D 立繪（用戶提供嘅網上寵物梗圖，已去背）。由 tools/make_spimg.py 生成，唔好手改。 */\nvar SPIMG='+'{'+','.join("%s:'%s'"%(k,v) for k,v in out.items())+'};\nvar SPSND={'+','.join("%s:'%s'"%(k,v) for k,v in snd.items())+'};\n'
open(os.path.join(os.path.dirname(__file__),'..','src','p_spimg.js'),'w').write(js);print('p_spimg.js',len(js)//1024,'KB')
