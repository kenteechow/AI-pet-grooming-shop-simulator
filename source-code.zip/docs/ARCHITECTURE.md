# ARCHITECTURE
- 單一 HTML。`src/shell.html` 係骨架，`build.py` 將 `p_base.css`、`p_sandbox.css`、`p_new.css` 同 `ORDER` 入面嘅 JS 塞入去。
- 狀態：`UI.P`（店）、`UI.F`（創辦人）、`UI.R`（`runAll` 結果）、`UI.sens` `UI.cmp` `UI.q` `UI.mc`（懶計算，改參數就作廢）。
- 流程：輸入 → `changed()`（140ms debounce）→ `recompute()` → `renderMain()` → `lazy()` 計重嘢。
- 引擎按週：`shopStep(S)` 推一週；`runShop` 跑 52 週；`toMonths` 合併成 12 個月。
- v0.2 計劃：`p_core`（主循環 `clockLoop → endOfDay → weekEnd → monthStart`）直接 call `shopStep` 嘅每日版本，加 3D（three.js r128）。
