/* p_cam：城市天際線 2 式鏡頭。目標（CT）同實際（CAM）分開，每幀順滑追上；WASD 連續移動、Q/E 旋轉、R/F 縮放、
   左鍵拖曳移動（放手有慣性）、右鍵或中鍵拖曳旋轉同俯仰、滾輪向游標縮放、縮近會自動放平、雙擊飛去嗰度、畫面邊緣推動（可關）。 */
var CAM_DEF={tx:0,ty:3.2,tz:-4.5,rad:20,th:.35,tilt:0};
var CAM=clone(CAM_DEF),CT=clone(CAM_DEF),CV={x:0,z:0},KEYS={},EDGE={on:1,x:-1,y:-1};
CAM.ph=CT.ph=autoPh(CAM_DEF.rad);
function autoPh(rad){/* 縮近：放平睇（1.2）；拉遠：較似俯瞰（0.72） */var k=clamp((rad-6)/58,0,1);return 1.2-.48*k;}
function camClamp(o){var hm=typeof HANDS!=='undefined'&&HANDS.a;/* 落手做：第一身近鏡，可以再近、再俯 */o.tx=clamp(o.tx,-45,45);o.tz=clamp(o.tz,-18,26);o.rad=clamp(o.rad,hm?1.8:5,70);o.tilt=clamp(o.tilt||0,-.45,hm?.9:.25);o.ph=clamp(autoPh(o.rad)+o.tilt,.3,1.36);}
function camApply(){
 camClamp(CAM);var c=W3.cam,sp=Math.sin(CAM.ph);
 c.position.set(CAM.tx+CAM.rad*sp*Math.sin(CAM.th),CAM.ty+CAM.rad*Math.cos(CAM.ph),CAM.tz+CAM.rad*sp*Math.cos(CAM.th));
 c.position.x=clamp(c.position.x,-70,70);c.position.z=clamp(c.position.z,-40,60);c.position.y=Math.max(1.6,c.position.y);
 c.lookAt(CAM.tx,CAM.ty,CAM.tz);
}
function camJump(o){for(var k in o){CT[k]=o[k];CAM[k]=o[k];}if(o.ph!=null){CT.tilt=CAM.tilt=o.ph-autoPh(CT.rad);}camClamp(CT);camApply();}
function camReset(){CT=clone(CAM_DEF);camClamp(CT);if(!CAM.ph)CAM=clone(CT);}
function camPan(dx,dz){var cs=Math.cos(CT.th),sn=Math.sin(CT.th);CT.tx+=dx*cs+dz*sn;CT.tz+=-dx*sn+dz*cs;camClamp(CT);}
function camRot(dth,dph){CT.th+=dth;CT.tilt=(CT.tilt||0)+(dph||0);camClamp(CT);}
function camZoom(f,px,py){var old=CT.rad;CT.rad=clamp(CT.rad*f,5,70);
 if(px!=null&&W3.on){var g=groundAt(px,py,CT.ty);if(g){var k=1-CT.rad/old;CT.tx+=(g.x-CT.tx)*k;CT.tz+=(g.z-CT.tz)*k;}}camClamp(CT);}
function camFly(x,z,rad){CT.tx=x;CT.tz=z;if(rad)CT.rad=rad;camClamp(CT);}
function groundAt(px,py,y){var rc=new THREE.Raycaster(),r=W3.r.domElement.getBoundingClientRect();rc.setFromCamera({x:(px-r.left)/r.width*2-1,y:-(py-r.top)/r.height*2+1},W3.cam);
 var pl=new THREE.Plane(new THREE.Vector3(0,1,0),-y),p=new THREE.Vector3();return rc.ray.intersectPlane(pl,p)?p:null;}
function camUpdate(dt){
 if(!W3.on)return;var sp=CT.rad*1.1*dt,typing=/INPUT|SELECT|TEXTAREA/.test((document.activeElement||{}).tagName||'');
 if(!typing&&!(s&&s.modal)){var dx=(KEYS.d?1:0)-(KEYS.a?1:0),dz=(KEYS.s?1:0)-(KEYS.w?1:0);if(dx||dz)camPan(dx*sp,dz*sp);
  if(KEYS.q)camRot(1.6*dt,0);if(KEYS.e)camRot(-1.6*dt,0);if(KEYS.r)camZoom(1-1.4*dt);if(KEYS.f)camZoom(1+1.4*dt);}
 /* 畫面邊緣推動 */
 if(EDGE.on&&EDGE.x>=0&&!(s&&s.modal)){var el=W3.el,w=el.clientWidth,h=el.clientHeight,m=8,ex=EDGE.x<m?-1:EDGE.x>w-m?1:0,ez=EDGE.y<m?-1:EDGE.y>h-m?1:0;if(ex||ez)camPan(ex*sp*.8,ez*sp*.8);}
 /* 慣性 */
 if(Math.abs(CV.x)+Math.abs(CV.z)>.001){camPan(CV.x*dt,CV.z*dt);var d=Math.exp(-dt*4);CV.x*=d;CV.z*=d;}
 var k=1-Math.exp(-dt*9);
 ['tx','ty','tz','rad','tilt'].forEach(function(p){CAM[p]+=(CT[p]-CAM[p])*k;});
 var dth=CT.th-CAM.th;CAM.th+=dth*k;
 camApply();
}
function camControls(dom){
 var ptrs={},mode=null,lx=0,ly=0,moved=0,pinch=0,ang=0,lt=0;
 dom.addEventListener('contextmenu',function(e){e.preventDefault();});
 dom.addEventListener('pointerdown',function(e){dom.setPointerCapture(e.pointerId);ptrs[e.pointerId]={x:e.clientX,y:e.clientY};mode=(e.button===2||e.button===1||e.shiftKey)?'rot':'pan';lx=e.clientX;ly=e.clientY;moved=0;CV.x=CV.z=0;lt=performance.now();
  var k=Object.keys(ptrs);if(k.length===2){var a=ptrs[k[0]],b=ptrs[k[1]];pinch=Math.hypot(a.x-b.x,a.y-b.y);ang=Math.atan2(b.y-a.y,b.x-a.x);mode='pinch';}});
 dom.addEventListener('pointermove',function(e){EDGE.x=e.clientX-dom.getBoundingClientRect().left;EDGE.y=e.clientY-dom.getBoundingClientRect().top;
  if(!ptrs[e.pointerId])return;ptrs[e.pointerId]={x:e.clientX,y:e.clientY};var dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;moved+=Math.abs(dx)+Math.abs(dy);
  var k=Object.keys(ptrs),now=performance.now(),ddt=Math.max(.008,(now-lt)/1000);lt=now;
  if(mode==='pinch'&&k.length===2){var a=ptrs[k[0]],b=ptrs[k[1]],d=Math.hypot(a.x-b.x,a.y-b.y),an=Math.atan2(b.y-a.y,b.x-a.x);if(pinch)camZoom(pinch/d);camRot(an-ang,0);pinch=d;ang=an;return;}
  if(mode==='rot')camRot(-dx*.006,-dy*.004);
  else{var f=CT.rad*.0017;camPan(-dx*f,-dy*f);CV.x=-dx*f/ddt*.6;CV.z=-dy*f/ddt*.6;}});
 function up(e){var wasClick=moved<6&&mode!=='pinch';delete ptrs[e.pointerId];if(!Object.keys(ptrs).length)mode=null;if(moved<6){CV.x=CV.z=0;}if(wasClick&&e.button===0)pick3D(e.clientX,e.clientY);}
 dom.addEventListener('pointerup',up);dom.addEventListener('pointercancel',function(e){delete ptrs[e.pointerId];mode=null;});
 dom.addEventListener('pointerleave',function(){EDGE.x=-1;});
 dom.addEventListener('wheel',function(e){e.preventDefault();camZoom(e.deltaY>0?1.12:.89,e.clientX,e.clientY);},{passive:false});
 dom.addEventListener('dblclick',function(e){var g=groundAt(e.clientX,e.clientY,CT.ty);if(g)camFly(g.x,g.z,Math.max(8,CT.rad*.6));});
}
document.addEventListener('keydown',function(e){var k=e.key.toLowerCase();if('wasdqerf'.indexOf(k)>=0&&k.length===1)KEYS[k]=1;});
document.addEventListener('keyup',function(e){KEYS[e.key.toLowerCase()]=0;});
window.addEventListener('blur',function(){KEYS={};});
