/* p_special：特殊客（v0.20）。
   - 會講嘢嘅毛孩自己行嚟，堅持要店長（你）親自接待。輪到佢嗰陣，畫面變成視覺小說：佢一路做美容一路問你人生、感情嘅問題（唔涉及政治）。
   - 你嘅答案（同埋美容做法啱唔啱）影響佢嘅「心情」；最後心情決定佢點樣行出門口（結局），同埋評價、小費、損失。
   - 角色用網上寵物梗圖（Cheems、Swole Doge、Doge、Pop Cat 等，圖由用戶提供，見 p_spimg.js）同佢哋嘅經典對白；遊戲非牟利。
   - 對話時左邊有 2D 立繪（`SPIMG`），結局會換結局圖；3D 枱上同行出去嘅係方塊造型。
   - 出現：開局第一個星期一定有一位；七位嘅次序每一輪打亂（跟遊戲種子）；之後每星期大約一半機會。冇店長親自接待（時間到咗都冇做），佢會黑面走，畀兩星。
   - 「成長 → 特殊客」有圖鑑（見過邊個、解鎖咗邊個結局），亦可以請下一位今日嚟（試玩）。
   - 小費、損失、口碑變化都係遊戲設定，唔係真實數字。 */
var SPC={
 chai:{n:'Cheems',breed:'柴犬',seg:'m',svc:'wash',price:600,c:'#e0a050',img:'cheems',bio:'圓碌碌嘅柴犬，講嘢會多咗個 m（Hemlo、Imposimble）。日日健身但都係咁圓，成日諗人生意義。',
  intro:[['','一隻圓碌碌嘅柴犬自己推門入嚟，一屁股坐低，望住你。'],['Cheems','Hemlo，店長。'],['Cheems','我要店長親自做。其他人，我唔信。'],['Cheems','今日洗澡。順便……諗吓人生。好 imposimble 嘅問題。']],
  g:[{q:'我啲毛好多，你諗住點？',anim:'brush',part:'back',o:[['先用排梳梳走底毛',12,'識貨。好多人一嚟就淋水，搞到我成身黐埋。'],['淋濕晒先再慢慢梳',-15,'Prombem。你想我變濕麵團？'],['剃短啲，夏天涼爽',-20,'剃？我係雙層毛。你知唔知你講緊乜。']]},
     {q:'吹乾要幾耐？我趕住去健身。',anim:'dry',part:'back',o:[['底毛吹乾先放你走',12,'……好。健身要耐性，吹毛都係。'],['面層乾咗就收工',-15,'入面仲濕濕哋，你當我唔知？'],['開最熱嗰檔快啲',-15,'熱到我想 bonk 人。']]}],
  q:[{q:'網上成日將我同 Swole Doge 比。以前嘅狗咁勁，而家嘅我係咪好廢？',o:[['比較圖影唔到你嘅全部',15,'……影唔到全部。Thamk you，店長。'],['係呀，你真係弱咗啲',-15,'……Imposimble 咁直接。'],['咁你去健身追返佢囉',-3,'追……佢係一張圖嚟，我點追？']]},
     {q:'如果我成世都係 Cheems，冇變過 Swole Doge，得唔得？',o:[['得，做返自己都好好',15,'……做 Cheems 都可以。Hemlo，新嘅我。'],['唔得，要變強先有價值',-15,'咁我而家冇價值？'],['你試吓食多啲蛋白質',-3,'……我試過。食咗三日。']]},
     {q:'一個 Cheemsburger 同人生意義，你揀邊樣？',o:[['肚餓先食，食完再諗',15,'……合理。好 reasomable。'],['當然揀人生意義',-3,'但係我好肚餓。'],['兩樣都冇咩意義',-15,'你令我連漢堡都唔想食。']]},
     {q:'點解我講嘢會多咗個 m？係咪我有問題？',o:[['咁先係你，唔使改',15,'唔使改……Thamk you。'],['係，你應該練吓發音',-15,'……Imposimble。'],['多個 m 好得意啫',3,'得意……但我係認真問。']]},
     {q:'如果勇氣係會用完嘅，我今日仲有幾多？',o:[['夠你行入嚟，已經唔少',15,'……係喎。我自己推門入嚟㗎。'],['你一睇就冇乜勇氣',-15,'……'],['勇氣唔係咁計嘅',-3,'咁係點計？']]}],
  end:{good:{t:'Swole Doge 覺醒',look:'buff',img:'swole',tip:300,stars:5,exit:'挺起胸膛、兩隻手臂脹卜卜咁行出門口',rv:'洗完澡，諗通咗，連肌肉都出埋嚟。',lines:[['','Cheems 望住鏡入面嘅自己，深呼吸一下。'],['','佢嘅胸口同兩隻手臂突然脹大——變咗做 Swole Doge。'],['Swole Doge','店長，今日洗走嘅唔止係死毛。']]},
   normal:{t:'乾淨嘅圓',look:'base',img:'cheems',stars:4,exit:'圓碌碌、乾乾淨淨咁行出門口',rv:'洗得幾乾淨，人生就未諗通。Thamk you。',lines:[['','Cheems 企起身，抖一抖身上嘅毛。'],['Cheems','唔錯。我仲係圓，但係乾淨嘅圓。Thamk you。']]},
   bad:{t:'*BONK*',look:'bat',img:'bonk',stars:1,cost:1800,costWhy:'Cheems 用棒球棍打爛咗鏡同半個貨架',exit:'孭住棒球棍、頭都唔回咁行出門口',rv:'店長完全唔明我。鏡，我已經幫你打爛咗。',lines:[['','Cheems 眼神一變，由背後抽出一支棒球棍。'],['Cheems','呢間店，唔夠用心。'],['Cheems','*BONK*'],['','一棍打落鏡度，再掃低半個貨架。']]}}},
 ronin:{n:'武士 Cheems',breed:'柴犬（戴竹笠）',seg:'m',svc:'nail',price:500,c:'#c9a45a',img:'samurai',bio:'戴住竹笠、腰間插住刀嘅柴犬。講嘢好少，最憎人嘈：Silence, wench.',
  intro:[['','門鈴一響，一隻戴竹笠嘅柴犬靜靜行入嚟，腰間插住一把刀。'],['武士 Cheems','剪甲。'],['武士 Cheems','店長親自來。旁人，退下。']],
  g:[{q:'你要點捉住我隻腳？',anim:'hold',part:'paw',o:[['輕輕扶穩，唔會拗你',12,'……手勢穩。好。'],['用力夾實，費事你郁',-15,'你當我係犯人？'],['你自己企定，我快手',-10,'刀未出鞘，已失分寸。']]},
     {q:'我啲甲，係黑色。',anim:'clip',part:'paw',o:[['每次剪少少，睇切面',12,'慢，即係快。'],['估吓位置，一刀過',-20,'……血。你見到未？'],['照白甲咁剪就得',-15,'眼睇唔到，就當冇？']]}],
  q:[{q:'一把刀未出鞘就贏咗，算唔算真正嘅贏？',o:[['唔使出鞘，先係最高境界',15,'……師父都係咁講。'],['唔算，要打過先知',-10,'打過……就有人受傷。'],['贏就係贏，唔使諗',-3,'淺。']]},
     {q:'人人都話我好兇，成日叫人收聲。其實我係咪好怕嘈？',o:[['可能你需要嘅係安靜',15,'……我需要安靜。原來係咁。'],['係，你脾氣真係差',-15,'Silence.'],['唔鍾意嘈就戴耳筒',-3,'刀同耳筒，唔襯。']]},
     {q:'如果沉默係金，咁講嘢係乜？',o:[['講啱嘅嘢，係另一種金',15,'……另一種金。好。'],['講嘢係垃圾',-10,'你講咗呢句，都係垃圾？'],['講嘢係銀囉',-3,'……公式化。']]},
     {q:'竹笠遮住我塊面，係保護我，定係收埋我？',o:[['兩樣都係，幾時除由你',15,'……我可以揀。'],['收埋，你唔敢見人',-15,'Silence, wench.'],['純粹遮太陽啫',-3,'……你唔明武士。']]},
     {q:'一個人行到最後，同一班人行到一半，邊樣好？',o:[['睇你想同邊個睇風景',15,'……風景。我未諗過要同人睇。'],['一個人行到最後',-3,'我一直係咁。好凍。'],['一班人，人多好玩',-3,'人多……好嘈。']]}],
  end:{good:{t:'除笠',look:'nohat',img:'samurai',tip:200,stars:5,exit:'拎住竹笠、抬起頭行出門口',rv:'無言。好。',lines:[['','武士 Cheems 除低竹笠，第一次露出成塊面，向你微微點頭。'],['武士 Cheems','多謝。今晚，我去見師父。']]},
   normal:{t:'過客',look:'base',img:'samurai',stars:4,exit:'壓低竹笠、靜靜咁行出門口',rv:'甲剪得好。話，多咗。',lines:[['','佢壓低竹笠，放低錢，一言不發咁行出門。']]},
   bad:{t:'Silence, wench.',look:'blade',img:'samurai',fx:'shake',stars:1,cost:400,costWhy:'武士 Cheems 劈爛咗收銀枱嘅價目表，要重新印',exit:'刀出鞘、頭都唔回咁行出門口',rv:'Silence, wench.',lines:[['','武士 Cheems 轉身，刀光一閃——'],['','收銀枱上嘅價目表跌咗落地，裂開兩邊。'],['武士 Cheems','Silence, wench.']]}}},
 orange:{n:'肥橙',breed:'橙色大肥貓',seg:'k',svc:'cat',price:550,c:'#e8963e',img:'orange0',bio:'橙色大肥貓，坐手推車出入。感情豐富，心情好就會仰天唱歌。',
  intro:[['','一隻橙色大肥貓被人用手推車推入嚟。佢自己落車，坐得好端正，仰起個頭。'],['肥橙','喵。我今日心情唔好。'],['肥橙','我需要被梳毛，同埋被理解。']],
  g:[{q:'我背脊舔唔到，打晒結。',anim:'brush',part:'back',o:[['分小撮梳，唔得用電剪',12,'……溫柔。我鍾意。'],['剪刀貼住皮剪走佢',-20,'喵！！你剪到我皮呀！'],['一次過大力梳開佢',-15,'痛到我唔想講心事。']]},
     {q:'唔好掂我個肚。',anim:'hold',part:'paw',o:[['明白，我側身扶住你',12,'你有聽我講嘢。好少人做到。'],['摸吓個肚放鬆吓',-20,'……我講咗唔好。'],['反轉你剪後腳先',-15,'你當我係烏龜？']]}],
  q:[{q:'如果一首歌冇人聽，佢仲算唔算一首歌？',o:[['你唱咗，佢就存在',15,'……存在。喵，我想唱。'],['冇人聽就唔算',-15,'……（佢合埋口）'],['錄低放上網囉',-3,'放上網……又會冇人聽。']]},
     {q:'我仰起個頭望天花板，係咪就望到天堂？',o:[['望到嘅係你想望嘅嘢',15,'……我想望嘅係罐罐。同佢。'],['只係望到天花板',-10,'你好冇浪漫。'],['你頸會攰㗎',-3,'……都係。']]},
     {q:'心痛嗰陣，我分唔到係心痛定係肚餓。',o:[['可以兩樣都係，慢慢分',15,'……咁我先食少少，再慢慢心痛。'],['你肯定係肚餓',-10,'你唔明我。'],['心痛係錯覺',-15,'喵！！']]},
     {q:'大叫一聲，係唔係最誠實嘅說話？',o:[['有時係，但細聲都得',15,'細聲都得……我試吓。喵。'],['係，所以要大聲叫',-10,'喵——！！（樓上拍地板）'],['大叫只係嘈',-3,'嘈……但係真。']]},
     {q:'鍾意一隻貓，係咪一定要講出口？',o:[['講咗未必有結果，唔後悔',15,'唔會後悔……我記住。'],['唔講出口就唔會受傷',-3,'但係都唔會開心。'],['等對方先開口講',-10,'我等咗三年。']]}],
  end:{good:{t:'仰天高歌',look:'sing',img:'orange1',fx:'hop',tip:150,stars:5,exit:'仰起個頭、一路唱歌一路行出門口',rv:'被梳得好舒服，仲有人聽我講心事。',lines:[['','肥橙閉埋眼，張大個口，好陶醉咁唱起歌嚟。成間店都靜咗。'],['肥橙','我諗通咗。我要先鍾意自己。']]},
   normal:{t:'下次再講',look:'base',img:'orange0',stars:4,exit:'坐返上手推車，被推出門口',rv:'梳毛幾舒服。',lines:[['','肥橙打咗個喊露，慢慢爬返上手推車。'],['肥橙','梳得幾好。心事，下次先講。']]},
   bad:{t:'走音失戀歌',look:'yowl',img:'orange1',fx:'shake',stars:1,complain:'樓上住戶投訴美容店傳出怪叫聲，管理處上嚟了解',exit:'張大個口、一路嗌一路行出門口',rv:'冇人明白我。我唱歌畀全條街聽。',lines:[['','肥橙張大個口，用盡全力唱咗一首好走音嘅失戀歌，唱足十分鐘。'],['','樓上鄰居拍門。']]}}},
 loaf:{n:'Doge',breed:'柴犬',seg:'m',svc:'wash',price:500,c:'#e2b06a',img:'doge',bio:'講嘢一嚿嚿彈出嚟：Such wow，much 毛。有時會縮成一條麵包，好多人以為佢係麵包。',
  intro:[['','一隻柴犬側住頭望住你，眼神好似好有深意。'],['Doge','Wow。'],['Doge','Such 美容店。Very 香。Much 想洗澡。'],['Doge','不過……有時我覺得自己似一條麵包。']],
  g:[{q:'我啲毛，much 多。',anim:'brush',part:'back',o:[['先梳走底毛同死毛',12,'Wow。Very 鬆。Such 出爐。'],['淋濕先，梳就遲啲',-15,'Much 發脹。Very 唔妥。'],['剃短佢，咪唔似包',-15,'Such 剃？Very no。']]},
     {q:'水唔好太熱。Much 驚發起。',anim:'shower',part:'back',o:[['手腕試吓，微暖就啱',12,'Wow。Such 啱溫。'],['熱啲先洗得乾淨',-15,'Very 膨脹。Much 驚。'],['凍水，咁就唔會發',-10,'Such 凍。Very 隔夜包。']]}],
  q:[{q:'Such 問題：「Wow」係一種感覺，定係一個答案？',o:[['兩樣都係，睇你點用',15,'Wow。Such 答案。'],['只係一個英文字',-15,'Much 冷淡。'],['係網上嘅口頭禪',-3,'Very 表面。']]},
     {q:'人人都話要帶我去月球。月球有冇罐罐？',o:[['唔知，但可以帶埋去',15,'Wow。Much 準備。'],['月球乜都冇',-10,'Very 失望。'],['你唔會去到月球',-15,'Such 現實。Much 傷心。']]},
     {q:'如果冇人望住我，我仲係唔係 Doge？',o:[['你一直都係，唔使人望',15,'Wow。Very 自己。'],['冇人望就冇人記得',-15,'……Much 消失。'],['你可以自己影相',-3,'Such 自拍。Very 孤獨。']]},
     {q:'我同麵包，究竟差幾遠？',o:[['識諗呢條問題，已經唔同',15,'Wow……Much 有道理。'],['差唔遠，形都一樣',-15,'Such 麵包。Very 傷。'],['麵包冇你咁多毛',-3,'Much 科學。Very 冷。']]},
     {q:'側住頭望世界，同正面望，邊個先係真？',o:[['兩個角度加埋先完整',15,'Wow。Such 立體。'],['正面先係真',-10,'Very 死板。'],['你頸梗咗啫',-3,'……Much 好笑。']]}],
  end:{good:{t:'Much dog. Very wow.',look:'waist',img:'doge',fx:'hop',tip:150,stars:5,exit:'有腰有腳、輕快咁跑出門口',rv:'Such 美容。Very 狗。Wow。',lines:[['','Doge 企起身，伸咗一個好長好長嘅懶腰——'],['','條腰出現咗，四隻腳都有返力。'],['Doge','Much dog. Very 有腰. Wow.']]},
   normal:{t:'Such 香',look:'base',img:'doge',stars:4,exit:'慢慢行出門口，回頭望咗你一眼',rv:'Such 乾淨。Very 香。',lines:[['','Doge 慢慢行出門口，回頭望咗你一眼。'],['Doge','Such 乾淨。Very 香。Wow。']]},
   bad:{t:'正式成為麵包',look:'bread',img:'dogebread',stars:2,exit:'縮成一條、被街坊當成麵包咁抬出門口',rv:'Such bread. Very 包. Wow……',lines:[['','Doge 縮埋一條，四隻腳都唔見咗，外皮仲變成金黃色。'],['Doge','Such bread. Very 包. Wow……']]}}},
 mimi:{n:'委屈貓',breed:'灰色虎斑細貓',seg:'k',svc:'cat',price:450,c:'#8e8e96',img:'sadcat',bio:'雙手抱頭、張大口喊嘅細貓。一啲小事就覺得好委屈，網上大家都用佢嚟講「我好冤枉」。',
  intro:[['','一隻灰色虎斑細貓雙手抱頭，張大口喊住入嚟。'],['委屈貓','嗚哇——我好委屈——'],['委屈貓','……我嚟剪甲。順便……想有人聽我講。']],
  g:[{q:'我好怕被人包住。',anim:'towel',part:'whole',o:[['毛巾輕輕包，動作慢',12,'……好似冇咁驚。'],['包得越實就越安全',-15,'嗚哇——我唞唔到氣！'],['捉住後頸提起你',-20,'嗚……我唔係 BB 貓啦！']]},
     {q:'爪要剪，但唔好剪到痛。',anim:'clip',part:'paw',o:[['按肉墊推出爪，剪尖端',12,'……唔痛。（佢唔喊喇）'],['剪到粉紅位先夠短',-20,'嗚哇——好痛呀！！'],['用狗甲剪快手剪晒',-10,'個甲剪好大把……嗚。']]}],
  q:[{q:'我又冇做錯嘢，點解個個都鬧我？',o:[['你覺得委屈，可以講出嚟',15,'……（佢放低隻手）我講。'],['你一定有做錯啲嘢',-15,'嗚——（抱頭喊得更大聲）'],['唔好理佢哋就得',-3,'但係我好在意……']]},
     {q:'喊係咪好冇用？',o:[['喊完舒服啲，唔係冇用',15,'……咁我喊多一陣就好。'],['係，喊解決唔到問題',-10,'嗚……'],['大個咗就唔好喊啦',-15,'嗚哇——！']]},
     {q:'如果全世界只有我覺得委屈，係咪我太敏感？',o:[['你嘅感受唔使人批准',15,'……唔使批准。（佢索一索鼻）'],['係，你太敏感',-15,'嗚——'],['可能啲人唔知你委屈',3,'……佢哋唔知？咁我講吓。']]},
     {q:'網上啲人用我張相嚟扮慘。我嘅委屈係咪變咗笑話？',o:[['大家用你，因為有共鳴',15,'共鳴……原來唔止我一個。'],['係，大家笑緊你',-15,'嗚……（佢縮埋一舊）'],['你應該收佢哋錢',-3,'收錢……我只係想被明白。']]},
     {q:'抱住個頭，會唔會安全啲？',o:[['想抱就抱，我陪住你',15,'……（佢慢慢放低隻手）其實冇咁驚喇。'],['唔會，咁樣好傻',-15,'嗚……'],['抱頭就睇唔到路喎',-3,'……都係。']]}],
  end:{good:{t:'喊完就好',look:'calm',img:'sadcat',fx:'hop',tip:100,stars:5,exit:'放低雙手、抹乾眼淚行出門口',rv:'有人聽我講，好舒服。',lines:[['','委屈貓喊咗一陣，慢慢放低抱住頭嘅雙手。'],['委屈貓','……其實講咗出嚟，就冇咁委屈喇。']]},
   normal:{t:'索索鼻',look:'base',img:'sadcat',stars:4,exit:'索住鼻、抱住頭行出門口',rv:'剪得幾好……嗚。',lines:[['','委屈貓索一索鼻，抱住頭慢慢行出門口。']]},
   bad:{t:'喊到成條街聽到',look:'cry',img:'sadcat',fx:'shake',stars:2,complain:'街坊投訴美容店有隻貓喊足半個鐘',exit:'抱住頭、喊住行出門口',rv:'嗚哇——冇人明白我——',lines:[['','委屈貓抱住頭，越喊越大聲。'],['委屈貓','嗚哇——冇人明白我——']]}}},
 happy:{n:'Happy 貓',breed:'灰白細貓',seg:'k',svc:'cat',price:450,c:'#bdb7b0',img:'happy_stand',spin:[],spinRe:'happy happy',spinLook:'jump',snd:'happy',
  bio:'一開心就原地跳，兩隻手亂揮：Happy happy happy～ 網上大家用佢嚟表達開心到停唔到。',
  intro:[['','一隻灰白色細貓一路跳一路入嚟，兩隻手揮過不停。'],['Happy 貓','Happy happy happy～'],['Happy 貓','店長！我好開心！雖然我都唔知點解！']],
  g:[{q:'我一開心就會跳，你點捉住我剪甲？',anim:'hold',part:'paw',o:[['等佢跳完，輕輕扶穩',12,'Happy……（佢乖乖坐低）'],['趁佢跳起捉住佢',-15,'（佢跳到天花板咁高）'],['按實佢唔准郁',-15,'……（佢唔再 happy）']]},
     {q:'吹風機嘅風，好似跳舞咁！',anim:'dry',part:'back',o:[['低風速遠啲吹，分段',12,'Happy happy happy～'],['大風量對住吹',-15,'（佢俾風吹到轉咗個圈）'],['開最熱嗰檔快啲',-15,'好熱……唔 happy 喇。']]}],
  q:[{q:'如果每日都 happy，happy 仲算唔算 happy？',o:[['有唔開心，開心先有味',15,'……咁我今日唔開心都 OK。'],['唔算，會好悶',-3,'悶……但係我鍾意。'],['你成日扮開心啫',-15,'……（佢停咗唔跳）']]},
     {q:'跳舞嗰陣，係我跳緊舞，定係舞跳緊我？',o:[['跳到忘我，就係一齊跳',15,'一齊跳……Happy happy happy～'],['當然係你跳緊舞',-3,'……好實際。'],['舞點會跳人？',-10,'你冇跳過舞。']]},
     {q:'開心可唔可以收埋，留返第日先用？',o:[['可以，但今日用都唔嘥',15,'今日用……Happy happy！'],['唔得，過咗期就冇',-10,'……開心會過期？'],['開心係用唔晒嘅',3,'用唔晒……咁我放心。']]},
     {q:'網上啲人一見我就跟住跳。我係咪要永遠開心畀人睇？',o:[['你唔開心都可以唔跳',15,'……可以唔跳。原來可以。'],['係，你要對得住觀眾',-15,'……好攰。'],['唔開心就扮開心',-10,'扮……我唔想扮。']]},
     {q:'我唔知點解開心，咁係咪唔算數？',o:[['開心唔使有原因',15,'唔使原因……Happy happy happy～'],['冇原因就係傻開心',-10,'傻……（佢停低咗）'],['搵個原因先開心',-3,'搵咗好耐都搵唔到。']]}],
  end:{good:{t:'Happy happy happy',look:'jump',img:'happy_stand',tip:100,stars:5,exit:'一路跳一路揮手行出門口',rv:'Happy happy happy～',lines:[['','Happy 貓跳到半天高，兩隻手揮過不停。'],['Happy 貓','Happy happy happy～！']]},
   normal:{t:'跳兩下',look:'base',img:'happy_stand',stars:4,exit:'輕輕跳兩下，揮揮手行出門口',rv:'整得好靚！',lines:[['','Happy 貓輕輕跳咗兩下，向你揮揮手先走。']]},
   bad:{t:'唔再跳',look:'slump',img:'happy_stand',fx:'sad',stars:2,exit:'垂低雙手、慢慢行出門口',rv:'唔開心了。',lines:[['','Happy 貓停咗唔跳，垂低雙手慢慢行出去。'],['Happy 貓','……唔開心了。']]}}},
 pop:{n:'Pop Cat',breed:'白啡貓',seg:'k',svc:'cat',price:450,c:'#efe6d6',img:'pop0',mouth:{open:'pop1',closed:'pop0',openMs:380,closedMs:520,snd:'pop',re:'POP|啵'},bio:'一開口就「啵」一聲。網上好多人鍾意佢張口嗰下，但佢成日覺得冇人真係聽佢講嘢。',
  intro:[['','一隻白啡色嘅貓坐低，靜靜望住你。'],['Pop Cat','……'],['Pop Cat','POP！'],['','佢張大個口「啵」咗一聲，又合返埋。']],
  g:[{q:'我唔鍾意被人捉住。',anim:'towel',part:'whole',o:[['毛巾輕輕包，動作慢',12,'……啵。（細細聲，放鬆咗）'],['捉住後頸提起你',-20,'POP！！（大聲抗議）'],['包得越實就越安全',-15,'啵……啵……（透唔到氣）']]},
     {q:'爪要剪，但我會縮。',anim:'clip',part:'paw',o:[['按肉墊推出爪，剪尖端',12,'啵。好似唔痛喎。'],['剪到粉紅位先夠短',-20,'POP！！好痛！'],['捉實隻腳快手剪晒',-12,'啵！（佢縮咗手）']]}],
  q:[{q:'網上有人撳咗我幾千億下。我係咪只係一個數字？',o:[['數字數唔到你諗乜',15,'……數唔到。啵。'],['係，你就係個數字',-15,'……（佢合埋口）'],['數字大，代表你紅',-3,'紅……但係好攰。']]},
     {q:'張開口同合埋口，邊個先係真正嘅我？',o:[['兩個都係，唔使揀',15,'POP！……唔使揀。'],['張開口嗰個，大家鍾意',-10,'大家鍾意……我唔一定鍾意。'],['合埋口嗰個，冇咁嘈',-10,'……啵。']]},
     {q:'重複做同一件事一千萬次，會唔會變成藝術？',o:[['用心做，就有可能',15,'用心……啵、啵、啵。'],['唔會，只係重複',-10,'……只係重複。'],['會，因為好多人睇',-3,'人睇先算藝術？']]},
     {q:'我成日開口，但好似冇人真係聽。點算？',o:[['我而家喺度聽緊你講',15,'……啵。多謝你。'],['講少啲就冇人嫌嘈',-15,'……（佢閉埋口）'],['講大聲啲咪得囉',-3,'POP！！……咁樣？好似更加冇人聽。']]},
     {q:'一個「啵」字，可唔可以講晒所有心事？',o:[['可以，聽嘅人用心就得',15,'……（佢輕輕啵咗一聲，好溫柔）'],['唔可以，要講清楚',-3,'講清楚……好難。'],['啵就係啵，冇意思',-15,'……']]}],
  end:{good:{t:'POP！',look:'pop',img:'pop1',fx:'hop',tip:120,stars:5,exit:'一路「啵、啵、啵」咁行出門口',rv:'POP！（翻譯：好開心，有人聽我講嘢）',lines:[['','Pop Cat 深呼吸，張大個口——'],['Pop Cat','POP！'],['','今次唔係因為驚，係因為開心。佢一路「啵、啵、啵」咁行出門口。']]},
   normal:{t:'啵',look:'base',img:'pop0',stars:4,exit:'輕輕「啵」咗一聲，行出門口',rv:'啵。',lines:[['','Pop Cat 輕輕「啵」咗一聲，向你點點頭。']]},
   bad:{t:'唔再啵',look:'slump',img:'pop0',fx:'sad',stars:2,exit:'合埋個口、低住頭行出門口',rv:'……',lines:[['','Pop Cat 合埋個口，一聲都冇出，低住頭行出去。']]}}},
 huh:{n:'Huh 貓',breed:'白貓（黑色瀏海）',seg:'k',svc:'cat',price:450,c:'#f2f2f2',img:'huh',bio:'表情永遠係「Huh？」嘅肥白貓，頭頂有撮黑毛。對人生有好多疑問。',
  intro:[['','一隻肥白貓坐喺你面前，頭頂有一撮黑毛，望住你，好似聽唔明。'],['Huh 貓','Huh？'],['Huh 貓','……我嚟剪甲同梳毛。不過我有好多嘢唔明。']],
  g:[{q:'我舔唔到背脊，打晒結。',anim:'brush',part:'back',o:[['小撮梳，唔得就電剪',12,'……Huh。原來可以咁梳。'],['剪刀貼住皮剪走佢',-20,'Huh？！（佢彈起）'],['一次過大力梳開佢',-15,'Huh？？好痛。']]},
     {q:'你點樣捉住我剪甲？',anim:'hold',part:'paw',o:[['唔掂肚，側身扶住你',12,'Huh……好舒服。'],['反轉你仰臥剪後腳',-15,'Huh？！？'],['攬住個肚抱實你',-15,'Huh。（佢咬咗你一啖）']]}],
  q:[{q:'如果魚識飛，佢係鳥定係魚？',o:[['係一條好特別嘅魚',15,'Huh……特別嘅魚。我鍾意。'],['唔會有魚識飛',-10,'Huh？有飛魚㗎。'],['係鳥，識飛就係鳥',-3,'Huh？咁蚊都係鳥？']]},
     {q:'點解人類要將時間分成星期一同星期日？',o:[['方便約定，大家對得上',15,'Huh。原來係為咗見面。'],['因為星期一要返工',-3,'Huh？貓冇星期一。'],['唔使問，跟住用就得',-10,'Huh？']]},
     {q:'「Huh」係一個問題，定係一個答案？',o:[['睇點講，可以兩樣都係',15,'……Huh。（佢諗咗好耐）好深。'],['係問題，冇答案',-3,'Huh？'],['只係一個聲',-15,'Huh？？']]},
     {q:'點解每日都要起身？',o:[['為咗一件細細嘅開心事',15,'Huh……例如罐罐？……好似都係。'],['因為要返工賺錢',-3,'Huh？我係貓，我唔使返工。'],['唔使問咁多，起身就係',-10,'Huh？']]},
     {q:'我成日唔明人哋講乜。我係咪好蠢？',o:[['唔明就問，唔係蠢',15,'Huh……咁我問多啲。'],['係有少少蠢',-15,'Huh？？？'],['扮明就得啦',-10,'Huh。扮……我扮唔到。']]}],
  end:{good:{t:'Huh。原來係咁。',look:'nod',img:'huh',fx:'hop',tip:100,stars:5,exit:'好滿足咁行出門口',rv:'Huh。（翻譯：我明白咗啲嘢）',lines:[['','Huh 貓諗咗好耐，眼神第一次清晰咗。'],['Huh 貓','……Huh。原來係咁。']]},
   normal:{t:'Huh？',look:'base',img:'huh',stars:4,exit:'望住你，慢慢行出門口',rv:'Huh？梳得幾好。',lines:[['Huh 貓','Huh？……算啦，梳得幾舒服。']]},
   bad:{t:'Huh？？？',look:'shake',img:'huh',fx:'shake',stars:2,exit:'一路搖頭一路行出門口',rv:'Huh？？？店長講嘢我完全唔明。',lines:[['','Huh 貓望住你，越聽越唔明。'],['Huh 貓','Huh？？？'],['','佢一路搖頭一路行出門口。']]}}},
 oiia:{n:'OIIA 貓',breed:'虎斑貓',seg:'k',svc:'cat',price:450,c:'#8a7f72',img:'oiia_stand',spin:['oiia_spin01','oiia_spin02','oiia_spin03','oiia_spin04','oiia_spin05','oiia_spin06','oiia_spin07','oiia_spin08','oiia_spin09','oiia_spin10','oiia_spin11','oiia_spin12','oiia_spin13','oiia_spin14','oiia_spin15','oiia_spin16','oiia_spin17','oiia_spin18'],snd:'oiia',
  bio:'平時定晒格望住你，一開心（或者一緊張）就原地狂轉，一路轉一路「OIIAOIIA」。全世界都拎佢把聲嚟改歌。',
  intro:[['','一隻虎斑貓企喺門口，定晒格望住你，一動唔動。'],['','……突然，佢開始原地狂轉。'],['OIIA 貓','OIIAOIIA——'],['','轉完，佢又定晒格望住你，好似咩都冇發生過。'],['OIIA 貓','……我嚟梳毛。']],
  g:[{q:'我一緊張就會轉。你點包住我？',anim:'towel',part:'whole',o:[['等佢停咗，毛巾輕輕包',12,'……（佢冇轉）好舒服。'],['趁佢轉嗰陣捉住佢',-15,'OIIA——！（佢轉得更快）'],['包得越實就越唔會轉',-15,'……（佢喺毛巾入面轉）']]},
     {q:'吹風機好嘈，我會轉。',anim:'dry',part:'back',o:[['低風速遠啲吹，分段',12,'……（佢只係耳仔郁咗一下）'],['大風量快手吹完佢',-15,'OIIAOIIA！！（成枱都係毛）'],['開熱風等佢轉乾',-15,'（佢轉到成隻貓都熱晒）']]}],
  q:[{q:'我成日原地轉圈，係咪即係冇進步？',o:[['轉圈都係一種前進',15,'OIIA……（佢諗咗一陣）係喎。'],['係，你喺度浪費時間',-15,'……（佢定格咗）'],['唔好轉，行直線啦',-3,'直線……好悶。']]},
     {q:'我一停低，大家就話我好呆。轉同唔轉，邊個先係我？',o:[['停定轉都係你',15,'OIIAOIIA！'],['轉嗰個，比較好笑',-10,'好笑……我唔係表演嚟。'],['停嗰個，安靜啲',-3,'……（佢定晒格望住你）']]},
     {q:'轉到頭暈嗰陣，世界係咪都喺度轉？',o:[['地球都轉，你唔孤單',15,'OIIA！咁我同地球一樣！'],['頭暈就唔好轉囉',-10,'但係轉好開心。'],['你暈咗啫，冇嘢轉',-3,'……（佢慢慢停低）']]},
     {q:'全世界都拎我把聲嚟改歌。我嘅聲，仲係唔係我嘅？',o:[['原版永遠係你嘅',15,'OIIA……（好細聲，好滿足）'],['紅咗就係大家嘅',-10,'……大家嘅。（佢停咗轉）'],['你可以收版權費',-3,'版權……貓可以收錢？']]},
     {q:'如果轉一圈可以忘記一件唔開心嘅事，我應該轉幾多圈？',o:[['唔使忘記，講出嚟先',15,'……（佢停低，望住你）我講。'],['轉到唔記得為止',-10,'OIIAOIIAOIIA……（佢轉到暈）'],['一圈就夠，唔好貪',-3,'一圈……唔夠喎。']]}],
  end:{good:{t:'OIIAOIIA',look:'spin',img:'oiia_stand',tip:120,stars:5,exit:'一路原地轉圈一路轉出門口，街上嘅人停低拍片',rv:'OIIAOIIA！（翻譯：好開心）',lines:[['','OIIA 貓望住鏡入面嘅自己，定格咗三秒。'],['OIIA 貓','OIIAOIIA——！'],['','佢一路原地轉圈，一路轉出門口，街上嘅人都停低拍片。']]},
   normal:{t:'定格',look:'base',img:'oiia_stand',stars:4,exit:'定晒格望住你三秒，慢慢行出門口',rv:'……（定格望住鏡頭）',lines:[['','OIIA 貓定晒格望住你三秒，之後慢慢行出門口。']]},
   bad:{t:'轉到失控',look:'spinfast',img:'oiia_stand',fx:'shake',stars:2,cost:600,costWhy:'OIIA 貓轉到失控，撞跌咗成排沐浴露',exit:'轉到失控、一路撞一路轉出門口',rv:'OIIA？OIIA！OIIA？？（翻譯：好亂）',lines:[['','OIIA 貓開始轉，越轉越快，停唔到。'],['OIIA 貓','OIIAOIIAOIIAOIIA——'],['','佢撞跌咗成排沐浴露，一路轉一路轉出門口。']]}}}};
var SP_ORDER=['chai','orange','ronin','loaf','mimi','happy','pop','huh','oiia'];
SPC.happy.spin=(function(){var L=[];for(var i=1;i<=24;i++)L.push('happy_jump'+(i<10?'0':'')+i);return L;})();
SPC.oiia.spinRe='OIIA';SPC.oiia.spinLook='spin';
var SP_SNUB={rv:'要求店長親自接待，店長都冇出現。',stars:2};
function spState(){if(!s.sp)s.sp={wk:{},n:0,seen:{}};return s.sp;}
HOOKS.init.push(function(){s.sp={wk:{},n:0,seen:{}};});
function spOK(){return !!s&&!s.bg&&!s.demo&&!s.visit&&typeof handsOwner==='function'&&!!handsOwner();}
/* 喺 day 之後揀一個店長有返工、有 60 分鐘空檔嘅時段（11:00–17:00 開始） */
function spSlot(dFrom,dTo,from0){var o=handsOwner();if(!o)return null;
 for(var d=dFrom;d<=dTo;d++){if(!staffWorks(o,d))continue;var from=d===s.day?Math.max(from0||OPEN_MIN,s.t+30):OPEN_MIN;from=Math.ceil(Math.max(from,660)/5)*5;
  var gs=freeGaps(d,o.id,from);for(var i=0;i<gs.length;i++){var st=Math.max(gs[i][0],from);if(st<=1020&&gs[i][1]-st>=60)return [d,st];}}
 return null;}
/* 嚟嘅次序：每一輪七位打亂（跟遊戲種子固定），唔會連續兩次同一位 */
function spRound(r){var L=SP_ORDER.length,o=spShuf(L,'ord'+(s.seed||0)+'#'+r).map(function(i){return SP_ORDER[i];});
 if(r>0){var prev=spRound(r-1);if(o[0]===prev[L-1]){var t0=o[0];o[0]=o[1];o[1]=t0;}}return o;}
function spNextId(){var S=spState(),L=SP_ORDER.length;return spRound(Math.floor(S.n/L))[S.n%L];}
function spSpawn(id,slot){var C=SPC[id],o=handsOwner();if(!C||!o||!slot||!s.wk)return null;
 var a={id:s.nextId++,day:slot[0],seg:C.seg,svc:C.svc,dur:60,price:C.price,out:'ok',pet:C.n,breed:C.breed,owner:'自己嚟',regular:false,pref:slot[1],st:'booked',g:null,tb:0,a:0,b:0,refill:false,inc:null,tag:'特殊客',special:id,hreq:''};
 s.wk.appts.push(a);setSlot(a,slot[0],o.id,slot[1]);a.manual=0;spState().n++;
 news('特殊客',(slot[0]===s.day?'今日 ':'星期'+WKD[slot[0]%7]+' ')+hm(slot[1])+' 有位特殊客人預約：'+C.n+'（'+C.breed+'），指明要店長親自接待');return a;}
/* 每星期決定一次：第一個星期一定有；之後大約一半機會（固定：同一個星期結果一樣） */
function spWeek(){if(!spOK()||!s.wk)return;var S=spState(),k=s.wk.start;if(S.wk[k]!=null)return;
 var first=!Object.keys(S.wk).length,go=first||hHash('sp'+k)%100<50;S.wk[k]=0;if(!go)return;
 var ds=[];for(var d=Math.max(s.day,k);d<k+7;d++)ds.push(d);if(!ds.length)return;
 var start=ds[Math.min(ds.length-1,first?1:hHash('spd'+k)%ds.length)];var slot=spSlot(start,k+6)||spSlot(ds[0],k+6);if(!slot)return;
 var a=spSpawn(spNextId(),slot);if(a)S.wk[k]=a.id;}
HOOKS.day.push(function(){if(s.day%7!==0)spWeek();});
HOOKS.plan=HOOKS.plan||[];HOOKS.plan.push(function(){if(s.day>0)spWeek();});
/* 試玩：請下一位今日（冇位就聽日之後）嚟 */
function spInvite(){if(!spOK())return null;var slot=spSlot(s.day,s.wk.start+6);if(!slot){news('特殊客','今個星期店長已經冇 60 分鐘空檔，請唔到特殊客');return null;}return spSpawn(spNextId(),slot);}
/* ---------- 對話流程（唔郁 DOM，測試都用得） ---------- */
/* 固定洗牌（同一張預約每次一樣） */
function spShuf(n,key){var o=[],h=hHash(key)+1,nx=function(){h=(h*1103515245+12345)%2147483648;return Math.floor(h/65536);};for(var i=0;i<n;i++)o.push(i);nx();nx();for(var j=n-1;j>0;j--){var k=nx()%(j+1),tmp=o[j];o[j]=o[k];o[k]=tmp;}return o;}
function spPicks(a){var C=SPC[a.special],idx=spShuf(5,'q#'+a.id).slice(0,3);return idx.map(function(i){return C.q[i];});}
function spNodes(a){var C=SPC[a.special],Q=spPicks(a);
 return [{t:'say',lines:C.intro},{t:'ask',g:1,x:C.g[0]},{t:'ask',x:Q[0]},{t:'ask',g:1,x:C.g[1]},{t:'ask',x:Q[1]},{t:'ask',x:Q[2]},{t:'end',lines:[]}];}
function spEnding(mood){return mood>=80?'good':mood>=45?'normal':'bad';}
function spMood0(){return 50;}
/* 答案：每一題揀 o 嘅索引（原始次序）；返回心情同結局 */
function spRun(a,ans){var N=spNodes(a),m=spMood0(),j=0;N.forEach(function(n){if(n.t!=='ask')return;var o=n.x.o[ans[j++]];if(o)m=Math.max(0,Math.min(100,m+o[1]));});return {mood:m,end:spEnding(m)};}
function spApply(a,end){var C=SPC[a.special],E=C.end[end],S=spState();a.handsDone=1;a.spEnd=end;a.spLook=E.look;a.inc=null;a.handsStars=E.stars;a.handsTxt=E.rv;a.handsQ=end==='good'?1:end==='normal'?.7:.2;
 if(E.tip){a.price+=E.tip;a.spTip=E.tip;}
 if(E.cost&&typeof oneOff==='function')oneOff(-E.cost,E.costWhy,'event');
 if(E.complain)news('管理處',E.complain);
 if(end==='good'&&typeof glAddXP==='function')glAddXP(1,'特殊客「'+C.n+'」滿意離開');
 var r=S.seen[a.special]=S.seen[a.special]||{n:0,ends:{}};r.n++;r.ends[end]=(r.ends[end]||0)+1;
 news('特殊客',C.n+'：「'+E.t+'」，'+E.exit+(E.tip?'（小費 '+hk(E.tip)+'）':'')+(E.cost?'（損失 '+hk(E.cost)+'）':''));}
function spSnub(a){var S=spState();a.spEnd='snub';a.spLook='base';a.inc=null;a.handsStars=SP_SNUB.stars;a.handsTxt=SP_SNUB.rv;a.handsQ=.3;
 var r=S.seen[a.special]=S.seen[a.special]||{n:0,ends:{}};r.n++;r.ends.snub=(r.ends.snub||0)+1;news('特殊客',SPC[a.special].n+'等唔到店長親自接待，黑面離開');}
var _spDone=onDone;onDone=function(a){if(a&&a.special&&!a.spEnd)spSnub(a);return _spDone.apply(this,arguments);};
/* ---------- 3D 角色（方塊造型；2D 立繪喺對話框旁邊） ---------- */
function spModel(id){var g=vgroup(),R=vgroup(g),P={},C=SPC[id],col=C.c,sc={m:.95,k:.8}[C.seg]||.9;
 var leg=function(x,z,c,h){var l=vb(R,.09,h||.14,.09,x,(h||.14)/2,z,c||col);return l;};
 if(id==='chai'){var cr='#f6e3c2';P.body=vb(R,.62,.46,.52,-.06,.34,0,col);vb(R,.06,.3,.36,.25,.32,0,cr);
  P.head=headMesh(.44,.38,.42,col,0,'pet');P.head.position.set(.34,.68,0);R.add(P.head);vb(R,.06,.12,.26,.57,.6,0,cr);
  vb(R,.08,.14,.08,.3,.94,-.13,col);vb(R,.08,.14,.08,.3,.94,.13,col);vb(R,.16,.16,.16,-.4,.58,0,col);
  P.chest=vb(R,.3,.4,.6,.16,.56,0,cr,{own:1});P.abs=vgroup(R,.32,.42,0);[-.12,0,.12].forEach(function(z){vb(P.abs,.02,.03,.08,0,0,z,'#d9b98a');vb(P.abs,.02,.03,.08,0,.1,z,'#d9b98a');});
  P.armL=vgroup(R,.16,.7,-.42);P.armR=vgroup(R,.16,.7,.42);[P.armL,P.armR].forEach(function(a){vb(a,.3,.3,.3,0,-.06,0,col);vb(a,.24,.3,.24,.04,-.32,0,col);vb(a,.2,.14,.2,.06,-.52,0,cr);});
  P.bat=vgroup(R,.34,.42,.34);vb(P.bat,.08,.22,.08,0,.06,0,'#6b4226');vb(P.bat,.11,.5,.11,0,.42,0,'#e3b26a');vb(P.bat,.13,.24,.13,0,.74,0,'#e9bd78');
  P.plegs=[leg(-.24,-.14),leg(-.24,.14),leg(.16,-.14),leg(.16,.14)];}
 else if(id==='ronin'){P.body=vb(R,.46,.32,.34,-.04,.3,0,col);P.head=headMesh(.42,.38,.4,col,0,'pet');P.head.position.set(.27,.52,0);R.add(P.head);
  vb(R,.08,.14,.08,.24,.76,-.13,col);vb(R,.08,.14,.08,.24,.76,.13,col);vb(R,.14,.14,.14,-.3,.48,0,col);vb(R,.04,.04,.36,-.04,.38,0,'#2b2b2b');
  P.hat=vgroup(R,.27,.76,0);vb(P.hat,.66,.05,.66,0,0,0,'#d9b56a');vb(P.hat,.46,.06,.46,0,.05,0,'#ccaa5e');vb(P.hat,.26,.06,.26,0,.1,0,'#c09e52');vb(P.hat,.08,.06,.08,0,.15,0,'#b08e46');
  P.sword=vgroup(R,-.04,.34,.2);vb(P.sword,.56,.04,.04,-.06,0,0,'#b9a46a');vb(P.sword,.14,.05,.05,.25,0,0,'#3a2a20');vb(P.sword,.03,.1,.1,.17,0,0,'#2b2b2b');
  P.plegs=[leg(-.15,-.1),leg(-.15,.1),leg(.12,-.1),leg(.12,.1)];}
 else if(id==='orange'){P.body=vb(R,.62,.5,.52,-.06,.32,0,col);vb(R,.08,.3,.38,.25,.3,0,'#f4d7a8');P.head=headMesh(.46,.42,.44,col,0,'pet');P.head.position.set(.3,.68,0);R.add(P.head);
  vb(P.head,.1,.12,.1,-.04,.25,-.14,col);vb(P.head,.1,.12,.1,-.04,.25,.14,col);vb(R,.06,.06,.4,-.4,.4,0,col).rotation.z=.8;
  P.mouth=vb(P.head,.02,.12,.14,.235,-.08,0,'#5a1f1f');P.halo=vb(R,.5,.03,.5,.3,1.08,0,'#fff3b0',{e:'#fff3b0',ei:.8});
  P.plegs=[leg(-.24,-.14),leg(-.24,.14),leg(.14,-.14),leg(.14,.14)];}
 else if(id==='loaf'){P.segs=[vb(R,.3,.36,.42,-.32,.24,0,col,{own:1}),vb(R,.34,.36,.42,0,.24,0,col,{own:1}),vb(R,.3,.36,.42,.3,.24,0,col,{own:1})];
  P.head=headMesh(.12,.3,.36,col,0,'pet');P.head.position.set(.5,.26,0);R.add(P.head);vb(R,.06,.08,.06,.4,.46,-.12,col);vb(R,.06,.08,.06,.4,.46,.12,col);
  P.plegs=[leg(-.3,-.14,null,.08),leg(-.3,.14,null,.08),leg(.3,-.14,null,.08),leg(.3,.14,null,.08)];P.segs.concat(P.plegs).forEach(function(m){m.userData.y0=m.position.y;});}
 else if(id==='oiia'){var sd='#4f473e';P.body=vb(R,.44,.34,.34,-.05,.3,0,col);[-.14,-.02,.1].forEach(function(x){vb(R,.04,.02,.35,x,.475,0,sd);vb(R,.04,.2,.02,x,.32,.175,sd);vb(R,.04,.2,.02,x,.32,-.175,sd);});
  P.head=headMesh(.4,.36,.38,col,0,'pet');P.head.position.set(.27,.56,0);R.add(P.head);vb(P.head,.09,.12,.09,-.04,.23,-.13,col);vb(P.head,.09,.12,.09,-.04,.23,.13,col);vb(P.head,.2,.03,.3,-.02,.185,0,sd);
  vb(R,.06,.06,.36,-.32,.42,0,col).rotation.z=.6;P.plegs=[leg(-.18,-.1),leg(-.18,.1),leg(.1,-.1),leg(.1,.1)];}
 else if(id==='pop'||id==='huh'){var pc=id==='pop'?'#b07a4a':'#2b2b2b';P.body=vb(R,id==='huh'?.5:.4,id==='huh'?.4:.32,id==='huh'?.44:.32,-.05,.3,0,col);
  P.head=headMesh(.42,.38,.4,col,0,'pet');P.head.position.set(.27,.6,0);R.add(P.head);vb(P.head,.09,.12,.09,-.04,.24,-.13,id==='pop'?pc:col);vb(P.head,.09,.12,.09,-.04,.24,.13,col);
  if(id==='pop'){vb(P.head,.3,.14,.2,-.05,.12,-.11,pc);vb(R,.2,.1,.2,-.15,.47,.08,pc);}else{vb(P.head,.36,.08,.18,-.02,.17,-.05,pc);vb(R,.1,.04,.45,-.18,.45,0,'#9a9a9a');vb(R,.1,.04,.45,.02,.45,0,'#9a9a9a');}
  P.mouth=vb(P.head,.02,.16,.18,.215,-.08,0,'#5a1f1f');vb(R,.05,.05,.34,-.32,.42,0,col).rotation.z=.7;
  P.plegs=[leg(-.18,-.1),leg(-.18,.1),leg(.1,-.1),leg(.1,.1)];}
 else{/* mimi／happy */var st=id==='happy'?'#7d7873':'#5f5f68';P.body=vb(R,.36,.28,.28,-.04,.28,0,col);[-.12,0,.12].forEach(function(x){vb(R,.04,.02,.29,x-.04,.43,0,st);});
  P.head=headMesh(.38,.34,.36,col,0,'pet');P.head.position.set(.22,.52,0);R.add(P.head);vb(P.head,.08,.1,.08,-.04,.21,-.12,col);vb(P.head,.08,.1,.08,-.04,.21,.12,col);vb(P.head,.02,.03,.2,-.04,.15,0,st);
  vb(R,.05,.32,.05,-.24,.5,0,col);P.armL=vgroup(R,.12,.38,-.16);P.armR=vgroup(R,.12,.38,.16);[P.armL,P.armR].forEach(function(a){vb(a,.09,.26,.09,0,-.13,0,col);vb(a,.1,.07,.1,0,-.28,0,'#efe8dc');});
  P.plegs=[leg(-.14,-.08,null,.16),leg(-.14,.08,null,.16)];}
 R.scale.set(sc,sc,sc);g.traverse(function(m){if(m.isMesh)m.castShadow=true;});
 g.userData={fluff:[],sc:sc,plegs:P.plegs,sp:id,P:P,R:R};spLook(g,'base',0);return g;}
function spLook(m,look,t){var P=m.userData.P,R=m.userData.R,id=m.userData.sp;if(!P)return;R.position.y=0;R.rotation.set(0,0,0);R.scale.setScalar(m.userData.sc);
 if(id==='chai'){var b=look==='buff';P.chest.visible=P.abs.visible=P.armL.visible=P.armR.visible=b;P.body.scale.set(b?.8:1,b?1.12:1,b?.86:1);P.head.scale.set(b?.78:1,b?.78:1,b?.78:1);P.head.position.y=b?.84:.68;R.scale.setScalar(m.userData.sc*(b?1.15:1));
  P.armL.rotation.set(b?Math.sin(t*3)*.2:0,0,0);P.armR.rotation.set(b?-Math.sin(t*3)*.2:0,0,0);P.bat.visible=look==='bat';if(look==='bat'){var sw=Math.max(0,Math.sin(t*4));P.bat.rotation.set(0,0,.5-sw*1.9);P.armR.visible=true;P.armR.rotation.set(0,0,.3-sw*1.2);}}
 else if(id==='ronin'){P.hat.visible=look!=='nohat';P.sword.rotation.set(0,0,look==='blade'?.9+Math.sin(t*5)*.25:0);P.sword.position.set(look==='blade'?.3:-.04,look==='blade'?.5:.34,.2);}
 else if(id==='orange'){var up=look==='sing'||look==='yowl';P.head.rotation.z=up?.55:0;P.mouth.visible=look==='yowl'||(look==='sing'&&Math.sin(t*4)>0);P.halo.visible=look==='sing';if(look==='sing')P.halo.position.y=1.08+Math.sin(t*2)*.04;if(look==='yowl')R.rotation.x=Math.sin(t*20)*.03;}
 else if(id==='loaf'){var w=look==='waist',br=look==='bread';P.segs[1].scale.set(1,w?.7:1,w?.72:1);P.segs.forEach(function(s0,i){s0.scale.y=i===1&&w?.7:1;s0.position.y=s0.userData.y0+(w?.12:0);if(s0.material&&s0.material.color)s0.material.color.set(br?'#c98a3a':m.userData.colBase||SPC.loaf.c);});
  P.head.position.y=.26+(w?.12:0);P.plegs.forEach(function(l){l.visible=!br;l.scale.y=w?2.4:1;l.position.y=w?.1:l.userData.y0;});}
 else if(id==='oiia'){if(look==='spin')R.rotation.y=t*18;else if(look==='spinfast'){R.rotation.y=t*34;R.rotation.z=Math.sin(t*9)*.15;R.position.y=Math.abs(Math.sin(t*12))*.05;}}
 else if(id==='pop'||id==='huh'){P.mouth.visible=look==='pop'&&Math.sin(t*6)>0;R.position.y=look==='pop'?Math.abs(Math.sin(t*6))*.05:0;
  P.head.rotation.set(look==='shake'?0:0,look==='shake'?Math.sin(t*9)*.4:0,look==='nod'?Math.sin(t*4)*.18:look==='slump'?-.35:0);P.head.position.y=look==='slump'?.52:.6;}
 else if(id==='mimi'){var calm=look==='calm';P.armL.rotation.set(0,0,calm?0:2.9);P.armR.rotation.set(0,0,calm?0:2.9);P.head.rotation.z=calm?.15:-.1;P.head.position.y=.52;if(look==='cry')R.rotation.x=Math.sin(t*30)*.05;if(calm)R.position.y=Math.abs(Math.sin(t*3))*.03;}
 else{var jp=look==='jump',sl=look==='slump';P.armL.rotation.set(0,0,jp?2.1+Math.sin(t*14)*.7:sl?0:.4);P.armR.rotation.set(0,0,jp?2.1-Math.sin(t*14)*.7:sl?0:.4);R.position.y=jp?Math.abs(Math.sin(t*7))*.3:0;P.head.rotation.z=sl?-.35:0;P.head.position.y=sl?.46:.52;}}
/* makePet：特殊客用自己嘅方塊造型 */
if(typeof makePet==='function'){var _spMakePet=makePet;makePet=function(seg,i){var a=s&&s.wk&&s.wk.appts.filter(function(x){return x.id===i&&x.special;})[0];return a?spModel(a.special):_spMakePet.apply(this,arguments);};}
if(typeof syncShop==='function'){var _spSS=syncShop;syncShop=function(dt){_spSS.apply(this,arguments);if(!s||!s.wk||s.bg)return;var t=W3.t||0;
 todayAppts().forEach(function(a){if(!a.special)return;var look=a.spLook||'base';
  ['p','q'].forEach(function(k){var m=W3.actors[k+a.id];if(m&&m.userData.P)spLook(m,look,t);});
  /* 特殊客自己行嚟：唔顯示人，毛孩自己行 */
  var o=W3.actors['w'+a.id],q=W3.actors['q'+a.id];if(o&&o.visible){o.visible=false;if(q&&q.visible){q.position.copy(o.position);q.rotation.y=o.rotation.y-Math.PI/2;}}});
 if(HANDS.a&&HANDS.a.special&&HANDS.vn){var pet=W3.actors['p'+HANDS.a.id],V=HANDS.vn;if(pet&&V.spinning&&pet.userData.P&&!(V.phase==='end'||V.phase==='card'))spLook(pet,V.spinning,t);if(pet){var dtv=t-(V.fx||-9);if(V.fxk==='good'&&dtv<.6)pet.position.y+=Math.sin(dtv/.6*Math.PI)*.18;if(V.fxk==='bad'&&dtv<.8)pet.rotation.z=Math.sin(dtv*40)*.12;}}};}
/* ---------- 視覺小說介面（用落手做嘅框架：時間鎖、鏡頭、收埋其他介面） ---------- */
var SPT={raf:0,cps:40};
function spLine(V){var n=V.nodes[V.i];if(!n)return null;if(n.t==='say'||n.t==='end')return n.lines[V.li]||null;if(V.phase==='q')return [SPC[V.id].n,n.x.q];return V.rl[V.li];}
function spEnter(a,V){var n=V.nodes[V.i];if(typeof handsAnimClear==='function'&&typeof W3!=='undefined'&&W3.sc&&HANDS.anim)handsAnimClear();V.li=0;V.done=false;V.t0=typeof performance!=='undefined'?performance.now():0;
 if(n.t==='ask')V.phase='q';else if(n.t==='end'){V.end=spEnding(V.mood);var E=SPC[V.id].end[V.end];n.lines=E.lines;a.spLook=E.look;V.phase='end';}else V.phase='say';}
function spStart(a){var V={id:a.special,nodes:spNodes(a),i:0,li:0,mood:spMood0(),picks:[],phase:'say',done:false,t0:0};spEnter(a,V);return V;}
function spNext(a,V){if(!V.done){V.done=true;return;}var n=V.nodes[V.i];
 if(V.phase==='card')return;
 if(V.phase==='q')return;
 var L=n.t==='ask'?V.rl:n.lines;if(V.li<L.length-1){V.li++;V.done=false;V.t0=performance.now();return;}
 if(n.t==='end'){V.phase='card';return;}
 V.i++;spEnter(a,V);}
function spPick(a,V,oi){var n=V.nodes[V.i];if(V.phase!=='q'||!V.done)return;var o=n.x.o[oi];if(!o)return;V.mood=Math.max(0,Math.min(100,V.mood+o[1]));V.picks.push(oi);
 V.phase='reply';V.rl=[['你',o[0]],[SPC[V.id].n,o[2]]];V.li=0;V.done=false;V.t0=performance.now();V.fx=(typeof W3!=='undefined'&&W3.t)||0;V.fxk=o[1]>0?'good':o[1]<=-10?'bad':'';
 if(n.g&&typeof handsAnim==='function'&&typeof W3!=='undefined'&&W3.sc)handsAnim(n.x.anim,n.x.part,o[1]>0);}
function spMoodLbl(m){return m>=80?'好開心':m>=60?'幾好':m>=45?'一般':m>=25?'唔多高興':'好嬲';}
function renderSpecial(){var el=document.getElementById('hands');if(!el)return;var a=HANDS.a,V=HANDS.vn;if(!a||!V){el.classList.remove('vn');return;}
 el.classList.add('vn');var C=SPC[V.id],n=V.nodes[V.i],L=spLine(V),h='';
 h+='<div class="vn-top"><span class="lbl">特殊客 · 店長親自接待 · '+esc(C.breed)+'</span><span class="vn-mood">心情：'+spMoodLbl(V.mood)+'<span class="bar"><i style="width:'+V.mood+'%"></i></span></span><button class="x" data-act="handsx" aria-label="唔做住">×</button></div>';
 if(V.phase==='card'){var E=C.end[V.end];
  h+='<div class="vn-card '+V.end+'">'+(typeof SPIMG!=='undefined'&&SPIMG[E.img]?'<img class="vn-cimg'+(E.fx==='sad'?' sad':'')+'" src="'+SPIMG[E.img]+'" alt="">':'')+'<span class="lbl">結局</span><b>'+esc(E.t)+'</b><p>'+esc(C.n)+esc(E.exit)+'。</p><ul><li>評價 '+E.stars+' 星：「'+esc(E.rv)+'」</li>'+(E.tip?'<li>小費 +'+hk(E.tip)+'</li>':'')+(E.cost?'<li>損失 −'+hk(E.cost)+'：'+esc(E.costWhy)+'</li>':'')+(E.complain?'<li>'+esc(E.complain)+'</li>':'')+'</ul></div><button class="btn pri" data-act="handsdone">送佢出門</button>';}
 else if(L){var who=L[0],cls=who===''?'nar':who==='你'?'me':'ch';
  h+='<div class="vn-box '+cls+'" data-act="vnnext">'+(who?'<span class="vn-name"'+(cls==='ch'?' style="background:'+C.c+'"':'')+'>'+esc(who)+'</span>':'')+'<p class="vn-t" data-full="'+esc(L[1])+'">'+(V.done?esc(L[1]):'')+'</p>'+(V.done&&V.phase!=='q'?'<span class="vn-go">▼</span>':'')+'</div>';
  if(V.phase==='q'&&V.done){var ord=spShuf(3,'o#'+a.id+'#'+V.i);
   h+='<div class="vn-o">'+(n.g?'<span class="vn-k">美容做法</span>':'<span class="vn-k">佢問你</span>')+ord.map(function(oi){return '<button class="btn" data-act="vnpick" data-o="'+oi+'">'+esc(n.x.o[oi][0])+'</button>';}).join('')+'</div>';}}
 el.innerHTML=h;el.hidden=false;spPortrait(a,V);
 if(!V.done)spType();}
/* 2D 立繪：對話時喺對話框左上；結局換結局圖；Pop Cat 講嘢時口一開一合 */
function spImgKey(V,talk){var C=SPC[V.id];if(V.phase==='end'||V.phase==='card')return C.end[V.end].img||C.img;return talk&&C.talk?C.talk:C.img;}
/* 動畫立繪：OIIA 貓講「OIIA」轉圈（有聲）、Happy 貓講「happy happy」跳；結局係轉圈／跳就一直播 */
/* v0.21.3：動圖播幾耐，聲就播幾耐（循環），動圖一停聲就停 */
function spSound(k){if(typeof SPSND==='undefined'||!SPSND[k]||typeof SND==='undefined'||!SND.on)return null;try{var au=new Audio(SPSND[k]);au.volume=SND.vol;au.loop=true;var pr=au.play();if(pr&&pr.catch)pr.catch(function(){});return au;}catch(e){return null;}}
function spSoundStop(){if(SPT.au){try{SPT.au.pause();}catch(e){}SPT.au=null;}}
function spSpinning(V){var C=SPC[V.id];if(!C.spin||!C.spin.length)return false;var E=(V.phase==='end'||V.phase==='card')?C.end[V.end]:null;if(E)return E.look==='spin'||E.look==='spinfast'||E.look==='jump'?E.look:false;var L=spLine(V);return L&&new RegExp(C.spinRe,'i').test(L[1])?C.spinLook:false;}
/* v0.22.1 Pop Cat：講「POP／啵」嗰陣口慢慢一開一合（開 0.38 秒、合 0.52 秒），每次張口「啵」一聲 */
function spMouthOn(V){var C=SPC[V.id],M=C.mouth;if(!M)return false;var E=(V.phase==='end'||V.phase==='card')?C.end[V.end]:null;if(E)return E.look==='pop';var L=spLine(V);return !!(L&&L[0]===C.n&&new RegExp(M.re).test(L[1]));}
function spMouthStop(){if(SPT.mt){clearTimeout(SPT.mt);SPT.mt=0;}SPT.mOn=0;}
function spMouth(V){var M=SPC[V.id].mouth;if(!M||!spMouthOn(V)){if(SPT.mOn){spMouthStop();var im=document.querySelector('#spPortrait img');if(im&&M)im.setAttribute('src',SPIMG[M.closed]);}return;}
 if(SPT.mOn)return;SPT.mOn=1;var open=false;(function tick(){var VV=HANDS.vn,im=document.querySelector('#spPortrait img');if(!VV||!im||!SPT.mOn||!spMouthOn(VV)){spMouthStop();if(im&&M)im.setAttribute('src',SPIMG[M.closed]);return;}
  open=!open;im.setAttribute('src',SPIMG[open?M.open:M.closed]);if(open&&M.snd&&typeof SPSND!=='undefined'&&SPSND[M.snd]&&typeof SND!=='undefined'&&SND.on){try{var au=new Audio(SPSND[M.snd]);au.volume=SND.vol;var pr=au.play();if(pr&&pr.catch)pr.catch(function(){});}catch(e){}SPT.pops=(SPT.pops||0)+1;}
  SPT.mt=setTimeout(tick,open?M.openMs:M.closedMs);})();}
function spSpinStop(){if(SPT.spin){clearInterval(SPT.spin);SPT.spin=0;}spSoundStop();}
function spPortrait(a,V){var g=document.getElementById('game'),el=document.getElementById('hands');if(!g)return;var pf=document.getElementById('spPortrait');
 if(!a||!V){spSpinStop();spMouthStop();if(pf)pf.hidden=true;return;}
 if(!pf){pf=document.createElement('div');pf.id='spPortrait';pf.className='spp';pf.innerHTML='<img alt="">';g.appendChild(pf);}
 var E=(V.phase==='end'||V.phase==='card')?SPC[V.id].end[V.end]:null,fx=E?(E.fx||''):V.phase==='reply'&&V.li===1?(V.fxk==='good'?'nod':V.fxk==='bad'?'shake':''):'';
 var img=pf.firstChild,src=typeof SPIMG!=='undefined'?SPIMG[spImgKey(V)]:'';if(!src){pf.hidden=true;return;}
 var sp=spSpinning(V);V.spinning=sp;if(sp){var C=SPC[V.id],key=V.i+'|'+V.li+'|'+(V.phase==='card'?'end':V.phase);
  if(!SPT.spin||SPT.spinFast!==(sp==='spinfast')){spSpinStop();SPT.spinFast=sp==='spinfast';SPT.spinI=0;SPT.spin=setInterval(function(){var im=document.querySelector('#spPortrait img'),VV=HANDS.vn;if(!im||!VV){spSpinStop();return;}var L2=SPC[VV.id].spin;SPT.spinI=(SPT.spinI+1)%L2.length;im.setAttribute('src',SPIMG[L2[SPT.spinI]]);},SPT.spinFast?45:80);}
  if(V.sndKey!==key||(!SPT.au&&V.phase!=='card')){V.sndKey=key;if(C.snd&&!(V.phase==='card'&&SPT.au)){spSoundStop();SPT.au=spSound(C.snd);}}}
 else{spSpinStop();if(!spMouthOn(V)&&img.getAttribute('src')!==src)img.setAttribute('src',src);}img.alt=SPC[V.id].n;spMouth(V);
 var cls='spp '+fx+(V.id==='chai'&&E&&V.end==='bad'?' wide':'');if(pf.className!==cls)pf.className=cls;pf.hidden=false;
 if(el){var gr=g.getBoundingClientRect(),r=el.getBoundingClientRect();pf.style.left=Math.max(8,r.left-gr.left+6)+'px';pf.style.bottom=Math.max(8,gr.bottom-r.top+4)+'px';}}
function spType(){if(SPT.raf)cancelAnimationFrame(SPT.raf);(function f(){var V=HANDS.vn,p=document.querySelector('#hands .vn-t');if(!V||!p||V.done)return;var full=p.getAttribute('data-full'),k=Math.floor((performance.now()-V.t0)/1000*SPT.cps);
  if(k>=full.length){V.done=true;renderSpecial();return;}p.textContent=full.slice(0,k);
  SPT.raf=requestAnimationFrame(f);})();}
if(typeof document!=='undefined'){
 var _spRH=renderHands;renderHands=function(){if(HANDS.a&&HANDS.a.special){if(!HANDS.vn)HANDS.vn=spStart(HANDS.a);HANDS.stress=0;return renderSpecial();}var el=document.getElementById('hands');if(el)el.classList.remove('vn');spPortrait(null,null);return _spRH.apply(this,arguments);};
 var _spHC=handsClose;handsClose=function(apply){var a=HANDS.a,V=HANDS.vn;spPortrait(null,null);if(a&&a.special){if(apply&&V&&V.end)spApply(a,V.end);else a.spLook=a.spEnd?a.spLook:'base';HANDS.vn=null;if(SPT.raf)cancelAnimationFrame(SPT.raf);return _spHC.call(this,false);}return _spHC.apply(this,arguments);};
 var _spHO=handsOpen;handsOpen=function(id){HANDS.vn=null;return _spHO.apply(this,arguments);};
 document.addEventListener('keydown',function(e){if(!HANDS.a||!HANDS.vn||/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))return;var V=HANDS.vn;
  if(e.key===' '||e.key==='Enter'){e.preventDefault();e.stopImmediatePropagation();if(V.phase!=='q'||!V.done){spNext(HANDS.a,V);renderSpecial();}return;}
  if(/^[1-3]$/.test(e.key)&&V.phase==='q'&&V.done){e.preventDefault();e.stopImmediatePropagation();var b=document.querySelectorAll('#hands [data-act=vnpick]')[+e.key-1];if(b)b.click();return;}
  if(/^[0-9]$/.test(e.key)){e.preventDefault();e.stopImmediatePropagation();if(typeof handsFlash==='function')handsFlash();}},true);
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!HANDS.a||!HANDS.vn)return;var act=el.getAttribute('data-act');
  if(act==='vnnext'){spNext(HANDS.a,HANDS.vn);renderSpecial();}
  if(act==='vnpick'){spPick(HANDS.a,HANDS.vn,+el.getAttribute('data-o'));renderSpecial();}});
 /* 提示：特殊客到咗就自動暫停，提示掣變「特殊客到」 */
 var _spHUD=renderHUD;renderHUD=function(){_spHUD.apply(this,arguments);if(!s||s.bg||!s.wk)return;var cue=document.getElementById('handsCue');
  var a=!HANDS.a&&todayAppts().filter(function(x){return x.special&&handsCan(x)&&x.st==='doing';})[0];
  if(a&&!a.spAlert){a.spAlert=1;s.paused=true;news('特殊客',SPC[a.special].n+'到咗，指明要店長親自接待。撳「特殊客到」開始。');}
  if(cue){if(a){var t='特殊客到：'+SPC[a.special].n+'（店長親自接待）';if(cue.textContent!==t)cue.textContent=t;cue.setAttribute('data-id',a.id);cue.hidden=false;cue.classList.add('sp');}else cue.classList.remove('sp');}};
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act=spinvite]');if(!el||!s)return;var a=spInvite();if(a)news('特殊客','你請咗 '+SPC[a.special].n+' 嚟（試玩）');renderPanel();},false);}
/* 成長 → 特殊客圖鑑 */
if(typeof SUBS!=='undefined'&&SUBS.grow)SUBS.grow.push(['sp','特殊客']);
if(typeof pGrow==='function'){var _spGrow=pGrow;pGrow=function(sub){if(sub!=='sp')return _spGrow.apply(this,arguments);var S=spState();
 var up=s.wk&&s.wk.appts.filter(function(x){return x.special&&(x.st==='booked'||x.st==='arrived'||x.st==='doing');})[0];
 return '<p class="note">會講嘢嘅毛孩，指明要店長親自接待。輪到佢時會變成對話：你嘅答案同美容做法決定佢點樣行出門口。</p>'+
  (up?'<p class="note">已預約：'+esc(SPC[up.special].n)+' · '+(up.day===s.day?'今日':'星期'+WKD[up.day%7])+' '+hm(up.a)+'</p>':'<button class="btn" data-act="spinvite">請下一位特殊客嚟（試玩）</button>')+
  '<div class="insg">'+SP_ORDER.map(function(id){var C=SPC[id],r=S.seen[id];return '<div class="insc spc'+(r?'':' lock')+'">'+(r&&typeof SPIMG!=='undefined'?'<img class="spc-img" src="'+SPIMG[C.img]+'" alt="">':'')+'<div class="insh"><b>'+(r?esc(C.n):'？？？')+'</b><span class="pill'+(r?' ok':'')+'">'+(r?'見過 '+r.n+' 次':'未見過')+'</span></div><p>'+(r?esc(C.bio):'未見過嘅特殊客。')+'</p>'+
   (r?'<p class="note">結局：'+['good','normal','bad'].map(function(k){return r.ends[k]?esc(C.end[k].t):'？？？';}).join(' · ')+'</p>':'')+'</div>';}).join('')+'</div>';};}
