/* p_consts：常數、寵物分群、AI 崗位、預設參數。全部係「可調整假設」。 */
var VERSION='v0.22.1';
var WPM=52/12; /* 每月週數 */

/* 寵物分群：share 佔比、cyc 回訪週期(週)、price 平均價(洗澡同全剪混合，HK$)、g 美容師分鐘、a 助理分鐘、mat 打結機率、beh 行為風險、sens 價錢敏感 */
var SEGS=[
 {id:'s',name:'細狗短毛',eg:'芝娃娃、八哥',share:.15,cyc:8,price:280,g:35,a:35,mat:.05,beh:.05,sens:.5},
 {id:'c',name:'細狗長毛／捲毛',eg:'貴婦、比熊、西施',share:.35,cyc:5,price:440,g:85,a:40,mat:.25,beh:.08,sens:.5},
 {id:'m',name:'中狗雙層毛',eg:'柴犬、柯基',share:.15,cyc:7,price:460,g:65,a:50,mat:.12,beh:.08,sens:.5},
 {id:'l',name:'大狗',eg:'金毛、哈士奇',share:.10,cyc:8,price:700,g:90,a:60,mat:.12,beh:.08,sens:.3},
 {id:'k',name:'貓',eg:'唐貓、波斯',share:.15,cyc:10,price:520,g:70,a:30,mat:.15,beh:.25,sens:.3},
 {id:'o',name:'老年／皮膚敏感',eg:'任何品種',share:.10,cyc:6,price:420,g:75,a:40,mat:.10,beh:.15,sens:.3}
];

/* 沉睡原因：AI 提醒只救到部分 */
var DORM=[
 {id:'forget',name:'忘記',share:.30,ai:1},
 {id:'price',name:'價錢',share:.20,ai:.35},
 {id:'move',name:'搬咗／地點',share:.15,ai:0},
 {id:'exp',name:'體驗唔好',share:.15,ai:0},
 {id:'health',name:'寵物健康',share:.10,ai:0},
 {id:'switch',name:'轉咗第二間',share:.10,ai:.1}
];

/* AI 崗位：每級 setup 建置費、fee 月費、wk 部署週、keep 行政時間剩低(有審核/冇審核)、err 冇審核錯誤率 */
var ROLES=[
 {id:'reply',seal:'覆',name:'預約客服',who:'老闆／前台',
  desc:'WhatsApp／IG 查詢、報價、提醒',
  L:[{t:'快速回覆',tools:'WhatsApp Business App（快速回覆、目錄、離線訊息）',guard:'全部人手覆',setup:0,fee:0,wk:1,keep:[.85,.80],err:0,loss:[.20,.08],ns:.85},
     {t:'AI 報價助手',tools:'WhatsApp Business Platform（經 SleekFlow／respond.io）＋ Claude／GPT API',guard:'報價超出範圍、相片見到皮膚問題、投訴 → 轉人',setup:3000,fee:600,wk:2,keep:[.50,.35],err:.06,loss:[.08,.04],ns:.55},
     {t:'AI 接單',tools:'L2 ＋ 預約系統（例如 MoeGo）＋ FPS／PayMe for Business 訂金連結',guard:'新客大狗、行為問題、健康問題、投訴一律轉人',setup:8000,fee:1200,wk:4,keep:[.25,.10],err:.08,loss:[.03,.02],ns:.45}]},
 {id:'sched',seal:'排',name:'排程',who:'老闆',
  desc:'按美容師專長同寵物大細排時段、候補',
  L:[{t:'共用日曆',tools:'Google Calendar',guard:'老闆自己排',setup:0,fee:0,wk:1,keep:[.85,.85],err:0,refill:.10,guard2:0},
     {t:'預約系統',tools:'MoeGo Salon Basic（約 US$79／月）或本地系統',guard:'每日開工前睇一次',setup:1500,fee:650,wk:2,keep:[.5,.45],err:.01,refill:.22,guard2:0},
     {t:'AI 動態排程',tools:'預約系統 ＋ AI 候補補位 ＋ 超載拒單',guard:'每日開工前老闆確認',setup:4000,fee:900,wk:3,keep:[.3,.2],err:.02,refill:.45,guard2:1}]},
 {id:'file',seal:'檔',name:'毛孩檔案',who:'美容師',
  desc:'過敏、皮膚、咬人、怕吹風紀錄',
  L:[{t:'入店問卷',tools:'Google Form ＋ 相片',guard:'美容師打字',setup:0,fee:0,wk:1,keep:[1,1],err:0,sec:90,comp:.40},
     {t:'語音備註',tools:'語音轉文字（Whisper／Gemini）＋ AI 整理標籤',guard:'美容師確認標籤',setup:2000,fee:300,wk:2,keep:[1,1],err:.01,sec:20,comp:.80},
     {t:'到店前提示',tools:'L2 ＋ 自動提示上次問題、皮膚變化提示睇獸醫',guard:'AI 只記錄，唔診斷',setup:3000,fee:500,wk:3,keep:[1,1],err:.02,sec:10,comp:.90}]},
 {id:'media',seal:'影',name:'美容報告同社媒',who:'助理',
  desc:'前後相、報告卡、IG、Google 評價',
  L:[{t:'Canva 模板',tools:'Canva',guard:'人手做',setup:0,fee:0,wk:1,keep:[.8,.8],err:0,wom:.03},
     {t:'AI 報告卡',tools:'AI 生成前後相報告，WhatsApp 發畀主人',guard:'有負面觀察唔公開',setup:1500,fee:300,wk:2,keep:[.4,.3],err:.02,wom:.08},
     {t:'自動社媒草稿',tools:'L2 ＋ IG 草稿、Google 評價邀請',guard:'用寵物相要主人同意',setup:2500,fee:500,wk:3,keep:[.25,.15],err:.03,wom:.12}]},
 {id:'recall',seal:'回',name:'回訪提醒',who:'老闆',
  desc:'到期提醒、沉睡客喚回',
  L:[{t:'人手名單',tools:'Excel 名單，每週人手發',guard:'全部人手',setup:0,fee:0,wk:1,keep:[1,1],err:0,rec:.30,react:.015},
     {t:'自動提醒',tools:'按分群週期自動發 utility 訊息（HK$0.23／條）',guard:'每人每月營銷訊息上限',setup:1500,fee:300,wk:2,keep:[.3,.25],err:.01,rec:.60,react:.035},
     {t:'沉睡客分類',tools:'AI 讀對話同紀錄估沉睡原因，個人化喚回',guard:'寵物可能過身嘅唔發優惠；要直銷同意',setup:3000,fee:600,wk:3,keep:[.2,.15],err:.03,rec:.75,react:.06}]},
 {id:'acct',seal:'數',name:'收費會員帳目',who:'老闆',
  desc:'POS、套票、月結、毛利警報',
  L:[{t:'POS ＋ Excel',tools:'POS ＋ Excel',guard:'人手對數',setup:0,fee:0,wk:1,keep:[.8,.8],err:0},
     {t:'會員系統',tools:'會員套票系統 ＋ AI 月結摘要',guard:'老闆睇月結',setup:1500,fee:400,wk:2,keep:[.5,.45],err:.01},
     {t:'毛利警報',tools:'AI 試算套票、折扣對毛利影響',guard:'改價前老闆確認',setup:2500,fee:600,wk:3,keep:[.35,.3],err:.01}]}
];

/* 老闆每週行政分鐘（未用 AI） */
var ADMIN={replyPerInq:6,perBooking:2.5,recallManual:90,acct:180,media:150,misc:120};

/* 店家端預設（基準情境：社區美容店） */
var DEF_SHOP={
 name:'社區美容店',
 groomers:2, ownerGrooms:1, groomerDays:6, openH:9, tables:2, tubs:1, assistantH:30,
 groomerBase:16000, groomerComm:40, assistantRate:60,
 priceIdx:1, addonRate:.30, addonAmt:100,
 active:340, inq:34, afterHours:.35, conv:.55, ads:3000,
 ret90:.82, noShow:.12, lateCancel:.08, deposit:0,
 quitRate:.10, followShare:.30, hireWeeks:6,
 rent:18000, utilities:4500, insurance:1000, misc:2000, consum:35, cardFee:.015,
 econ:1, compGap:0, cycMult:1, upsell:.30, inqMult:1, capMult:1,
 memberShare:0, memberDisc:.15, memberCyc:.75, memberAnyway:.60,
 minorRate:1/400, skinRate:1/1500, stressRate:1/300, seriousRate:1/8000, incidentMult:1,
 willSec:30, overbook:0,
 review:1, msgCost:.23, llmPerConv:.08,
 lv:{reply:2,sched:0,file:0,media:0,recall:2,acct:0},
 startCash:150000,
 forceQuitWeek:-1, forceSeriousWeek:-1
};

/* 創辦人端預設 */
var DEF_FOUNDER={
 model:'A', months:12,
 hoursAvail:160, contentH:40, devH:10, hourValue:150,
 startCash:100000, churnMult:1, trialTake:.5, market:400, tools:800, ads:2000, cpl:600, leadsContent:3, draw:0,
 A:{fee:1500,setup:3000,setupH:6,supportH1:4,supportH:2,salesH:2,conv:.35,cycle:1,pkg:{reply:2,sched:0,file:0,media:0,recall:2,acct:0}},
 B:{fee:2500,setup:15000,setupH:25,supportH1:6,supportH:5,salesH:4,conv:.15,cycle:2,pkg:{reply:2,sched:2,file:2,media:1,recall:2,acct:1}},
 C:{memberFee:128,benefit:90,comm:.12,memberCAC:250,memberChurn:.10,csPer100:8,partnerSalesH:4,partnerSetupH:10,partnerSupportH:2,partnerConv:.3,partnerSpare:30,visitsPerMember:.9,ticket:480,refundShare:.5,memberAds:6000},
 D:{seedShops:3,seedDisc:.5,caseBoost:.15,refComm:.08,memberAtSeed:.15},
 churnByMult:[[0,.18],[1,.12],[2,.05],[4,.02],[8,.01]],
 baseSupportPlat:100
};

var MODELS={A:'AI 前台 SaaS',B:'AI 落地顧問',C:'毛孩會員平台',D:'混合模式'};
var MODELS_S={A:'SaaS',B:'顧問',C:'會員平台',D:'混合'};

/* 數據來源 */
var SOURCES=[
 ['香港狗貓數量','約 22.1 萬狗、18.4 萬貓、9.4% 家庭','政府新聞公報引統計處專題住戶調查','2018 調查','https://www.info.gov.hk/gia/general/202311/22/P2023112200352.htm'],
 ['美容價錢','細狗 $200–300、中狗 $300–450、大狗 $400–600；精品店 $450–600+','hkhowmuch.com','2026','https://hkhowmuch.com/en/cost/dog-grooming-bath-cost-hk/'],
 ['SPCA Hair Force、上門美容','細狗全套由 $300 起；上門由 $520 起','dogdoghk.com 整理','2025–26','https://dogdoghk.com/en/services/grooming/'],
 ['美容師人工','學徒 $10k–15k、初級 $16k–22k、中級 $22k–30k、資深 $28k–45k','jobfinder.com.hk（編輯估算）','2025–26','https://www.jobfinder.com.hk/blog/%E5%AF%B5%E7%89%A9%E7%BE%8E%E5%AE%B9-%E4%BA%BA%E5%B7%A5-664/'],
 ['最低工資','HK$43.1／小時','勞工處','2026-05-01','https://www.labour.gov.hk/common/public/smw/Points_to_note_on_revised_SMW_rate_2026-TC.pdf'],
 ['寄養所牌照','HK$3,810／年；純美容唔需要特別牌照','漁護署、Family CLIC','現行','https://www.pets.gov.hk/english/animal_business/boarding_establishment_licence.html'],
 ['開店成本','一人細舖 $20–40 萬；中型 $21.5–42.5 萬','startright.hk 等','2026','https://startright.hk/hong-kong-pet-industry-startup/'],
 ['WhatsApp 香港收費','utility $0.23、marketing $0.64（2026-10-01 起）','islash.io 整理，要向 Meta 官方核實','2026','https://islash.io/product/2026-whatsapp-pricing-updates'],
 ['MoeGo','US$49–149／月','Capterra','2026','https://www.capterra.com/p/165732/MoeGo/pricing/'],
 ['本地對手 AI 預約','HK$800–2,000／月；聲稱 no-show 15–20% → 5% 以下','ud.hk（行銷文章，冇列來源）','2026-04','https://www.ud.hk/en-US/resources/ai/2026-04-17-ai-for-pet-grooming-shops-hk'],
 ['預繳消費修例','建議只包美容院、健身，未包寵物服務','商經局諮詢文件','2026','https://www.cedb.gov.hk/assets/resources/cedb/consultations-and-publications/Summary_of_proposals-Trade_Descriptions_Ordinance_2026_tc.pdf'],
 ['美容時長','30 分鐘至 3 小時以上；打結、怕吹風、新手會加長','Care.com','—','https://www.care.com/c/how-long-does-it-take-to-groom-a-dog/'],
 ['外國 KPI','no-show、回訪、使用率、加購 benchmark','簡報引 animalfriendsos、moego、noshowcalc','—','https://animalfriendsos.com/os/guides/pet-business-kpi-dashboard']
];
var ESTIMATES='分群佔比、時長、事故率、沉睡原因佔比、收工後查詢比例、AI 費用、續約流失對價值倍數、創辦人時數分配、查詢轉化率。';
