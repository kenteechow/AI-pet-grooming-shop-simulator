/* p_fgame：創辦人層入遊戲（v0.4）。老闆線：自己間店做出成績，同行嚟問，先解鎖。副業現金入小金庫；創辦人時數超過晚黑嘅 40 小時，就食老闆嘅美容時間。 */
if(typeof SUBS!=='undefined')SUBS.fd=[['ov','總覽'],['shops','客戶店'],['time','時間'],['model','模式']];
var FD_FREE=40;
EVENTS.peers={title:'同行嚟問你點做',body:function(){return '你間店連續 3 個月 no-show 低過 7%。有 3 位同行老闆 WhatsApp 你：「你用咩 AI？可唔可以幫我哋都搞？」';},
 ai:'呢個就係「混合模式」嘅自然起點：自己間店做示範店。但你係一人公司，副業每一個鐘都係由剪狗或者休息時間嚟。',
 ch:['A','B','C','D'].map(function(m){var t=MODEL_TIPS[m];return{t:'開始副業：'+m+' '+MODELS[m],pro:[t.start],con:[t.risk],f:function(){startFounder(m);}};}).concat([{t:'暫時唔做',pro:['專心做自己間店'],con:['之後要喺「報告」面板先開得返'],f:function(){}}])};
function startFounder(model){
 if(s.fd)return;var F=clone(DEF_FOUNDER);F.model=model;F.startCash=0;F.contentH=20;F.devH=8;F.hoursAvail=80;F.ads=1000;F.months=999;
 s.fd={model:model,F:F,st:founderInit(F,clone(DEF_SHOP),{det:false,seed:s.seed+99}),extraH:0,hist:[],start:s.months.length};
 if(typeof DOCK!=='undefined'&&!DOCK.some(function(d){return d[0]==='fd';}))DOCK.push(['fd','創','創辦人']);s.newFlag.fd=1;
 news('創辦人','你開始咗副業：模式 '+model+' '+MODELS[model]+'。每月晚黑有大約 '+FD_FREE+' 小時，超過就要用剪狗時間');
}
HOOKS.month.push(function(rec){
 var bk=rec.booked||1,ns=rec.ns/bk;s.goodNs=(ns<.07?(s.goodNs||0)+1:0);
 var hasAI=ROLES.some(function(r){return s.lv[r.id]>=2;});
 if(!s.fd&&!s.fdOffered&&s.goodNs>=3&&hasAI){s.fdOffered=1;queueEvent('peers');}
 if(!s.fd)return;
 var F=s.fd.F;var m=founderStep(s.fd.st);
 s.own.fund+=m.net;m.date=rec.y+'年'+rec.m+'月';s.fd.hist.push(m);rec.fd={mrr:m.mrr,net:m.net,worked:m.worked};
 s.fd.extraH=Math.max(0,m.worked-FD_FREE)/WPM;
 own().morale=clamp(own().morale-Math.max(0,m.worked-FD_FREE)*.002,.1,1);
 news('創辦人','副業：MRR '+hk(m.mrr)+'，'+(F.model==='C'?'會員 '+Math.round(m.members):'付費店 '+m.accts.toFixed(1)+' 間')+'，淨現金 '+hk(m.net)+'（入小金庫），做咗 '+Math.round(m.worked)+' 小時'+(s.fd.extraH>0?'，每週食咗 '+s.fd.extraH.toFixed(1)+' 小時剪狗時間':''));
});
HOOKS.sync.push(function(P){P.extraAdminH=s.fd?s.fd.extraH:0;});
function pFd(sub){
 var fd=s.fd;if(!fd)return '<p>未開始副業。</p>';var H=fd.hist,L=H[H.length-1],F=fd.F;
 if(sub==='ov'){
  if(!L)return '<p>模式 '+fd.model+' '+MODELS[fd.model]+'。第一個月結之後先有數字。</p>'+fdKnobs();
  var ser=[{name:'MRR',c:'s1',vals:H.map(function(x){return x.mrr;})}],ser2=[{name:'副業累計現金',c:'s2',vals:H.map(function(x){return x.cash;})}];
  var warn=[];if(L.supNeed>(L.availH-F.contentH-F.devH)*.8)warn.push('支援時間就快爆：一人創辦人無法同時服務太多客製化客戶');if(fd.extraH>3)warn.push('副業每週食咗你 '+fd.extraH.toFixed(1)+' 小時剪狗時間，自己間店產能跌緊');if(L.mult!=null&&L.mult<1.5)warn.push('店家價值倍數得 '+L.mult.toFixed(1)+'，店家會覺得唔抵，流失會升');if(L.ltvcac!=null&&L.ltvcac<1.5)warn.push('LTV/CAC 低過 1.5：增長唔等於健康');
  return '<div class="kgrid">'+kbox('MRR',hk(L.mrr))+kbox(F.model==='C'?'會員':'付費店',F.model==='C'?Math.round(L.members):L.accts.toFixed(1))+kbox('上月淨現金',hk(L.net),L.net<0?'bad':'')+kbox('做咗',Math.round(L.worked)+' 小時')+
   kbox('食咗剪狗時間',fd.extraH.toFixed(1)+' h／週',fd.extraH>3?'bad':'')+kbox('店家價值倍數',L.mult!=null?L.mult.toFixed(1)+' 倍':'—',L.mult!=null&&L.mult<1.5?'bad':'')+kbox('LTV/CAC',L.ltvcac!=null?L.ltvcac.toFixed(1):'—')+kbox('小金庫',hk(s.own.fund))+'</div>'+
   (warn.length?'<div class="list">'+warn.map(function(w){return '<div class="bs red"><span class="n">!</span><div><b>'+esc(w)+'</b></div></div>';}).join('')+'</div>':'')+
   (H.length>1?'<h3>MRR</h3>'+chart({series:ser,labels:H.map(function(x){return x.date.replace(/^\d+年/,'');}),h:160})+'<h3>副業累計現金</h3>'+chart({series:ser2,labels:H.map(function(x){return x.date.replace(/^\d+年/,'');}),h:140}):'')+fdKnobs();}
 if(sub==='shops'){var cs=fd.st.cohorts.filter(function(c){return c.w>.01;});
  if(F.model==='C')return '<p>會員 '+Math.round(fd.st.members)+' 位，合作店 '+fd.st.partners.toFixed(1)+' 間。會員平台嘅服務質素唔喺你手。</p>';
  return cs.length?'<div class="tw"><table><thead><tr><th>客戶店</th><th class="num">店數</th><th>狀態</th><th class="num">月費</th><th class="num">價值倍數</th><th class="num">做咗</th></tr></thead><tbody>'+cs.map(function(c){var m=c.mult[c.mult.length-1];return '<tr><td>'+c.name+'（第 '+(c.start+1)+' 月簽）</td><td class="num">'+c.w.toFixed(1)+'</td><td>'+(c.trial?'試用中':'付費')+'</td><td class="num">'+hk(c.fee)+'</td><td class="num '+(m<1.5?'dn':'')+'">'+(m!=null?m.toFixed(1):'—')+'</td><td class="num">'+c.age+' 個月</td></tr>';}).join('')+'</tbody></table></div><p class="note">每間客戶店都有「用 AI」同「唔用 AI」兩個雙胞胎模擬，價值倍數＝用 AI 多賺嘅 ÷ 月費。店越滿，AI 帶嚟嘅預約越用唔著。</p>':'<p class="note">未有客戶店。銷售週期 '+(F[fd.model==='D'?'B':fd.model==='C'?'A':fd.model].cycle||1)+' 個月。</p>';}
 if(sub==='time'){if(!L)return '<p class="note">第一個月結之後先有數字。</p>'+fdKnobs();
  return '<table class="mt"><tbody><tr><td>可用（晚黑 '+FD_FREE+' 小時＋可以食剪狗時間）</td><td class="num">'+Math.round(L.availH)+' 小時</td></tr><tr><td>hoslab 內容</td><td class="num">'+F.contentH+'</td></tr><tr><td>產品開發</td><td class="num">'+F.devH+'</td></tr><tr><td>支援現有客</td><td class="num">'+Math.round(L.supNeed)+'</td></tr><tr><td>銷售同搭建</td><td class="num">'+Math.round(L.needH-L.supNeed-F.contentH-F.devH)+'</td></tr><tr><td><b>實際做咗</b></td><td class="num"><b>'+Math.round(L.worked)+'</b></td></tr></tbody></table>'+
   '<p class="note">超過 '+FD_FREE+' 小時嘅部分，每週食咗你 '+fd.extraH.toFixed(1)+' 小時剪狗時間（排程表灰色「行政」會變長）。現金流為正唔代表一人公司撐得住。</p>'+fdKnobs();}
 var t=MODEL_TIPS[fd.model];return '<p><b>'+fd.model+' '+MODELS[fd.model]+'</b></p><p><b>最大風險：</b>'+t.risk+'</p><p><b>建議起步：</b>'+t.start+'</p><p class="note">想試其他模式嘅數，可以去標題畫面嘅「沙盒模擬器」。遊戲入面揀咗就唔轉，好似現實咁。</p>';
}
function fdKnobs(){var F=s.fd.F;return '<h3>調整</h3><div class="aedit"><span>每月副業時數上限 <b class="num">'+F.hoursAvail+'</b></span><button class="btn" data-act="fdk" data-k="hoursAvail" data-v="-10">−10</button><button class="btn" data-act="fdk" data-k="hoursAvail" data-v="10">＋10</button>'+
 '<span>每月廣告 <b class="num">'+hk(F.ads)+'</b></span><button class="btn" data-act="fdk" data-k="ads" data-v="-500">−500</button><button class="btn" data-act="fdk" data-k="ads" data-v="500">＋500</button></div>';}
if(typeof document!=='undefined')document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!GAME.on||!s)return;var a=el.getAttribute('data-act');
 if(a==='fdk'&&s.fd){var k=el.getAttribute('data-k'),v=+el.getAttribute('data-v');s.fd.F[k]=Math.max(k==='hoursAvail'?20:0,s.fd.F[k]+v);s.fd.st.F=s.fd.F;renderPanel();}
 if(a==='fdstart'){queueEvent('peers');}
 if(a==='fdcheat'){s.fdOffered=1;s.modal=null;queueEvent('peers');}});
