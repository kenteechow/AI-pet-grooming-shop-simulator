/* p_clients：持續嘅主人同毛孩紀錄（v0.12）。
   - 身份用穩定 ID（主人 o12、毛孩 p34），唔靠名：同名唔會混。
   - 呢度只係「身份＋紀錄」：每週幾多張預約、幾多 no-show 仍然由引擎（shopStep）決定，紀錄唔會自己加客或者加錢。
   - 熟客預約：搵一隻同分群、到期又未有預約嘅毛孩；搵唔到就當係「開店前已有嘅熟客」，第一次出現時冇紀錄（未記錄）。
   - 新客預約：開一個新主人＋新毛孩（5% 機會係舊主人嘅第二隻）。
   - 只有「完成」先計一次服務；No-show、臨時取消、冇位分開記。同一張預約重複標記唔會重複計。
   - 觀察紀錄：冇 AI 靠美容師手寫（好多時冇寫）；檔 L1 問卷＋打字；檔 L2／L3 AI 由語音備註整理草稿，有機會寫錯。
     有人工審核：美容師即場核對（約 1 分鐘），寫錯會改正；冇審核：草稿保持「未確認」，唔會當事實用，玩家可以喺紀錄度叫美容師核對。
   - 健康相關觀察只會寫「已通知主人，建議睇獸醫」，AI 唔診斷。
   - 數字（觀察機會、草稿出錯率）係示範估算。 */
var CL_OBS={
 any:[['怕大風聲，低風速同分段休息會放鬆啲','care'],['腋下同耳後容易打結，要先梳開','care'],['剪腳毛會縮腳，要助手扶住','care'],['怕陌生人，先俾佢聞手先開始','care'],['主人鍾意耳仔留長，唔好剪短','style'],['主人要求面部剪圓啲','style'],['左耳有少少紅','health'],['指甲黑色，要分幾次慢慢剪','care']],
 k:[['怕水聲，用毛巾包住先唔會掙扎','care'],['唔好剪鬚','style'],['尾巴附近有毛結','care'],['下巴有黑色粒粒','health'],['會抓人，要戴手套同兩個人','care'],['耳仔有好多啡色耳垢','health'],['有啲肥，背脊同尾根易打結','care'],['一摸肚就咬','care']],
 o:[['企耐咗會氣喘，要多啲休息','health'],['後腳無力，要托住佢','care'],['怕冷，吹乾要快啲','care']],
 l:[['大隻但好乖，洗澡要兩個人','care'],['換毛期，要額外時間吹走底毛','care']]};
var CL_WRONG={'怕大風聲，低風速同分段休息會放鬆啲':'鍾意大風，可以用高速吹乾','主人鍾意耳仔留長，唔好剪短':'主人要求耳仔剪短','唔好剪鬚':'鬚可以修短','後腳無力，要托住佢':'前腳無力，要托住佢','怕冷，吹乾要快啲':'唔怕冷，可以慢慢吹','怕陌生人，先俾佢聞手先開始':'好親人，可以直接開始','指甲黑色，要分幾次慢慢剪':'指甲白色，一次剪完','一摸肚就咬':'鍾意人摸肚','會抓人，要戴手套同兩個人':'好乖，一個人做得'};
var CL_OWNER=[['最近做完絕育，肚仔唔好壓','health'],['今次想剪短啲，天氣熱','style'],['最近皮膚敏感緊，獸醫開咗藥膏','health'],['上次返去好開心，想同上次一樣','style']];
var CL_CYCLE={s:35,c:35,m:42,l:42,k:56,o:35};/* 回訪週期（日），示範估算 */
var CL_RATE={observe:.45,write0:.30,draftErr:[0,0,.08,.06]};/* 示範估算 */
function clInit(){s.cl={v:1,n:1,owners:{},pets:{}};}
function clNew(kind){return kind+(s.cl.n++);}
function clMkOwner(pre){var o={id:clNew('o'),name:pick(OWNN),pets:[],since:s.day,pre:!!pre,cons:{promo:R()<(s.consent==null?.6:s.consent),photo:'unasked',withdrawn:false}};s.cl.owners[o.id]=o;return o;}
function clMkPet(o,seg,pre){var p={id:clNew('p'),oid:o.id,name:pick(PETN),seg:seg,breed:pick(BREED[seg]),since:s.day,pre:!!pre,visits:[],notes:[],cnt:{done:0,noshow:0,cancel:0,lost:0},last:null,next:null};s.cl.pets[p.id]=p;o.pets.push(p.id);return p;}
function clPet(id){return s.cl&&s.cl.pets[id]||null;}
function clOwner(id){return s.cl&&s.cl.owners[id]||null;}
/* 揀一隻到期嘅熟客毛孩：同分群、最少隔咗週期嘅六成、而家冇未完成嘅預約 */
function clDue(seg){var best=null,bs=-1;for(var k in s.cl.pets){var p=s.cl.pets[k];if(p.seg!==seg||(p.next!=null&&p.next>=s.day)||p.last==null)continue;if(p.cnt.done<1)continue;
  var gap=s.day-p.last,cyc=CL_CYCLE[seg]||35;if(gap<cyc*.6)continue;var sc=1-Math.abs(gap/cyc-1)+R()*.15;if(sc>bs){bs=sc;best=p;}}return best;}
function clAssign(a,regular){
 if(!s.cl)clInit();if(a.pid)return;
 var p=null,o=null;
 if(regular==null)regular=a.regular;
 if(regular){p=clDue(a.seg);if(p){o=s.cl.owners[p.oid];}else{o=clMkOwner(true);p=clMkPet(o,a.seg,true);}}
 else{var olds=Object.keys(s.cl.owners);if(olds.length>8&&R()<.05){o=s.cl.owners[olds[Math.floor(R()*olds.length)]];}else o=clMkOwner(false);p=clMkPet(o,a.seg,false);}
 a.pid=p.id;a.oid=o.id;a.pet=p.name;a.owner=o.name;a.breed=p.breed;p.next=a.day;
}
/* 記低一張預約嘅結果。st：done／noshow／cancel／lost。同一張預約只計一次 */
function clMark(a,st){
 if(!s.cl||!a.pid)return;var p=clPet(a.pid);if(!p)return;
 var v=null;for(var i=0;i<p.visits.length;i++)if(p.visits[i].aid===a.id)v=p.visits[i];
 if(v){if(v.st===st)return;p.cnt[v.st]=Math.max(0,(p.cnt[v.st]||0)-1);v.st=st;}
 else{v={aid:a.id,day:a.day,svc:a.svc,st:st,g:a.g,t:a.a,price:a.price};p.visits.push(v);if(p.visits.length>20)p.visits.shift();}
 p.cnt[st]=(p.cnt[st]||0)+1;p.next=null;if(st==='done'){p.last=a.day;v.gname=staffName(a.g);v.price=a.price;v.inc=a.inc||null;}
}
/* 加唔到入排程（例如候補冇位）：啱啱開嘅新紀錄就刪走，舊紀錄就清返「已預約」 */
function clDrop(a){var p=clPet(a.pid);if(!p)return;if(!p.visits.length&&p.since===s.day){var o=clOwner(p.oid);delete s.cl.pets[p.id];if(o){o.pets=o.pets.filter(function(x){return x!==p.id;});if(!o.pets.length)delete s.cl.owners[o.id];}}else p.next=null;a.pid=a.oid=null;}
function clConfirmed(p){return p.notes.filter(function(n){return n.st==='confirmed'||n.st==='corrected'||n.st==='owner';});}
function clDrafts(p){return p.notes.filter(function(n){return n.st==='draft';});}
function clNoteText(n){return n.st==='corrected'?n.fix:n.txt;}
function clAddNote(p,n){n.id=clNew('n');n.day=s.day;p.notes.push(n);if(p.notes.length>10)p.notes.shift();return n;}
/* 美容師核對一份 AI 草稿：寫錯就改正，寫啱就確認 */
function clReview(p,n,who){if(n.st!=='draft')return;s.rep.reviewMin=(s.rep.reviewMin||0)+1;
 if(n.wrong){n.st='corrected';n.fix=n.truth;n.by=who||'美容師';}else{n.st='confirmed';n.by=who||'美容師';}}
/* 服務完成：可能有新觀察；按「檔」嘅等級決定點樣記低 */
function clObserve(a){
 var p=clPet(a.pid);if(!p)return;clAskPhoto(a);clReport(a);
 if(R()>CL_RATE.observe)return;
 var pool=CL_OBS.any.concat(CL_OBS[a.seg]||[]),known={};p.notes.forEach(function(n){known[n.truth||n.txt]=1;});
 pool=pool.filter(function(o){return !known[o[0]];});if(!pool.length)return;
 var ob=pool[Math.floor(R()*pool.length)],lv=s.lv.file||0,gname=staffName(a.g);
 if(lv===0){if(R()>CL_RATE.write0)return;clAddNote(p,{txt:ob[0],truth:ob[0],kind:ob[1],src:'groomer',st:'confirmed',by:gname});return;}
 var comp=roleDef('file').L[lv-1].comp;if(R()>comp)return;
 if(lv===1){clAddNote(p,{txt:ob[0],truth:ob[0],kind:ob[1],src:'groomer',st:'confirmed',by:gname});return;}
 var wrong=R()<CL_RATE.draftErr[lv]&&!!CL_WRONG[ob[0]];
 var n=clAddNote(p,{txt:wrong?CL_WRONG[ob[0]]:ob[0],truth:ob[0],kind:ob[1],src:'ai',st:'draft',wrong:wrong});
 if(s.review){clReview(p,n,gname);if(n.st==='corrected'){s.rep.guards++;aiLog('檔','「'+p.name+'」AI 草稿寫錯（「'+n.txt+'」），'+gname+'改正為「'+n.fix+'」');}}
}
/* 到店：主人可能補充；檔 L3 會出「到店前提示」，只用已確認嘅紀錄 */
function clArrive(a){
 var p=clPet(a.pid);if(!p||p.cnt.done<1)return;
 if(R()<.12){var ow=CL_OWNER[Math.floor(R()*CL_OWNER.length)];clAddNote(p,{txt:ow[0],truth:ow[0],kind:ow[1],src:'owner',st:'owner',by:a.owner});}
 if((s.lv.file||0)>=3){var c=clConfirmed(p);if(c.length)aiLog('檔','到店前提示「'+p.name+'」：'+c.slice(-2).map(clNoteText).join('；')+(clDrafts(p).length?'（另有未確認草稿，冇用）':''));}
}
/* 事故分配：有已確認照顧紀錄嘅毛孩，「緊張」事故權重減半（總數仍然由引擎決定） */
function clStressW(a){var p=clPet(a.pid);if(!p)return 1;return clConfirmed(p).some(function(n){return n.kind==='care';})?.5:1;}
function clPickWeighted(list,wf){var tot=0;list.forEach(function(x){tot+=wf(x);});var r=R()*tot;for(var i=0;i<list.length;i++){r-=wf(list[i]);if(r<=0)return list[i];}return list[list.length-1];}
/* ---------- 同意（v0.13）：服務通知、推廣、相片分開 ----------
   服務通知（已預約服務嘅提醒、改期）唔使推廣同意；推廣要有同意，撤回之後唔再發；相片分「只可以私下發畀主人」同「可以公開」。
   聚合直銷同意率 s.consent 仍然係引擎用嘅數；呢度係見過嘅客人逐個記。 */
function clCons(o){if(!o.cons)o.cons={promo:false,photo:'unasked',withdrawn:false};return o.cons;}
function clCanPromo(o){var c=clCons(o);return !!c.promo&&!c.withdrawn;}
function clCanPost(o){return clCons(o).photo==='public';}
/* 聚合同意率升咗（老闆逐個問、AI 前台順手問）：未同意又冇撤回嘅主人按比例轉做同意 */
function clConsentSync(oldR,newR){if(!s.cl||newR<=oldR)return;var f=(newR-oldR)/Math.max(.01,1-oldR);for(var k in s.cl.owners){var c=clCons(s.cl.owners[k]);if(!c.promo&&!c.withdrawn&&R()<f)c.promo=true;}}
function clAskPhoto(a){var o=clOwner(a.oid);if(!o)return;var c=clCons(o);if(c.photo!=='unasked')return;
 if(R()>((s.lv.media||0)>=1?1:.5))return;c.photo=R()<.35?'public':'private';c.photoDay=s.day;}
/* 影 L2／L3：AI 報告卡。有審核只用已確認紀錄；冇審核會連未確認草稿一齊用，草稿錯就會報錯 */
function clReport(a){var p=clPet(a.pid);if(!p||(s.lv.media||0)<2)return;
 var lines=clConfirmed(p).slice(-2).map(clNoteText),err=null;
 if(!s.review){var d=clDrafts(p).slice(-1)[0];if(d){lines.push(d.txt);if(d.wrong)err=d.txt;}}
 p.reports=p.reports||[];p.reports.push({day:s.day,lines:lines,err:err,rev:!!s.review});if(p.reports.length>5)p.reports.shift();
 if(err){s.rep.errs++;s.S.rating=Math.max(1,s.S.rating-.003);var fbe={day:s.day,t:a.b,pet:p.name,owner:a.owner,pid:a.pid,oid:a.oid,good:false,txt:'報告卡寫「'+err+'」，根本唔係咁',stars:2};s.fb.unshift(fbe);clFb(a,fbe);news('AI 出錯','冇人審核：AI 報告卡用咗未確認草稿，同「'+p.name+'」主人講錯咗「'+err+'」');}}
/* 每星期：推廣（回）同社媒（影 L3） */
function clWeekly(){if(!s.cl)return;var lv=s.lv.recall||0,sent=0,blocked=0,posts=0,skipped=0;
 for(var k in s.cl.pets){var p=s.cl.pets[k],o=s.cl.owners[p.oid];if(!o||p.last==null||p.next!=null&&p.next>=s.day)continue;
  var gap=s.day-p.last,cyc=CL_CYCLE[p.seg]||35;
  if(lv>=1&&gap>cyc*1.3&&(o.lastPromo==null||s.day-o.lastPromo>=28)){if(clCanPromo(o)){o.lastPromo=s.day;sent++;s.rep.promos=(s.rep.promos||0)+1;
    if(R()<.03){clCons(o).withdrawn=true;clCons(o).promo=false;clCons(o).wdDay=s.day;news('私隱',o.name+' 回覆「唔好再發推廣」，已經記低撤回，之後唔會再發（預約提醒照發）');}}else blocked++;}
  if((s.lv.media||0)>=3&&gap<7&&posts<3&&p.last>=s.day-7){if(clCanPost(o)){posts++;s.rep.posts=(s.rep.posts||0)+1;p.posted=s.day;}else skipped++;}}
 s.aiPend=s.aiPend||[];var lg=function(seal,txt,tm){s.aiPend.push({t:tm,seal:seal,txt:txt});};
 if(sent||blocked)lg('回','本週推廣：發咗 '+sent+' 位（有同意）；'+blocked+' 位冇同意或者已撤回，冇發',DAY0+20);
 if(posts||skipped)lg('影','IG 草稿 '+posts+' 篇（只用同意公開嘅相）；'+skipped+' 隻冇公開同意，冇用佢哋嘅相',DAY0+25);}
HOOKS.week.push(clWeekly);
/* 舊存檔：補身份 */
function clMigrate(){if(!s.cl)clInit();if(s.wk)s.wk.appts.forEach(function(a){if(!a.pid){var keepPet=a.pet,keepOwn=a.owner,keepBr=a.breed;clAssign(a,true);var p=clPet(a.pid),o=clOwner(a.oid);p.name=a.pet=keepPet;o.name=a.owner=keepOwn;p.breed=a.breed=keepBr;p.migrated=1;
  if(a.st==='done'||a.st==='gone')clMark(a,'done');else if(a.st==='noshow'||a.st==='cancel'||a.st==='lost')clMark(a,a.st);}});}
/* 遊戲規則（示範假設）：完成 2 次或以上、或者開店前已有，就當熟客 */
function clKind(p){if(p.pre)return p.cnt.done?'熟客（開店前已有）':'開店前已有嘅熟客 · 未有紀錄';return p.cnt.done>=2?'熟客':p.cnt.done===1?'新客 · 嚟過 1 次':'第一次嚟';}
function clStats(){var r={pets:0,first:0,pre:0,done:0,conf:0,draft:0,none:0,owners:0};if(!s.cl)return r;r.owners=Object.keys(s.cl.owners).length;
 for(var k in s.cl.pets){var p=s.cl.pets[k];r.pets++;if(p.pre)r.pre++;else r.first++;r.done+=p.cnt.done;var c=clConfirmed(p).length,d=clDrafts(p).length;r.conf+=c;r.draft+=d;if(!c&&!d&&p.cnt.done)r.none++;}return r;}
HOOKS.init.push(function(){clInit();});

/* ---------- 介面：客人 → 紀錄 ---------- */
var CLV={f:'today',q:'',pid:null};
function noteRow(p,n){var st={confirmed:['已確認','ok'],corrected:['美容師改正','ok'],owner:['主人提供','own'],draft:['未確認草稿','warn']}[n.st]||['',''];
 var src={groomer:'美容師手寫',ai:'AI 由語音備註整理',owner:'主人講'}[n.src]||'';
 var body=n.st==='corrected'?'<s>'+esc(n.txt)+'</s> → '+esc(n.fix):esc(n.txt);
 var health=n.kind==='health'&&n.st!=='draft'?'<em class="clh">已通知主人，建議睇獸醫（美容店唔做診斷）</em>':'';
 return '<li class="cln '+st[1]+'"><span class="clp">'+st[0]+'</span><span>'+body+health+'<small>'+src+(n.by?' · '+esc(n.by):'')+' · '+dateStr(n.day).replace(/^\d+年/,'')+'</small></span>'+
  (n.st==='draft'?'<button class="btn" data-act="clrev" data-p="'+p.id+'" data-n="'+n.id+'">叫美容師核對</button>':'')+'</li>';}
function petCard(p,a){var o=clOwner(p.oid),g=SEGS.filter(function(x){return x.id===p.seg;})[0],c=p.cnt;
 var nth=a?(c.done+(a.st==='done'||a.st==='gone'?0:1)):0,tag=clKind(p)+(nth?' · 今次係第 '+nth+' 次完成服務':'');
 return '<div class="clc"><div class="clt"><button class="lnk pfn" data-act="clopen" data-p="'+p.id+'"><b>'+esc(p.name)+'</b></button><span class="num">#'+p.id.slice(1)+'</span><span class="pill">'+esc(p.breed)+' · '+g.name+'</span><span class="pill">'+tag+'</span></div>'+
  (o?'<div class="clcons">'+consPills(o)+'</div>':'')+(p.reports&&p.reports.length?'<div class="clrep">上次報告卡：'+esc(p.reports[p.reports.length-1].lines.join('；')||'冇觀察')+(p.reports[p.reports.length-1].err?' <span class="pill bad">寫錯咗</span>':'')+'</div>':'')+
  '<div class="clm">主人 '+esc(o?o.name:'—')+(o&&o.pets.length>1?'（有 '+o.pets.length+' 隻）':'')+' · 完成 '+c.done+' 次'+(c.noshow?' · No-show '+c.noshow:'')+(c.cancel?' · 取消 '+c.cancel:'')+(c.lost?' · 冇位 '+c.lost:'')+(p.last!=null?' · 上次 '+dateStr(p.last).replace(/^\d+年/,''):'')+(a?' · 今次 '+hm(a.a)+' '+stLabel(a):'')+'</div>'+
  (p.notes.length?'<ul class="cll">'+p.notes.slice().reverse().map(function(n){return noteRow(p,n);}).join('')+'</ul>':'<p class="note">'+(p.cnt.done?'未記錄：之前嘅服務冇人寫低觀察。':p.pre?'未記錄：開店前嘅資料冇入系統。':'未記錄：第一次到店。')+'</p>')+'</div>';}
function consPills(o){var c=clCons(o);return '<span class="pill ok">服務通知：可以</span><span class="pill '+(c.withdrawn?'bad':c.promo?'ok':'')+'">推廣：'+(c.withdrawn?'已撤回':c.promo?'同意':'未同意')+'</span><span class="pill '+(c.photo==='public'?'ok':'')+'">相片：'+({unasked:'未問',private:'只可以私下發',public:'可以公開'}[c.photo])+'</span>';}
function pRec(){
 if(!s.cl)clInit();var st=clStats(),lv=s.lv.file||0;
 var how=lv===0?'而家冇 AI：美容師得閒先手寫，好多觀察冇記低。':lv===1?'檔 L1：入店問卷＋美容師打字，記得多啲，但花時間。':'檔 L'+lv+'：AI 由語音備註整理草稿。'+(s.review?'有人工審核，美容師即場核對（每份約 1 分鐘）。':'冇人工審核：草稿會保持「未確認」，唔會用嚟做下次提示。');how+=' ';
 if(CLV.pid&&clPet(CLV.pid))return profileHTML(clPet(CLV.pid));
 return '<div class="kgrid">'+kbox('有紀錄嘅毛孩',st.pets)+kbox('第一次嚟',st.first)+kbox('已確認紀錄',st.conf)+kbox('未確認草稿',st.draft)+'</div>'+
  '<p class="note">'+how+'只計遊戲入面見過嘅客人；開店前已有嘅熟客第一次出現時冇紀錄。完成先計一次服務，No-show、取消、冇位分開記。熟客＝完成 2 次或以上，或者開店前已有（遊戲假設）。'+(s.rep.reviewMin?' 今局美容師核對草稿共約 '+s.rep.reviewMin+' 分鐘。':'')+'</p>'+
  '<div class="seg2">'+[['today','今日到店'],['draft','未確認草稿'],['all','最近 30 隻']].map(function(x){return '<button class="'+(CLV.f===x[0]?'on':'')+'" data-act="clf" data-f="'+x[0]+'">'+x[1]+'</button>';}).join('')+'</div>'+
  '<label class="clq"><span>搵檔案</span><input type="search" data-act="clq" placeholder="寵物名、主人、#編號、品種" value="'+esc(CLV.q||'')+'"></label><div id="clList">'+clListHTML()+'</div>';}
if(typeof document!=='undefined')document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');
 if(a==='clf'){CLV.f=el.getAttribute('data-f');CLV.q='';renderPanel();}
 if(a==='clrev'){var p=clPet(el.getAttribute('data-p'));if(!p)return;var n=p.notes.filter(function(x){return x.id===el.getAttribute('data-n');})[0];if(!n)return;
  var g=groomers()[0];clReview(p,n,g?g.name:'美容師');news('紀錄',n.st==='corrected'?'核對「'+p.name+'」草稿：AI 寫錯咗，已改正為「'+n.fix+'」':'核對「'+p.name+'」草稿：內容正確，已確認');renderPanel();renderSel();}});
/* ---------- v0.15：每個主人同每隻毛孩嘅檔案（可以搜尋） ----------
   檔案內容：主人資料、同意、消費、平均評分；毛孩嘅要求（造型、照顧、健康，只列已確認或者主人講嘅）、未確認草稿、
   每次服務（日期、服務、美容師、價錢、狀態、主人意見同星數）、報告卡、下次預約。評分只係有留意見嗰幾次，唔係每次都有。 */
function clFb(a,f){var p=clPet(a.pid);if(!p)return;for(var i=p.visits.length-1;i>=0;i--)if(p.visits[i].aid===a.id){p.visits[i].fb={good:f.good,txt:f.txt,stars:f.stars};return;}}
function clOwnerStats(o){var r={spend:0,done:0,stars:[],last:null,pets:o.pets.map(clPet).filter(Boolean)};r.pets.forEach(function(p){p.visits.forEach(function(v){if(v.st==='done'){r.done++;r.spend+=v.price||0;if(r.last==null||v.day>r.last)r.last=v.day;}if(v.fb&&v.fb.stars)r.stars.push(v.fb.stars);});});
 r.avg=r.stars.length?r.stars.reduce(function(x,y){return x+y;},0)/r.stars.length:null;return r;}
function clNextAppt(p){return s.wk?s.wk.appts.filter(function(a){return a.pid===p.id&&a.st==='booked';})[0]:null;}
function stars(n){var h='';for(var i=1;i<=5;i++)h+='<i class="star'+(i<=n?' on':'')+'"></i>';return '<span class="stars" aria-label="'+n+' 粒星">'+h+'</span>';}
var VST={done:'完成',noshow:'No-show',cancel:'臨時取消',lost:'冇位'};
function clReqs(p){var g={style:[],care:[],health:[]};clConfirmed(p).forEach(function(n){(g[n.kind]||g.care).push(n);});return g;}
function profileHTML(p){var o=clOwner(p.oid),os=o?clOwnerStats(o):null,seg=SEGS.filter(function(x){return x.id===p.seg;})[0],nx=clNextAppt(p),rq=clReqs(p),dr=clDrafts(p);
 var reqList=function(arr,lbl){return arr.length?'<div class="pfr"><b>'+lbl+'</b><ul>'+arr.slice().reverse().map(function(n){return '<li>'+esc(clNoteText(n))+(n.kind==='health'?'<em class="clh">已通知主人，建議睇獸醫（美容店唔做診斷）</em>':'')+'<small>'+({groomer:'美容師',ai:'AI 草稿，美容師確認',owner:'主人講'}[n.src]||'')+(n.by?' · '+esc(n.by):'')+' · '+dateStr(n.day).replace(/^\d+年/,'')+'</small></li>';}).join('')+'</ul></div>':'';};
 var vis=p.visits.slice().reverse();
 return '<button class="tback" data-act="clback">‹ 返回紀錄</button>'+
  '<div class="pfh"><div><h3>'+esc(p.name)+' <span class="num">#'+p.id.slice(1)+'</span></h3><p>'+esc(p.breed)+' · '+seg.name+' · '+esc(clKind(p))+' · '+(p.pre?'開店前已經係客':'由 '+dateStr(p.since).replace(/^\d+年/,'')+' 開始')+'</p></div>'+
  '<div class="pfk">'+kbox('完成服務',p.cnt.done+' 次')+kbox('上次',p.last!=null?dateStr(p.last).replace(/^\d+年/,''):'—')+kbox('下次預約',nx?dateStr(nx.day).replace(/^\d+年/,'')+' '+hm(nx.a):'未有')+'</div></div>'+
  (o?'<div class="pfo"><b>主人：'+esc(o.name)+' <span class="num">#'+o.id.slice(1)+'</span></b><span>'+(o.pre?'開店前已經係客':'由 '+dateStr(o.since).replace(/^\d+年/,'')+' 開始')+' · 累計消費 '+hk(os.spend)+' · 平均評分 '+(os.avg?os.avg.toFixed(1)+'（'+os.stars.length+' 次有評）':'未有評分')+'</span>'+
   (os.pets.length>1?'<span>其他毛孩：'+os.pets.filter(function(q){return q.id!==p.id;}).map(function(q){return '<button class="lnk" data-act="clopen" data-p="'+q.id+'">'+esc(q.name)+' #'+q.id.slice(1)+'</button>';}).join('、')+'</span>':'')+
   '<div class="clcons">'+consPills(o)+'</div></div>':'')+
  '<h4>要求同注意事項</h4>'+((rq.style.length||rq.care.length||rq.health.length)?reqList(rq.style,'造型要求')+reqList(rq.care,'照顧注意')+reqList(rq.health,'健康提示'):'<p class="note">未記錄。'+(p.cnt.done?'之前嘅服務冇人寫低要求。':'')+'</p>')+
  (dr.length?'<div class="pfr warn"><b>未確認草稿（唔會當事實用）</b><ul>'+dr.map(function(n){return '<li>'+esc(n.txt)+' <button class="btn" data-act="clrev" data-p="'+p.id+'" data-n="'+n.id+'">叫美容師核對</button></li>';}).join('')+'</ul></div>':'')+
  '<h4>服務紀錄</h4>'+(vis.length?'<ul class="pfvl">'+
   vis.map(function(v){return '<li><div class="pfv1"><b>'+dateStr(v.day).replace(/^\d+年/,'')+(v.t?' '+hm(v.t):'')+'</b><span>'+(SVC[v.svc]?SVC[v.svc].n:'—')+'</span><span>'+esc(v.gname||(v.g!=null?staffName(v.g):'—'))+'</span><span class="num">'+(v.st==='done'&&v.price?hk(v.price):'—')+'</span><span class="pill '+(v.st==='done'?'ok':v.st==='noshow'?'bad':'')+'">'+(VST[v.st]||v.st)+'</span>'+(v.inc?'<span class="pill bad">有事故</span>':'')+'</div>'+
    '<div class="pfv2">'+(v.fb?stars(v.fb.stars)+' 「'+esc(v.fb.txt)+'」':'<span class="note">冇留意見</span>')+'</div></li>';}).join('')+'</ul>':'<p class="note">未有服務紀錄。</p>')+
  (p.reports&&p.reports.length?'<h4>報告卡</h4><ul class="pfrep">'+p.reports.slice().reverse().map(function(r){return '<li><b>'+dateStr(r.day).replace(/^\d+年/,'')+'</b> '+esc(r.lines.join('；')||'冇特別觀察')+(r.err?' <span class="pill bad">寫錯咗</span>':'')+(r.rev?'':' <small class="note">冇人工審核</small>')+'</li>';}).join('')+'</ul>':'')+
  '<p class="note">只係遊戲入面見過嘅服務；開店前嘅紀錄冇入系統。評分只係有留意見嗰幾次。</p>';}
/* 搜尋：名、主人名、#編號、品種 */
function clSearch(q){q=String(q||'').trim().toLowerCase().replace(/^#/,'');if(!q)return [];var out=[];
 for(var k in s.cl.pets){var p=s.cl.pets[k],o=s.cl.owners[p.oid];var hay=(p.name+' '+p.breed+' '+p.id.slice(1)+' '+(o?o.name+' '+o.id.slice(1):'')).toLowerCase();if(hay.indexOf(q)>=0)out.push(p);}
 return out.sort(function(x,y){return (y.last==null?-1:y.last)-(x.last==null?-1:x.last);}).slice(0,40);}
function clListHTML(){var list=[];
 if(CLV.q){list=clSearch(CLV.q).map(function(p){return [p,null];});}
 else if(CLV.f==='today')list=todayAppts().filter(function(a){return a.pid&&clPet(a.pid);}).map(function(a){return [clPet(a.pid),a];});
 else{var all=Object.keys(s.cl.pets).map(function(k){return s.cl.pets[k];});if(CLV.f==='draft')all=all.filter(function(p){return clDrafts(p).length;});
  all.sort(function(x,y){return (y.last==null?-1:y.last)-(x.last==null?-1:x.last);});list=all.slice(0,30).map(function(p){return [p,null];});}
 return list.length?list.map(function(x){return petCard(x[0],x[1]);}).join(''):'<p class="note">'+(CLV.q?'搵唔到「'+esc(CLV.q)+'」。':CLV.f==='today'?'今日冇預約。':'冇符合嘅紀錄。')+'</p>';}
if(typeof document!=='undefined'){
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');
  if(a==='clopen'){CLV.pid=el.getAttribute('data-p');if(PANEL.id!=='cust')openPanel('cust');PANEL.sub='rec';renderPanel();var pn=document.querySelector('#panel .pbody,#panel');if(pn)pn.scrollTop=0;}
  if(a==='clback'){CLV.pid=null;renderPanel();}});
 document.addEventListener('input',function(e){if(!e.target.matches('[data-act=clq]')||!s)return;CLV.q=e.target.value;var L=document.getElementById('clList');if(L)L.innerHTML=clListHTML();});}
