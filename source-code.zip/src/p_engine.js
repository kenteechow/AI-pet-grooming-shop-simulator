/* p_engine：店層模擬（純函數，按週）。遊戲同沙盒共用。det=true 用期望值，det=false 隨機抽（蒙地卡羅）。 */
function rngMake(seed){var a=(seed>>>0)||1;return function(){a=(a+0x6D2B79F5)|0;var t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
function poisson(lam,r){if(lam<=0)return 0;if(lam>30){var u=r()||1e-9,v=r();var z=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);return Math.max(0,Math.round(lam+z*Math.sqrt(lam)));}var L=Math.exp(-lam),k=0,p=1;do{k++;p*=r();}while(p>L);return k-1;}
function binom(n,p,r){var k=0,m=Math.round(n);for(var i=0;i<m;i++)if(r()<p)k++;return k;}
function clamp(x,a,b){return x<a?a:x>b?b:x;}
function clone(o){return JSON.parse(JSON.stringify(o));}
function sum(a){var s=0;for(var i=0;i<a.length;i++)s+=a[i];return s;}

var L0={reply:{loss:[.30,.10],ns:1,keep:[1,1],err:0},sched:{refill:.05,keep:[1,1],err:0,guard2:0},file:{comp:.30,sec:0,keep:[1,1],err:0},media:{wom:0,keep:[1,1],err:0},recall:{rec:0,react:.004,keep:[1,1],err:0},acct:{keep:[1,1],err:0}};
function roleDef(id){for(var i=0;i<ROLES.length;i++)if(ROLES[i].id===id)return ROLES[i];return null;}

function newShop(P,o){
 o=o||{};
 var S={P:clone(P),w:0,ctx:{det:o.det!==false,r:rngMake(o.seed||1)},
  act:SEGS.map(function(g){return P.active*g.share;}),
  dorm:DORM.map(function(d){return P.active*.35*d.share;}),
  trial:SEGS.map(function(){return 0;}),rating:4.5,backlog:0,gVac:0,gNew:0,scandal:0,cash:P.startCash,lastBooked:P.active/6,
  age:{},hist:[],setupDone:{}};
 ROLES.forEach(function(r){S.age[r.id]=0;});
 return S;
}
/* 部署進度：頭 4 週效率由 50% 升到 100% */
function rampEff(S,id){var lv=S.P.lv[id];if(!lv)return 1;var a=S.age[id];var wk=roleDef(id).L[lv-1].wk;if(a<wk)return 0;return Math.min(1,.5+.5*(a-wk)/4);}
function rv(S,id,key){
 var lv=S.P.lv[id],base=L0[id][key];
 if(!lv)return key==='keep'?base[S.P.review?0:1]:base;
 var L=roleDef(id).L[lv-1],v=L[key],e=rampEff(S,id);
 if(key==='keep'){v=v[S.P.review?0:1];return 1-(1-v)*e;}
 if(v===undefined)return base;
 if(Array.isArray(v))return v.map(function(x,i){return base[i]+(x-base[i])*e;});
 return base+(v-base)*e;
}
function drawN(lam,c){return c.det?lam:poisson(lam,c.r);}
/* 客人體驗（v0.22，示範估算）：
   回覆等候（小時）：收工後查詢冇 AI 要等到第二朝；L1 有離線自動回覆但真回覆都係朝早；L2／L3 AI 即時答，少數轉人。
   到店等候（分鐘）：店越忙越長；排程 L2／L3 時段排得準啲。
   評價：每完成一隻有幾多主人留 Google 評價；報告卡同評價邀請會多啲。報告卡覆蓋：有幾多主人收到前後相報告。
   體驗分 0–100 = 100 − 回覆等候 − 到店等候 − 事故率 − AI 答錯 + 報告卡 − 5。上星期嘅體驗分影響今個星期嘅評分走向同熟客回頭率。 */
var EXP={ahWait:[11,9,1.2,1],bhWait:[.7,.5,.12,.1],shop:[1,1,.75,.6],rev:[.03,.05,.10,.15],card:[0,.3,1,1],kRating:.08,kRet:.02,mid:70};
function expMix(S,id,arr){var l=S.P.lv[id]||0,e=l?rampEff(S,id):1;return arr[0]+(arr[l]-arr[0])*e;}
function expCalc(S,util,inc,done,err){var P=S.P;
 var rw=P.afterHours*expMix(S,'reply',EXP.ahWait)+(1-P.afterHours)*expMix(S,'reply',EXP.bhWait)*(1+util);
 var sw=(6+30*Math.max(0,util-.7))*expMix(S,'sched',EXP.shop),ir=done>0?inc/done*100:0,card=expMix(S,'media',EXP.card);
 var score=clamp(100-Math.min(30,rw*2.5)-Math.min(20,sw*.6)-Math.min(30,ir*10)-Math.min(25,(err||0)*150)+10*card-5,0,100);
 return {replyWait:rw,shopWait:sw,incRate:ir,aiErr:err||0,reviews:done*expMix(S,'media',EXP.rev)*(S.rating>=4.3?1:.7),card:card,expScore:score};}

function shopStep(S){
 var P=S.P,c=S.ctx,w=S.w,k=12/52,econ=P.econ,lv=P.lv;
 /* 部署：記建置費 */
 var setupCost=0;
 ROLES.forEach(function(r){var l=lv[r.id];var key=r.id+l;if(l&&!S.setupDone[key]){S.setupDone[key]=1;setupCost+=(P.aiSetupOverride!=null?0:r.L[l-1].setup);S.age[r.id]=0;}});
 if(P.aiSetupOverride!=null&&!S.setupDone.__ov){S.setupDone.__ov=1;setupCost+=P.aiSetupOverride;}
 /* 查詢 */
 var wom=rv(S,'media','wom');
 var inq=P.inq*P.inqMult*(.6+.4*econ)*(1+(S.rating-4.5)*.6)*(.7+.3*Math.min(2,P.ads/3000))*(1+wom)*(1-.2*S.scandal);
 inq=Math.max(0,inq);
 /* 老闆行政時間 */
 var admin=inq*ADMIN.replyPerInq*rv(S,'reply','keep')+S.lastBooked*ADMIN.perBooking*rv(S,'sched','keep')
  +(lv.recall?ADMIN.recallManual*rv(S,'recall','keep'):0)+ADMIN.acct*rv(S,'acct','keep')+ADMIN.media*rv(S,'media','keep')+ADMIN.misc;
 /* 前台職員分擔一半行政；創辦人工作（v0.4）食老闆時間 */
 if(P.front)admin*=.55;admin+=(P.extraAdminH||0)*60;
 /* 產能 */
 var dayMin=P.openH*60-45,nonOwner=Math.max(0,P.groomers-(P.ownerGrooms?1:0));
 var availNon=Math.max(0,nonOwner-S.gVac);
 var Gnon=Math.max(0,availNon-S.gNew*.3)*P.groomerDays*dayMin;
 var Gown=P.ownerGrooms?Math.max(0,(P.ownerDays||P.groomerDays)*dayMin-admin):0;
 var G=(Gnon+Gown)*P.capMult,A=P.assistantH*60;
 var gAvg=0,aAvg=0,base=0,beh=0;
 SEGS.forEach(function(g){gAvg+=g.share*g.g*(1+g.mat*.5);aAvg+=g.share*g.a;base+=g.share*g.price;beh+=g.share*g.beh;});
 var C=Math.min(G/gAvg,(G+A)/(gAvg+aAvg),P.tables*7*dayMin*P.capMult/gAvg,P.tubs*7*dayMin/(aAvg*.6));
 C=Math.max(0,C);
 var capParts=[G/gAvg,(G+A)/(gAvg+aAvg),P.tables*7*dayMin*P.capMult/gAvg,P.tubs*7*dayMin/(aAvg*.6)];
 var capNoAssistant=Math.max(0,Math.min(capParts[0],G/(gAvg+aAvg),capParts[2],capParts[3]));
 /* 會員 */
 var m=P.memberShare,inc=1-P.memberAnyway;
 var fmult=1/(1-inc*(1-P.memberCyc));
 var mv=m*fmult/(m*fmult+(1-m)||1);
 /* 舊客到期同回頭 */
 var file=rv(S,'file','comp'),sec=lv.file?roleDef('file').L[lv.file-1].sec:0;
 var comp=file*(sec>P.willSec?.6:1);
 var profF=.5+.5*comp;
 var cons=P.consent==null?1:P.consent;
 var rec=rv(S,'recall','rec')*profF*cons,react=rv(S,'recall','react')*profF*cons;
 var l3=lv.recall===3;
 var rebook=0,lostDue=0,dues=0,recovered=0,dueT=0,rbT=0;if(!S.trial)S.trial=SEGS.map(function(){return 0;});
 for(var i=0;i<SEGS.length;i++){
  var g=SEGS[i];
  var cyc=g.cyc*(P.cycMult||1)*(1+(1-econ))*(1-m*inc*(1-P.memberCyc));
  var due=S.act[i]/cyc;
  var p=P.ret90*(1-g.sens*(1-econ)*.6)*(1-g.sens*P.compGap*.8)*(1+(S.rating-4.5)*.08)-.10*Math.max(0,P.upsell-.3)+m*.05;
  p+=EXP.kRet*((S.expScore==null?EXP.mid:S.expScore)-EXP.mid)/30;
  p=clamp(p,0,.99);
  var churn=1-p;
  var recv=churn*(DORM[0].share*rec+(l3?(DORM[1].share*.35+DORM[5].share*.1)*rec:0));
  var rb=due*(p+recv);
  rebook+=rb;recovered+=due*recv;dues+=due;
  var lost=due-rb;lostDue+=lost;S.act[i]-=lost;
  /* 第一次嚟嘅客（v0.13，只喺 P.firstRetMult 有設定時用）：第一次回頭率較低；回頭之後先變熟客 */
  if(P.firstRetMult!=null&&S.trial[i]>0){var dT=S.trial[i]/cyc,pT=clamp(p*P.firstRetMult,0,.99),rT=dT*(pT+(1-pT)*DORM[0].share*rec);
   S.trial[i]-=dT;S.act[i]+=rT;rebook+=rT;dues+=dT;lostDue+=dT-rT;dueT+=dT;rbT+=rT;}
 }
 for(var d=0;d<DORM.length;d++)S.dorm[d]+=lostDue*DORM[d].share;
 /* 沉睡客喚回 */
 var R=S.dorm[0]*react+(l3?(S.dorm[1]*react*.35+S.dorm[5]*react*.1):0);
 S.dorm[0]-=S.dorm[0]*react;if(l3){S.dorm[1]-=S.dorm[1]*react*.35;S.dorm[5]-=S.dorm[5]*react*.1;}
 for(d=0;d<DORM.length;d++)S.dorm[d]*=.985;
 /* 新客 */
 var loss=rv(S,'reply','loss');
 var lossAvg=P.afterHours*loss[0]+(1-P.afterHours)*loss[1];
 var err=lv.reply?roleDef('reply').L[lv.reply-1].err*rampEff(S,'reply')*(P.review?.15:1)*(P.replyErrMult||1):0;
 var depF=P.deposit?.9:1;
 var newBook=inq*(1-lossAvg)*P.conv*depF*(1-err*.3);
 var aiReplies=lv.reply>=2?inq*(1-lossAvg):0;
 var errN=drawN(inq*err,c);
 /* 排程 */
 var guard=rv(S,'sched','guard2')>=.99;
 var regular=rebook+R+S.backlog;
 var demand=regular+newBook,cap=C*(1+P.overbook),booked,rejected=0,newAcc,lostDem=0;
 if(demand<=cap){booked=demand;newAcc=newBook;S.backlog=0;}
 else if(guard){
  var regB=Math.min(regular,cap);newAcc=Math.max(0,Math.min(newBook,cap-regB));booked=regB+newAcc;rejected=newBook-newAcc;
  var over=regular-regB;S.backlog=over*.7;var gone=over*.3;lostDem=rejected+gone;S.dorm[5]+=gone*.6;S.dorm[3]+=gone*.4;subAct(S,gone);
 } else {
  var f=cap/demand;booked=cap;newAcc=newBook*f;var ex=demand-cap;
  var exReg=ex*(regular/demand);S.backlog=ex*.55;var goneR=exReg*.45;S.dorm[5]+=goneR*.6;S.dorm[3]+=goneR*.4;subAct(S,goneR);
  rejected=(ex-exReg)*.45;lostDem=ex*.45;
 }
 var lead=C>0?S.backlog/C:0;
 /* 新客加入活躍名單 */
 if(P.firstRetMult!=null){for(var ti=0;ti<SEGS.length;ti++)S.trial[ti]+=newAcc*.92*SEGS[ti].share;addAct(S,R);}else addAct(S,newAcc*.92+R);
 /* no-show 同取消 */
 var ns=P.noShow*rv(S,'reply','ns')*(P.deposit?.5:1);
 var lc=P.lateCancel+(P.noShow-ns)*.3+.02*Math.min(3,lead);
 var refill=rv(S,'sched','refill')*(S.backlog>0?1:.6);
 var noShowN=booked*ns,lcN=booked*lc;
 var arrive=booked*(1-ns-lc)+lcN*refill;
 var done=Math.min(arrive,C);
 var util=C>0?done/C:0;
 /* 客單價 */
 var tMult=1-(1-econ)*.4;
 var addR=clamp(P.addonRate*(1+P.upsell-.3)*(1-(1-econ)),0,.95);
 var ticket=base*P.priceIdx*tMult*(1-mv*P.memberDisc)+addR*P.addonAmt;
 var rev=done*ticket;
 /* 事故 */
 var rush=util>.9?1+(util-.9)*10:1,newbie=1+.5*S.gNew/Math.max(1,P.groomers);
 var noRev=P.review?0:1;
 var wrong=noRev*((lv.file===3?.0015:0)+(lv.reply===3?.001:0));
 var minor=drawN(done*(P.minorRate*rush*newbie+wrong*.5)*P.incidentMult,c);
 var skin=drawN(done*(P.skinRate*(1+2*(1-comp))+wrong*.5)*P.incidentMult,c);
 var stress=drawN(done*P.stressRate*(beh/.1)*rush*P.incidentMult,c);
 var seriousL=done*P.seriousRate*rush*newbie*(1+(1-comp))*P.incidentMult;
 var serious=drawN(seriousL,c);if(w===P.forceSeriousWeek)serious+=1;
 var refunds=minor*450+skin*1200+serious*8000+errN*120;
 S.scandal=Math.min(1,S.scandal*.92+serious*(c.det&&w!==P.forceSeriousWeek?1:1));
 subAct(S,stress*.5+serious*3);S.dorm[3]+=stress*.5+serious*3;
 var complaints=minor+skin+stress*.3+serious+errN*.3;
 /* 口碑 */
 var target=4.7-.3*Math.min(1,lead/2)-(util>.95?.15:0)-err*2+EXP.kRating*((S.expScore==null?EXP.mid:S.expScore)-EXP.mid)/30;
 S.rating=clamp(S.rating+(target-S.rating)*.04-.02*minor-.03*skin-.01*stress-.25*serious-.004*errN,2.5,5);
 /* 美容師離職 */
 var avail2=Math.max(0,nonOwner-S.gVac),q=P.quitRate/52*(util>.92?1.8:1);
 var quits=c.det?avail2*q:binom(avail2,q,c.r);
 if(w===P.forceQuitWeek&&avail2>=.5)quits+=1;
 var followLost=0;
 if(quits>0){followLost=quits/Math.max(1,P.groomers)*sum(S.act)*P.followShare;subAct(S,followLost);S.dorm[5]+=followLost;}
 S.gVac+=quits;
 var hires=c.det?S.gVac/P.hireWeeks:binom(S.gVac,1/P.hireWeeks,c.r);
 if(w===P.forceQuitWeek)hires=0;
 S.gVac=Math.max(0,S.gVac-hires);S.gNew=S.gNew*(7/8)+hires;
 /* 成本 */
 var empl=Math.max(0,nonOwner-S.gVac);
 var shareNon=(Gnon+Gown)>0?Gnon/(Gnon+Gown):0;
 var wages=empl*P.groomerBase*k+P.groomerComm*done*shareNon;
 var mpf=empl*Math.min(1500,P.groomerBase*.05)*k;
 var asst=P.assistantH*P.assistantRate*1.05;
 var fixed=(P.rent+P.utilities+P.insurance+P.misc+P.ads+(P.extraWages||0))*k;
 var consum=done*P.consum,card=rev*.6*P.cardFee;
 var aiFee=0;ROLES.forEach(function(r){var l=lv[r.id];if(l)aiFee+=r.L[l-1].fee*k;});
 if(P.aiFeeOverride!=null)aiFee=P.aiFeeOverride*k;
 var msgs=(lv.reply?booked*2:0)+(lv.recall>=2?dues:0);
 var mkt=lv.recall?(S.dorm[0]+S.dorm[1])*.25*k*(lv.recall>=2?1:.3):0;
 var msgCost=msgs*P.msgCost+mkt*.64+(lv.reply>=2?inq*P.llmPerConv:0);
 var aiCost=aiFee+setupCost+(P.aiFeeOverride!=null?0:msgCost);
 var cost=wages+mpf+asst+fixed+consum+card+aiCost+refunds;
 var profit=rev-cost;S.cash+=profit;
 S.lastBooked=booked;S.w++;
 ROLES.forEach(function(r){S.age[r.id]++;});
 var h={w:w,lostDem:lostDem,inq:inq,aiReplies:aiReplies,newBook:newBook,newAcc:newAcc,rejected:rejected,booked:booked,demand:demand,cap:C,done:done,util:util,
  ns:ns,lc:lc,noShowN:noShowN,lcN:lcN,lead:lead,backlog:S.backlog,ticket:ticket,addR:addR,rev:rev,cost:cost,profit:profit,cash:S.cash,
  wages:wages+mpf+asst,fixed:fixed,consum:consum+card,aiCost:aiCost,msgCost:msgCost,refunds:refunds,setup:setupCost,
  act:sum(S.act),dorm:sum(S.dorm),dues:dues,rebook:rebook,recovered:recovered,react:R,lostDue:lostDue,followLost:followLost,
  ret:dues>0?rebook/dues:0,retFirst:dueT>0?rbT/dueT:null,retReg:dues-dueT>0?(rebook-rbT)/(dues-dueT):0,trial:sum(S.trial),rating:S.rating,minor:minor,skin:skin,stress:stress,serious:serious,complaints:complaints,errN:errN,
  adminH:admin/60,comp:comp,members:m*sum(S.act),quits:quits,gVac:S.gVac,mv:mv,capParts:capParts,capNoAssistant:capNoAssistant,capAssistantH:P.assistantH};
 var X=expCalc(S,util,minor+skin+stress+serious,done,err);for(var xk in X)h[xk]=X[xk];S.expScore=X.expScore;
 S.hist.push(h);return h;
}
function subAct(S,n){var t=sum(S.act);if(t<=0)return;var f=Math.max(0,1-n/t);for(var i=0;i<S.act.length;i++)S.act[i]*=f;}
function addAct(S,n){for(var i=0;i<SEGS.length;i++)S.act[i]+=n*SEGS[i].share;}

/* 週 → 月合併 */
var SUMK=['lostDem','inq','aiReplies','newBook','newAcc','rejected','booked','demand','cap','done','noShowN','lcN','rev','cost','profit','wages','fixed','consum','aiCost','msgCost','refunds','setup','dues','rebook','recovered','react','lostDue','followLost','minor','skin','stress','serious','complaints','errN','adminH','quits'];
var LASTK=['cash','act','dorm','rating','backlog','lead','comp','members','gVac'];
function toMonths(hist,months){
 /* 每月 = 52/12 週，部分週按比例計 */
 var out=[];months=months||12;
 for(var mo=0;mo<months;mo++){
  var a=mo*WPM,b=(mo+1)*WPM,o={m:mo+1};
  SUMK.forEach(function(k){o[k]=0;});
  var tk=0,ad=0,wt=0,last=null;
  for(var w=Math.floor(a);w<Math.ceil(b)&&w<hist.length;w++){
   var f=Math.min(b,w+1)-Math.max(a,w);if(f<=0)continue;
   var h=hist[w];SUMK.forEach(function(k){o[k]+=h[k]*f;});tk+=h.ticket*h.done*f;ad+=h.addR*h.done*f;wt+=f;last=h;}
  if(!last)break;
  LASTK.forEach(function(k){o[k]=last[k];});
  o.ns=o.booked?o.noShowN/o.booked:0;o.lc=o.booked?o.lcN/o.booked:0;o.util=o.cap?o.done/o.cap:0;
  o.ticket=o.done?tk/o.done:0;o.addR=o.done?ad/o.done:0;o.ret=o.dues?o.rebook/o.dues:0;
  o.conv=o.inq?o.newAcc/o.inq:0;
  out.push(o);
 }
 return out;
}
function runShop(P,o){o=o||{};var S=newShop(P,o),wk=Math.round((o.months||12)*WPM);for(var i=0;i<wk;i++)shopStep(S);return{S:S,hist:S.hist,months:toMonths(S.hist,o.months||12)};}
function lvZero(P){var q=clone(P);ROLES.forEach(function(r){q.lv[r.id]=0;});return q;}
/* 店層總結：AI 店 vs 唔用 AI 嘅傳統對照組 */
function shopSummary(months,skip){
 skip=skip||1;var ms=months.slice(skip),n=ms.length||1;
 function av(k){return sum(ms.map(function(x){return x[k];}))/n;}
 var L=months[months.length-1];
 var ltvYears=1/Math.max(.05,(1-av('ret'))*52/7/ (1)) ;
 return{rev:av('rev'),profit:av('profit'),done:av('done'),util:av('util'),ns:av('ns'),lc:av('lc'),ret:av('ret'),ticket:av('ticket'),addR:av('addR'),
  inq:av('inq'),lostDem:av('lostDem'),aiReplies:av('aiReplies'),conv:av('conv'),rejected:av('rejected'),lead:av('lead'),complaints:av('complaints'),refunds:av('refunds'),
  adminH:av('adminH'),comp:av('comp'),serious:sum(months.map(function(x){return x.serious;})),rating:L.rating,act:L.act,cash:L.cash,
  members:L.members,newAcc:av('newAcc'),lost:av('lostDue')+av('followLost'),aiCost:av('aiCost'),doneTotal:sum(months.map(function(x){return x.done;}))};
}
function ownerLTV(P,sm){
 /* LTV = 客單價 × 每年次數 × 留存年數 × 毛利率 */
 var cyc=0;SEGS.forEach(function(g){cyc+=g.share*g.cyc;});cyc*=(P.cycMult||1);
 var visits=52/cyc,life=1/Math.max(.02,1-sm.ret),years=Math.min(8,life/visits);
 var gm=sm.ticket>0?Math.max(0,(sm.ticket-P.consum-P.groomerComm*.5)/sm.ticket):0;
 return{visits:visits,years:years,gm:gm,ltv:sm.ticket*visits*years*gm,spend:sm.ticket*visits};
}
