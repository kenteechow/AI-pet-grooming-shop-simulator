/* p_ledger：月結口徑同保險申索（v0.13）。
   - 經營利潤 = 完成服務營收 − 經營支出（人工、租金等固定開支、用品、AI 月費、退款）。老闆底薪唔係經營支出，係月結時由公司現金畀老闆。
   - 一次性收支（AI 建置費、事件開支、事故賠償、保險賠款、注資、借貸收入）唔計入經營利潤，逐筆記低（`s.mled`），月結分開列。
   - 對數：月初公司現金 ＋ 經營利潤 − 老闆底薪 − 貸款還款 − 轉入小金庫 ± 一次性收支 ＝ 月末公司現金。
   - 小金庫係老闆個人錢，唔係公司現金。
   - 保險：事故費用先由店舖墊支；有公眾責任保險、而金額高過墊底費先可以申索；保險公司審核 3–6 週，可能全數（扣墊底費）、部分或者拒賠。比率係示範估算，唔係保單條款。 */
var CLAIM={excess:1000,approve:.7,partial:.2,partialShare:.5};/* 示範估算 */
var LED_CAT={setup:'AI 建置費',event:'事件',claim:'事故賠償',ins:'保險賠款',inject:'由小金庫注資',loan:'借貸收入'};
function oneOff(amt,why,cat){s.cash+=amt;(s.mled=s.mled||[]).push({day:s.day,amt:amt,why:why,cat:cat||'event'});}
/* 月結：記低月初現金同一次性收支，再開新一個月 */
HOOKS.init.push(function(){s.mcash0=s.cash;s.mled=[];s.claims=[];});
HOOKS.month.unshift(function(rec){rec.cash0=s.mcash0;rec.led=(s.mled||[]).slice();rec.ledSum=sum(rec.led.map(function(x){return x.amt;}));});
/* 事故：onDone 會 call。返回實際墊支金額 */
var INC_COST={minor:300,skin:600,stress:0,serious:12000};/* 示範估算：獸醫檢查、藥費、賠償 */
function incidentCost(a){var ex=INC_COST[a.inc]||0;if(!ex)return 0;
 oneOff(-ex,'「'+a.pet+'」'+({minor:'甲剪深咗，帶去睇獸醫',skin:'皮膚敏感，藥費',serious:'嚴重事故，獸醫費同賠償'}[a.inc]||'事故'),'claim');
 s.claims=s.claims||[];var c={id:'c'+(s.nextId++),day:s.day,pet:a.pet,owner:a.owner,amt:ex,st:'self',paid:0};
 if(!s.ins||!s.ins.pl){c.st='noins';news('保險','冇買公眾責任保險：「'+a.pet+'」嘅 '+hk(ex)+' 全數自己畀');}
 else if(ex<=CLAIM.excess){c.st='under';news('保險','「'+a.pet+'」嘅 '+hk(ex)+' 低過墊底費 '+hk(CLAIM.excess)+'，唔值得申索，自己畀');}
 else{c.st='pending';c.due=s.day+21+Math.floor(R()*22);var r=R();c.out=r<CLAIM.approve?'paid':r<CLAIM.approve+CLAIM.partial?'partial':'rejected';
  news('保險','「'+a.pet+'」嘅 '+hk(ex)+' 先由店舖墊支，已經向保險公司申索（墊底費 '+hk(CLAIM.excess)+'），審核大約 3–6 週');}
 s.claims.unshift(c);if(s.claims.length>40)s.claims.length=40;return ex;}
HOOKS.day.push(function(){(s.claims||[]).forEach(function(c){if(c.st!=='pending'||s.day<c.due)return;
 if(c.out==='rejected'){c.st='rejected';news('保險','保險公司拒絕「'+c.pet+'」嘅申索（理由：屬保單除外責任），'+hk(c.amt)+' 要自己承擔');return;}
 var pay=Math.max(0,c.amt-CLAIM.excess)*(c.out==='partial'?CLAIM.partialShare:1);c.paid=pay;c.st=c.out;
 oneOff(pay,'保險賠款：「'+c.pet+'」'+(c.out==='partial'?'（部分）':''),'ins');news('保險','保險公司'+(c.out==='partial'?'只賠部分':'批咗')+'「'+c.pet+'」嘅申索：'+hk(pay)+'（已扣墊底費）');});});
function claimLabel(c){return {noins:['冇買保險，自己畀','bad'],under:['低過墊底費，自己畀',''],pending:['保險審核中，未確認賠唔賠','warn'],paid:['已賠（扣墊底費）','ok'],partial:['部分賠償','warn'],rejected:['拒賠','bad']}[c.st]||[c.st,''];}
/* ---------- 月結明細 ---------- */
function monthStmt(r){
 var c=r.cats||{},row=function(k,v,cls,sub){return '<tr class="'+(cls||'')+'"><td>'+k+(sub?'<small>'+sub+'</small>':'')+'</td><td class="num">'+(v==null?'—':(v>0&&cls!=='tot'&&cls!=='bal'?'+':'')+hk(v))+'</td></tr>';};
 var h='<table class="mt stmt"><tbody>'+row('營收（完成服務）',r.rev)+
  row('經營支出',-r.cost,'',[['人工',c.wages],['租金、水電、保險、雜項',c.fixed],['用品同手續費',c.consum],['AI 月費',c.ai],['退款',c.refunds]].filter(function(x){return x[1];}).map(function(x){return x[0]+' '+hk(x[1]);}).join(' · '))+
  row('經營利潤',r.profit,'tot','未計老闆底薪：老闆唔係支薪員工，底薪喺月結先由公司現金畀');
 if(r.ownerPay!=null){
  h+=row('老闆底薪（實際攞到）',-r.ownerPay,'',r.ownerPay<(r.ownerBase||s.own.base)?'目標 '+hk(r.ownerBase||s.own.base)+'，蝕錢月份只攞七成':'目標 '+hk(r.ownerBase||s.own.base))+
   (r.loanPay?row('貸款還款',-r.loanPay):'')+row('轉入你嘅小金庫',-r.toFund,'',r.toFund?'利潤扣底薪同還款後，剩餘嘅一半':'今個月冇剩餘，冇轉');
  if(r.led){h+=row('一次性收支',r.ledSum,'',r.led.length?'唔計入經營利潤':'今個月冇');
   r.led.forEach(function(x){h+='<tr class="sub"><td>'+esc(LED_CAT[x.cat]||'其他')+'：'+esc(x.why)+'</td><td class="num">'+(x.amt>0?'+':'')+hk(x.amt)+'</td></tr>';});}
  if(r.cash0!=null){var d=r.cash-r.cash0;h+='<tr class="tot"><td>公司現金變動</td><td class="num">'+(d>0?'+':'')+hk(d)+'</td></tr><tr class="bal"><td>月初 → 月末公司現金</td><td class="num">'+hk(r.cash0)+' → '+hk(r.cash)+'</td></tr></tbody></table>';}
  else h+='</tbody></table><p class="note">舊存檔嘅月份冇記低月初現金同一次性收支，只顯示月末公司現金 '+hk(r.cash)+'。</p>';
  h+='<p class="note">你嘅小金庫（個人錢，唔係公司現金）：'+hk(r.fund)+'。</p>';}
 else h+='</tbody></table>';
 return h;}
/* 今個月到而家（未月結） */
function monthSoFar(){var md=monthToDate(),c={wages:0,fixed:0,ai:0,refunds:0,consum:0};md.ds.forEach(function(x){for(var k in c)c[k]+=x.cats[k];});
 var led=(s.mled||[]).slice();return {rev:md.rev,cost:md.ds.reduce(function(a,x){return a+x.cost;},0),profit:md.profit,cats:c,led:led,ledSum:sum(led.map(function(x){return x.amt;}))};}
function claimsHTML(){var L=s.claims||[];if(!L.length)return '<h3>事故費用同申索</h3><p class="note">未有事故。</p>';
 return '<h3>事故費用同申索</h3><ul class="clml">'+L.map(function(c){var lb=claimLabel(c);return '<li><div class="clm1"><b>'+dateStr(c.day).replace(/^\d+年/,'')+'</b><span>'+esc(c.pet)+(c.owner?'（'+esc(c.owner)+'）':'')+'</span><span class="num">墊支 '+hk(c.amt)+'</span><span class="pill '+lb[1]+'">'+lb[0]+'</span></div>'+
  '<div class="clm2">'+(c.st==='pending'?'約 '+dateStr(c.due).replace(/^\d+年/,'')+' 有結果':c.paid?'保險賠 '+hk(c.paid)+'，自己承擔 '+hk(c.amt-c.paid):'自己承擔 '+hk(c.amt))+'</div></li>';}).join('')+'</ul>';}
function ledSoFar(){var L=s.mled||[];return '<h3>今個月一次性收支（唔計入經營利潤）</h3>'+(L.length?'<table class="mt"><tbody>'+L.map(function(x){return '<tr><td>'+esc(LED_CAT[x.cat]||'其他')+'：'+esc(x.why)+'<small>'+dateStr(x.day).replace(/^\d+年/,'')+'</small></td><td class="num">'+(x.amt>0?'+':'')+hk(x.amt)+'</td></tr>';}).join('')+'</tbody></table>':'<p class="note">今個月未有。</p>');}
/* 隔籬（對照店）都有事故費用：假設佢有買公眾責任保險，按期望值每日扣現金（唔計入經營利潤，同你嘅口徑一樣） */
HOOKS.day.push(function(){if(!s.wk||!s.wk.hs||!s.shDaily)return;var h=s.wk.hs,ins=(INC_COST.serious-CLAIM.excess)*(CLAIM.approve+CLAIM.partial*CLAIM.partialShare);
 s.shCash-=((h.minor||0)*INC_COST.minor+(h.skin||0)*INC_COST.skin+(h.serious||0)*(INC_COST.serious-ins))/7;});
