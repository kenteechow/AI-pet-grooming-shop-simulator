/* p_exp：AI 對客人嘅效果同「客人體驗」（v0.22）。
   - AI 部署面板：每個崗位寫明每一級對客人嘅效果（同冇 AI 比），總覽寫埋升下一級會變成點；部署之後顯示「部署前 4 週 → 最近 4 週」實際變化。
   - 客人 → 體驗：體驗分、回覆等候、到店等候、等位、事故率、評價、報告卡、AI 答錯；寫明邊個 AI 幫到、點樣影響評分同回頭率。
   - 客人 → 毛孩故事：揀一隻真係嚟過、有留低紀錄嘅毛孩，按日睇佢每次到店、觀察、報告卡、評價同下次預約。
   數字由引擎同崗位參數計（示範估算），實際變化會受其他因素影響（季節、事件、產能），唔可以全部歸因於 AI。 */
function effUtil(){return s&&s.wk&&s.wk.h?s.wk.h.util:.8;}
function effVal(id,l){var P=s.S.P,r=roleDef(id),L=l?r.L[l-1]:null,u=effUtil(),o={};
 if(id==='reply'){var loss=L&&L.loss?L.loss:L0.reply.loss;o.loss=P.afterHours*loss[0]+(1-P.afterHours)*loss[1];o.ns=P.noShow*(L?L.ns:1)*(P.deposit?.5:1);o.wait=P.afterHours*EXP.ahWait[l]+(1-P.afterHours)*EXP.bhWait[l]*(1+u);o.err=L?L.err*(s.review?.15:1):0;}
 else if(id==='sched'){o.refill=L?L.refill:L0.sched.refill;o.shop=(6+30*Math.max(0,u-.7))*EXP.shop[l];o.guard=l>=3;}
 else if(id==='file'){o.comp=L?L.comp:L0.file.comp;o.skin=(1+2*(1-o.comp))/(1+2*(1-L0.file.comp));o.serious=(1+(1-o.comp))/(1+(1-L0.file.comp));}
 else if(id==='media'){o.wom=L?L.wom:0;o.rev=EXP.rev[l];o.card=EXP.card[l];}
 else if(id==='recall'){o.rec=L?L.rec:0;o.react=L?L.react:L0.recall.react;}
 return o;}
var EFF_FMT={loss:['查詢流失',function(v){return pct(v);}],ns:['No-show',function(v){return (v*100).toFixed(1)+'%';}],wait:['回覆等候',function(v){return v<1?Math.round(v*60)+' 分鐘':v.toFixed(1)+' 小時';}],err:['AI 答錯',function(v){return (v*100).toFixed(1)+'%';}],
 refill:['取消後補到位',function(v){return pct(v);}],shop:['到店等候',function(v){return Math.round(v)+' 分鐘';}],guard:['爆滿時保住熟客',function(v){return v?'有':'冇';}],
 comp:['毛孩紀錄完整',function(v){return pct(v);}],skin:['皮膚問題風險',function(v){return v>=.995?'基準':'基準 × '+v.toFixed(2);}],serious:['嚴重事故風險',function(v){return v>=.995?'基準':'基準 × '+v.toFixed(2);}],
 wom:['口碑帶嚟查詢',function(v){return v?'+'+Math.round(v*100)+'%':'冇';}],rev:['主人留評價',function(v){return Math.round(v*100)+'%';}],card:['收到報告卡',function(v){return pct(v);}],
 rec:['到期有提醒',function(v){return pct(v);}],react:['沉睡客每週喚回',function(v){return (v*100).toFixed(1)+'%';}]};
var EFF_MAIN={reply:['loss','ns','wait'],sched:['refill','shop'],file:['comp','skin'],media:['wom','rev','card'],recall:['rec','react'],acct:[]};
/* 總覽一行：升下一級會變成點（最高級就寫同冇 AI 比） */
function aiEffLine(id,l){var keys=EFF_MAIN[id];if(!keys.length)return '<small class="aieff">客人方面：冇直接影響（幫你睇數同毛利）</small>';
 var a=l<3?effVal(id,l):effVal(id,0),b=l<3?effVal(id,l+1):effVal(id,3);
 return '<small class="aieff">'+(l<3?'升 L'+(l+1)+'：':'同冇 AI 比：')+keys.map(function(k){var F=EFF_FMT[k];return F[0]+' '+F[1](a[k])+' → '+F[1](b[k]);}).join(' · ')+'</small>';}
/* 部署前後實際：用引擎每週紀錄，部署前 4 週平均 vs 最近 4 週 */
var ACT_KEYS={reply:['newAcc','ns','replyWait'],sched:['lc','shopWait','done'],file:['incRate','rating'],media:['inq','reviews','expScore'],recall:['ret','react'],acct:[]};
var ACT_FMT={newAcc:['每週新客',1],ns:['No-show','%'],replyWait:['回覆等候（小時）',1],lc:['臨時取消','%'],shopWait:['到店等候（分鐘）',0],done:['每週完成',0],incRate:['每百隻事故',2],rating:['評分',2],inq:['每週查詢',0],reviews:['每週新評價',1],expScore:['體驗分',0],ret:['熟客回頭率','%'],react:['每週喚回沉睡客',1]};
function histAvg(H,k){var v=H.map(function(h){return h[k];}).filter(function(x){return x!=null&&isFinite(x);});return v.length?v.reduce(function(a,b){return a+b;},0)/v.length:null;}
function actFmt(k,v){if(v==null)return '—';var f=ACT_FMT[k][1];return f==='%'?(v*100).toFixed(1)+'%':v.toFixed(f);}
HOOKS.init.push(function(){s.aiSnap={};s.revN=0;});
if(typeof deploy==='function'){var _effDeploy=deploy;deploy=function(id,l){var before=s.lv[id];_effDeploy.apply(this,arguments);
 if(s.lv[id]!==before&&s.S&&s.S.hist){s.aiSnap=s.aiSnap||{};var week=Math.floor(s.day/7),H=s.S.hist.filter(function(h){return h.w<week;}).slice(-4),o={};ACT_KEYS[id].forEach(function(k){o[k]=histAvg(H,k);});s.aiSnap[id]={day:s.day,l:l,w:s.S.hist.length,m:o,beforeWeeks:H.length};}};}
function recordedWeeks(first,last){var weeks=[];for(var w=first;w<last;w++){var days=(s.days||[]).filter(function(d){return Math.floor(d.day/7)===w;});if(days.length===7)weeks.push(days.reduce(function(n,d){return n+(d.done||0);},0));}return weeks;}
function aiActual(id){var sn=s.aiSnap&&s.aiSnap[id],keys=ACT_KEYS[id];if(!sn||!keys.length)return '';var start=Math.floor(sn.day/7)+1,end=Math.floor(s.day/7),after=s.S.hist.filter(function(h){return h.w>=start&&h.w<end;}).slice(-4),level=roleDef(id).L[sn.l-1],before=recordedWeeks(Math.max(0,Math.floor(sn.day/7)-4),Math.floor(sn.day/7)),recorded=recordedWeeks(Math.max(start,end-4),end);
 var h='<h4>部署前 → 最近完整週（模型估算）</h4><p class="note">'+dateStr(sn.day).replace(/^\d+年/,'')+' 部署 L'+sn.l+'；部署需 '+level.wk+' 週，其後磨合 4 週。部署當週不計入比較。'+(rampPct(id)<1?'目前仍在部署或磨合中。':'目前已完成磨合。')+'</p>';
 if(after.length<2)h+='<p class="note">部署後至少要有兩個完整星期先可比較。</p>';
 else h+='<p class="note">部署前 '+(sn.beforeWeeks==null?'舊存檔（週數未記錄）':sn.beforeWeeks+' 週')+'，部署後 '+after.length+' 週；以下係遊戲模型推算，唔係逐單統計。</p><table class="mt"><tbody>'+keys.map(function(k){return '<tr><td>'+ACT_FMT[k][0]+'</td><td class="num">'+actFmt(k,sn.m&&sn.m[k])+' → '+actFmt(k,histAvg(after,k))+'</td></tr>';}).join('')+'</tbody></table>';
 var avg=function(a){return a.length?(a.reduce(function(x,y){return x+y;},0)/a.length).toFixed(1)+' 隻／週':'資料不足';};
 return h+'<h4>遊戲內記錄：完成服務</h4><p>部署前 '+before.length+' 個完整週：'+avg(before)+'；部署後最近 '+recorded.length+' 個完整週：'+avg(recorded)+'。</p><p class="note">按遊戲每日完成記錄計算；較舊記錄可能已清理。季節、事件、人手等都會影響結果，變化不能全歸因於 AI；數值不代表現實成效。</p>';}
/* 崗位頁：每級對客人嘅效果 */
function aiEffDetail(id,l){var keys=EFF_MAIN[id];
 var h='<h4>對客人嘅效果（示範估算）</h4>';if(!keys.length)return h+'<p class="note">呢個崗位唔直接影響客人；幫你睇毛利、套票同改價風險。</p>';
 h+='<table class="mt eff"><thead><tr><th></th><th>冇 AI</th><th>L1</th><th>L2</th><th>L3</th></tr></thead><tbody>'+keys.map(function(k){var F=EFF_FMT[k];return '<tr><td>'+F[0]+'</td>'+[0,1,2,3].map(function(i){return '<td class="num'+(i===(l||0)?' cur':'')+'">'+F[1](effVal(id,i)[k])+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table>';
 return h+aiActual(id);}
/* ---------- 客人體驗 ---------- */
HOOKS.plan=HOOKS.plan||[];HOOKS.plan.push(function(){if(s.wk&&s.wk.h&&s.wk.h.reviews!=null)s.revN=(s.revN||0)+s.wk.h.reviews;});
function expHints(){return {replyWait:'「覆」L2 以上 AI 即時答，收工後都唔使等到第二朝',shopWait:'太忙會長；「排」L2／L3 排時段準啲',lead:'做唔切就要等位；加人、加枱或者「排」L3 保住熟客',incRate:'「檔」紀錄齊，皮膚同嚴重事故少啲；落手做做得好都有幫助',reviews:'「影」L2 報告卡、L3 評價邀請',card:'「影」L2 以上每隻都有前後相報告',aiErr:'開「人工審核」，AI 答錯少好多'};}
function pExp(){var H=s.S.hist,cur=H[H.length-1]||{},old=H.length>4?H[H.length-5]:null,hn=expHints();
 var card=function(k,label,v,fmt,better,extra){var o=old&&old[k]!=null?old[k]:null,d=o==null?'':(Math.abs(v-o)<1e-9?'同 4 週前一樣':(better==='low'?(v<o?'▲ 好咗':'▼ 差咗'):(v>o?'▲ 好咗':'▼ 差咗'))+'（4 週前 '+fmt(o)+'）');
  return '<div class="insc"><div class="insh"><b>'+label+'</b><span class="pill'+(/好咗/.test(d)?' ok':/差咗/.test(d)?' warn':'')+'">'+fmt(v)+'</span></div>'+(d?'<p class="note">'+d+'</p>':'')+'<p>'+(hn[k]||extra||'')+'</p></div>';};
 if(cur.expScore==null)return '<p class="note">下星期一開始有體驗數據。</p>';
 var f1=function(v){return v<1?Math.round(v*60)+' 分鐘':v.toFixed(1)+' 小時';},fm=function(v){return Math.round(v)+' 分鐘';},fd=function(v){return (v*7).toFixed(1)+' 日';},fi=function(v){return v.toFixed(2)+' 宗';},fr=function(v){return v.toFixed(1)+' 個';},fp=function(v){return pct(v);};
 var sc=cur.expScore;
 return '<div class="glh"><span class="gllv">'+Math.round(sc)+'</span><div><b>本週客人體驗分</b><small>'+(sc>=85?'好好':sc>=70?'唔錯':sc>=55?'一般':'差')+' · 70 分係中間；高過 70 評分會慢慢升、熟客回頭率高少少，低過就相反</small><span class="bar"><i style="width:'+Math.round(sc)+'%"></i></span></div></div>'+
  '<div class="insg">'+card('replyWait','回覆等候',cur.replyWait,f1,'low')+card('shopWait','到店等候',cur.shopWait,fm,'low')+card('lead','等位',cur.lead||0,fd,'low')+card('incRate','每百隻事故',cur.incRate,fi,'low')+
  card('reviews','本週新評價',cur.reviews,fr,'high','累計約 '+Math.round(s.revN||0)+' 個。'+hn.reviews)+card('card','收到報告卡',cur.card,fp,'high')+card('aiErr','AI 答錯',cur.aiErr||0,function(v){return (v*100).toFixed(1)+'%';},'low')+'</div>'+
  '<p class="note">體驗分 = 100 − 回覆等候 − 到店等候 − 事故率 − AI 答錯 ＋ 報告卡 − 5（各項有上限）。上星期嘅體驗分影響今個星期評分走向（最多 ±0.08）同熟客回頭率（最多 ±2 個百分點）。全部係示範估算。</p>';}
/* ---------- 毛孩故事：真係嚟過、有紀錄嘅毛孩 ---------- */
function storyPets(){if(!s.cl)return [];var L=[];for(var k in s.cl.pets){var p=s.cl.pets[k];if(p.cnt&&p.cnt.done>0)L.push(p);}
 return L.sort(function(a,b){var na=a.notes.length+(a.reports||[]).length,nb=b.notes.length+(b.reports||[]).length;return (nb>0)-(na>0)||(b.last||0)-(a.last||0);});}
var storyUI={q:'',filter:'all',breed:'',page:0},STORY_PAGE=20;
function storyMatch(p){var q=storyUI.q.trim().toLowerCase(),o=clOwner(p.oid),rec=p.notes.length+(p.reports||[]).length;return (!q||[p.name,p.breed,p.id,o&&o.name].join(' ').toLowerCase().indexOf(q)>=0)&&(!storyUI.breed||p.breed===storyUI.breed)&&(storyUI.filter==='all'||(storyUI.filter==='records'&&rec>0)||(storyUI.filter==='repeat'&&p.cnt.done>1));}
function storyHTML(p){var o=clOwner(p.oid),g=SEGS.filter(function(x){return x.id===p.seg;})[0],ev={},add=function(d,h){(ev[d]=ev[d]||[]).push(h);},n=0;
 p.visits.slice().sort(function(a,b){return a.day-b.day||(a.t||0)-(b.t||0);}).forEach(function(v){
  if(v.st==='done'){n++;var h='<span class="story-tag">第 '+n+' 次到店 · '+hm(v.t||0)+'</span><h3>'+(SVC[v.svc]?SVC[v.svc].n:'')+' · '+esc(v.gname||'')+'</h3><p>收費 '+hk(v.price||0)+'。</p>';
   if(v.inc)h+='<div class="story-observation warning"><b>今次出咗事</b><p>'+esc(FB_BAD[v.inc]||v.inc)+'</p></div>';
   if(v.fb)h+='<div class="story-observation"><b>主人評價'+(v.fb.stars?' · '+v.fb.stars+' 星':'')+'</b><p>「'+esc(v.fb.txt)+'」</p></div>';add(v.day,h);}
  else if(v.st==='noshow'||v.st==='cancel')add(v.day,'<span class="story-tag">'+(v.st==='noshow'?'預約咗但冇嚟':'臨時取消')+'</span><p>'+hm(v.t||0)+' '+(SVC[v.svc]?SVC[v.svc].n:'')+'</p>');});
 p.notes.forEach(function(x){var src={groomer:'美容師觀察',ai:'AI 草稿',owner:'主人講'}[x.src]||'紀錄',st={draft:'未確認',confirmed:'已確認',corrected:'美容師改正咗',owner:'主人講'}[x.st]||'';
  add(x.day,'<div class="story-observation'+(x.st==='draft'?' warning':'')+'"><b>'+src+' · '+st+(x.by?' · '+esc(x.by):'')+'</b><p>'+(x.st==='corrected'?'<s>'+esc(x.txt)+'</s> → '+esc(x.fix):esc(x.txt))+'</p>'+(x.kind==='health'&&x.st!=='draft'?'<small>已通知主人，建議睇獸醫（美容店唔做診斷）</small>':'')+'</div>');});
 (p.reports||[]).forEach(function(r){add(r.day,'<div class="report-card"><div class="report-head"><span class="report-icon">'+esc(p.name.slice(0,1))+'</span><div><b>'+esc(p.name)+' 嘅美容報告卡</b><small>'+(r.rev?'美容師確認後發出':'冇人工審核直接發出')+'</small></div></div><div class="report-line"><b>觀察</b><span>'+esc(r.lines.join('；')||'冇特別觀察')+'</span></div>'+(r.err?'<div class="report-line"><b>寫錯咗</b><span>'+esc(r.err)+'（未確認嘅 AI 草稿）</span></div>':'')+'</div>');});
 var days=Object.keys(ev).map(Number).sort(function(a,b){return a-b;}),nx=clNextAppt(p),due=p.last!=null?p.last+(CL_CYCLE[p.seg]||35):null;
 var os=o?clOwnerStats(o):null;
 return '<div class="story-hero"><span class="eyebrow">毛孩故事 · 真實紀錄</span><h3>'+esc(p.name)+'</h3><p>'+esc(p.breed)+' · '+g.name+' · 主人 '+esc(o?o.name:'')+' · 由 '+dateStr(p.since).replace(/^\d+年/,'')+' 開始 · 完成 '+p.cnt.done+' 次'+(os&&os.avg?' · 主人平均 '+os.avg.toFixed(1)+' 星':'')+'</p><button class="btn" data-act="clopen" data-p="'+p.id+'">睇完整檔案</button></div>'+
  '<div class="story-tl">'+days.map(function(d){return '<div class="stl-day"><div class="stl-date">'+dateStr(d).replace(/^\d+年/,'')+'</div><div class="story-content">'+ev[d].join('')+'</div></div>';}).join('')+
  '<div class="stl-day"><div class="stl-date">之後</div><div class="story-content">'+(nx?'<span class="story-tag">下次預約</span><p>'+dateStr(nx.day).replace(/^\d+年/,'')+' '+hm(nx.a)+' · '+(SVC[nx.svc]?SVC[nx.svc].n:'')+'</p>':'<span class="story-tag">未有下次預約</span><p>'+(due!=null?'按 '+g.name+' 嘅週期，大約 '+dateStr(due).replace(/^\d+年/,'')+' 到期。'+((s.lv.recall||0)>=1?'「回」會提醒主人。':'冇開「回」，要靠主人自己記得。'):'')+'</p>')+'</div></div></div>';}
function petStoryReal(){var all=storyPets();
 if(s.storyDemo||s.demo||!all.length)return (all.length&&!s.demo?'<button class="tback" data-act="storyreal">‹ 返去真實毛孩</button>':'')+petStory()+(!all.length?'<p class="note">完成第一隻服務之後，呢度會改為顯示真係嚟過嘅毛孩故事。</p>':'');
 var breeds=all.map(function(p){return p.breed;}).filter(function(x,i,L){return x&&L.indexOf(x)===i;}).sort(function(a,b){return a.localeCompare(b,'zh-Hant');});if(storyUI.breed&&breeds.indexOf(storyUI.breed)<0)storyUI.breed='';var L=all.filter(storyMatch);
 storyUI.page=Math.min(storyUI.page,Math.max(0,Math.ceil(L.length/STORY_PAGE)-1));var page=L.slice(storyUI.page*STORY_PAGE,(storyUI.page+1)*STORY_PAGE),cur=page.filter(function(p){return p.id===s.storyPid;})[0]||page[0];if(cur)s.storyPid=cur.id;
 var i=L.indexOf(cur),lab=function(p){var rec=p.notes.length+(p.reports||[]).length;return esc(p.name)+'（'+esc(p.breed)+'）· '+p.cnt.done+' 次'+(rec?' · '+rec+' 條紀錄':'')+' · 上次 '+dateStr(p.last).replace(/^\d+年/,'');};
 var controls='<div class="story-pick"><label for="storySearch">搜尋毛孩、主人或品種</label><input id="storySearch" data-act="storysearch" value="'+esc(storyUI.q)+'" placeholder="輸入名稱或品種"><select data-act="storyfilter" aria-label="篩選毛孩"><option value="all"'+(storyUI.filter==='all'?' selected':'')+'>全部紀錄</option><option value="records"'+(storyUI.filter==='records'?' selected':'')+'>有觀察或報告</option><option value="repeat"'+(storyUI.filter==='repeat'?' selected':'')+'>到店多於一次</option></select><select data-act="storybreed" aria-label="篩選品種"><option value="">全部品種</option>'+breeds.map(function(b){return '<option value="'+esc(b)+'"'+(storyUI.breed===b?' selected':'')+'>'+esc(b)+'</option>';}).join('')+'</select><span class="note">符合 '+L.length+'／'+all.length+' 隻'+(L.length?' · 第 '+(storyUI.page+1)+'／'+Math.ceil(L.length/STORY_PAGE)+' 頁':'')+'</span>';
 if(cur)controls+='<select id="storySel" data-act="storysel" aria-label="選擇毛孩">'+page.map(function(p){return '<option value="'+p.id+'"'+(p.id===cur.id?' selected':'')+'>'+lab(p)+'</option>';}).join('')+'</select><button class="btn" data-act="storypage" data-page="'+(storyUI.page-1)+'"'+(storyUI.page===0?' disabled':'')+'>上一頁</button><button class="btn" data-act="storypage" data-page="'+(storyUI.page+1)+'"'+((storyUI.page+1)*STORY_PAGE>=L.length?' disabled':'')+'>下一頁</button><button class="btn" data-act="storypet" data-p="'+L[(i-1+L.length)%L.length].id+'">‹ 上一隻</button><button class="btn" data-act="storypet" data-p="'+L[(i+1)%L.length].id+'">下一隻 ›</button>';
 return controls+'<button class="btn" data-act="storydemo">示範故事（虛構）</button></div>'+(cur?storyHTML(cur):'<p class="note">搵唔到符合條件嘅毛孩，試下更改搜尋或篩選。</p>');}
if(typeof pCust==='function'){var _effCust=pCust;pCust=function(sub){if(sub==='exp')return pExp();if(sub==='story')return petStoryReal();return _effCust.apply(this,arguments);};}
if(typeof SUBS!=='undefined'&&SUBS.cust&&!SUBS.cust.some(function(x){return x[0]==='exp';}))SUBS.cust.splice(1,0,['exp','體驗']);
if(typeof document!=='undefined')document.addEventListener('input',function(e){if(!e.target.matches('[data-act=storysearch]')||!s)return;var pos=e.target.selectionStart;storyUI.q=e.target.value;storyUI.page=0;renderPanel();var input=document.querySelector('[data-act=storysearch]');if(input){input.focus();input.setSelectionRange(pos,pos);}});
if(typeof document!=='undefined')document.addEventListener('change',function(e){if(!s)return;if(e.target.matches('[data-act=storyfilter]')){storyUI.filter=e.target.value;storyUI.page=0;renderPanel();}else if(e.target.matches('[data-act=storybreed]')){storyUI.breed=e.target.value;storyUI.page=0;renderPanel();}else if(e.target.matches('[data-act=storysel]')){s.storyPid=e.target.value;s.storyDemo=0;e.target.blur();renderPanel();}});
if(typeof document!=='undefined')document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');
 if(a==='storypage'){storyUI.page=Number(el.getAttribute('data-page'));s.storyPid=null;renderPanel();}if(a==='storypet'){s.storyPid=el.getAttribute('data-p');var list=storyPets().filter(storyMatch),target=list.filter(function(p){return p.id===s.storyPid;})[0];if(target)storyUI.page=Math.floor(list.indexOf(target)/STORY_PAGE);s.storyDemo=0;renderPanel();}if(a==='storydemo'){s.storyDemo=1;s.petStory=0;renderPanel();}if(a==='storyreal'){s.storyDemo=0;renderPanel();}});
