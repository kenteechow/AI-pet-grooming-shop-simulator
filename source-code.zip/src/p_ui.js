/* p_ui：標題畫面同沙盒模擬器介面。 */
var UI={P:null,F:null,scen:'base',tab:'ov',R:null,sens:null,sensT:'founder',sensFor:null,mc:null,mcN:200,mcBusy:false,mcProg:0,mcStale:false,cmp:null,q:null,shut:true,timer:0};
var AVG_PRICE=0,AVG_CYC=0;SEGS.forEach(function(g){AVG_PRICE+=g.share*g.price;AVG_CYC+=g.share*g.cyc;});

function fmtv(t,v){
 switch(t){case 'hk':return hk(v);case 'pct':return pct(v).replace('.0%','%');case 'int':return Math.round(v).toLocaleString('en-US');
 case 'h':return v+' 小時';case 'x':return '×'+(+v).toFixed(2);case 'sec':return v+' 秒';case 'wk':return v+' 週';case 'mo':return v+' 個月';
 case 'inv':return '1/'+Math.round(1/v).toLocaleString('en-US');default:return (+v).toFixed(2);}
}
/* 參數定義：k 路徑、t 格式、tag 來源標記（src 有來源、est 示範估算、chk 要向真實店核實） */
var PG=[
 {g:'店舖同產能',open:1,items:[
  {k:'P.groomers',l:'美容師人數（連老闆）',min:1,max:6,step:1,t:'int'},{k:'P.ownerGrooms',l:'老闆自己做美容',chk:1},
  {k:'P.groomerDays',l:'每人每週返工日',min:4,max:7,step:1,t:'int'},{k:'P.openH',l:'每日營業時數',min:6,max:12,step:.5,t:'h'},
  {k:'P.tables',l:'美容枱',min:1,max:6,step:1,t:'int'},{k:'P.tubs',l:'浴缸',min:1,max:4,step:1,t:'int'},
  {k:'P.assistantH',l:'助理每週時數',min:0,max:80,step:5,t:'h'},{k:'P.capMult',l:'產能倍數（加減人手效率）',min:.6,max:1.6,step:.05,t:'x'}]},
 {g:'價錢同客源',open:1,items:[
  {k:'P.priceIdx',l:'價錢倍數',min:.7,max:1.5,step:.05,t:'x',show:function(v){return '×'+v.toFixed(2)+'（基本 '+hk(AVG_PRICE*v)+'）';},tag:'src'},
  {k:'P.addonRate',l:'加購率',min:0,max:.8,step:.05,t:'pct',tag:'chk'},{k:'P.addonAmt',l:'加購金額',min:0,max:300,step:10,t:'hk'},
  {k:'P.inq',l:'每週新客查詢',min:5,max:120,step:1,t:'int',tag:'chk'},{k:'P.afterHours',l:'收工後查詢佔比',min:0,max:.7,step:.05,t:'pct',tag:'chk'},
  {k:'P.conv',l:'收到報價後落實預約',min:.2,max:.9,step:.05,t:'pct',tag:'est'},{k:'P.active',l:'現有活躍客',min:50,max:1000,step:10,t:'int',tag:'chk'},
  {k:'P.ads',l:'每月廣告費',min:0,max:15000,step:500,t:'hk'}]},
 {g:'回訪同流失',items:[
  {k:'P.ret90',l:'熟客到期回頭率',min:.5,max:.97,step:.01,t:'pct',tag:'chk'},
  {k:'P.cycMult',l:'回訪週期倍數',min:.6,max:1.6,step:.05,t:'x',show:function(v){return '×'+v.toFixed(2)+'（平均 '+(AVG_CYC*v).toFixed(1)+' 週）';}},
  {k:'P.noShow',l:'No-show（冇嚟冇講）',min:0,max:.3,step:.01,t:'pct',tag:'chk'},{k:'P.lateCancel',l:'臨時取消（24 小時內）',min:0,max:.2,step:.01,t:'pct',tag:'chk'},
  {k:'P.deposit',l:'收 HK$100 訂金',chk:1},{k:'P.upsell',l:'加購推銷力度',min:0,max:1,step:.05,t:'pct'}]},
 {g:'員工',items:[
  {k:'P.groomerBase',l:'美容師底薪',min:0,max:35000,step:500,t:'hk',tag:'src'},{k:'P.groomerComm',l:'每隻佣金',min:0,max:150,step:5,t:'hk'},
  {k:'P.assistantRate',l:'助理時薪（最低工資 $43.1）',min:44,max:100,step:1,t:'hk',tag:'src'},
  {k:'P.quitRate',l:'美容師每年離職率',min:0,max:.6,step:.05,t:'pct'},{k:'P.followShare',l:'離職時帶走熟客',min:0,max:.6,step:.05,t:'pct',tag:'chk'},
  {k:'P.hireWeeks',l:'請人要幾耐',min:1,max:16,step:1,t:'wk'},{k:'P.willSec',l:'美容師每隻願意輸入',min:5,max:120,step:5,t:'sec',tag:'chk'}]},
 {g:'成本',items:[
  {k:'P.rent',l:'每月租金',min:5000,max:60000,step:500,t:'hk',tag:'est'},{k:'P.utilities',l:'水電',min:1000,max:12000,step:500,t:'hk'},
  {k:'P.insurance',l:'保險',min:0,max:5000,step:100,t:'hk'},{k:'P.misc',l:'雜項',min:0,max:10000,step:500,t:'hk'},
  {k:'P.consum',l:'每次用品',min:10,max:80,step:1,t:'hk'},{k:'P.startCash',l:'店舖起始現金',min:0,max:500000,step:10000,t:'hk'}]},
 {g:'外部環境同事故',items:[
  {k:'P.econ',l:'經濟指數（1 = 正常）',min:.6,max:1.1,step:.05,t:'x'},{k:'P.compGap',l:'對手平幾多',min:0,max:.4,step:.05,t:'pct'},
  {k:'P.inqMult',l:'查詢倍數',min:.5,max:2,step:.05,t:'x'},{k:'P.incidentMult',l:'事故率倍數',min:.2,max:5,step:.1,t:'x'},
  {k:'P.seriousRate',l:'嚴重事故：每幾多次服務 1 次',min:200,max:20000,step:100,inv:1,t:'inv',tag:'est'}]},
 {g:'會員制（店層）',items:[
  {k:'P.memberShare',l:'入會比例',min:0,max:1,step:.05,t:'pct'},{k:'P.memberDisc',l:'會員折扣',min:0,max:.4,step:.01,t:'pct'},
  {k:'P.memberCyc',l:'會員回訪週期倍數',min:.5,max:1,step:.05,t:'x'},{k:'P.memberAnyway',l:'「本身都會嚟」佔會員',min:0,max:1,step:.05,t:'pct',tag:'est'}]},
 {g:'AI 部署',roles:1},
 {g:'創辦人',items:[
  {k:'F.hoursAvail',l:'每月可用時數',min:80,max:240,step:5,t:'h'},{k:'F.contentH',l:'hoslab 內容時數',min:0,max:80,step:5,t:'h'},
  {k:'F.devH',l:'產品開發時數',min:0,max:60,step:5,t:'h'},{k:'F.hourValue',l:'時間成本（計 CAC 用）',min:0,max:500,step:10,t:'hk'},
  {k:'F.startCash',l:'創辦人起始現金',min:0,max:500000,step:10000,t:'hk'},{k:'F.ads',l:'每月廣告費',min:0,max:20000,step:500,t:'hk'},
  {k:'F.cpl',l:'每個 lead 廣告成本',min:100,max:3000,step:50,t:'hk',tag:'est'},{k:'F.leadsContent',l:'內容帶嚟 lead／月',min:0,max:20,step:1,t:'int',tag:'est'},
  {k:'F.market',l:'香港可接觸美容店',min:50,max:1500,step:10,t:'int',tag:'chk'},{k:'F.churnMult',l:'店家流失倍數',min:.3,max:3,step:.1,t:'x'},
  {k:'F.draw',l:'每月自己出糧',min:0,max:40000,step:1000,t:'hk'}]},
 {g:'模式 A：AI 前台 SaaS',model:'A',items:[
  {k:'F.A.fee',l:'每店月費',min:500,max:5000,step:100,t:'hk'},{k:'F.A.setup',l:'搭建費',min:0,max:10000,step:500,t:'hk'},
  {k:'F.A.setupH',l:'每店搭建時數',min:1,max:30,step:1,t:'h'},{k:'F.A.supportH1',l:'頭 2 個月每店支援',min:.5,max:15,step:.5,t:'h'},
  {k:'F.A.supportH',l:'之後每店支援',min:.5,max:10,step:.5,t:'h'},{k:'F.trialTake',l:'lead 肯試用',min:.1,max:.9,step:.05,t:'pct',tag:'est'},
  {k:'F.A.conv',l:'試用轉付費',min:.05,max:.9,step:.05,t:'pct',tag:'chk'}]},
 {g:'模式 B：AI 落地顧問',model:'B',items:[
  {k:'F.B.fee',l:'每月顧問費',min:500,max:8000,step:100,t:'hk'},{k:'F.B.setup',l:'一次性顧問費',min:0,max:50000,step:1000,t:'hk'},
  {k:'F.B.setupH',l:'每店搭建時數',min:5,max:60,step:1,t:'h'},{k:'F.B.supportH',l:'每店每月支援',min:1,max:15,step:.5,t:'h'},
  {k:'F.B.conv',l:'傾完簽約率',min:.05,max:.9,step:.05,t:'pct',tag:'chk'},{k:'F.B.cycle',l:'銷售週期',min:1,max:4,step:1,t:'mo'}]},
 {g:'模式 C：毛孩會員平台',model:'C',items:[
  {k:'F.C.memberFee',l:'會員月費',min:50,max:400,step:2,t:'hk'},{k:'F.C.benefit',l:'每月福利成本',min:0,max:200,step:5,t:'hk'},
  {k:'F.C.comm',l:'服務佣金',min:0,max:.3,step:.01,t:'pct'},{k:'F.C.memberCAC',l:'每位會員獲客成本',min:50,max:1000,step:10,t:'hk',tag:'chk'},
  {k:'F.C.memberChurn',l:'會員每月流失',min:.02,max:.3,step:.01,t:'pct'},{k:'F.C.csPer100',l:'每 100 會員客服時數',min:1,max:30,step:1,t:'h'},
  {k:'F.C.partnerSpare',l:'每間合作店每月空位',min:5,max:100,step:5,t:'int'},{k:'F.C.memberAds',l:'會員廣告費／月',min:0,max:20000,step:500,t:'hk'}]},
 {g:'模式 D：混合',model:'D',items:[
  {k:'F.D.seedShops',l:'種子店數',min:1,max:6,step:1,t:'int'},{k:'F.D.seedDisc',l:'種子店折扣',min:0,max:.8,step:.05,t:'pct'},
  {k:'F.D.caseBoost',l:'有案例後簽約率加幾多',min:0,max:.4,step:.05,t:'pct',tag:'est'},{k:'F.D.memberAtSeed',l:'種子店客人入會',min:0,max:.4,step:.01,t:'pct'},
  {k:'F.D.refComm',l:'轉介佣金',min:0,max:.2,step:.01,t:'pct'},{k:'F.A.fee',l:'轉 SaaS 後月費',min:500,max:5000,step:100,t:'hk'}]}
];
var TAG={src:'有來源',est:'示範估算',chk:'要向真實店核實'};
function pget(path){var p=path.split('.'),o=p[0]==='P'?UI.P:UI.F;for(var i=1;i<p.length-1;i++)o=o[p[i]];return [o,p[p.length-1]];}
function pval(it){var r=pget(it.k),v=r[0][r[1]];return it.inv?Math.round(1/v):v;}
function pshow(it,v){if(it.show)return it.show(v);if(it.inv)return '1/'+Math.round(v).toLocaleString('en-US');return fmtv(it.t,v);}

function resetParams(){UI.P=clone(DEF_SHOP);UI.F=clone(DEF_FOUNDER);applyScen(UI.scen,UI.P,UI.F);}
function invalidate(){UI.sens=null;UI.cmp=null;UI.q=null;if(UI.mc)UI.mcStale=true;}
function recompute(){UI.R=runAll(clone(UI.P),clone(UI.F));}

/* ---------- 側欄 ---------- */
function sideHTML(){
 var h='<button class="btn side-toggle" data-act="side">'+(UI.shut?'顯示參數':'收起參數')+'</button><div class="groups">';
 h+='<p class="note">每個數都係可調整假設。標記：有來源／示範估算／要向真實店核實。</p>';
 PG.forEach(function(G){
  if(G.model&&G.model!==UI.F.model&&!(UI.F.model==='D'&&G.model==='A'&&false))return;
  h+='<details'+(G.open||G.roles||G.model?' open':'')+'><summary>'+G.g+(G.roles?'<span class="lbl">'+aiCount()+'</span>':'')+'</summary><div class="items">';
  if(G.roles)h+=rolesHTML();
  else G.items.forEach(function(it){
   var id='in-'+it.k.replace(/\./g,'-');
   if(it.chk){h+='<div class="prm chk"><input type="checkbox" id="'+id+'" data-k="'+it.k+'"'+(pval(it)?' checked':'')+'><label for="'+id+'">'+it.l+'</label></div>';return;}
   var v=pval(it);
   h+='<div class="prm"><label for="'+id+'">'+it.l+'</label><output id="o-'+id+'">'+esc(pshow(it,v))+'</output><input type="range" id="'+id+'" data-k="'+it.k+'"'+(it.inv?' data-inv="1"':'')+' min="'+it.min+'" max="'+it.max+'" step="'+it.step+'" value="'+v+'">'+(it.tag?'<span class="tag">'+TAG[it.tag]+'</span>':'')+'</div>';
  });
  h+='</div></details>';
 });
 return h+'</div>';
}
function aiCount(){var n=0;ROLES.forEach(function(r){if(UI.P.lv[r.id])n++;});return n+'／'+ROLES.length+' 個崗位';}
function rolesHTML(){
 var h='';
 ROLES.forEach(function(r){var l=UI.P.lv[r.id];
  h+='<div class="role"><span class="seal'+(l?'':' off')+'">'+r.seal+'</span><div class="rn">'+r.name+'<small>'+(l?'L'+l+' '+r.L[l-1].t:'未用 AI')+'</small></div><div class="seg" role="group" aria-label="'+r.name+'等級">';
  for(var i=0;i<=3;i++)h+='<button data-act="lv" data-role="'+r.id+'" data-lv="'+i+'" class="'+(l===i?'on':'')+'">'+(i?'L'+i:'冇')+'</button>';
  h+='</div></div>';});
 h+='<div class="prm chk"><input type="checkbox" id="in-P-review" data-k="P.review"'+(UI.P.review?' checked':'')+'><label for="in-P-review">人工審核 AI（關咗會出錯）</label></div>';
 h+='<p class="note">「貨」同「送」兩個崗位喺 v0.2 遊戲先加入。</p>';
 return h;
}
function topHTML(){
 var h='<div class="name"><span class="seal">沙</span>AI 重構寵物美容<small>沙盒模擬器 '+VERSION+'</small></div>';
 h+='<label class="lbl" for="scen">情境</label><select id="scen" data-act="scen">'+SCEN.map(function(s){return '<option value="'+s.id+'"'+(s.id===UI.scen?' selected':'')+'>'+s.name+'</option>';}).join('')+'</select>';
 h+='<span class="lbl">商業模式</span><div class="seg" role="group" aria-label="商業模式">'+['A','B','C','D'].map(function(m){return '<button data-act="model" data-m="'+m+'" class="'+(UI.F.model===m?'on':'')+'" title="'+MODELS[m]+'">'+m+' '+MODELS_S[m]+'</button>';}).join('')+'</div>';
 h+='<button class="btn" data-act="reset">重設</button><button class="btn" data-act="home">主選單</button>';
 return h;
}

/* ---------- 分頁 ---------- */
var TABS=[['ov','總覽'],['shop','店層'],['fd','創辦人'],['bs','盲點'],['sens','敏感度'],['mc','蒙地卡羅'],['cmp','四模式'],['fail','停損線'],['q','10 條問題'],['src','來源同假設']];
function tabsHTML(){
 var R=UI.R,nb=R.blind.filter(function(b){return b.on;}),red=nb.filter(function(b){return b.lvl==='red';}).length,nf=R.fail.filter(function(f){return f.bad;}).length;
 return '<nav class="tabs" aria-label="分頁">'+TABS.map(function(t){var b='';
  if(t[0]==='bs')b='<span class="badge '+(red?'red':nb.length?'amb':'')+'">'+nb.length+'</span>';
  if(t[0]==='fail')b='<span class="badge '+(nf?'red':'')+'">'+nf+'</span>';
  if(t[0]==='mc'&&UI.mc)b='<span class="badge">'+(UI.mcStale?'舊':UI.mc.n)+'</span>';
  return '<button data-act="tab" data-t="'+t[0]+'" class="'+(UI.tab===t[0]?'on':'')+'"'+(UI.tab===t[0]?' aria-current="page"':'')+'>'+t[1]+b+'</button>';}).join('')+'</nav>';
}
function kpi(k,v,d,cls){return '<div class="kpi'+(cls?' '+cls:'')+'"><span class="k">'+k+'</span><span class="v">'+v+'</span>'+(d?'<span class="d">'+d+'</span>':'')+'</div>';}
function delta(a,b,fmt,goodUp){var d=a-b;if(Math.abs(d)<1e-9)return '同傳統店一樣';var good=goodUp===false?d<0:d>0;return '<span class="'+(good?'up':'dn')+'">'+(d>0?'+':'−')+fmt(Math.abs(d))+'</span> 對比傳統店';}
function months(n){var a=[];for(var i=1;i<=n;i++)a.push(i+'月');return a;}
function scenLine(){var s=SCEN.filter(function(x){return x.id===UI.scen;})[0];return '情境：'+s.name+'（'+s.desc+'）· 模式 '+UI.F.model+' '+MODELS[UI.F.model];}

function pageOv(){
 var R=UI.R,a=R.aiS,b=R.baseS,fs=R.fr.sum,F=UI.F,h='<section class="page"><h2>總覽</h2><p class="sub">'+esc(scenLine())+'。「傳統店」係同一間店唔用 AI 嘅對照組。</p>';
 h+='<h3>你間店（用 AI）</h3><div class="kpis">'+
  kpi('每月利潤（未扣老闆人工）',hk(a.profit),delta(a.profit,b.profit,hk))+
  kpi('每月完成服務',a.done.toFixed(0)+' 次',delta(a.done,b.done,function(x){return x.toFixed(0)+' 次';}))+
  kpi('美容枱使用率',pct(a.util),a.util>.92?'太滿，事故風險升':'',a.util>.92?'amb':'')+
  kpi('No-show',pct(a.ns),delta(a.ns,b.ns,pct,false))+
  kpi('臨時取消',pct(a.lc),delta(a.lc,b.lc,pct,false))+
  kpi('熟客到期回頭',pct(a.ret),delta(a.ret,b.ret,pct))+
  kpi('老闆行政時間',Math.round(a.adminH)+' 小時／月',delta(a.adminH,b.adminH,function(x){return Math.round(x)+' 小時';},false))+
  kpi('年尾 Google 評分',a.rating.toFixed(2),delta(a.rating,b.rating,function(x){return x.toFixed(2);}),a.rating<4?'red':'')+'</div>';
 h+='<h3>創辦人（模式 '+F.model+'）</h3><div class="kpis">'+
  kpi('12 個月後現金',hk(fs.cash),'起始 '+hk(F.startCash),fs.minCash<0?'red':'')+
  kpi('MRR（第 12 個月）',hk(fs.mrr),'ARR '+hk(fs.arr))+
  kpi(F.model==='C'?'合作店／會員':'付費店',F.model==='C'?fs.accts.toFixed(0)+' 間／'+fs.members.toFixed(0)+' 人':fs.accts.toFixed(1)+' 間'+(F.model==='D'?' · 會員 '+fs.members.toFixed(0):''),'')+
  kpi('收支平衡',fs.breakeven?'第 '+fs.breakeven+' 個月':'12 個月內未達','',fs.breakeven?'':'amb')+
  kpi('創辦人時數峰值',Math.round(fs.maxNeed)+' 小時','可用 '+F.hoursAvail+' 小時',fs.maxNeed>F.hoursAvail?'amb':'')+
  kpi('LTV/CAC',fs.ltvcac!=null?fs.ltvcac.toFixed(1):'—','CAC 連時間 '+(fs.cacFull!=null?hk(fs.cacFull):'—'),fs.ltvcac!=null&&fs.ltvcac<1.5?'red':'')+
  kpi('CAC 回收期',fs.payback!=null?fs.payback.toFixed(1)+' 個月':'—','',fs.payback>12?'amb':'')+
  kpi('店家價值倍數',fs.mult!=null?fs.mult.toFixed(1)+' 倍':'—','店家得到嘅價值 ÷ 月費',fs.mult!=null&&fs.mult<1.5?'red':'')+'</div>';
 var fm=R.fr.months;
 var s1=[{name:'現金',c:'s1',vals:fm.map(function(x){return x.cash;})}];
 var am=R.ai.months,bm=R.base.months,s2=[{name:'用 AI',c:'s1',vals:am.map(function(x){return x.profit;})},{name:'傳統店',c:'s2',vals:bm.map(function(x){return x.profit;})}];
 h+='<div class="grid2"><div class="card"><h3>創辦人現金（12 個月）</h3>'+chart({series:s1,labels:months(fm.length),aria:'創辦人每月現金'})+'</div>';
 h+='<div class="card"><h3>店舖每月利潤</h3>'+legend(s2)+chart({series:s2,labels:months(am.length),aria:'用 AI 同傳統店每月利潤'})+'</div></div>';
 var on=R.blind.filter(function(x){return x.on;});
 h+='<div class="grid2"><div class="card"><h3>盲點診斷</h3>'+(on.length?'<div class="list">'+on.map(bsHTML).join('')+'</div>':'<p class="note">而家冇盲點觸發。試吓轉情境，例如「美容師滿載」或者「會員制失敗」。</p>')+'</div>';
 h+='<div class="card"><h3>最脆弱嘅 3 個假設</h3>'+(UI.sens&&UI.sensFor==='founder'?'<ol>'+UI.sens.rows.slice(0,3).map(function(r){return '<li>'+r.name+'：±20% 令 12 個月現金變 '+hk(r.lo)+' 至 '+hk(r.hi)+'</li>';}).join('')+'</ol><p class="note">按模式 '+F.model+' 嘅 12 個月現金計。詳細睇「敏感度」。</p>':'<p class="note">計算中…</p>');
 var nf=R.fail.filter(function(f){return f.bad;});
 h+='<h3 style="margin-top:14px">停損線</h3>'+(nf.length?'<ul>'+nf.map(function(f){return '<li>'+f.name+'（而家 '+esc(f.val)+'）</li>';}).join('')+'</ul>':'<p class="note">未踩到停損線。</p>')+'</div></div>';
 return h+'</section>';
}
function bsHTML(b){return '<div class="bs '+(b.on?b.lvl:'off')+'"><span class="n">'+b.id+'</span><div><b>'+b.title+'</b> '+(b.on?'<span class="pill '+(b.lvl==='red'?'red':'amb')+'"><i>!</i>'+(b.lvl==='red'?'高風險':'要留意')+'</span>':'<span class="pill ok"><i>✓</i>未觸發</span>')+(b.on?'<p>'+esc(b.why)+'</p><p class="fix">'+esc(b.fix)+'</p>':'')+'</div></div>';}

function pageShop(){
 var R=UI.R,a=R.aiS,b=R.baseS,P=UI.P,la=R.ltv,lb=R.ltvBase;
 function row(n,x,y,f,up){var d=x-y,cls=Math.abs(d)<1e-9?'':((up===false?d<0:d>0)?'up':'dn');return '<tr><td>'+n+'</td><td class="num">'+f(x)+'</td><td class="num">'+f(y)+'</td><td class="num '+cls+'">'+(Math.abs(d)<1e-9?'—':(d>0?'+':'−')+f(Math.abs(d)))+'</td></tr>';}
 var i0=function(x){return Math.round(x).toLocaleString('en-US');},f1=function(x){return x.toFixed(1);},f2=function(x){return x.toFixed(2);};
 var g=P.groomers;
 var h='<section class="page"><h2>店層：'+esc(P.name)+'</h2><p class="sub">每月平均（第 2–12 個月）。AI 崗位頭幾週有磨合期，所以第 1 個月唔計。</p>';
 h+='<div class="card tw"><table><thead><tr><th>指標</th><th class="num">用 AI</th><th class="num">傳統店</th><th class="num">差</th></tr></thead><tbody>';
 h+='<tr class="grp"><td colspan="4">店家端</td></tr>'+
  row('每月營收',a.rev,b.rev,hk)+row('每月利潤（未扣老闆人工）',a.profit,b.profit,hk)+row('每位美容師每月營收',a.rev/g,b.rev/g,hk)+
  row('美容枱使用率',a.util,b.util,pct)+row('平均客單價',a.ticket,b.ticket,hk)+row('加購率',a.addR,b.addR,pct)+
  row('No-show',a.ns,b.ns,pct,false)+row('臨時取消',a.lc,b.lc,pct,false)+row('熟客到期回頭（≈90 日回訪）',a.ret,b.ret,pct)+
  row('每位主人 LTV（毛利）',la.ltv,lb.ltv,hk)+row('每位新客獲取成本',P.ads/Math.max(1,a.newAcc),P.ads/Math.max(1,b.newAcc),hk,false)+
  row('每月新客',a.newAcc,b.newAcc,f1)+row('每月流失客',a.lost,b.lost,f1,false)+row('每月投訴',a.complaints,b.complaints,f1,false)+row('每月退款',a.refunds,b.refunds,hk,false)+
  row('新客查詢 → 預約',a.conv,b.conv,pct)+row('因冇位流失嘅預約需求／月',a.lostDem,b.lostDem,f1,false)+row('等位（週）',a.lead,b.lead,f2,false)+
  row('老闆行政時數／月',a.adminH,b.adminH,f1,false)+row('毛孩檔案完整度',a.comp,b.comp,pct)+row('AI 成本／月',a.aiCost,b.aiCost,hk,false)+
  row('年尾活躍客',a.act,b.act,i0)+row('年尾 Google 評分',a.rating,b.rating,f2);
 h+='<tr class="grp"><td colspan="4">毛孩主人端</td></tr>'+
  row('每位主人每年美容次數',la.visits,lb.visits,f1)+row('每位主人每年消費',la.spend,lb.spend,hk)+row('留存年數（估）',la.years,lb.years,f1)+
  row('每次服務投訴率',a.complaints/Math.max(1,a.done),b.complaints/Math.max(1,b.done),function(x){return (x*100).toFixed(2)+'%';},false)+
  row('退款佔營收',a.refunds/Math.max(1,a.rev),b.refunds/Math.max(1,b.rev),function(x){return (x*100).toFixed(2)+'%';},false)+
  row('年尾會員數',a.members,b.members,i0)+'<tr><td>轉介率</td><td class="num" colspan="3">v0.2 加入</td></tr>';
 h+='</tbody></table></div>';
 var am=R.ai.months,bm=R.base.months;
 var s1=[{name:'用 AI',c:'s1',vals:am.map(function(x){return x.profit;})},{name:'傳統店',c:'s2',vals:bm.map(function(x){return x.profit;})}];
 var s2=[{name:'完成',c:'s1',vals:am.map(function(x){return x.done;})},{name:'產能',c:'s3',vals:am.map(function(x){return x.cap;}),dash:1},{name:'預約',c:'s2',vals:am.map(function(x){return x.booked;})}];
 var cnt=function(v){return Math.round(v)+' 次';};
 h+='<div class="grid2"><div class="card"><h3>每月利潤</h3>'+legend(s1)+chart({series:s1,labels:months(am.length)})+'</div><div class="card"><h3>產能、預約、完成（用 AI）</h3>'+legend(s2)+chart({series:s2,labels:months(am.length),fmt:function(v){return Math.round(v);},tipFmt:cnt})+'</div></div>';
 var L=am[am.length-1];
 function fun(rows){var mx=rows[0][1]||1;return '<div class="funnel">'+rows.map(function(r){return '<div class="row"><div>'+r[0]+'</div><div><div class="fb" style="width:'+Math.max(1,r[1]/mx*100)+'%"></div></div><div>'+Math.round(r[1])+'</div></div>';}).join('')+'</div>';}
 var replied=L.inq*(1-(P.afterHours*rv(R.ai.S,'reply','loss')[0]+(1-P.afterHours)*rv(R.ai.S,'reply','loss')[1]));
 h+='<div class="grid2"><div class="card"><h3>新客漏斗（第 12 個月）</h3>'+fun([['新客查詢',L.inq],['有人覆',replied],['落實預約',L.newAcc]])+'<p class="note">冇人覆嘅查詢大多數去咗第二間。</p></div>';
 h+='<div class="card"><h3>預約漏斗（第 12 個月）</h3>'+fun([['總預約',L.booked],['到店',L.booked-L.noShowN-L.lcN+L.lcN*rv(R.ai.S,'sched','refill')],['完成',L.done]])+'<p class="note">總預約包括熟客回頭同新客。No-show '+pct(L.ns)+'、臨時取消 '+pct(L.lc)+' 分開計。</p></div></div>';
 var S=R.ai.S,dt=sum(S.dorm)||1;
 h+='<div class="grid2"><div class="card tw"><h3>沉睡客原因（年尾）</h3><table><thead><tr><th>原因</th><th class="num">人數</th><th class="num">佔比</th><th>AI 提醒有冇用</th></tr></thead><tbody>'+
  DORM.map(function(d,i){return '<tr><td>'+d.name+'</td><td class="num">'+Math.round(S.dorm[i])+'</td><td class="num">'+pct(S.dorm[i]/dt)+'</td><td>'+(d.ai>=1?'有用':d.ai>0?'部分（L3）':'冇用，要人處理')+'</td></tr>';}).join('')+'</tbody></table></div>';
 h+='<div class="card tw"><h3>AI 崗位（而家部署）</h3><table><thead><tr><th>崗位</th><th>等級</th><th class="num">建置</th><th class="num">月費</th><th class="num">部署</th></tr></thead><tbody>'+
  ROLES.map(function(r){var l=P.lv[r.id],L2=l?r.L[l-1]:null;return '<tr><td><span class="seal'+(l?'':' off')+'" style="width:20px;height:20px;font-size:12px;margin-right:6px">'+r.seal+'</span>'+r.name+'</td><td>'+(L2?'L'+l+' '+L2.t:'未用')+'</td><td class="num">'+(L2?hk(L2.setup):'—')+'</td><td class="num">'+(L2?hk(L2.fee):'—')+'</td><td class="num">'+(L2?L2.wk+' 週':'—')+'</td></tr>'+(L2?'<tr><td colspan="5" style="font-size:12px;color:var(--ink2)">工具：'+esc(L2.tools)+'<br>人工把關：'+esc(L2.guard)+'</td></tr>':'');}).join('')+'</tbody></table>'+
  '<p class="note">AI 做唔到：實際美容手藝、安撫寵物、判斷健康風險、處理受傷事故、同主人建立信任。</p></div></div>';
 return h+'</section>';
}
function pageFd(){
 var R=UI.R,F=UI.F,fm=R.fr.months,fs=R.fr.sum,h='<section class="page"><h2>創辦人：模式 '+F.model+' '+MODELS[F.model]+'</h2><p class="sub">客戶店每間都有「用 AI」同「唔用 AI」兩個雙胞胎模擬；店家價值倍數 = 用 AI 多賺嘅 ÷ 月費，決定佢續唔續。</p>';
 var lab=months(fm.length);
 var c1=[{name:'現金',c:'s1',vals:fm.map(function(x){return x.cash;})}],c2=[{name:'MRR',c:'s1',vals:fm.map(function(x){return x.mrr;})}];
 var c3=[{name:'需要',c:'s2',vals:fm.map(function(x){return x.needH;})},{name:'實際做',c:'s1',vals:fm.map(function(x){return x.worked;})},{name:'可用',c:'s3',vals:fm.map(function(x){return x.availH;}),dash:1}];
 var hf=function(v){return Math.round(v)+' 小時';};
 h+='<div class="grid2"><div class="card"><h3>現金</h3>'+chart({series:c1,labels:lab})+'</div><div class="card"><h3>MRR</h3>'+chart({series:c2,labels:lab})+'</div></div>';
 h+='<div class="grid2"><div class="card"><h3>創辦人時數</h3>'+legend(c3)+chart({series:c3,labels:lab,fmt:function(v){return Math.round(v);},tipFmt:hf})+'<p class="note">最多可以超時到可用時數 1.4 倍；連續 3 個月超時，士氣會跌。</p></div>';
 var c4=F.model==='C'?[{name:'會員',c:'s1',vals:fm.map(function(x){return x.members;})},{name:'合作店',c:'s2',vals:fm.map(function(x){return x.partners;})}]:[{name:'付費店',c:'s1',vals:fm.map(function(x){return x.accts;})},{name:'試用中',c:'s2',vals:fm.map(function(x){return x.trials;})}];
 h+='<div class="card"><h3>'+(F.model==='C'?'會員同合作店':'店數')+'</h3>'+legend(c4)+chart({series:c4,labels:lab,fmt:function(v){return v.toFixed(v<10?1:0);},tipFmt:function(v){return v.toFixed(1);}})+'</div></div>';
 var x=function(v,f){return v==null?'—':f(v);};
 h+='<div class="card tw"><h3>每月明細</h3><table><thead><tr><th>月</th><th class="num">收入</th><th class="num">變動成本</th><th class="num">淨現金流</th><th class="num">現金</th><th class="num">MRR</th><th class="num">'+(F.model==='C'?'會員':'付費店')+'</th><th class="num">新增</th><th class="num">流失</th><th class="num">需要時數</th><th class="num">價值倍數</th><th class="num">CAC（連時間）</th></tr></thead><tbody>'+
  fm.map(function(m){return '<tr><td>'+m.m+'月</td><td class="num">'+hk(m.rev)+'</td><td class="num">'+hk(m.varCost)+'</td><td class="num '+(m.net<0?'dn':'')+'">'+hk(m.net)+'</td><td class="num">'+hk(m.cash)+'</td><td class="num">'+hk(m.mrr)+'</td><td class="num">'+(F.model==='C'?m.members.toFixed(0):m.accts.toFixed(1))+'</td><td class="num">'+m.newPaid.toFixed(1)+'</td><td class="num">'+m.churned.toFixed(1)+'</td><td class="num">'+Math.round(m.needH)+'</td><td class="num">'+x(m.mult,function(v){return v.toFixed(1);})+'</td><td class="num">'+x(m.cacFull,hk)+'</td></tr>';}).join('')+'</tbody></table></div>';
 h+='<div class="kpis">'+kpi('毛利率',pct(fs.gm))+kpi('每戶月收入',hk(fs.arpa))+kpi('月流失率（最後 3 個月）',pct(fs.churn))+kpi('LTV',hk(fs.ltv))+kpi('超時月數',fs.overMonths+' 個月')+kpi('每 $1,000 MRR 用時',fs.hoursPerK?fs.hoursPerK.toFixed(1)+' 小時':'—')+'</div>';
 return h+'</section>';
}
function pageBs(){var R=UI.R;return '<section class="page"><h2>盲點診斷</h2><p class="sub">十條規則，每次改參數都會重新檢查。紅色係高風險，黃色係要留意。</p><div class="list">'+R.blind.slice().sort(function(a,b){return (b.on-a.on)||(a.id-b.id);}).map(bsHTML).join('')+'</div></section>';}
function pageSens(){
 var h='<section class="page"><h2>敏感度分析</h2><p class="sub">每次只改一個變數 ±20%，其他唔變，睇結果變幾多。條越長，個假設越要先核實。</p>';
 h+='<div class="seg" role="group" aria-label="睇邊個結果"><button data-act="sensT" data-t="founder" class="'+(UI.sensT==='founder'?'on':'')+'">創辦人 12 個月現金</button><button data-act="sensT" data-t="shop" class="'+(UI.sensT==='shop'?'on':'')+'">店舖 12 個月利潤</button></div>';
 if(!UI.sens||UI.sensFor!==UI.sensT)return h+'<p class="note">計算中…</p></section>';
 var s=UI.sens;
 h+='<div class="card"><h3>'+(UI.sensT==='founder'?'模式 '+UI.F.model+'：12 個月後現金 '+hk(s.base):'店舖 12 個月利潤 '+hk(s.base))+'</h3><div class="legend"><span><i style="background:var(--s1)"></i>變多</span><span><i style="background:var(--neg)"></i>變少</span></div>'+chart({type:'tornado',rows:s.rows,h:380})+'</div>';
 h+='<div class="card tw"><table><thead><tr><th>變數</th><th class="num">−20%</th><th class="num">+20%</th><th class="num">影響幅度</th></tr></thead><tbody>'+s.rows.map(function(r){return '<tr><td>'+r.name+'</td><td class="num">'+hk(r.lo)+'</td><td class="num">'+hk(r.hi)+'</td><td class="num">'+hk(r.span)+'</td></tr>';}).join('')+'</tbody></table>'+
  '<p class="note">「每店支援時數」影響現金得好少，因為創辦人時間唔係現金；但佢會令時數爆，睇「創辦人」頁同盲點 6、10。產能同回訪週期影響大，因為店越有空位，AI 帶嚟嘅預約先至用得着。</p></div>';
 return h+'</section>';
}
function pageMc(){
 var h='<section class="page"><h2>蒙地卡羅</h2><p class="sub">同一組假設跑好多次，每次隨機抽 no-show（±30%）、熟客回頭率（±5 個百分點）、事故率、查詢量、獲客成本、簽約率、流失率，再加隨機事故同離職。</p>';
 h+='<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center"><label class="lbl" for="mcN">次數</label><select id="mcN" data-act="mcN">'+[100,200,500].map(function(n){return '<option'+(UI.mcN===n?' selected':'')+'>'+n+'</option>';}).join('')+'</select><button class="btn pri" data-act="mcRun"'+(UI.mcBusy?' disabled':'')+'>'+(UI.mcBusy?'計算中…':'開始模擬')+'</button>'+(UI.mcStale&&UI.mc?'<span class="pill amb"><i>!</i>參數改咗，結果係舊嘅</span>':'')+'</div>';
 if(UI.mcBusy)h+='<div class="prog"><i style="width:'+Math.round(UI.mcProg*100)+'%"></i></div>';
 if(!UI.mc)return h+(UI.mcBusy?'':'<p class="note">撳「開始模擬」。200 次大約要幾秒。</p>')+'</section>';
 var m=UI.mc;
 h+='<div class="kpis">'+kpi('現金曾經跌穿零',pct(m.pNeg),'',m.pNeg>.1?'red':'')+kpi('12 個月現金（中位數）',hk(m.cash12.p50),'10%：'+hk(m.cash12.p10)+' · 90%：'+hk(m.cash12.p90))+
  kpi('MRR 第 12 個月（中位數）',hk(m.mrr12.p50),'10%：'+hk(m.mrr12.p10)+' · 90%：'+hk(m.mrr12.p90))+kpi('店舖全年利潤（中位數）',hk(m.profit.p50),'10%：'+hk(m.profit.p10))+
  kpi('一年內有嚴重事故',pct(m.pSerious),'',m.pSerious>.5?'amb':'')+kpi('年尾評分跌穿 4.0',pct(m.pRating4),'',m.pRating4>.1?'red':'')+'</div>';
 var band=m.band.map(function(b){return{lo:b.p10,hi:b.p90};});
 h+='<div class="card"><h3>創辦人現金：中位數同 10%–90% 範圍（'+m.n+' 次）</h3>'+chart({series:[{name:'中位數',c:'s1',vals:m.band.map(function(b){return b.p50;})}],band:band,labels:months(m.band.length)})+'</div>';
 return h+'</section>';
}
function pageCmp(){
 var h='<section class="page"><h2>四模式比較</h2><p class="sub">同一組店家假設，四種模式各跑 12 個月。「最大風險」係敏感度分析入面影響最大嘅變數。</p>';
 if(!UI.cmp)return h+'<p class="note">計算中…</p></section>';
 var c=UI.cmp,cs=['s1','s2','s3','s4'];
 var ser=c.map(function(x,i){return{name:x.model+' '+MODELS[x.model].replace('AI ',''),c:cs[i],vals:x.months.map(function(m){return m.cash;})};});
 h+='<div class="card"><h3>12 個月現金</h3>'+legend(ser)+chart({series:ser,labels:months(12),h:260})+'</div>';
 var row=function(n,f){return '<tr><td>'+n+'</td>'+c.map(function(x){return '<td class="num">'+f(x)+'</td>';}).join('')+'</tr>';};
 h+='<div class="card tw"><table><thead><tr><th>指標</th>'+c.map(function(x){return '<th class="num">'+x.model+' '+MODELS[x.model]+'</th>';}).join('')+'</tr></thead><tbody>'+
  row('12 個月後現金',function(x){return hk(x.sum.cash);})+row('最低現金',function(x){return hk(x.sum.minCash);})+row('收支平衡月份',function(x){return x.sum.breakeven?'第 '+x.sum.breakeven+' 個月':'未達';})+
  row('MRR 第 12 個月',function(x){return hk(x.sum.mrr);})+row('到 $30,000 MRR',function(x){return x.sum.mrr30?'第 '+x.sum.mrr30+' 個月':'未到';})+
  row('創辦人平均負荷',function(x){return Math.round(x.sum.avgLoad*100)+'%';})+row('超時月數',function(x){return x.sum.overMonths;})+
  row('每 $1,000 MRR 用時',function(x){return x.sum.hoursPerK?x.sum.hoursPerK.toFixed(1)+' 小時':'—';})+row('LTV/CAC',function(x){return x.sum.ltvcac!=null?x.sum.ltvcac.toFixed(1):'—';})+
  row('最敏感變數',function(x){return x.top.map(function(t){return t.name;}).join('、');})+'</tbody></table></div>';
 h+='<div class="grid2">'+c.map(function(x){var t=MODEL_TIPS[x.model];return '<div class="card"><h3>'+x.model+' '+MODELS[x.model]+'</h3><p><b>最大風險：</b>'+t.risk+'</p><p><b>建議起步：</b>'+t.start+'</p></div>';}).join('')+'</div>';
 return h+'</section>';
}
function pageFail(){var R=UI.R;return '<section class="page"><h2>停損線</h2><p class="sub">踩中任何一條，就應該停低諗清楚，唔好繼續加店或者加廣告。</p><div class="card tw"><table><thead><tr><th>條件</th><th class="num">而家</th><th class="num">門檻</th><th>狀態</th></tr></thead><tbody>'+
 R.fail.map(function(f){return '<tr><td>'+f.name+(f.txt?'<br><span class="note">'+f.txt+'</span>':'')+'</td><td class="num">'+esc(f.val)+'</td><td class="num">'+esc(f.thr)+'</td><td><span class="pill '+(f.bad?'red':'ok')+'"><i>'+(f.bad?'!':'✓')+'</i>'+(f.bad?'踩中':'未踩中')+'</span></td></tr>';}).join('')+'</tbody></table></div></section>';}
function pageQ(){var h='<section class="page"><h2>簡報 10 條問題</h2><p class="sub">全部用而家嘅參數即時計。改左邊參數，答案會跟住變。</p>';if(!UI.q)return h+'<p class="note">計算中…</p></section>';
 return h+'<div class="list">'+UI.q.map(function(x,i){return '<div class="q"><b>'+(i+1)+'. '+esc(x.q)+'</b><p>'+esc(x.a)+'</p></div>';}).join('')+'</div></section>';}
function pageSrc(){
 return '<section class="page src"><h2>數據來源同假設</h2><p class="sub">外國 benchmark 唔等於香港事實：香港租金、人工、犬種（細狗多）、樓宇環境、WhatsApp 習慣都唔同。</p><div class="card tw"><table><thead><tr><th>數據</th><th>數值</th><th>來源</th><th>年份</th></tr></thead><tbody>'+
  SOURCES.map(function(s){return '<tr><td>'+s[0]+'</td><td style="white-space:normal">'+s[1]+'</td><td style="white-space:normal"><a href="'+s[4]+'" target="_blank" rel="noopener">'+s[2]+'</a></td><td>'+s[3]+'</td></tr>';}).join('')+'</tbody></table></div>'+
  '<div class="card"><h3>示範估算（未核實）</h3><p>'+ESTIMATES+'</p><h3>寵物分群</h3><div class="tw"><table><thead><tr><th>分群</th><th>例子</th><th class="num">佔比</th><th class="num">週期</th><th class="num">平均價</th><th class="num">美容師分鐘</th></tr></thead><tbody>'+
  SEGS.map(function(g){return '<tr><td>'+g.name+'</td><td>'+g.eg+'</td><td class="num">'+pct(g.share)+'</td><td class="num">'+g.cyc+' 週</td><td class="num">'+hk(g.price)+'</td><td class="num">'+g.g+'</td></tr>';}).join('')+'</tbody></table></div>'+
  '<h3 style="margin-top:12px">牌照</h3><p>純美容一般唔需要漁護署牌照；有過夜寄養就要動物寄養所牌照（年費 HK$3,810）；賣動物要動物售賣商牌照。有一個網站話要「動物美容院牌照」，同其他來源唔同，開業前要向漁護署（1823）核實。</p></div></section>';
}

/* ---------- 渲染 ---------- */
function renderAll(){$('#sbTop').innerHTML=topHTML();$('#sbSide').innerHTML=sideHTML();$('#sbSide').classList.toggle('shut',UI.shut);renderMain();}
function renderMain(){
 var pg={ov:pageOv,shop:pageShop,fd:pageFd,bs:pageBs,sens:pageSens,mc:pageMc,cmp:pageCmp,fail:pageFail,q:pageQ,src:pageSrc}[UI.tab];
 var m=$('#sbMain'),st=m.scrollTop;CH={};
 m.innerHTML=tabsHTML()+pg();drawCharts(m);m.scrollTop=st;
 var sideCount=document.querySelector('.side details summary .lbl');if(sideCount)sideCount.textContent=aiCount();
 lazy();
}
function lazy(){
 var t=UI.tab;
 if((t==='ov'||t==='sens')&&(!UI.sens||UI.sensFor!==(t==='ov'?'founder':UI.sensT))){var want=t==='ov'?'founder':UI.sensT;
  setTimeout(function(){if(UI.sens&&UI.sensFor===want)return;UI.sens=sensitivity(clone(UI.P),clone(UI.F),want);UI.sensFor=want;if(UI.tab===t)renderMain();},20);}
 if(t==='cmp'&&!UI.cmp)setTimeout(function(){if(UI.cmp)return;UI.cmp=compareModels(clone(UI.P),clone(UI.F));if(UI.tab==='cmp')renderMain();},20);
 if(t==='q'&&!UI.q)setTimeout(function(){if(UI.q)return;UI.q=qAnswers(clone(UI.P),clone(UI.F));if(UI.tab==='q')renderMain();},20);
}
function $(s){return document.querySelector(s);}
function changed(){invalidate();clearTimeout(UI.timer);UI.timer=setTimeout(function(){recompute();renderMain();},140);}
