/* p_log：日誌（v0.21）。
   - 所有通知（日結、補位、排程、員工、保險……）唔再喺畫面底下逐條彈，全部收入「日誌」面板，按日分組，可以按類別篩選。
   - 畫面底下只會短暫顯示「重要」通知（投訴、事故、特殊客、升級、事件、保險、貸款、管理處等），今日三個鐘內嘅最多兩條。
   - 右下有「日誌」掣，顯示有幾多條未睇；打開就當睇咗。日誌記最近 400 條。 */
var LOG_IMP={'投訴':1,'嚴重事故':1,'特殊客':1,'升級':1,'里程碑':1,'管理處':1,'保險':1,'AI 出錯':1,'事件':1,'貸款':1,'創辦人':1,'私隱':1,'法規':1,'舖位':1};
var LOG_GRP={day:['日結'],appt:['排程','補位','取消','No-show','加做','落手做','特殊客'],cust:['客人','投訴','嚴重事故','服務','事件','隔籬','天氣','開店','創辦人','紀錄'],
 staff:['員工','老闆','挑戰','升級','里程碑'],money:['保險','貸款','宣傳','零售','舖位','管理處','法規','私隱'],ai:['AI','AI 出錯','存檔']};
function logIn(n,sub){if(!sub||sub==='all')return true;if(sub==='imp')return !!LOG_IMP[n.who];return (LOG_GRP[sub]||[]).indexOf(n.who)>=0;}
function logUnread(){return Math.max(0,(s.newsN||0)-(s.logRead||0));}
var _logNews=news;news=function(who,txt){_logNews.apply(this,arguments);s.newsN=(s.newsN||0)+1;};
HOOKS.init.push(function(){s.newsN=s.news?s.news.length:0;s.logRead=s.newsN;});
if(typeof SUBS!=='undefined')SUBS.log=[['all','全部'],['imp','重要'],['day','日結'],['appt','預約'],['cust','客人'],['staff','員工同老闆'],['money','錢同法規'],['ai','AI']];
function pLog(sub){var L=(s.news||[]).filter(function(n){return logIn(n,sub);}),h='',last=null;
 if(!L.length)return '<p class="note">呢個類別未有紀錄。</p>';
 L.forEach(function(n){if(n.day!==last){if(last!==null)h+='</ul>';last=n.day;h+='<h4 class="lg-d">'+dateStr(n.day)+(n.day===s.day?' · 今日':'')+'</h4><ul class="lg">';}
  h+='<li class="'+(LOG_IMP[n.who]?'imp':'')+'"><span class="num">'+hm(Math.min(DAY1-1,Math.floor(n.t||0)))+'</span><span class="pill'+(LOG_IMP[n.who]?' warn':'')+'">'+esc(n.who)+'</span><span class="lg-t">'+esc(n.txt)+'</span></li>';});
 return '<p class="note">記錄最近 400 條通知。畫面底下只會短暫顯示重要通知。</p>'+h+'</ul>';}
if(typeof document!=='undefined'){
 var _logOP=openPanel;openPanel=function(id){var r=_logOP.apply(this,arguments);if(id==='log'&&s){s.logRead=s.newsN||0;renderHUD();}return r;};
 var _logRH=renderHUD;renderHUD=function(){_logRH.apply(this,arguments);if(!s||s.bg)return;
  /* 底下通知：只顯示今日三個鐘內嘅重要通知 */
  var nw=document.getElementById('news');if(nw){var ns=(s.news||[]).filter(function(n){return LOG_IMP[n.who]&&n.day===s.day&&s.t-n.t<180;}).slice(0,2);
   var hh=ns.map(function(n){return '<div><span class="num">'+hm(n.t)+'</span><b>'+esc(n.who)+'</b>'+esc(n.txt)+'</div>';}).join('');if(nw.innerHTML!==hh)nw.innerHTML=hh;}
  /* 右下「日誌」掣 */
  var br=document.querySelector('#game .hud-br');if(br){var b=document.getElementById('btnLog');
   if(!b){b=document.createElement('button');b.id='btnLog';b.className='hbtn';b.setAttribute('data-act','panel');b.setAttribute('data-p','log');var cr=br.querySelector('[data-act=camreset]');br.insertBefore(b,cr||null);}
   if(PANEL.id==='log')s.logRead=s.newsN||0;var u=logUnread(),un=u>99?'99+':u,t='日誌'+(u?'<span class="lgb">'+un+'</span><small>'+un+' 條新</small>':'<small>通知同日結紀錄</small>');if(b.innerHTML!==t)b.innerHTML=t;b.classList.toggle('on',PANEL.id==='log');}};}
