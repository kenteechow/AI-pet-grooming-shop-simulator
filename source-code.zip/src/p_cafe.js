/* p_cafe：地下「好運茶餐廳」。紅白格仔地、綠色牆磚、燒味櫥窗、凍櫃、卡位、吊扇、餐牌；收銀、伙記、食客（午市同晚市多人）。 */
function buildCafe(g){
 var C={cust:[],fans:[]};W3.cafe=C;
 var floor=flatTex(g,9.8,9.8,0,.02,0,checkerCanvas('#c9533f','#f2e8d5'),1.2,.04);floor.receiveShadow=true;
 vb(g,10,3.2,.2,0,1.6,-4.9,'#efe3c6');vb(g,.2,3.2,10,4.9,1.6,0,'#efe3c6');
 vb(g,10,1.1,.22,0,.55,-4.88,'#2f7d5b');vb(g,.22,1.1,10,4.88,.55,0,'#2f7d5b');
 /* 樓梯通道（去 1 樓） */
 vb(g,.2,3.2,9.6,-3.4,1.6,-.2,'#d9cbb0');vb(g,.2,3.2,10,-4.9,1.6,0,'#d9cbb0');
 for(var st=0;st<12;st++)vb(g,1.3,.27*(st+1),.6,-4.15,.135*(st+1),4.2-st*.62,'#9c8b78');
 vb(g,1.1,2.3,.1,-4.15,1.15,5.02,'#3a2a20');vb(g,.9,.5,.06,-4.15,2.6,5.08,'#ffffff');W3.neons.push(sign(g,'1樓 毛孩美容',.95,.45,-4.15,2.6,5.12,'#0d655f','#ffffff'));
 /* 補齊樓面及前立面，參觀地下時隱藏天花板以便睇入面。 */
 var roof=vgroup(g,0,0,0);W3.cafeRoof=roof;vb(roof,10,.14,10,0,3.13,0,'#e6d8bd');
 vb(g,10,.55,.2,0,2.91,4.9,'#efe3c6');
 vb(g,.18,2.7,.22,-4.9,1.35,4.9,'#d9cbb0');vb(g,.18,2.7,.22,4.9,1.35,4.9,'#efe3c6');
 /* 舖面：玻璃、鋁框、門 */
 vb(g,8.1,.5,.2,.75,.25,4.95,'#6b5a48');
 vb(g,8.1,2.1,.05,.75,1.55,5.0,'#cfe6ee',{op:.32});
 [-3.3,-1.3,.75,2.8,4.8].forEach(function(x){vb(g,.08,2.6,.1,x,1.3,5.02,'#b9c0c4');});vb(g,8.2,.08,.1,.75,2.62,5.02,'#b9c0c4');
 /* 帆布簷篷（綠白間條） */
 var fr=vgroup(g,0,0,0);W3.cafeFront=fr;
 for(var k=0;k<8;k++)vb(fr,1.02,.12,1.2,-2.8+k*1.02,2.42,5.65,k%2?'#f4f1e6':'#2e7d4f',{own:1});
 vb(fr,8.2,.08,.08,.8,2.34,6.25,'#2e7d4f',{own:1});
 W3.neons.push(sign(fr,'好運茶餐廳',6,.66,.8,2.86,5.25,'#fff6d0','#2e6b3a'));
 /* 門口餐牌架 */
 var ab=vgroup(g,3.6,0,6.8);vb(ab,.7,1,.06,0,.55,0,'#2b2b2b');var mb=new THREE.MeshLambertMaterial({map:textTex('今日餐','#ffffff','#2b2b2b',true,64,192)});var mbm=new THREE.Mesh(vbox(.6,.9,.02),mb);mbm.position.set(0,.6,.04);ab.add(mbm);
 /* 燒味櫥窗 */
 vb(g,2,.9,.9,-2.2,.45,4.2,'#b0a08a');vb(g,2,1.1,.9,-2.2,1.45,4.2,'#f1d9a8',{op:.3});vb(g,2,.06,.9,-2.2,2.02,4.2,'#9a9a9a');
 for(var hk=0;hk<5;hk++){vb(g,.03,.25,.03,-2.9+hk*.35,1.85,4.2,'#777');vb(g,.24,.36,.14,-2.9+hk*.35,1.55,4.2,hk%2?'#b5482a':'#d0803a');}
 /* 收銀櫃位、凍櫃 */
 vb(g,2.8,1.05,.8,2.9,.52,-2.9,'#8a5a3a');vb(g,2.9,.08,.9,2.9,1.08,-2.9,'#e8e0d0');vb(g,.45,.3,.35,2.2,1.27,-2.9,'#333');vb(g,.3,.2,.04,2.2,1.42,-3.05,'#7fd1ff');
 vb(g,1.2,2.2,.8,-2.4,1.1,-4.4,'#dde3e6');vb(g,1.05,1.9,.04,-2.4,1.15,-3.98,'#bfe3f0',{op:.45});
 [0,1,2,3].forEach(function(r){[0,1,2].forEach(function(c){vb(g,.18,.28,.18,-2.75+c*.35,.5+r*.48,-4.2,['#d33','#2a7','#fa0','#36c'][(r+c)%4]);});});
 /* 餐牌、時鐘 */
 var mp=new THREE.MeshLambertMaterial({map:textTex('常餐 $42　菠蘿油 $18　凍奶茶 $22　餐蛋麵 $38','#fff4c8','#a3242a',false,512,64)});var mm=new THREE.Mesh(vbox(5.4,.55,.04),mp);mm.position.set(.9,2.55,-4.77);g.add(mm);
 vb(g,.45,.45,.05,4.75,2.4,-2,'#ffffff');
 /* 枱櫈同卡位 */
 C.seats=[];
 [[-1.6,1.4],[.6,1.4],[-1.6,-1.2],[.6,-1.2]].forEach(function(p){vb(g,.9,.06,.9,p[0],.78,p[1],'#f2efe8');vb(g,.12,.74,.12,p[0],.39,p[1],'#555');
  [[-.65,0],[.65,0],[0,-.65],[0,.65]].forEach(function(q){vb(g,.38,.08,.38,p[0]+q[0],.46,p[1]+q[1],'#c0392b');vb(g,.06,.42,.06,p[0]+q[0],.21,p[1]+q[1],'#555');C.seats.push([p[0]+q[0],p[1]+q[1],Math.atan2(-q[0],-q[1])]);});});
 [[3.9,2.6],[3.9,.6]].forEach(function(p){vb(g,1,.06,1.2,p[0]-.6,.78,p[1],'#f2efe8');vb(g,.6,.45,1.3,p[0]+.25,.23,p[1],'#7a2f22');vb(g,.18,.9,1.3,p[0]+.6,.6,p[1],'#7a2f22');C.seats.push([p[0]+.2,p[1]-.3,-Math.PI/2]);C.seats.push([p[0]+.2,p[1]+.3,-Math.PI/2]);});
 /* 吊扇 */
 [[-.6,.2],[2.4,-1]].forEach(function(p){var f=vgroup(g,p[0],2.95,p[1]);vb(f,.08,.25,.08,0,.12,0,'#555');for(var b=0;b<4;b++){var bl=vb(f,.9,.03,.16,0,0,0,'#8a6a4a');bl.rotation.y=b*Math.PI/2;bl.position.set(Math.cos(b*Math.PI/2)*.45,0,-Math.sin(b*Math.PI/2)*.45);}C.fans.push(f);});
 var pl=new THREE.PointLight('#ffe6c0',.45,11,1.5);pl.position.set(.6,2.7,-5);W3.sc.add(pl);W3.cafeLight=pl;
 /* 人：收銀、伙記、食客 */
 C.cashier=makePerson({i:41,apron:'#ffffff',cloth:'#e9e2d0'});C.cashier.position.set(2.9,0,-3.5);g.add(C.cashier);
 C.waiter=makePerson({i:42,apron:'#2b2b2b',cloth:'#f2f2f2'});C.waiter.position.set(1,0,0);g.add(C.waiter);C.wt=0;
 C.seats.forEach(function(st,i){var p=makePerson({i:50+i,long:i%3===0});p.position.set(st[0],-.08,st[1]);p.rotation.y=st[2];p.visible=false;g.add(p);C.cust.push(p);});
}
function cafeBusy(t){/* 午市、晚市多人 */if(t<480||t>1290)return 0;var lunch=Math.exp(-Math.pow((t-780)/55,2)),din=Math.exp(-Math.pow((t-1140)/60,2));return clamp(.15+.8*lunch+.6*din,0,1);}
function updateCafe(dt){
 var C=W3.cafe;if(!C)return;var gs=Math.min(s.speed||1,4)*(s.paused||s.modal?0:1);
 C.fans.forEach(function(f){f.rotation.y+=dt*6*(gs>0?1:.2);});
 var b=cafeBusy(s.t),n=Math.round(b*C.cust.length);
 C.cust.forEach(function(p,i){var on=((i*7)%C.cust.length)<n;p.visible=on;if(on&&p.userData.arms){var sw=Math.sin(W3.t*3+i)*.3;p.userData.arms[0].rotation.x=-.6+sw;p.userData.arms[1].rotation.x=-.6-sw;}});
 C.wt+=dt*gs*.25;var k=(Math.sin(C.wt)+1)/2,wp=C.waiter.position,ox=wp.x,oz=wp.z;wp.set(-1.6+k*2.6,0,.1+Math.sin(C.wt*2)*.6);var mx=wp.x-ox,mz=wp.z-oz,mv=Math.hypot(mx,mz);if(mv>1e-4)turnTo(C.waiter,Math.atan2(mx,mz),dt);stride(C.waiter,mv,dt);
 
 W3.cafeLight.intensity=(s.t>=480&&s.t<=1290)?.45:.1;
 C.n=n;
}
