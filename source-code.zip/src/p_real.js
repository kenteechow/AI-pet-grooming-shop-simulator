/* p_real：真實營運細節。老闆底薪同小金庫、貸款、保險、直銷同意、現金危機、手動排程。 */
var LOANS={bank:{name:'銀行中小企貸款',apr:.065,months:36,max:300000,wait:14,need:'要有 3 個月帳目，而且冇蝕穿現金；審批 2 週'},
 fin:{name:'財務公司',apr:.32,months:12,max:100000,wait:0,need:'即日批，但年利率 32%'}};
function loanPay(amt,apr,n){var r=apr/12;return amt*r/(1-Math.pow(1+r,-n));}
HOOKS.init.push(function(id){
 s.own={base:id==='solo'?12000:15000,fund:id==='solo'?30000:50000,lastPay:0};
 s.loans=[];s.ins={pl:1};s.consent=.6;s.consentWk=-1;s.bank=null;s.over=0;s.dead=0;
 var fr=s.staff.filter(function(x){return x.role==='front';});s.base.front=fr.length;s.base.extraWages=sum(fr.map(function(x){return x.wage*1.05;}));
});
HOOKS.sync.push(function(P){P.consent=s.consent;if(!s.ins.pl)P.insurance=Math.max(0,P.insurance-600);});
HOOKS.week.push(function(){
 var c0=s.consent;s.consent=Math.min(.95,s.consent+(1-s.consent)*(s.lv.reply>=2?.04:.008));clConsentSync(c0,s.consent);
 if(s.bank&&s.day>=s.bank.at){var L=LOANS.bank;s.loans.push({type:'bank',name:L.name,amt:s.bank.amt,pay:loanPay(s.bank.amt,L.apr,L.months),left:L.months});oneOff(s.bank.amt,'銀行貸款','loan');news('貸款','銀行批咗 '+hk(s.bank.amt)+'，每月還 '+hk(loanPay(s.bank.amt,L.apr,L.months)));s.bank=null;}
});
HOOKS.month.push(function(rec){
 var lp=0;s.loans.forEach(function(l){if(l.left>0){s.cash-=l.pay;lp+=l.pay;l.left--;}});s.loans=s.loans.filter(function(l){return l.left>0;});
 var pay=s.own.base*(rec.profit<0?.7:1);s.cash-=pay;
 var extra=rec.profit-pay-lp,toFund=extra>0?extra*.5:0;s.cash-=toFund;s.own.fund+=toFund;s.own.lastPay=pay;
 rec.loanPay=lp;rec.ownerPay=pay;rec.ownerBase=s.own.base;rec.toFund=toFund;rec.net=rec.profit-pay-toFund-lp;rec.fund=s.own.fund;
 var sp=s.own.base*(rec.shProfit<0?.7:1);s.shCash-=sp+Math.max(0,rec.shProfit-sp)*.5;
 if(pay<s.own.base)news('老闆','今個月蝕錢，你嘅底薪減咗 30%，只攞 '+hk(pay));
 if(toFund>0)news('老闆','賺多咗 '+hk(extra)+'，一半（'+hk(toFund)+'）入你嘅小金庫');
 if(s.cash<0){s.over++;if(s.cash<-80000&&s.over>=2){s.dead=1;s.modal={type:'over',rec:rec};return;}queueEvent('cashLow');}else s.over=0;
});
function injectFund(amt){amt=Math.min(amt,s.own.fund);if(amt<=0)return;s.own.fund-=amt;oneOff(amt,'由你嘅小金庫轉入公司','inject');news('老闆','由小金庫注資 '+hk(amt)+' 入公司');}
function takeLoan(type,amt){
 var L=LOANS[type];amt=Math.min(amt,L.max);
 if(type==='bank'){if(s.months.length<3||s.over>0){news('貸款','銀行拒絕：'+(s.months.length<3?'未夠 3 個月帳目':'公司現金蝕穿咗'));return false;}if(s.bank){news('貸款','銀行審批緊上一份申請');return false;}
  s.bank={amt:amt,at:s.day+L.wait};news('貸款','已經遞交銀行貸款申請 '+hk(amt)+'，大約 2 週有結果');return true;}
 s.loans.push({type:type,name:L.name,amt:amt,pay:loanPay(amt,L.apr,L.months),left:L.months});oneOff(amt,L.name,'loan');news('貸款','財務公司即日批咗 '+hk(amt)+'，每月還 '+hk(loanPay(amt,L.apr,L.months)));return true;
}
function askConsent(){if(s.consentWk===weekNo()){news('私隱','今個星期已經問過');return;}s.consentWk=weekNo();var c0=s.consent;s.consent=Math.min(.95,s.consent+.08);clConsentSync(c0,s.consent);own().morale-=.03;news('私隱','你逐個熟客問「可唔可以 WhatsApp 你推廣」，直銷同意率升到 '+pct(s.consent));}
EVENTS.cashLow={title:'現金唔夠',body:function(){return '公司現金得返 '+hk(s.cash)+'。下個月租同人工要照畀。小金庫有 '+hk(s.own.fund)+'。';},
 ai:'AI 救唔到現金流。但「數」L3 可以預先試算邊個月會唔夠錢，同埋邊樣開支最大。',
 ch:[{t:'由小金庫注資',pro:['冇利息'],con:['你自己嘅錢'],f:function(){injectFund(Math.max(30000,-s.cash+20000));}},
  {t:'借財務公司 HK$80,000',pro:['即日有錢'],con:['年利率 32%，每月還款重'],f:function(){takeLoan('fin',80000);}},
  {t:'申請銀行貸款 HK$150,000',pro:['利息低'],con:['要等 2 週，未夠 3 個月帳目會被拒'],f:function(){takeLoan('bank',150000);}},
  {t:'暫時頂住',pro:['唔使借錢'],con:['再蝕落去會結業'],f:function(){}}]};
EVENTS.lease={title:'租約到期',body:function(){return '深水埗地舖租約下個月到期。業主話續租要加 15%（'+hk(s.base.rent*1.15)+'／月）。';},when:function(){return s.open==='old';},
 ai:'AI 改變唔到租金，但如果 AI 前台同排程慳返人手，細一啲嘅舖都可以做到同樣生意。',
 ch:[{t:'照續，加 15%',pro:['唔使搬'],con:['每月租金多'],f:function(){s.base.rent*=1.15;}},
  {t:'退返一部分舖位，剩 2 張枱',pro:['租金減 30%'],con:['產能少一張枱'],f:function(){s.base.rent*=.7;s.base.tables=2;s.base.tubs=1;news('舖位','退咗後半舖位，月租 '+hk(s.base.rent)+'，剩 2 張美容枱');}}]};
EVENTS.mgmt={title:'管理處投訴',body:function(){return '樓上鄰居投訴狗吠同大風量吹風機（業內叫吹水機，用強風吹走毛入面嘅水，好嘈）嘅聲，管理處話大廈公契唔准做「動物相關商業用途」。';},when:function(){return s.open==='solo';},
 ai:'AI 幫唔到法規問題。開業前應該睇清楚公契同地契用途。',
 ch:[{t:'加隔音、承諾 7 點後唔用大風量吹風機',pro:['暫時唔使搬'],con:['裝修 HK$8,000','收早 30 分鐘'],f:function(){s.cash-=8000;addMod('openH','add',-.5,52,false,'承諾早收');}},
  {t:'搵律師睇公契',pro:['知道自己有冇得做'],con:['律師費 HK$5,000'],f:function(){s.cash-=5000;news('法規','律師話公契寫明「商業用途」冇特別禁止動物，但要減少滋擾');}}]};
HOOKS.day.push(function(){
 if(s.open==='old'&&s.day===210&&!s.evSeen.lease)queueEvent('lease');
 if(s.open==='solo'&&s.day===63&&!s.evSeen.mgmt)queueEvent('mgmt');
});

/* ---------- 手動排程 ---------- */
function apptById(id){return s.wk.appts.filter(function(a){return a.id===id;})[0];}
function movable(a){return a&&a.st==='booked'&&a.g!=null&&(a.day>s.day||(a.day===s.day&&a.a>s.t+15));}
function canPlace(a,day,gid,t,ignore){
 var g=s.staff.filter(function(x){return x.id===gid;})[0];
 if(!g||!staffWorks(g,day))return (g?g.name:'嗰位')+'嗰日唔返工';
 if(day<s.day||day>=s.wk.start+7)return '只可以排今個星期';
 if(t<OPEN_MIN||t+a.dur>CLOSE_MIN)return '超出營業時間（'+hm(OPEN_MIN)+'–'+hm(CLOSE_MIN)+'）';
 if(day===s.day&&t<s.t+15)return '嗰個時間已經過咗';
 var b=(dayBusy(day)[gid]||[]);
 for(var i=0;i<b.length;i++){var x=b[i];if(x[2]===a.id||(ignore&&x[2]===ignore))continue;if(t<x[1]&&t+a.dur>x[0])return '撞正'+(typeof x[2]==='string'?x[2]+'時間':'另一個預約（'+((apptById(x[2])||{}).pet||'')+'）');}
 return null;
}
function unbusy(a){var b=dayBusy(a.day)[a.g];if(b)for(var i=b.length-1;i>=0;i--)if(b[i][2]===a.id)b.splice(i,1);}
function setSlot(a,day,gid,t){a.day=day;a.g=gid;a.a=t;a.b=t+a.dur;var gi=groomers().filter(function(g){return staffWorks(g,day);}).map(function(g){return g.id;}).indexOf(gid);a.tb=Math.max(0,gi)%s.base.tables;dayBusy(day)[gid].push([a.a,a.b,a.id]);a.manual=1;}
function moveAppt(id,day,gid,t){
 var a=apptById(id);if(!movable(a))return '呢個預約已經開始或者完成，唔可以調';
 var err=canPlace(a,day,gid,t);if(err)return err;
 unbusy(a);setSlot(a,day,gid,t);news('排程','你調咗「'+a.pet+'」去星期'+WKD[day%7]+' '+hm(t)+' · '+staffName(gid));return null;
}
function swapAppt(id1,id2){
 var a=apptById(id1),b=apptById(id2);if(!movable(a)||!movable(b))return '其中一個預約已經開始，唔可以互換';
 var A={day:a.day,g:a.g,t:a.a},B={day:b.day,g:b.g,t:b.a};
 unbusy(a);unbusy(b);
 var e1=canPlace(a,B.day,B.g,B.t,b.id),e2=canPlace(b,A.day,A.g,A.t,a.id);
 if(e1||e2){setSlot(a,A.day,A.g,A.t);setSlot(b,B.day,B.g,B.t);a.manual=b.manual=0;return '互換唔到：'+(e1||e2);}
 setSlot(a,B.day,B.g,B.t);setSlot(b,A.day,A.g,A.t);news('排程','你互換咗「'+a.pet+'」同「'+b.pet+'」嘅時段');return null;
}
function addFromBacklog(day,gid,t){
 if(s.S.backlog<1)return '候補名單冇人等緊';
 var h=s.wk.h,a=mkAppt(h,s.S.P,day-s.day,1,0);a.tag='候補';a.regular=true;a.out=R()<h.ns*.5?'noshow':'ok';clAssign(a,true);
 var err=canPlace(a,day,gid,t);if(err){clDrop(a);return err;}
 s.wk.appts.push(a);setSlot(a,day,gid,t);s.S.backlog-=1;news('排程','由候補名單加咗「'+a.pet+'」：星期'+WKD[day%7]+' '+hm(t)+' · '+staffName(gid));return null;
}
