/* p_merge：將靜態方塊（共用顏色材質）合併成每種顏色一個 mesh，大幅減少 draw call，令畫面流暢。 */
function mergeStatic(root,skip){
 root.updateMatrixWorld(true);var inv=new THREE.Matrix4().copy(root.matrixWorld).invert(),mw=new THREE.Matrix4();
 var shared=new Set(Object.keys(MAT).map(function(k){return MAT[k];})),groups=new Map();
 function walk(o){if(skip.has(o))return;o.children.slice().forEach(walk);
  if(o.isMesh&&!Array.isArray(o.material)&&shared.has(o.material)&&!o.material.transparent&&o.geometry.index){var a=groups.get(o.material);if(!a){a=[];groups.set(o.material,a);}a.push(o);}}
 walk(root);var nMesh=0,nOut=0;
 groups.forEach(function(list,mat){
  if(list.length<3)return;var nv=0,ni=0;list.forEach(function(o){nv+=o.geometry.attributes.position.count;ni+=o.geometry.index.count;});
  var pos=new Float32Array(nv*3),nor=new Float32Array(nv*3),idx=new Uint32Array(ni),vo=0,io=0,v=new THREE.Vector3(),nm=new THREE.Matrix3();
  list.forEach(function(o){var G=o.geometry,P=G.attributes.position,N=G.attributes.normal,I=G.index;mw.multiplyMatrices(inv,o.matrixWorld);nm.getNormalMatrix(mw);
   for(var i=0;i<P.count;i++){v.fromBufferAttribute(P,i).applyMatrix4(mw);pos[(vo+i)*3]=v.x;pos[(vo+i)*3+1]=v.y;pos[(vo+i)*3+2]=v.z;v.fromBufferAttribute(N,i).applyMatrix3(nm).normalize();nor[(vo+i)*3]=v.x;nor[(vo+i)*3+1]=v.y;nor[(vo+i)*3+2]=v.z;}
   for(var j=0;j<I.count;j++)idx[io+j]=I.getX(j)+vo;vo+=P.count;io+=I.count;o.parent.remove(o);nMesh++;});
  var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));g.setAttribute('normal',new THREE.BufferAttribute(nor,3));g.setIndex(new THREE.BufferAttribute(idx,1));
  var m=new THREE.Mesh(g,mat);m.receiveShadow=true;m.castShadow=true;m.matrixAutoUpdate=false;root.add(m);nOut++;});
 W3.merged=W3.merged||{from:0,to:0};W3.merged.from+=nMesh;W3.merged.to+=nOut;
}
