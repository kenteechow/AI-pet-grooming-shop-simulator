/* p_hud：遊戲 HUD、工時面板、dock、最新消息、彈窗、選中卡、設定。 */
var DOCK=[['sched','排','排程'],['cust','客','客人'],['staff','人','員工'],['ai','智','AI 部署'],['fin','財','財務'],['shadow','鄰','隔籬'],['rep','報','報告']];
var PANEL={id:null,sub:null};
function hudHTML(){
 return '<div id="view"></div><div id="labels"></div>'+
 '<div class="hud hud-tl" id="hudTL"></div><div class="hud hud-tr" id="hudTR"></div><div id="hudLeftStack" class="left-stack"><div id="guide" class="guide" role="region" aria-label="第一週目標" hidden></div><div id="goalCard" class="goalcard" hidden></div><div class="hud hud-bl" id="hudBL"></div></div>'+
 '<div class="hud hud-br"><button class="hbtn big" data-act="floor" id="btnFloor"></button><button class="hbtn big" data-act="ext" id="btnExt">建築外觀<small>睇屋頂同外牆</small></button><button class="hbtn" data-act="camreset">重設視角</button><button class="hbtn" data-act="settings" aria-label="設定（Esc）">設定</button></div>'+
 '<div class="hud news" id="news"></div><nav class="hud dock" id="dock" aria-label="管理面板"></nav>'+
 '<aside class="panel" id="panel" hidden></aside><div class="selcard" id="selCard" hidden></div><div class="democard" id="demoCard" hidden></div>'+
 '<div class="modal-bg" id="modalBg" hidden><div class="modal" id="modal" role="dialog" aria-modal="true"></div></div>';
}
function renderHUD(){
 if(!s)return;var P=s.S.P,w=s.wk,h=w.h;
 var spd=[[0,'暫停'],[1,'1×'],[3,'3×'],[10,'10×'],[30,'30×']];if(s.demo)spd.push([-1,'自動']);
 var tlH='<div class="shopname"><span class="seal">毛</span><div><b>'+esc(s.openName)+'</b><small>觀塘 · 第 '+weekNo()+' 週</small></div></div>'+
  '<div class="clock"><span class="num big">'+hm(Math.floor(s.t))+'</span><span>'+dateStr(s.day)+'</span><span class="wx">'+(s.rain===2?'大雨':s.rain?'落雨':'天晴')+'</span></div>'+
  '<div class="seg spd" role="group" aria-label="速度">'+spd.map(function(x){var on=x[0]===0?s.paused:x[0]===-1?(!s.paused&&s.demoAuto!==false):(!s.paused&&s.speed===x[0]&&!(s.demo&&s.demoAuto!==false));return '<button data-act="spd" data-v="'+x[0]+'" class="'+(on?'on':'')+'">'+x[1]+'</button>';}).join('')+'</div>'+skipHTML();
 /* 時間面板：只有內容（唔計時鐘數字）變咗先重砌，免得撳緊嘅掣被換走；時鐘由主循環逐格更新 */
 var tlEl=$('#hudTL'),tlK=tlH.replace(/<span class="num big">[^<]*<\/span>/,'');if(tlEl._k!==tlK){tlEl.innerHTML=tlH;tlEl._k=tlK;}
 var md=monthToDate(),est=md.days?md.profit/md.days*md.dim:0,todayCost=w.cost.wages+w.cost.fixed+w.cost.ai+w.cost.refunds+s.today.done*P.consum;
 $('#hudTR').innerHTML=hk2('現金',hk(s.cash),'今日 <span class="up">+'+hk(s.today.rev).replace('HK$','$')+'</span> / <span class="dn">−'+hk(todayCost).replace('HK$','$')+'</span>')+
  hk2('活躍客',Math.round(actN(s.S))+' 位','沉睡 '+Math.round(sum(s.S.dorm)))+hk2('評分',s.S.rating.toFixed(2),s.S.rating<4.2?'<span class="dn">要留意</span>':'Google')+
  hk2('人手',activeStaff().length+' 人','美容師 '+groomers().length)+(md.days<5?hk2('本月預計','—','要多幾日數據'):hk2('本月預計',hk(est),est<0?'<span class="dn">蝕錢</span>':'盈利',est<0?'bad':''));
 /* 工時 */
 var rows=activeStaff().map(function(x){var hw=staffHours(x),r=hw.avail?hw.used/hw.avail:0,cls=r>=.95?'hot':r>=.75?'mid':'';
  var shift=staffShift(x,s.day),status=!shift?'今日休息':x.role==='asst'?(s.t<shift.start?'兼職未到班':s.t>=shift.end?'兼職已收工':'兼職當值'):x.role==='owner'?'老闆':'全職';
  var tag='<i class="tg'+(x.leaving>=0?' red':'')+'">'+(x.leaving>=0?'離職中':status)+'</i>';
  return '<button class="wrow" data-act="panel" data-p="staff" title="'+(shift?'今日 '+hm(shift.start)+'–'+hm(shift.end):'今日休息')+'；撳開睇本週班表"><span class="nm">'+esc(x.name.replace('（老闆）',''))+tag+'</span><span class="bar '+cls+'"><i style="width:'+Math.min(100,r*100).toFixed(0)+'%"></i></span><span class="num">'+Math.round(hw.used)+'/'+Math.round(hw.avail)+'h</span></button>';}).join('');
 var hudBL=$('#hudBL'),oldRows=hudBL.querySelector('.staff-rows'),scroll=oldRows?oldRows.scrollTop:0;
 var hudContent='<div class="hbl-h"><b>本週工時'+(activeStaff().length>6?' <small class="staff-scroll-hint">可捲動</small>':'')+'</b><span>老闆行政 <b class="num">'+h.adminH.toFixed(1)+'</b> 小時</span></div><div class="staff-rows" role="region" aria-label="員工工時列表" tabindex="0">'+rows+'</div>';
 if(!oldRows||hudBL._h!==hudContent){var focused=oldRows&&oldRows.contains(document.activeElement)||document.activeElement===oldRows;hudBL.innerHTML=hudContent;hudBL._h=hudContent;var newRows=hudBL.querySelector('.staff-rows');newRows.scrollTop=scroll;if(focused)newRows.focus({preventScroll:true});}
 var ns=s.news.slice(0,2);
 $('#news').innerHTML=ns.map(function(n){return '<div><span class="num">'+(n.day===s.day?hm(n.t):dateStr(n.day).replace(/^\d+年/,''))+'</span><b>'+esc(n.who)+'</b>'+esc(n.txt)+'</div>';}).join('');
 renderDock();
 $('#btnExt').classList.toggle('on',!!s.exterior);
 $('#btnFloor').innerHTML=s.floorG?'地下 G/F<small>撳返去 1 樓美容店</small>':'1 樓 1/F<small>撳去地下茶餐廳</small>';
 if(s.visit)renderVisitHUD();
}
/* 保留按鈕節點，避免 HUD 更新令游標懸停、焦點和高亮不斷重設。 */
function renderDock(){var dock=$('#dock'),wanted={};
 DOCK.filter(function(d){return d[0]!=='shadow';}).forEach(function(d){var id=d[0],b=dockBadge(id),btn=dock.querySelector('button[data-p="'+id+'"]');wanted[id]=1;
  if(!btn){btn=document.createElement('button');btn.setAttribute('data-act','panel');btn.setAttribute('data-p',id);dock.appendChild(btn);}
  var cls=(PANEL.id===id?'on ':'')+(s.newFlag[id]?'new':''),content='<span class="seal sm">'+d[1]+'</span>'+d[2]+(b?'<span class="badge">'+b+'</span>':'')+(s.newFlag[id]?'<span class="newtag">新</span>':'');
  if(btn.className!==cls)btn.className=cls;if(btn.innerHTML!==content)btn.innerHTML=content;
 });
 Array.prototype.slice.call(dock.querySelectorAll('button[data-p]')).forEach(function(btn){if(!wanted[btn.getAttribute('data-p')])btn.remove();});
}
function hk2(k,v,d,cls){return '<div class="kp '+(cls||'')+'"><span class="k">'+k+'</span><span class="v num">'+v+'</span><span class="d">'+d+'</span></div>';}
function dockBadge(id){if(id==='staff'&&s.cands.length)return s.cands.length+' 份 CV';if(id==='ai'){var n=ROLES.filter(function(r){return s.lv[r.id];}).length;return n?n+'/6':'';}if(id==='fin'&&s.cash<0)return '欠 '+hk(-s.cash);return '';}
function staffHours(x){
 var w=s.wk,used=0,days=0;for(var d=w.start;d<w.start+7;d++){if(!staffWorks(x,d))continue;days++;}
 if(x.role==='asst')return{used:x.hoursW*Math.min(1,w.done/Math.max(1,w.appts.length)+.3),avail:x.hoursW};
 w.appts.forEach(function(a){if(a.g===x.id&&a.st!=='lost')used+=a.dur;});
 if(x.role==='owner')used+=w.adm*days+taskMinWeek()+(w.fillMin||0);
 return{used:used/60,avail:days*(CLOSE_MIN-OPEN_MIN-45)/60};
}
function monthToDate(){var d0=dateOf(s.day),y=d0.getFullYear(),m=d0.getMonth();var ds=s.days.filter(function(x){var q=dateOf(x.day);return q.getFullYear()===y&&q.getMonth()===m;});
 return{days:ds.length,profit:sum(ds.map(function(x){return x.rev-x.cost;})),rev:sum(ds.map(function(x){return x.rev;})),dim:new Date(y,m+1,0).getDate(),ds:ds};}
/* 選中卡：寵物、主人、員工 */
function renderSel(){
 var el=$('#selCard');if(!el)return;if(!s||!s.sel){el.hidden=true;return;}
 var sl=s.sel,h='';
 if(sl.type==='pet'||sl.type==='owner'){var a=s.wk.appts.filter(function(x){return x.id===sl.id;})[0];if(!a){el.hidden=true;return;}
  var g=SEGS.filter(function(x){return x.id===a.seg;})[0];
  h='<div class="sc-h"><b>'+esc(sl.type==='pet'?a.pet:a.owner)+'</b><button class="x" data-act="selx" aria-label="關閉">×</button></div>'+
   '<dl><dt>時間</dt><dd class="num">'+hm(a.a)+'–'+hm(a.b)+'</dd><dt>美容師</dt><dd>'+esc(staffName(a.g))+' · 枱 '+(a.tb+1)+'</dd><dt>寵物</dt><dd>'+esc(a.pet)+'（'+esc(a.breed)+'，'+g.name+'）</dd><dt>服務</dt><dd>'+SVC[a.svc].n+' · '+hk(a.price)+'</dd><dt>主人</dt><dd>'+esc(a.owner)+(a.regular?' · 熟客':' · 新客')+(a.tag?' · '+a.tag:'')+'</dd><dt>狀態</dt><dd>'+stLabel(a)+'</dd></dl>'+
   '<p class="think">'+esc(thought(a,sl.type))+'</p>'+selRec(a);}
 else if(sl.type==='staff'){var x=s.staff.filter(function(z){return z.id===sl.id;})[0];if(!x){el.hidden=true;return;}
  h='<div class="sc-h"><b>'+esc(x.name)+'</b><button class="x" data-act="selx" aria-label="關閉">×</button></div><dl><dt>職位</dt><dd>'+roleName(x)+'</dd><dt>士氣</dt><dd>'+Math.round(x.morale*100)+'%</dd><dt>特點</dt><dd>'+(x.shown&&x.trait?esc(x.trait.n):'未知')+'</dd></dl><p class="think">'+esc(staffThought(x))+'</p>';}
 el.innerHTML=h;el.hidden=false;
}
function stLabel(a){return {booked:'已預約',arrived:'到咗，等緊',doing:'美容中',done:'完成，等主人接',gone:'已接走',noshow:'No-show',cancel:'臨時取消',lost:'冇位'}[a.st]||a.st;}
/* 選中卡：持續紀錄（只顯示已確認或主人提供嘅內容做提示） */
function selRec(a){var p=a.pid&&clPet(a.pid);if(!p)return '';var c=clConfirmed(p),d=clDrafts(p);
 return '<div class="sc-rec"><b>紀錄 #'+p.id.slice(1)+'</b> · '+esc(clKind(p))+(p.cnt.done?' · 完成 '+p.cnt.done+' 次':'')+(p.cnt.noshow?' · No-show '+p.cnt.noshow:'')+'<br>'+(c.length?'上次提示：'+esc(c.slice(-2).map(clNoteText).join('；')):'上次提示：未記錄')+(d.length?'<br><span class="note">另有 '+d.length+' 份未確認 AI 草稿（唔會用嚟做提示）</span>':'')+'<br><button class="btn" data-act="clopen" data-p="'+p.id+'">睇檔案</button></div>';}
function thought(a,who){
 var hp=a.pid&&clPet(a.pid),seen=hp&&hp.cnt.done>0;
 if(who==='owner')return a.st==='arrived'||a.st==='booked'?(seen?(clConfirmed(hp).length?'「上次你哋記得佢嘅習慣，今次照樣就得。」':'「同上次一樣就得，唔好剪太短。」'):hp&&hp.pre?'「我哋幫襯咗好耐，不過你哋應該冇紀錄。」':'「第一次嚟，希望佢唔好太驚。」'):(a.inc?'「'+FB_BAD[a.inc]+'，我好唔開心。」':'「幾企理，下次再約。」');
 if(a.st==='doing')return a.inc==='stress'?'佢好緊張，一直震。':a.seg==='k'?'貓咪好警惕，要慢慢嚟。':a.seg==='o'?'年紀大，要留意呼吸。':'乖乖企好俾人剪。';
 if(a.st==='done'||a.st==='gone')return '洗完香噴噴，等主人接。';
 return '喺籠入面等緊。';}
function staffThought(x){if(x.morale<.5)return '「我好攰，諗緊要唔要轉工。」';if(x.role==='owner')return s.wk.h.adminH>12?'「成日覆 WhatsApp，冇時間剪狗。」':'「今日幾順。」';return '「今日 OK。」';}
function roleName(x){return x.role==='owner'?'老闆兼美容師':x.role==='groomer'?'全職美容師':x.role==='front'?'全職前台':'兼職助理';}

/* ---------- 彈窗 ---------- */
function renderModal(){
 var bg=$('#modalBg');if(!bg)return;var m=s&&s.modal;if(!m){bg.hidden=true;return;}
 var h='';
 if(m.type==='event'){var E=EVENTS[m.id];
  h='<div class="m-h"><span class="lbl">事件 · '+dateStr(s.day)+'</span><h2>'+esc(E.title)+'</h2></div><div class="m-b"><p>'+esc(E.body(m.ctx))+'</p>'+
   '<div class="choices3">'+E.ch.map(function(c,i){return '<button class="opt" data-act="evch" data-i="'+i+'"><b>'+esc(c.t)+'</b><ul>'+c.pro.map(function(p){return '<li class="pro">＋ '+esc(p)+'</li>';}).join('')+c.con.map(function(p){return '<li class="con">− '+esc(p)+'</li>';}).join('')+'</ul></button>';}).join('')+'</div>'+
   '<div class="aibox"><span class="seal sm">智</span><div><b>如果有 AI 會點</b><p>'+esc(E.ai)+'</p></div></div></div>';}
 else if(m.type==='month'){var r=m.rec,c=r.cats;
  h='<div class="m-h"><span class="lbl">月結</span><h2>'+r.y+' 年 '+r.m+' 月</h2></div><div class="m-b"><div class="kgrid">'+
   kbox('營收',hk(r.rev))+kbox('經營支出',hk(r.cost))+kbox('經營利潤',hk(r.profit),r.profit<0?'bad':'')+kbox('月末公司現金',hk(r.cash),r.cash<0?'bad':'')+
   kbox('完成服務',r.done+' 隻')+kbox('No-show',r.ns+' 個')+kbox('臨時取消',r.cancel+' 個')+kbox('冇位流失',r.lost+' 個')+'</div>'+
   monthStmt(r)+
   '<p class="cmpline">隔籬（唔用 AI）今個月利潤約 <b>'+hk(r.shProfit)+'</b>，現金 '+hk(r.shCash)+'，評分 '+r.shRating.toFixed(2)+'。你嘅評分 '+r.rating.toFixed(2)+'。</p></div>'+
   '<div class="m-f"><button class="btn pri" data-act="mclose">繼續</button></div>';}
 else if(m.type==='soloIntro'){
  h='<div class="m-h"><span class="lbl">一人工作室 · 開局背景</span><h2>帶住經驗，開自己間店</h2></div><div class="m-b">'+
   '<p>你做咗約 5 年寵物美容，曾經喺美容店工作，亦接過上門服務。多年來認識咗一批主人；知道你開新工作室之後，部分熟客願意繼續搵你，亦有人介紹朋友過嚟。</p>'+
   '<p>你喺荃灣租咗一間 300 呎樓上舖，只有一張美容枱。洗剪、覆訊息、排期同對數都由你一個人做。新店有舊客支持，但每位客人幾時回來、會唔會繼續幫襯，都唔保證。</p>'+
   '<div class="kgrid">'+kbox('開局活躍名單（估算）',Math.round(s.base.active)+' 位')+kbox('公司現金',hk(s.base.startCash))+kbox('老闆小金庫',hk(s.own.fund))+kbox('每月租金',hk(s.base.rent))+'</div>'+
   '<p class="note">故事與數字均為遊戲示範假設。活躍名單唔等於最近 30／90 日實際到店人數，亦唔代表全部人已預約；第一週排程後數字可能變動。</p></div>'+
   '<div class="m-f"><button class="btn pri" data-act="mclose">開始經營</button></div>';}
 else if(m.type==='over')h=overHTML(m);
 else if(m.type==='demo')h=demoModalHTML(m);
 else if(m.type==='settings'){
  h='<div class="m-h"><span class="lbl">設定（Esc）</span><h2>暫停中</h2></div><div class="m-b set">'+
   '<button class="btn pri" data-act="mclose">繼續</button><button class="btn" data-act="labels">名字標籤：'+(s.labels?'開':'關')+'</button><button class="btn" data-act="camreset">重設視角</button><button class="btn" data-act="skipopt">自動跳過非營業時間：'+(OPTS.skip===0?'關':'開')+'</button><button class="btn" data-act="savenow">儲存</button><button class="btn" data-act="shadow">陰影：'+(W3.sun&&W3.sun.castShadow?'開':'關')+'</button><button class="btn" data-act="edge">畫面邊緣推鏡：'+(EDGE.on?'開':'關')+'</button><button class="btn" data-act="shadowpanel">隔籬經營比較</button><button class="btn" data-act="visit">'+(s.visit?'返去自己間店':'參觀隔籬')+'</button><button class="btn" data-act="demo">示範模式</button><button class="btn" data-act="sound">音效：'+(SND.on?'開':'關')+'</button><button class="btn" data-act="music">背景音樂：'+(SND.music?'開':'關')+'</button><label class="vol">音效音量<input type="range" min="0" max="1" step=".05" value="'+SND.vol+'" data-act="vol" data-k="sfx"></label><label class="vol">音樂音量<input type="range" min="0" max="1" step=".05" value="'+SND.mvol+'" data-act="vol" data-k="mus"></label><button class="btn" data-act="home">主選單</button>'+
   '<div class="gpu"><b>顯示卡</b><p class="num">'+esc(W3.gpu)+'</p><p class="note">如果見到係內置顯示卡（例如 Intel UHD）而部機有獨立顯示卡：Windows「設定 → 系統 → 顯示器 → 圖形」，揀你個瀏覽器 → 選項 →「高效能」，再重開瀏覽器。</p></div>'+
   '<p class="note">鏡頭：左鍵拖曳移動（放手有慣性）、右鍵或中鍵拖曳旋轉同俯仰、滾輪向游標縮放（縮近會自動放平）、雙擊飛去嗰度；WASD 移動、Q／E 旋轉、R／F 縮放；滑鼠去到畫面邊緣會推鏡。空白鍵暫停，1–4 轉速度。</p></div>';}
 $('#modal').innerHTML=h;bg.hidden=false;
}
function kbox(k,v,cls){return '<div class="kb '+(cls||'')+'"><span>'+k+'</span><b class="num">'+v+'</b></div>';}
