/* p_real_ui：老闆、小金庫、貸款、保險面板；結業彈窗；手動排程拖放；參觀隔籬。 */
function pOwner(){
 var o=s.own,last=s.months[s.months.length-1];
 return '<p>你都係一個人：每月月結先出老闆底薪 '+hk(o.base)+'；蝕錢嗰個月減 30%；賺多過底薪嘅部分，一半入你嘅小金庫，一半留喺公司。</p><div class="kgrid">'+
  kbox('小金庫',hk(o.fund))+kbox('上月底薪',hk(o.lastPay))+kbox('公司現金',hk(s.cash),s.cash<0?'bad':'')+kbox('老闆士氣',Math.round(own().morale*100)+'%')+'</div>'+
  (last&&last.ownerPay!=null?'<h3>上月月結</h3>'+monthStmt(last):'<p class="note">第一次月結之後先有數。</p>')+
  '<h3>由小金庫注資入公司</h3><div class="aedit">'+[20000,50000].map(function(v){return '<button class="btn" data-act="inject" data-v="'+v+'"'+(o.fund<v?' disabled title="小金庫唔夠"':'')+'>注資 '+hk(v)+'</button>';}).join('')+'<button class="btn" data-act="inject" data-v="'+Math.floor(o.fund)+'"'+(o.fund<1?' disabled':'')+'>全部注資</button></div>'+
  '<p class="note">一人公司唔可以淨係睇損益表：老闆每週行政 '+s.wk.h.adminH.toFixed(1)+' 小時，加埋剪狗時間，士氣低過 50% 會影響判斷（v0.4 創辦人工作仲會再食你嘅時間）。</p>';
}
function pLoan(){
 var h='<p>現金唔夠可以借錢，但每月要還本金同利息。</p><div class="cards2">'+Object.keys(LOANS).map(function(k){var L=LOANS[k],amt=k==='bank'?150000:80000;
  return '<div class="scard"><div class="sc-top"><b>'+L.name+'</b></div><dl><dt>年利率</dt><dd>'+pct(L.apr)+'</dd><dt>年期</dt><dd>'+L.months+' 個月</dd><dt>上限</dt><dd>'+hk(L.max)+'</dd><dt>條件</dt><dd>'+L.need+'</dd><dt>借 '+hk(amt)+'</dt><dd class="num">每月還 '+hk(loanPay(amt,L.apr,L.months))+'，總利息 '+hk(loanPay(amt,L.apr,L.months)*L.months-amt)+'</dd></dl>'+
  '<button class="btn" data-act="loan" data-k="'+k+'" data-v="'+amt+'"'+(k==='bank'&&s.bank?' disabled title="審批中"':'')+'>申請 '+hk(amt)+'</button></div>';}).join('')+'</div>';
 h+=s.bank?'<p class="note">銀行審批中：'+hk(s.bank.amt)+'，'+dateStr(s.bank.at)+' 有結果。</p>':'';
 h+=s.loans.length?'<div class="tw"><table><thead><tr><th>貸款</th><th class="num">本金</th><th class="num">每月還</th><th class="num">仲有</th></tr></thead><tbody>'+s.loans.map(function(l){return '<tr><td>'+l.name+'</td><td class="num">'+hk(l.amt)+'</td><td class="num">'+hk(l.pay)+'</td><td class="num">'+l.left+' 個月</td></tr>';}).join('')+'</tbody></table></div>':'<p class="note">而家冇貸款。</p>';
 return h;
}
/* 保險同法規（v0.16.1 改版）：卡片式，唔再用三欄表（窄面板會逐隻字斷行）。 */
function insCard(title,pill,cls,desc,extra){return '<div class="insc"><div class="insh"><b>'+title+'</b>'+(pill?'<span class="pill '+(cls||'')+'">'+pill+'</span>':'')+'</div><p>'+desc+'</p>'+(extra||'')+'</div>';}
function pIns(){
 var L=s.claims||[],paid=0,self=0,pend=0;L.forEach(function(c){paid+=c.paid||0;if(c.st==='pending')pend+=c.amt;else self+=c.amt-(c.paid||0);});
 var h='<div class="kgrid">'+kbox('事故墊支（累計）',hk(sum(L.map(function(c){return c.amt;}))))+kbox('保險已賠',hk(paid))+kbox('審核中',hk(pend))+kbox('自己承擔',hk(self),self>0?'bad':'')+'</div>';
 h+='<h3>保險</h3><div class="insg">'+
  insCard('僱員補償保險','已買','ok','法例強制。工傷要申報，由保險公司按《僱員補償條例》同保單處理；病假錢通常要僱主先畀。')+
  insCard('公眾責任保險',s.ins.pl?'已買':'冇買',s.ins.pl?'ok':'bad','寵物受傷、主人索償。每月約 HK$600、墊底費 '+hk(CLAIM.excess)+'（示範估算）。事故費用先由店舖墊支，保險公司審核 3–6 週後先賠，可能部分賠或者拒賠。',
   '<label class="sw insw"><input type="checkbox" data-act="pl" '+(s.ins.pl?'checked':'')+'> '+(s.ins.pl?'續保中（撳一下停保）':'冇買：事故費用全數自己畀（撳一下買返）')+'</label>')+'</div>';
 h+='<h3>牌照同法規</h3><div class="insg">'+
  insCard('商業登記','已登記','ok','開業必須。')+
  insCard('強積金','自動扣','ok','僱主供 5%，每人每月最多 HK$1,500。')+
  insCard('最低工資','助理時薪 '+hk(s.S.P.assistantRate),'','HK$43.1／小時（2026-05-01 起）。')+
  insCard('漁護署牌照','冇做寄養','','純美容唔需要；過夜寄養要動物寄養所牌照（HK$3,810／年）。')+
  insCard('私隱條例','同意率 '+pct(s.consent),'','直銷推廣要客人同意（第 6A 部）；預約提醒唔使。')+
  insCard('大廈公契／用途',s.open==='solo'?'要留意':'商業樓宇',s.open==='solo'?'warn':'','住宅、工廈可能唔准做動物相關生意；狗吠同大風量吹風機容易惹滋擾投訴。')+
  insCard('預繳套票','未賣套票','','2026 修例建議只包美容院、健身；結業會惹消委會投訴。')+'</div>'+
  '<p class="note">牌照資料要開業前向漁護署（1823）核實；保險條款以保單為準，遊戲入面嘅墊底費同批核比率係示範估算。</p>'+claimsHTML();
 return h;}
function overHTML(m){var r=m.rec;return '<div class="m-h"><span class="lbl">'+r.y+' 年 '+r.m+' 月</span><h2>現金連續兩個月蝕穿，間店結業</h2></div><div class="m-b"><p>公司現金 '+hk(s.cash)+'，小金庫 '+hk(s.own.fund)+'。隔籬（唔用 AI）現金 '+hk(s.shCash)+'。</p><p>回頭睇：最大嘅開支係人工同租金；AI 慳到嘅主要係老闆時間，唔會自己變成生意，要有產能同客源先得。</p></div><div class="m-f"><button class="btn" data-act="home">主選單</button><button class="btn pri" data-act="restart">再開一間</button></div>';}

/* ---------- 點擊 ---------- */
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el||!GAME.on||!s)return;var a=el.getAttribute('data-act');
 if(a==='inject'){injectFund(+el.getAttribute('data-v'));renderPanel();renderHUD();}
 else if(a==='loan'){takeLoan(el.getAttribute('data-k'),+el.getAttribute('data-v'));renderPanel();renderHUD();}
 else if(a==='consent'){askConsent();renderPanel();}
 else if(a==='restart'){var id=s.open;s.modal=null;startGame(id);}
 else if(a==='lane'&&!e.target.closest('.blk')){var r=el.getBoundingClientRect(),t=OPEN_MIN+Math.round(((e.clientX-r.left)/r.width*(CLOSE_MIN-OPEN_MIN))/15)*15;
  SCHED.slot={day:+el.getAttribute('data-day'),g:+el.getAttribute('data-g'),t:t};SCHED.sel=null;SCHED.msg=null;renderPanel();}
 else if(a==='addbk'){var sl=SCHED.slot,err=addFromBacklog(sl.day,sl.g,sl.t);SCHED.msg={ok:!err,t:err?'加唔到：'+err:'已經加咗一位候補'};if(!err)SCHED.slot=null;renderPanel();}
 else if(a==='slotx'){SCHED.slot=null;renderPanel();}
 else if(a==='apply'){var id2=+el.getAttribute('data-id'),err2=moveAppt(id2,+$('#ed-day').value,+$('#ed-g').value,+$('#ed-t').value);SCHED.msg={ok:!err2,t:err2?'調唔到：'+err2:'已經調好'};renderPanel();}
 else if(a==='appt'){SCHED.slot=null;SCHED.msg=null;}
 else if(a==='visit'){s.visit=s.visit?0:1;s.modal=null;news('隔籬',s.visit?'你過咗去隔籬參觀':'你返咗自己間店');renderHUD();}
});
document.addEventListener('change',function(e){if(e.target.matches('[data-act=pl]')&&s){s.ins.pl=e.target.checked?1:0;news('保險','公眾責任保險：'+(s.ins.pl?'買咗':'停咗'));renderPanel();}});
/* ---------- 拖放 ---------- */
var DRAG=null;
document.addEventListener('dragstart',function(e){var b=e.target.closest&&e.target.closest('.blk.ap');if(!b)return;DRAG=+b.getAttribute('data-id');try{e.dataTransfer.setData('text/plain',String(DRAG));e.dataTransfer.effectAllowed='move';}catch(x){}});
document.addEventListener('dragover',function(e){if(DRAG!=null&&e.target.closest&&e.target.closest('.lane'))e.preventDefault();});
document.addEventListener('drop',function(e){
 if(DRAG==null)return;var lane=e.target.closest&&e.target.closest('.lane');if(!lane){DRAG=null;return;}e.preventDefault();
 var other=e.target.closest('.blk.ap'),err;
 if(other&&+other.getAttribute('data-id')!==DRAG)err=swapAppt(DRAG,+other.getAttribute('data-id'));
 else{var r=lane.getBoundingClientRect(),a=apptById(DRAG),t=OPEN_MIN+Math.round(((e.clientX-r.left)/r.width*(CLOSE_MIN-OPEN_MIN)-a.dur/2)/15)*15;err=moveAppt(DRAG,+lane.getAttribute('data-day'),+lane.getAttribute('data-g'),t);}
 SCHED.msg={ok:!err,t:err?'調唔到：'+err:'已經調好'};SCHED.sel=DRAG;DRAG=null;renderPanel();
});
document.addEventListener('dragend',function(){DRAG=null;});

/* ---------- 參觀隔籬 ---------- */
HOOKS.plan=HOOKS.plan||[];
HOOKS.plan.push(function(){
 /* 隔籬都有一張張預約（只用嚟畫 3D）：佢冇 AI，老闆行政時間長 */
 var hs=s.wk.hs,n=probRound(hs.done),gN=s.base.groomers+s.shHires,adm=hs.adminH*60/6,list=[];
 var lanes=[];for(var g=0;g<gN;g++)lanes.push(g);
 var cur={};
 for(var d=0;d<7;d++){lanes.forEach(function(g){cur[d+'_'+g]=OPEN_MIN+(g===0?adm*.6:0);});}
 for(var i=0;i<n;i++){var d2=Number(pickW({0:DAYW[0],1:DAYW[1],2:DAYW[2],3:DAYW[3],4:DAYW[4],5:DAYW[5],6:DAYW[6]})),a=mkAppt(hs,s.sh.P,d2,.8,0);a.out='ok';
  var best=null;lanes.forEach(function(g){if((g+d2)%7===6)return;var k=d2+'_'+g,t=cur[k];if(t<LUNCH[1]&&t+a.dur>LUNCH[0])t=LUNCH[1];if(t+a.dur<=CLOSE_MIN-(g===0?adm*.4:0)&&(!best||t<best.t))best={g:g,t:t};});
  if(!best)continue;a.g=-1-best.g;a.tb=best.g%s.base.tables;a.a=best.t;a.b=best.t+a.dur;cur[d2+'_'+best.g]=a.b;list.push(a);}
 s.shWk={appts:list,gN:gN};
});
function shadowStaff(day){var n=s.shWk?s.shWk.gN:s.base.groomers,out=[];for(var g=0;g<n;g++)if((g+(day-s.wk.start))%7!==6)out.push({id:-1-g,name:g===0?'隔籬老闆':'隔籬美容師 '+g,role:g===0?'owner':'groomer'});out.push({id:-50,name:'隔籬助理',role:'asst'});return out;}
function shopView(){
 if(!s.visit||!s.shWk)return null;var t=s.t,ap=s.shWk.appts.filter(function(a){return a.day===s.day;});
 ap.forEach(function(a){a.st=t<a.a-15?'booked':t<a.a?'arrived':t<a.b?'doing':t<a.b+40?'done':'gone';});
 var st=shadowStaff(s.day);return{appts:ap,gs:st.filter(function(x){return x.role!=='asst';}),shifts:st};
}
function renderVisitHUD(){
 if(!s.visit)return;var a=s.wk.h,b=s.wk.hs,ma=s.months[s.months.length-1];
 $('#hudTR').innerHTML=hk2('隔籬現金',hk(s.shCash),'佢冇用 AI')+hk2('活躍客',Math.round(actN(s.sh))+' 位','你 '+Math.round(actN(s.S)))+hk2('評分',s.sh.rating.toFixed(2),'你 '+s.S.rating.toFixed(2))+hk2('美容師',(s.base.groomers+s.shHires)+' 人','你 '+groomers().length);
 function r(n,x,y,f,up){var d=x-y,c=Math.abs(d)<1e-9?'':((up===false?d<0:d>0)?'up':'dn');return '<div class="vrow"><span>'+n+'</span><b class="num '+c+'">'+f(x)+'</b><b class="num">'+f(y)+'</b></div>';}
 var f1=function(v){return v.toFixed(1);};
 $('#hudBL').innerHTML='<div class="hbl-h"><b>你 vs 隔籬</b><span>綠色＝你較好</span></div><div class="vrow hd"><span></span><b>你</b><b>隔籬</b></div>'+
  r('現金',s.cash,s.shCash,function(v){return sMoney(v);})+(ma?r('上月利潤',ma.profit,ma.shProfit,function(v){return sMoney(v);}):'')+r('本週完成',a.done,b.done,f1)+r('老闆行政 h',a.adminH,b.adminH,f1,false)+r('No-show',a.ns,b.ns,pct,false)+r('人手',activeStaff().length,s.base.groomers+s.shHires+1,function(v){return Math.round(v)+'';},false)+r('評分',s.S.rating,s.sh.rating,function(v){return v.toFixed(2);})+
  '<button class="btn pri" data-act="visit">返去自己間店</button>';
 var tl=$('#hudTL .shopname b');if(tl)tl.textContent='隔籬（唔用 AI）';
}
