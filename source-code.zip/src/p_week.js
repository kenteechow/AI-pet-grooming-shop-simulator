/* p_week：跳過非營業時間、7 日返工（v0.14）。
   跳過：收工後（19:30 再過一個鐘，美容店冇客人喺度）到第二朝 09:30（開門前一個鐘，等第一批客人行嚟），時間用每秒約 280 分鐘快速推過去，
   光線照樣跟時間漸變；所有預約、任務、事件照常逐步處理（只係快啲）。選項「自動跳過非營業時間」預設開；
   關咗嘅話，時間面板會出「跳到 09:30」掣。午夜有事件或者月結彈窗會停低。
   7 日返工：老闆可以揀「唔放（7 日都返）」；員工按《僱傭條例》每 7 日最少有 1 日休息日，只可以改邊日放。
   改休息日由下星期一起生效（排咗嘅預約唔使重排）。老闆 7 日都返：剪狗時間多一日，但每週士氣 −3%、事故率 +5%（示範估算）。 */
var SKIP={rate:280,from:CLOSE_MIN+60,to:OPEN_MIN-60};
function skipWin(){return !!s&&(s.t>=SKIP.from||s.t<SKIP.to);}
function skipBusy(){return todayAppts().some(function(a){return a.st==='arrived'||a.st==='doing'||a.st==='done';});}
function skipOn(){if(!skipWin()){if(s)s.skipNow=0;return false;}var auto=typeof OPTS==='undefined'||OPTS.skip!==0;return (auto||!!s.skipNow)&&!skipBusy();}
/* 呢一格最多推幾多分鐘：晚上推到午夜（之後日結），朝早推到 09:30 */
function skipCap(){return s.t>=SKIP.from?DAY1-s.t:SKIP.to-s.t;}
function skipHTML(){if(!s||s.bg||!skipWin())return '';
 if(skipOn())return '<div class="skipline"><span>跳過非營業時間</span><button class="lnk" data-act="skipstop">停</button></div>';
 if(skipBusy())return '';
 return '<div class="skipline"><span>非營業時間</span><button class="btn pri" data-act="skipnow">跳到 '+hm(SKIP.to)+'</button></div>';}
/* ---------- 休息日同 7 日返工 ---------- */
function offLabel(v){return v===-1?'唔放（7 日都返）':'星期'+WKD[v];}
function offSel(x){var opts=[0,1,2,3,4,5,6];if(x.role==='owner')opts.push(-1);var cur=x.offNext!=null?x.offNext:x.off;
 return '<select data-act="offday" data-id="'+x.id+'" aria-label="'+esc(x.name)+'嘅休息日">'+opts.map(function(v){return '<option value="'+v+'"'+(v===cur?' selected':'')+'>'+offLabel(v)+'</option>';}).join('')+'</select>'+
  (x.offNext!=null&&x.offNext!==x.off?'<small class="note">而家'+offLabel(x.off)+'，下星期一起'+offLabel(x.offNext)+'</small>':'')+
  (x.role==='owner'?(x.off===-1?'<small class="note warn">7 日都返：每週士氣 −3%，事故率 +5%</small>':''):'<small class="note">《僱傭條例》：每 7 日最少 1 日休息日，唔可以強迫佢返</small>');}
HOOKS.week.push(function(){
 s.staff.forEach(function(x){if(x.offNext!=null){if(x.offNext!==x.off)news('員工',x.name+'由今個星期起'+(x.offNext===-1?'7 日都返':'逢星期'+WKD[x.offNext]+'休息'));x.off=x.offNext;delete x.offNext;}});
 var o=s.staff.filter(function(x){return x.role==='owner';})[0];
 if(o&&o.off===-1){o.morale=Math.max(.1,o.morale-.03);if(o.morale<.5&&!s.warn7){s.warn7=1;news('老闆','連續 7 日返工，你好攰（士氣 '+Math.round(o.morale*100)+'%）。考慮返一日休息日。');}}else s.warn7=0;});
HOOKS.sync.push(function(P){var o=s.staff.filter(function(x){return x.role==='owner';})[0];if(o&&o.off===-1){P.ownerDays=7;P.incidentMult*=1.05;}});
if(typeof document!=='undefined'){
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');
  if(a==='skipnow'){s.skipNow=1;s.paused=false;renderHUD();}
  if(a==='skipstop'){s.skipNow=0;OPTS.skip=0;optsSave();renderHUD();}
  if(a==='skipopt'){OPTS.skip=OPTS.skip===0?1:0;optsSave();renderModal();}});
 document.addEventListener('change',function(e){if(!e.target.matches('[data-act=offday]')||!s)return;var id=+e.target.getAttribute('data-id'),v=+e.target.value,x=s.staff.filter(function(z){return z.id===id;})[0];if(!x)return;
  if(v===-1&&x.role!=='owner')return;x.offNext=v;news('員工',x.name+'嘅休息日改做'+offLabel(v)+'，下星期一起生效');renderPanel();});}
/* ---------- 自動由候補名單補空位（v0.16） ----------
   每日朝早（星期一喺排完新一週之後）睇今日同聽日每位美容師嘅空檔，有候補就自動加入（每次最多 4 個）。
   冇「排」L2：係老闆逐個打電話，每個約 5 分鐘，計入老闆工時；「排」L2 以上：AI 自動 WhatsApp 候補客，唔使老闆時間。
   今日只補兩個鐘之後嘅時段（要畀時間客人過嚟）。候補嘅客都有機會 no-show（同手動加一樣）。預設開，排程面板可以關。 */
var AUTOFILL={max:4,callMin:5,lead:120};
function autoFillOn(){return !!s&&s.autoFill!==0&&!s.bg;}
function autoFill(){if(!autoFillOn()||!s.wk||s.S.backlog<1)return 0;var n=0,ai=(s.lv.sched||0)>=2,names=[];
 for(var d=s.day;d<=s.day+1&&d<s.wk.start+7;d++){groomers().forEach(function(g){if(n>=AUTOFILL.max||s.S.backlog<1||!staffWorks(g,d))return;
  var from=d===s.day?Math.max(s.t+AUTOFILL.lead,OPEN_MIN):OPEN_MIN;from=Math.ceil(from/5)*5;
  freeGaps(d,g.id,from).forEach(function(gp){while(n<AUTOFILL.max&&s.S.backlog>=1){var a=mkAppt(s.wk.h,s.S.P,d-s.day,1,0);if(gp[1]-gp[0]<a.dur){return;}
    a.tag='候補';a.regular=true;a.out=R()<s.wk.h.ns*.5?'noshow':'ok';a.auto=1;clAssign(a,true);
    if(canPlace(a,d,g.id,gp[0])){clDrop(a);return;}
    s.wk.appts.push(a);setSlot(a,d,g.id,gp[0]);a.manual=0;s.S.backlog-=1;n++;names.push(a.pet+'（星期'+WKD[d%7]+' '+hm(a.a)+'）');gp[0]=a.b;s.rep.refill++;}});});}
 if(n){if(ai){aiLog('排','自動 WhatsApp 候補客，補咗 '+n+' 個空位：'+names.join('、'),Math.max(DAY0,Math.min(s.t,DAY1-1)));news('補位','AI 由候補名單補咗 '+n+' 個空位');}
  else{s.wk.fillMin=(s.wk.fillMin||0)+n*AUTOFILL.callMin;news('補位','你打電話畀候補客，補咗 '+n+' 個空位（用咗約 '+n*AUTOFILL.callMin+' 分鐘）：'+names.join('、'));}}
 return n;}
HOOKS.day.push(function(){if(s.day%7!==0)autoFill();});
HOOKS.plan=HOOKS.plan||[];HOOKS.plan.push(function(){autoFill();});
if(typeof document!=='undefined')document.addEventListener('change',function(e){if(!e.target.matches('[data-act=autofill]')||!s)return;s.autoFill=e.target.checked?1:0;news('排程','自動由候補名單補空位：'+(s.autoFill?'開':'關'));renderPanel();});
