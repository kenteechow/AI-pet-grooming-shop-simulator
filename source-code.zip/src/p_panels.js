/* p_panels：排程、客人、員工、AI 部署、財務、隔籬、報告。標題、關閉掣、子目錄固定喺頂，內容先捲。 */
var SUBS={
 sched:[['week','本週'],['today','今日']],
 cust:[['funnel','漏斗'],['rec','客人紀錄'],['story','毛孩故事'],['dorm','沉睡客'],['fb','意見']],
 staff:[['team','團隊'],['hire','請人']],
 ai:null,
 fin:[['month','今個月'],['months','月結'],['trend','走勢'],['owner','老闆同小金庫'],['loan','貸款'],['ins','保險同法規']],
 shadow:[['cmp','比較']],
 rep:[['report','成果報告']]
};
var SCHED={filter:{wash:1,cut:1,nail:1,cat:1},probOnly:0,sel:null};
function aiSubs(){return [['ov','總覽'],['day','AI 嘅一日']].concat(ROLES.map(function(r){return [r.id,r.seal+' '+r.name];}));}
function openPanel(id){if(PANEL.id===id){PANEL.id=null;renderPanel();renderHUD();return;}PANEL.id=id;var subs=id==='ai'?aiSubs():SUBS[id];PANEL.sub=subs[0][0];delete s.newFlag[id];renderPanel();renderHUD();}
function renderPanel(){
 var el=$('#panel');if(!el)return;if(!PANEL.id||!s){el.hidden=true;return;}
 var id=PANEL.id,subs=id==='ai'?aiSubs():SUBS[id],d=DOCK.filter(function(x){return x[0]===id;})[0]||{log:['log','誌','日誌']}[id];
 var body=el.querySelector('.p-body'),st=body?body.scrollTop:0;
 CH={};
 var h='<div class="p-head"><div class="p-title"><span class="seal sm">'+d[1]+'</span><h2>'+d[2]+'</h2><button class="x" data-act="pclose" aria-label="關閉">×</button></div><div class="p-subs" role="tablist">'+
  subs.map(function(x){var b=subBadge(id,x[0]);return '<button role="tab" data-act="psub" data-s="'+x[0]+'" class="'+(PANEL.sub===x[0]?'on':'')+'">'+x[1]+(b?'<span class="badge">'+b+'</span>':'')+'</button>';}).join('')+'</div></div>';
 var fn={sched:pSched,cust:pCust,staff:pStaff,ai:pAI,fin:pFin,shadow:pShadow,rep:pRep,fd:pFd,grow:typeof pGrow==='function'?pGrow:null,log:typeof pLog==='function'?pLog:null}[id];
 h+='<div class="p-body">'+fn(PANEL.sub)+'</div>';
 el.innerHTML=h;el.hidden=false;var nb=el.querySelector('.p-body');nb.scrollTop=st;drawCharts(nb);
}
function subBadge(id,sub){if(id==='staff'&&sub==='hire'&&s.cands.length)return s.cands.length+' 份 CV';if(id==='ai'){var r=roleDef(sub);if(r&&s.lv[sub])return 'L'+s.lv[sub];}if(id==='cust'&&sub==='fb'){var n=s.fb.filter(function(f){return !f.good&&s.day-f.day<7;}).length;return n?n+' 個投訴':'';}return '';}

/* ---------- 排程 ---------- */
function pSched(sub){
 var w=s.wk,h='';
 var tog='<div class="schtop"><label class="sw"><input type="checkbox" checked disabled> 自動排程：開</label><span class="note">每星期一排一次；你手動調過嘅唔會被重排</span><label class="sw"><input type="checkbox" data-act="autofill" '+(s.autoFill!==0?'checked':'')+'> 自動補候補</label><span class="note">'+((s.lv.sched||0)>=2?'AI 自動 WhatsApp 候補客':'冇 AI：你每個打約 5 分鐘電話')+'，每朝補今日同聽日嘅空檔；而家候補 '+Math.floor(s.S.backlog)+' 位</span><span class="sp"></span>'+
  Object.keys(SVC).map(function(k){return '<button class="chip '+(SCHED.filter[k]?'on':'')+'" data-act="sfil" data-k="'+k+'"><i class="dot" style="background:var(--'+SVC[k].c+')"></i>'+SVC[k].n+'</button>';}).join('')+
  '<button class="chip '+(SCHED.probOnly?'on':'')+'" data-act="sprob">只睇取消／no-show</button></div>';
 if(sub==='today'){var ap=todayAppts().filter(function(a){return a.st!=='lost';}).sort(function(a,b){return a.a-b.a;});
  return tog+'<div class="tw"><table><thead><tr><th>時間</th><th>寵物</th><th>服務</th><th>美容師</th><th>狀態</th><th class="num">價錢</th></tr></thead><tbody>'+
   ap.map(function(a){return '<tr class="'+(a.st==='noshow'||a.st==='cancel'?'prob':'')+'" data-act="appt" data-id="'+a.id+'"><td class="num">'+hm(a.a)+'</td><td>'+esc(a.pet)+'<br><span class="note">'+esc(a.breed)+(a.tag?' · '+a.tag:'')+'</span></td><td><span class="seal xs" style="border-color:var(--'+SVC[a.svc].c+');color:var(--'+SVC[a.svc].c+')">'+SVC[a.svc].seal+'</span> '+SVC[a.svc].n+'</td><td>'+esc(staffName(a.g).replace('（老闆）',''))+'</td><td>'+stPill(a)+'</td><td class="num">'+hk(a.price)+'</td></tr>';}).join('')+'</tbody></table></div>';}
 var detail=SCHED.msg?'<div class="smsg '+(SCHED.msg.ok?'ok':'bad')+'">'+esc(SCHED.msg.t)+'</div>':'';if(SCHED.slot)detail+=slotBox(SCHED.slot);if(SCHED.sel){var a0=w.appts.filter(function(x){return x.id===SCHED.sel;})[0];if(a0)detail+=apptDetail(a0);}
 var span=CLOSE_MIN-OPEN_MIN,ticks='';for(var t=OPEN_MIN;t<=CLOSE_MIN;t+=60)ticks+='<span style="left:'+((t-OPEN_MIN)/span*100)+'%">'+hm(t).slice(0,2)+'</span>';
 function dayRows(d){var gs=groomers().filter(function(g){return staffWorks(g,d);}),busy=w.busy&&w.busy[d]||{},out='';
  var lbl='<div class="dlab'+(d===s.day?' today':'')+'">'+WKD[d%7]+'<small>'+(dateOf(d).getMonth()+1)+'/'+dateOf(d).getDate()+'</small></div>';
  if(!gs.length)return '<div class="drow">'+lbl+'<div class="lanes"><div class="lane empty">冇人返工</div></div></div>';
  out+='<div class="drow">'+lbl+'<div class="lanes">';
  gs.forEach(function(g){out+='<div class="lane" data-act="lane" data-day="'+d+'" data-g="'+g.id+'" title="拖預約嚟呢度調位；撳空格由候補名單加人"><span class="gname">'+esc(g.name.replace('（老闆）','老闆'))+'</span>';
   (busy[g.id]||[]).forEach(function(b){if(typeof b[2]==='string')out+='<span class="blk '+(b[2]==='行政'?'adm':b[2]==='午飯'?'lun':'task')+'" style="left:'+((b[0]-OPEN_MIN)/span*100)+'%;width:'+((b[1]-b[0])/span*100)+'%" title="'+b[2]+' '+hm(b[0])+'–'+hm(b[1])+'">'+b[2]+'</span>';});
   w.appts.forEach(function(a){if(a.day!==d||a.g!==g.id||a.st==='lost'||!SCHED.filter[a.svc])return;var prob=a.st==='noshow'||a.st==='cancel'||(a.out!=='ok'&&d>=s.day);if(SCHED.probOnly&&!prob)return;
    out+='<button class="blk ap s-'+a.svc+' st-'+a.st+(SCHED.sel===a.id?' sel':'')+(a.manual?' man':'')+'" data-act="appt" data-id="'+a.id+'"'+(movable(a)?' draggable="true"':'')+' style="left:'+((a.a-OPEN_MIN)/span*100)+'%;width:'+((a.b-a.a)/span*100)+'%" title="'+hm(a.a)+' '+esc(a.pet)+' '+SVC[a.svc].n+'">'+SVC[a.svc].seal+'<em>'+esc(a.pet)+'</em></button>';});
   out+='</div>';});
  return out+'</div></div>';}
 var wd='',we='';for(var d=w.start;d<w.start+7;d++){if(d%7<5)wd+=dayRows(d);else we+=dayRows(d);}
 var cov=SEGS.map(function(g){var n=w.appts.filter(function(a){return a.seg===g.id&&a.st!=='lost';}).length;return '<span class="cov'+(n?'':' zero')+'">'+g.name+' <b class="num">'+n+'</b></span>';}).join('');
 h=tog+detail+'<div class="sgrid"><div class="ticks">'+ticks+'</div><h4>平日</h4>'+wd+'<h4>週末</h4>'+we+'</div>'+
  '<div class="covr"><b>覆蓋表（本週）</b>'+cov+'</div><p class="note">拖預約去空格＝調時間或者換人；拖去另一個預約＝互換；撳空格可以由候補名單（而家 '+Math.floor(s.S.backlog)+' 位）加人。本週預約 '+w.appts.length+' 個，因為冇位改咗日 '+w.appts.filter(function(a){return a.moved;}).length+' 個，完全冇位流失 '+w.lost+' 個。灰色「行政」係老闆覆 WhatsApp、排程、對數嘅時間；部署 AI 之後會縮短。</p>';
 return h;
}
function stPill(a){var m={booked:['','已預約'],arrived:['','到咗'],doing:['ok','美容中'],done:['ok','完成'],gone:['','已接走'],noshow:['red','No-show'],cancel:['amb','取消'],lost:['red','冇位']}[a.st]||['',a.st];return '<span class="pill '+m[0]+'">'+m[1]+'</span>';}
function apptDetail(a){var g=SEGS.filter(function(x){return x.id===a.seg;})[0],fb=s.fb.filter(function(f){return f.pid?f.pid===a.pid&&f.day===a.day:f.pet===a.pet&&f.owner===a.owner;})[0];
 var edit='';
 if(movable(a)){var days='',tms='',gsel='';for(var d=Math.max(s.day,s.wk.start);d<s.wk.start+7;d++)days+='<option value="'+d+'"'+(d===a.day?' selected':'')+'>星期'+WKD[d%7]+'</option>';
  for(var t0=OPEN_MIN;t0+a.dur<=CLOSE_MIN;t0+=15)tms+='<option value="'+t0+'"'+(t0===a.a?' selected':'')+'>'+hm(t0)+'</option>';
  groomers().forEach(function(x){gsel+='<option value="'+x.id+'"'+(x.id===a.g?' selected':'')+'>'+esc(x.name.replace('（老闆）','（老闆）'))+'</option>';});
  edit='<div class="aedit"><label>日子<select id="ed-day">'+days+'</select></label><label>時間<select id="ed-t">'+tms+'</select></label><label>美容師<select id="ed-g">'+gsel+'</select></label><button class="btn pri" data-act="apply" data-id="'+a.id+'">改</button></div>';}
 else edit='<div class="note">'+(a.st==='booked'?'就快開始，唔可以再調':'已經'+stLabel(a)+'，唔可以調')+'</div>';
 return '<div class="adet"><div class="adj"><b>'+hm(a.a)+'–'+hm(a.b)+'</b> · 星期'+WKD[a.day%7]+' · '+esc(staffName(a.g))+' · 美容枱 '+(a.tb+1)+(a.manual?' · <span class="pill">手動</span>':'')+'</div>'+edit+
  '<div class="adi">'+esc(a.pet)+'（'+esc(a.breed)+'，'+g.name+'）· '+SVC[a.svc].n+' '+a.dur+' 分鐘 · '+hk(a.price)+' · '+esc(a.owner)+(a.regular?' 熟客':' 新客')+(a.tag?' · '+a.tag:'')+' · '+stPill(a)+(fb?'<br>主人評價：「'+esc(fb.txt)+'」':'')+'</div></div>';}
function slotBox(sl){return '<div class="adet"><div class="adj">空格：星期'+WKD[sl.day%7]+' '+hm(sl.t)+' · '+esc(staffName(sl.g))+'</div><div class="aedit"><span class="note">候補名單有 '+Math.floor(s.S.backlog)+' 位等緊</span><button class="btn pri" data-act="addbk"'+(s.S.backlog<1?' disabled title="候補名單冇人"':'')+'>＋ 加一位候補</button><button class="btn" data-act="slotx">取消</button></div></div>';}
/* ---------- 客人 ---------- */
function pCust(sub){
 var lw=s.weeks.length>1?s.weeks[s.weeks.length-2]:s.weeks[s.weeks.length-1],h=lw.h;
 if(sub==='story')return petStory();
 if(sub==='rec')return pRec();
 if(sub==='funnel'){var loss=rv(s.S,'reply','loss'),la=s.S.P.afterHours,rep=h.inq*(1-(la*loss[0]+(1-la)*loss[1]));
  function fun(rows){var mx=rows[0][1]||1;return '<div class="funnel">'+rows.map(function(r){return '<div class="row"><div>'+r[0]+'</div><div><div class="fb" style="width:'+Math.max(1,r[1]/mx*100)+'%"></div></div><div class="num">'+Math.round(r[1])+'</div></div>';}).join('')+'</div>';}
  return '<h3>上週新客漏斗</h3>'+fun([['新客查詢',h.inq],['有人覆',rep],['落實預約',h.newAcc]])+'<p class="note">收工後查詢佔 '+pct(la)+'。冇人覆嘅多數去咗第二間。</p>'+
   '<h3>上週預約漏斗</h3>'+fun([['總預約',h.booked],['到店',h.booked-h.noShowN-h.lcN],['完成',h.done]])+'<p class="note">No-show '+pct(h.ns)+'、臨時取消 '+pct(h.lc)+'，分開計。等位 '+h.lead.toFixed(1)+' 週。</p>'+
   '<div class="kgrid">'+kbox('活躍客',Math.round(actN(s.S)))+kbox('上週新客',h.newAcc.toFixed(0))+kbox('上週流失',(h.lostDue+h.followLost).toFixed(0))+kbox('熟客到期回頭',pct(h.retReg!=null?h.retReg:h.ret))+(h.retFirst!=null?kbox('第一次嚟之後回頭',pct(h.retFirst)):'')+kbox('第一次嚟、未回頭',Math.round(h.trial||0))+'</div><p class="note">活躍客係模型估算嘅活躍名單，按每週新預約、流失同喚回更新，唔係最近 30 日或 90 日實際到店人數；開局已有模擬客源。活躍客包括「第一次嚟、未回頭」嘅客：佢哋第一次之後回頭嘅機會係熟客嘅 75%（示範估算），回頭一次先當熟客。</p>';}
 if(sub==='dorm'){var dt=sum(s.S.dorm)||1;return '<p>超過週期冇再嚟嘅客人，按原因分。AI 提醒只救到部分。</p><div class="tw"><table><thead><tr><th>原因</th><th class="num">人數</th><th class="num">佔比</th><th>AI 提醒有冇用</th></tr></thead><tbody>'+
  DORM.map(function(d,i){return '<tr><td>'+d.name+'</td><td class="num">'+Math.round(s.S.dorm[i])+'</td><td class="num">'+pct(s.S.dorm[i]/dt)+'</td><td>'+(d.ai>=1?'有用':d.ai>0?'部分（要 L3）':'冇用，要人處理')+'</td></tr>';}).join('')+'</tbody></table></div>'+
  (s.lv.recall<3?'<p class="note">「回」L3 先會幫你分原因；而家嘅數係模擬入面嘅真實分佈，現實中冇 L3 你唔會知。</p>':'')+
  '<div class="adet"><b>直銷同意率 '+pct(s.consent)+'</b><span class="note">《私隱條例》第 6A 部：未同意嘅客人唔可以發推廣。提醒同喚回只會去到同意咗嘅客。'+(s.lv.reply>=2?'AI 前台會喺預約時順手問，每週慢慢升。':'')+'</span><button class="btn" data-act="consent"'+(s.consentWk===weekNo()?' disabled title="今個星期問過"':'')+'>老闆逐個問（士氣 −3%）</button></div>';}
 return '<div class="list">'+(s.fb.length?s.fb.slice(0,30).map(function(f){return '<div class="fbi '+(f.good?'good':'bad')+'"><span class="num">'+dateStr(f.day).replace(/^\d+年/,'')+' '+hm(f.t)+'</span>'+(f.pid?'<button class="lnk" data-act="clopen" data-p="'+f.pid+'"><b>'+esc(f.owner)+'（'+esc(f.pet)+'）</b></button>':'<b>'+esc(f.owner)+'（'+esc(f.pet)+'）</b>')+(f.stars?stars(f.stars):'')+'<p>「'+esc(f.txt)+'」</p></div>';}).join(''):'<p class="note">未有意見。</p>')+'</div>';
}
/* 虛構案例：獨立示範服務流程，不改變客戶或財務模型。 */
function petStory(){
 var stage=s.petStory||0;
 var badge=['01 初次到店','02 檢查草稿','03 主人報告','04 再次到店'];
 var content=[
  '<span class="story-tag">第一次到店 · 美容師觀察</span><h3>豆豆有啲怕吹風</h3><p>主人陳太帶豆豆嚟洗剪。美容師阿欣觀察到：豆豆聽到大風聲會縮開；轉用低風速、分段休息後，牠比較放鬆。</p><div class="story-observation"><b>阿欣嘅原始紀錄</b><p>「怕大風聲；低風速同休息有幫助。今次完成洗剪。」</p></div><p class="note">按下面生成一份 AI 草稿，睇吓有冇忠實記錄。</p><button class="btn pri" data-act="storynext">整理成草稿</button>',
  '<span class="story-tag">AI 草稿 · 等待美容師核實</span><h3>呢句有冇寫錯？</h3><div class="story-observation warning"><b>AI 草稿</b><p>「豆豆鍾意大風，今次全程用高速吹乾。」</p></div><p>原始紀錄係怕大風聲，低風速同休息有幫助。AI 將觀察寫反咗，唔可以直接發畀主人。</p><button class="btn pri" data-act="storynext">美容師修正並確認</button>',
  '<span class="story-tag">已由美容師確認 · 給主人</span><h3>豆豆嘅美容小記</h3><div class="report-card"><div class="report-head"><span class="report-icon">豆</span><div><b>豆豆</b><small>今次服務 · 洗澡及修剪</small></div></div><div class="report-line"><b>今次觀察</b><span>豆豆對大風聲較敏感；改用低風速並分段休息後較放鬆。</span></div><div class="report-line"><b>下次可以</b><span>到店時同美容師講講豆豆近期狀況，我哋會先參考今次紀錄。</span></div><small>示範報告 · 美容師確認後才交給主人</small></div><p class="note">報告記錄美容觀察，唔作健康診斷；如主人關注健康，建議諮詢獸醫。</p><button class="btn pri" data-act="storynext">睇下次到店</button>',
  '<span class="story-tag">第二次到店 · 延續紀錄</span><h3>唔使由零開始</h3><p>預約前，陳太補充豆豆最近仍然怕大風聲。阿欣開工前睇返上次經確認嘅紀錄，再同主人確認今次安排。</p><div class="story-observation"><b>服務前提示</b><p>怕大風聲 → 先同主人確認，考慮低風速同分段休息。</p></div><p class="note">人觀察 → AI 整理 → 人確認 → 主人收到 → 下次參考。呢個係虛構示範，唔會改變遊戲數值或自動傳送訊息。</p><button class="btn" data-act="storyreset">重新睇故事</button>'
 ];
 return '<div class="story-hero"><span class="eyebrow">服務故事 · 虛構示範</span><h3>記得每一次，照顧每一隻</h3><p>一份可靠紀錄，點樣幫美容師同主人接住上次嘅對話？</p></div><div class="story-progress">'+badge.map(function(x,i){return '<span class="'+(i===stage?'active':i<stage?'done':'')+'">'+x+'</span>';}).join('')+'</div><div class="story-content">'+content[stage]+'</div>';
}
document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');if(a==='storynext'){s.petStory=Math.min(3,(s.petStory||0)+1);renderPanel();}if(a==='storyreset'){s.petStory=0;renderPanel();}});

/* ---------- 員工 ---------- */
function pStaff(sub){
 if(sub==='hire')return '<p>每星期一更新 3 份 CV。請咗下星期一返工；入職 3 週後先知佢真正特點。</p><div class="cards2">'+s.cands.map(function(c){
  return '<div class="scard"><div class="sc-top"><b>'+esc(c.name)+'</b><span class="pill">'+(c.role==='groomer'?'美容師':'兼職助理')+'</span></div><dl><dt>證書</dt><dd>'+esc(c.cert)+'</dd><dt>經驗</dt><dd>'+esc(c.exp)+'</dd><dt>人工</dt><dd class="num">'+(c.role==='groomer'?hk(c.wage)+'／月＋每隻 '+hk(c.comm):hk(c.rate)+'／小時 × '+c.hoursW+' 小時')+'</dd><dt>返工</dt><dd>每週 6 日，星期'+WKD[c.off===0?3:c.off]+'休息</dd><dt>面試印象</dt><dd>'+esc(c.trait.hint)+'</dd></dl>'+
  '<button class="btn pri" data-act="hire" data-id="'+c.id+'">請（下星期一返工）</button></div>';}).join('')+'</div>'+(s.cands.length?'':'<p class="note">今個星期冇 CV，下星期一再睇。</p>');
 return '<div class="cards2">'+s.staff.filter(function(x){return x.leaving!==-2;}).map(function(x){var hw=staffHours(x),mr=x.morale;
  return '<div class="scard"><div class="sc-top"><b>'+esc(x.name)+'</b><span class="pill">'+roleName(x)+'</span>'+(x.leaving>=0?'<span class="pill red">'+dateStr(x.leaving).replace(/^\d+年/,'')+'走</span>':'')+(x.joined>s.day?'<span class="pill">下週返工</span>':'')+'</div>'+
  '<dl><dt>證書</dt><dd>'+esc(x.cert)+'</dd><dt>經驗</dt><dd>'+esc(x.exp)+'</dd><dt>人工</dt><dd class="num">'+(x.role==='owner'?'食利潤':x.role==='groomer'?hk(x.wage)+'＋每隻 '+hk(x.comm):hk(x.rate)+'／小時 × '+x.hoursW)+'</dd><dt>休息日</dt><dd class="offd">'+offSel(x)+'</dd>'+
  '<dt>本週工時</dt><dd class="num">'+hw.used.toFixed(1)+' / '+hw.avail.toFixed(0)+' 小時</dd><dt>特點</dt><dd>'+(x.shown&&x.trait?'<b>'+esc(x.trait.n)+'</b>：'+esc(x.trait.d):x.trait?'未知（入職 3 週後顯露）':'—')+'</dd></dl>'+
  '<div class="mor"><span>士氣 '+Math.round(mr*100)+'%</span><span class="bar '+(mr<.5?'hot':mr<.65?'mid':'')+'"><i style="width:'+Math.round(mr*100)+'%"></i></span><span class="note">'+moraleWhy(x)+'</span></div>'+
  (x.role!=='owner'&&x.leaving<0?'<button class="btn" data-act="fire" data-id="'+x.id+'">通知離職（一週通知期）</button>':'')+'</div>';}).join('')+'</div>';
}
function moraleWhy(x){var h=s.wk.h;if(x.role==='owner')return h.adminH>10?'每週行政 '+h.adminH.toFixed(0)+' 小時，好攰':'時間分配 OK';if(h.util>.9)return '太忙，美容枱使用率 '+pct(h.util);if(x.morale<.6)return '覺得人工唔夠';return '工作量合理';}

/* ---------- AI 部署 ---------- */
function roleWeekH(id,l){var h=s.wk.h,keep=function(lv){if(!lv)return 1;var v=roleDef(id).L[lv-1].keep[s.review?0:1];return v;};
 var base={reply:h.inq*ADMIN.replyPerInq/60,sched:h.booked*ADMIN.perBooking/60,file:h.done*90/3600,media:ADMIN.media/60,recall:ADMIN.recallManual/60,acct:ADMIN.acct/60}[id];
 if(id==='file'){var sec=l?roleDef('file').L[l-1].sec:90;return h.done*sec/3600;}
 return base*keep(l);}
/* 總覽一按升級：掣上寫明下一級建置費同月費；現金唔夠就停用並寫差幾多 */
function aiUpBtn(r,l){var nx=l<3?r.L[l]:null;if(!nx)return '<button class="btn" data-act="psub" data-s="'+r.id+'">工作流</button>';
 var price=(nx.setup?hk(nx.setup):'免費')+(nx.fee?'＋'+hk(nx.fee)+'／月':''),short=nx.setup-s.cash;
 if(short>0)return '<button class="btn aiup" disabled title="現金唔夠，差 '+hk(short)+'"><b>升 L'+(l+1)+'</b><small>差 '+hk(short)+'</small></button>';
 return '<button class="btn pri aiup" data-act="deploy" data-r="'+r.id+'" data-l="'+(l+1)+'" title="L'+(l+1)+' '+esc(nx.t)+'：'+esc(nx.tools)+'；'+nx.wk+' 週部署，之後 4 週磨合"><b>升 L'+(l+1)+'</b><small>'+price+'</small></button>';}
function pAI(sub){
 if(sub==='ov'){
  var h='<div class="aiov">'+ROLES.map(function(r){var l=s.lv[r.id],rp=rampPct(r.id),L=l?r.L[l-1]:null,nxt=l<3?r.L[l]:null;
   return '<div class="airow"><span class="seal'+(l?'':' off')+'">'+r.seal+'</span><button class="ain" data-act="psub" data-s="'+r.id+'" title="睇工作流同每級細節"><b>'+r.name+' <i class="aimore">細節 ›</i></b><small>'+esc(r.desc)+'</small></button>'+
    '<div class="lv3">'+[1,2,3].map(function(i){return '<i class="'+(l>=i?'on':'')+'" title="L'+i+' '+r.L[i-1].t+'"></i>';}).join('')+'</div>'+
    '<div class="aiprog"><span class="bar"><i style="width:'+Math.round(rp*100)+'%"></i></span><small>'+(l?(rp<1?'磨合中 '+Math.round(rp*100)+'%':'已上軌道'):'未部署')+'</small></div>'+
    '<div class="aihr num">'+(nxt?roleWeekH(r.id,l).toFixed(1)+' → '+roleWeekH(r.id,l+1).toFixed(1)+' h／週<small>升 L'+(l+1)+' 後（磨合完）</small>':roleWeekH(r.id,l).toFixed(1)+' h／週<small>已經最高級</small>')+'</div><div class="aiwho">'+(l?'AI ＋ '+r.who+'把關':r.who)+'</div>'+
    aiUpBtn(r,l)+(typeof aiEffLine==='function'?aiEffLine(r.id,l):'')+'</div>';}).join('')+'</div>';
  h+='<div class="aifoot"><label class="sw"><input type="checkbox" data-act="review" '+(s.review?'checked':'')+'> 人工審核 AI 回覆</label><span class="note">'+(s.review?'有審核：老闆每日睇一次，出錯少。':'冇審核：慳時間，但 AI 會報錯價、答應咗冇位嘅時段。')+'</span></div>'+
   '<details class="lim"><summary>AI 嘅限制（遊戲入面全部有模擬）</summary><ul><li>磨合期：上線頭 4 週效率由一半慢慢升。</li><li>冇人工審核會出錯，出錯有後果。</li><li>毛孩檔案唔齊，個人化效果打折。</li><li>未同意直銷嘅客人唔可以發推廣（私隱條例第 6A 部）。</li><li>部分熟客唔鍾意同 AI 傾。</li><li>供應商更新模型會令效果變，平台會加價（WhatsApp 2026-10 已改收費）。</li><li>AI 做唔到：美容手藝、安撫寵物、判斷健康風險、處理事故、同主人建立信任。</li></ul></details>';
  return h;}
 if(sub==='day'){var L=s.aiDay.slice().sort(function(a,b){return a.t-b.t;}).filter(function(x){return x.t<=s.t||x.t<DAY0;});
  return '<p>'+dateStr(s.day)+' 到 '+hm(s.t)+' 為止，AI 做咗咩。</p>'+(L.length?'<ol class="aiday">'+L.map(function(x){return '<li><span class="num">'+(x.t<DAY0?'收工後':hm(x.t))+'</span><span class="seal xs">'+x.seal+'</span>'+esc(x.txt)+'</li>';}).join('')+'</ol>':'<p class="note">今日 AI 未做嘢'+(ROLES.some(function(r){return s.lv[r.id];})?'。':'：你未部署任何崗位。')+'</p>');}
 var r=roleDef(sub),l=s.lv[r.id];
 var left='<div class="rleft"><span class="seal big">'+r.seal+'</span><h3>'+r.name+'</h3><p>'+esc(r.desc)+'</p><dl><dt>而家</dt><dd>'+(l?'L'+l+' '+r.L[l-1].t:'未用 AI')+'</dd><dt>進度</dt><dd>'+(l?Math.round(rampPct(r.id)*100)+'%':'—')+'</dd><dt>負責</dt><dd>'+r.who+'</dd><dt>每週工時</dt><dd class="num">'+roleWeekH(r.id,l).toFixed(1)+' 小時</dd></dl>'+
  '<label class="sw"><input type="checkbox" data-act="review" '+(s.review?'checked':'')+'> 人工審核</label></div>';
 var cols=r.L.map(function(L,i){var lv=i+1,cur=l===lv,dis=cur?'而家用緊':s.cash<L.setup?'現金唔夠':lv<l?'降級會浪費建置費':'';
  return '<div class="lcol'+(cur?' cur':'')+'"><div class="lh"><b>L'+lv+'</b> '+esc(L.t)+(cur?'<span class="pill ok">而家</span>':'')+'</div>'+
   '<dl><dt>建置費</dt><dd class="num">'+hk(L.setup)+'</dd><dt>月費</dt><dd class="num">'+hk(L.fee)+(lv>=2&&(r.id==='reply'||r.id==='recall')?' ＋ 訊息（每條 $0.23）':'')+'</dd><dt>部署時間</dt><dd>'+L.wk+' 週，之後 4 週磨合</dd></dl>'+
   '<p class="note"><b>預計作用：</b>'+esc(({reply:'協助回覆查詢及預約',sched:'協助安排時段和補位',file:'整理毛孩資料供美容師參考',media:'協助整理內容及顧客溝通',recall:'協助跟進到期客人',acct:'協助老闆整理經營數據'})[r.id])+'，效果見下方模型估算。</p><p><b>仍需人工：</b>'+esc(L.guard)+'</p>'+
   '<details><summary>工具、流程及部署步驟</summary><p><b>工具：</b>'+esc(L.tools)+'</p><ol class="flow">'+L.flow.map(function(f,k){return '<li><span class="lbl">'+FLOW_LBL[k]+'</span>'+esc(f)+'</li>';}).join('')+'</ol><p>行政剩低 '+Math.round(L.keep[0]*100)+'%（有審核）／'+Math.round(L.keep[1]*100)+'%（冇）。</p><ol>'+L.steps.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ol></details>'+
   '<button class="btn '+(dis?'':'pri')+'" data-act="deploy" data-r="'+r.id+'" data-l="'+lv+'"'+(dis?' disabled title="'+dis+'"':'')+'>'+(dis?dis:'部署 L'+lv)+'</button></div>';}).join('');
 return '<div class="rpage">'+left+'<div class="lcols">'+cols+'</div></div>'+(typeof aiEffDetail==='function'?'<div class="aieffd">'+aiEffDetail(r.id,l)+'</div>':'');
}
/* ---------- 財務 ---------- */
function pFin(sub){
 if(sub==='owner')return pOwner();if(sub==='loan')return pLoan();if(sub==='ins')return pIns();
 if(sub==='month'){var md=monthToDate(),c={wages:0,fixed:0,ai:0,refunds:0,consum:0};md.ds.forEach(function(x){for(var k in c)c[k]+=x.cats[k];});
  var est=md.days?md.profit/md.days*md.dim:0;
  return '<div class="kgrid">'+kbox('今個月營收',hk(md.rev))+kbox('今個月經營利潤',hk(md.profit),md.profit<0?'bad':'')+kbox('全月預計',hk(est),est<0?'bad':'')+kbox('現金',hk(s.cash),s.cash<0?'bad':'')+'</div>'+
   '<table class="mt"><tbody>'+[['人工（連強積金、助理）',c.wages],['租金、水電、保險、廣告、雜項',c.fixed],['用品同收款手續費',c.consum],['AI 月費同訊息',c.ai],['退款同賠償',c.refunds]].map(function(x){return '<tr><td>'+x[0]+'</td><td class="num">'+hk(x[1])+'</td></tr>';}).join('')+'</tbody></table><p class="note">上面係經營支出，計入經營利潤。現金每日午夜先更新；老闆底薪、還款同轉入小金庫要等月結先由公司現金扣。</p>'+ledSoFar();}
 if(sub==='months'){if(!s.months.length)return '<p class="note">第一次月結喺下個月 1 號。</p>';
  return '<div class="tw"><table><thead><tr><th>月份</th><th class="num">營收</th><th class="num">支出</th><th class="num">利潤</th><th class="num">隔籬利潤</th><th class="num">完成</th><th class="num">No-show</th></tr></thead><tbody>'+
   s.months.slice().reverse().map(function(m,i){return '<tr data-act="mopen" data-i="'+(s.months.length-1-i)+'" class="click"><td>'+m.y+'年'+m.m+'月</td><td class="num">'+hk(m.rev)+'</td><td class="num">'+hk(m.cost)+'</td><td class="num '+(m.profit<0?'dn':'')+'">'+hk(m.profit)+'</td><td class="num">'+hk(m.shProfit)+'</td><td class="num">'+m.done+'</td><td class="num">'+m.ns+'</td></tr>';}).join('')+'</tbody></table></div><p class="note">撳月份睇細節。</p>';}
 var ms=s.months;if(ms.length<2)return '<p class="note">要兩個月結之後先有走勢。</p>';
 var ser=[{name:'你',c:'s1',vals:ms.map(function(m){return m.profit;})},{name:'隔籬',c:'s2',vals:ms.map(function(m){return m.shProfit;})}];
 var ser2=[{name:'你',c:'s1',vals:ms.map(function(m){return m.cash;})},{name:'隔籬',c:'s2',vals:ms.map(function(m){return m.shCash;})}];
 var lab=ms.map(function(m){return m.m+'月';});
 return '<h3>每月利潤</h3>'+legend(ser)+chart({series:ser,labels:lab,h:180})+'<h3>現金</h3>'+legend(ser2)+chart({series:ser2,labels:lab,h:180});
}
/* ---------- 隔籬 ---------- */
function pShadow(){
 var a=s.wk.h,b=s.wk.hs,ma=s.months[s.months.length-1];
 function row(n,x,y,f,up){var d=x-y,cls=Math.abs(d)<1e-9?'':((up===false?d<0:d>0)?'up':'dn');return '<tr><td>'+n+'</td><td class="num '+cls+'">'+f(x)+'</td><td class="num">'+f(y)+'</td></tr>';}
 var f0=function(v){return Math.round(v)+'';},f1=function(v){return v.toFixed(1);};
 return '<div class="compare-intro"><span class="eyebrow">經營對照 · 示範估算</span><h3>同一條街，兩種做法</h3><p>兩間店由相同條件開局，隔籬唔用 AI，做唔切會請人。人手同經營決策會改變，所以差距唔可以全部歸因於 AI。</p></div><div class="tw"><table><thead><tr><th>本週</th><th class="num">你</th><th class="num">隔籬</th></tr></thead><tbody>'+
  row('現金',s.cash,s.shCash,hk)+(ma?row('上月利潤',ma.profit,ma.shProfit,hk):'')+row('美容師',groomers().length,s.base.groomers+s.shHires,f0,false)+row('本週完成',a.done,b.done,f1)+row('活躍客',actN(s.S),actN(s.sh),f0)+row('評分',s.S.rating,s.sh.rating,function(v){return v.toFixed(2);})+
  row('老闆行政（小時／週）',a.adminH,b.adminH,f1,false)+row('No-show',a.ns,b.ns,pct,false)+row('臨時取消',a.lc,b.lc,pct,false)+row('等位（週）',a.lead,b.lead,function(v){return v.toFixed(2);},false)+row('AI 成本（本週）',a.aiCost,0,hk,false)+'</tbody></table></div>'+
  '<p class="note">每月按同一日曆期間計算；隔籬每週模擬利潤按日平均分攤，並非逐單實際收入。舊存檔現金沿用原有入帳方式，過往月結不會重算。數字均為示範估算；綠色／紅色只表示方向，唔等於成因。</p>';
}
/* ---------- 報告 ---------- */
function pRep(){
 var r=s.rep,done=sum(s.days.map(function(d){return d.done;}))||1;
 return '<div class="compare-intro"><span class="eyebrow">營運回顧 · 示範估算</span><h3>時間、成本，同服務</h3><p>以下係遊戲模型累計數字，唔係現實成效；服務體驗要同主人溝通先知道。</p></div><div class="kgrid">'+kbox('AI 處理查詢',Math.round(r.aiReplies))+kbox('自動提醒',Math.round(r.remind+r.recalls))+kbox('候補補位',r.refill)+kbox('轉人把關',r.guards)+
  kbox('AI 出錯',r.errs,r.errs?'bad':'')+kbox('慳到老闆工時',(r.savedMin/60).toFixed(0)+' 小時')+kbox('AI 總成本',hk(r.aiCost))+kbox('每客 AI 成本',hk(r.aiCost/done))+kbox('已整理檔案',r.files)+kbox('報告卡',r.cards)+'</div><p class="note">檔案同報告卡係模型計數，唔代表主人已閱讀或認同；工時係估算，並非實測。AI 成本包括模型計算嘅費用，唔代表全部實際人手成本。</p>'+ 
  (s.fd?'':'<div class="aedit"><b>創辦人層</b><span class="note">連續 3 個月 no-show 低過 7%，而且有一個 AI 崗位去到 L2，同行就會嚟問。</span>'+(s.fdOffered?'<button class="btn pri" data-act="fdstart">開始副業</button>':'<button class="btn" data-act="fdcheat">提早解鎖（示範用）</button>')+'</div>')+'<h3>AI 做唔到</h3><ul><li>實際美容手藝</li><li>安撫寵物</li><li>判斷寵物健康風險（要轉獸醫）</li><li>處理受傷事故</li><li>同主人建立信任</li></ul><p class="note">可以用示範模式逐步了解遊戲。</p>';
}
