/* p_voxel：體素建模輔助（共用 geometry／material 快取）、人物、寵物、車。 */
var GEO={},MAT={};
function vbox(w,h,d){var k=w+'|'+h+'|'+d;if(!GEO[k])GEO[k]=new THREE.BoxGeometry(w,h,d);return GEO[k];}
function vmat(c,o){o=o||{};var k=c+'|'+(o.e||'')+'|'+(o.op||'')+'|'+(o.ei||'');if(!MAT[k]){MAT[k]=new THREE.MeshLambertMaterial({color:c});
 if(o.e){MAT[k].emissive=new THREE.Color(o.e);MAT[k].emissiveIntensity=o.ei||1;}if(o.op){MAT[k].transparent=true;MAT[k].opacity=o.op;MAT[k].depthWrite=false;}}return MAT[k];}
function vb(parent,w,h,d,x,y,z,c,o){var m=new THREE.Mesh(vbox(w,h,d),o&&o.own?new THREE.MeshLambertMaterial({color:c}):vmat(c,o));m.position.set(x,y,z);if(parent)parent.add(m);return m;}
function vgroup(parent,x,y,z){var g=new THREE.Group();g.position.set(x||0,y||0,z||0);if(parent)parent.add(g);return g;}
/* 文字貼圖（招牌） */
var TEXCACHE={};
function textTex(txt,fg,bg,vert,w,h){var k=txt+fg+bg+vert;if(TEXCACHE[k])return TEXCACHE[k];
 var cv=document.createElement('canvas');cv.width=w||256;cv.height=h||64;var g=cv.getContext('2d');g.fillStyle=bg;g.fillRect(0,0,cv.width,cv.height);g.fillStyle=fg;
 g.textAlign='center';g.textBaseline='middle';
 if(vert){var n=txt.length,fs=Math.min(cv.width*.8,cv.height/n*.9);g.font='bold '+fs+'px "Noto Sans HK","PingFang HK","Microsoft JhengHei",sans-serif';for(var i=0;i<n;i++)g.fillText(txt[i],cv.width/2,cv.height/n*(i+.5));}
 else{var fs2=Math.min(cv.height*.75,cv.width/txt.length*.95);g.font='bold '+fs2+'px "Noto Sans HK","PingFang HK","Microsoft JhengHei",sans-serif';g.fillText(txt,cv.width/2,cv.height/2);}
 var t=new THREE.CanvasTexture(cv);TEXCACHE[k]=t;return t;}
function sign(parent,txt,w,h,x,y,z,fg,bg,vert,ry){var mat=new THREE.MeshLambertMaterial({map:textTex(txt,fg,bg,vert,vert?64:256,vert?256:64),emissive:new THREE.Color('#ffffff'),emissiveMap:textTex(txt,fg,bg,vert,vert?64:256,vert?256:64),emissiveIntensity:.15});
 var edge=new THREE.MeshLambertMaterial({color:bg});var m=new THREE.Mesh(vbox(w,h,.12),[edge,edge,edge,edge,mat,mat]);m.position.set(x,y,z);if(ry)m.rotation.y=ry;m.userData.neon=1;m.userData.signFace=mat;parent.add(m);return m;}

/* 可愛方塊風：大頭細身，臉用貼圖（眼、腮紅、嘴） */
var FACEMAT={};
var BLOB0=null;function blobMat(){return BLOB0||(BLOB0=new THREE.MeshBasicMaterial({color:'#000',transparent:true,opacity:.28,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4}));}
function faceMat(skin,kind){var k=skin+kind;if(FACEMAT[k])return FACEMAT[k];var c=document.createElement('canvas');c.width=c.height=32;var g=c.getContext('2d');g.fillStyle=skin;g.fillRect(0,0,32,32);
 if(kind==='pet'){g.fillStyle='#1f1716';g.fillRect(7,11,5,6);g.fillRect(20,11,5,6);g.fillStyle='#fff';g.fillRect(8,12,2,2);g.fillRect(21,12,2,2);g.fillStyle='#3a2a22';g.fillRect(13,18,6,4);g.fillStyle='#f4a3b4';g.fillRect(4,19,4,2);g.fillRect(24,19,4,2);}
 else{g.fillStyle='#2b1d22';g.fillRect(7,14,6,5);g.fillRect(19,14,6,5);g.fillStyle='#ffffff';g.fillRect(8,15,2,2);g.fillRect(20,15,2,2);g.fillStyle='#f29aa8';g.fillRect(4,20,6,3);g.fillRect(22,20,6,3);g.fillStyle='#c46a6a';g.fillRect(15,23,3,1);}
 var t=new THREE.CanvasTexture(c);t.magFilter=THREE.NearestFilter;FACEMAT[k]=new THREE.MeshLambertMaterial({map:t});return FACEMAT[k];}
function headMesh(w,h,d,skin,faceIdx,kind){var mats=[];for(var i=0;i<6;i++)mats.push(i===faceIdx?faceMat(skin,kind):vmat(skin));return new THREE.Mesh(vbox(w,h,d),mats);}
var SKIN=['#f6d5bd','#efc7a8','#e2b18f','#f8dcc8'],HAIR=['#2a2322','#3d2b24','#5a3a2a','#7a5b3a','#9a9a9a','#1f2b4a','#6b3a2a'],CLOTH=['#5b8ed6','#e2706b','#7fb069','#9a7fd1','#f0b44c','#3f6e8c','#c9c9c9','#ee9bb5','#5c6370'];
function makePerson(o){
 o=o||{};var g=vgroup(),i=o.i||0,sk=o.skin||SKIN[i%SKIN.length],cl=o.cloth||CLOTH[i%CLOTH.length],pa=o.pants||'#3a3f4b',hr=o.hair||HAIR[i%HAIR.length];
 /* 手腳以肩膀、髖部為軸：手掌和鞋屬於同一隻肢體。 */
 var lL=vgroup(g,-.11,.28,0),lR=vgroup(g,.11,.28,0);
 [lL,lR].forEach(function(l){vb(l,.17,.28,.19,0,-.14,0,pa);vb(l,.18,.06,.24,0,-.25,.02,'#2b2b2b');});
 vb(g,.46,.42,.32,0,.49,0,cl);
 if(o.apron){vb(g,.4,.36,.04,0,.46,.17,o.apron);vb(g,.08,.08,.02,0,.58,.195,'#ffffff');}
 var aL=vgroup(g,-.3,.66,0),aR=vgroup(g,.3,.66,0);[aL,aR].forEach(function(a){vb(a,.13,.32,.15,0,-.16,0,cl);vb(a,.12,.1,.13,0,-.34,0,sk);});
 var hd=headMesh(.64,.56,.56,sk,4,'p');hd.position.set(0,.99,0);g.add(hd);
 vb(g,.68,.18,.6,0,1.29,-.01,hr);vb(g,.68,.4,.14,0,1.05,-.24,hr);
 [[-.22,.06],[0,.04],[.2,.07]].forEach(function(q){vb(g,.2,.12+q[1],.06,q[0],1.17-q[1]/2,.28,hr);});
 vb(g,.08,.34,.5,-.33,1.05,-.02,hr);vb(g,.08,.34,.5,.33,1.05,-.02,hr);
 if(o.long){vb(g,.16,.5,.16,-.3,.8,-.18,hr);vb(g,.16,.5,.16,.3,.8,-.18,hr);}
 if(o.bow)vb(g,.24,.12,.08,.22,1.36,-.15,o.bow);
 if(o.bag){vb(g,.08,.3,.24,.3,.42,0,'#7a4a2a');vb(g,.04,.4,.04,.27,.75,0,'#5a3a20');}
 g.traverse(function(m){if(m.isMesh)m.castShadow=true;});
 var bl=new THREE.Mesh(new THREE.PlaneGeometry(.7,.55),blobMat());bl.rotation.x=-Math.PI/2;bl.position.y=.02;g.add(bl);
 g.userData.legs=[lL,lR];g.userData.arms=[aL,aR];return g;
}
var PETCOL={s:['#c9a27a','#3a3330','#efe3cf'],c:['#f7f2ea','#e0aa72','#9a6a45','#f3e6cc'],m:['#e08a3e','#f0c993','#3d3733'],l:['#e0a854','#d2d2d2','#2f2a26'],k:['#9c9c9c','#efe8dc','#e0913f','#3b3b3b'],o:['#ece6dc','#c8c0b4']};
function makePet(seg,i){
 var g=vgroup(),col=PETCOL[seg][i%PETCOL[seg].length],sc={s:.75,c:.8,m:.95,l:1.25,k:.78,o:.78}[seg],fl=(seg==='c'||seg==='o')?1.18:1;
 var body=vb(g,.46*sc*fl,.32*sc*fl,.34*sc*fl,-.04*sc,.3*sc,0,col);
 var head=headMesh(.42*sc*fl,.38*sc*fl,.4*sc*fl,col,0,'pet');head.position.set(.27*sc,.52*sc,0);g.add(head);
 if(seg==='k'){vb(g,.08,.12*sc,.1,.26*sc,.76*sc,-.12*sc,col);vb(g,.08,.12*sc,.1,.26*sc,.76*sc,.12*sc,col);vb(g,.06,.06,.32*sc,-.3*sc,.5*sc,0,col).rotation.z=.7;}
 else if(seg==='m'){vb(g,.08,.14*sc,.08,.24*sc,.76*sc,-.13*sc,col);vb(g,.08,.14*sc,.08,.24*sc,.76*sc,.13*sc,col);vb(g,.14*sc,.14*sc,.14*sc,-.3*sc,.48*sc,0,col);}
 else{vb(g,.1*sc,.2*sc,.08*sc,.24*sc,.6*sc,-.22*sc,seg==='c'||seg==='o'?col:'#7a5a44');vb(g,.1*sc,.2*sc,.08*sc,.24*sc,.6*sc,.22*sc,seg==='c'||seg==='o'?col:'#7a5a44');vb(g,.08*sc,.08*sc,.16*sc,-.3*sc,.46*sc,0,col).rotation.z=.5;}
 if(seg==='c'||seg==='o')vb(g,.2*sc,.12*sc,.22*sc,.27*sc,.74*sc,0,col);
 var pl=[];[[-.15,-.1],[-.15,.1],[.12,-.1],[.12,.1]].forEach(function(p){pl.push(vb(g,.09*sc,.16*sc,.09*sc,p[0]*sc,.08*sc,p[1]*sc,col));});g.userData.plegs=pl;
 g.traverse(function(m){if(m.isMesh)m.castShadow=true;});
 g.userData.fluff=[body,head];g.userData.sc=sc;return g;
}
function setGroomed(pet,groomed){var f=groomed?.86:1;pet.userData.fluff.forEach(function(m){m.scale.set(f,f,f);});}
/* 車：的士（紅身白頂）、小巴（米黃綠頂）、私家車、巴士 */
var HEAD_BEAM_TEX=null;
function headBeamTex(){if(HEAD_BEAM_TEX)return HEAD_BEAM_TEX;var c=document.createElement('canvas');c.width=c.height=128;var x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,240,197,.9)');g.addColorStop(.45,'rgba(255,235,181,.48)');g.addColorStop(1,'rgba(255,235,181,0)');x.fillStyle=g;x.fillRect(0,0,128,128);return HEAD_BEAM_TEX=new THREE.CanvasTexture(c);}
function makeCar(type,i){
 var g=vgroup();var spec={taxi:['#c8282d','#e8e8e8',3.6,1.5,1.4],mini:['#f1e6c8','#2f8f5b',4.2,1.9,2.1],car:[CLOTH[i%CLOTH.length],'#22313a',3.8,1.6,1.35],bus:['#c62f2f','#e7e2d6',10,2.5,4.2]}[type];
 var L=spec[2],W=spec[3],H=spec[4];
 vb(g,L,H*.45,W,0,.25+H*.22,0,spec[0]);
 if(type==='bus'){vb(g,L*.98,H*.45,W*.98,0,.25+H*.68,0,spec[0]);vb(g,L*.9,.35,W*1.01,0,.25+H*.5,0,'#26323a');vb(g,L*.9,.35,W*1.01,0,.25+H*.85,0,'#26323a');}
 else{vb(g,L*.55,H*.4,W*.92,-L*.05,.25+H*.62,0,'#26323a');vb(g,L*.5,.08,W*.9,-L*.05,.25+H*.84,0,spec[1]);}
 if(type==='taxi')vb(g,.5,.15,.3,0,.25+H*.94,0,'#f2f2f2');
 [[-L*.33,-W/2],[-L*.33,W/2],[L*.33,-W/2],[L*.33,W/2]].forEach(function(p){vb(g,.55,.5,.2,p[0],.25,p[1],'#111');});
 [[-L*.33,-W/2-.02],[-L*.33,W/2+.02],[L*.33,-W/2-.02],[L*.33,W/2+.02]].forEach(function(p){vb(g,.26,.26,.04,p[0],.25,p[1]+(p[1]>0?.1:-.1),'#b8bec4');});
 vb(g,.16,.2,W*.9,L/2+.04,.35,0,'#465052');vb(g,.16,.2,W*.9,-L/2-.04,.35,0,'#465052');
 vb(g,.03,.13,.48,L/2+.13,.36,0,'#f4f4f4');vb(g,.03,.13,.48,-L/2-.13,.36,0,'#f2d22e');
 if(type==='bus'){for(var wi=0;wi<6;wi++){vb(g,1.2,.5,.02,-L*.35+wi*1.4,.25+H*.5,W/2+.01,'#9cc6dc');vb(g,1.2,.5,.02,-L*.35+wi*1.4,.25+H*.85,W/2+.01,'#9cc6dc');}}
 var hl=vb(g,.06,.16,W*.18,L/2+.1,.54,-W*.34,'#fff6c8',{own:1});var hr=vb(g,.06,.16,W*.18,L/2+.1,.54,W*.34,'#fff6c8',{own:1});g.userData.head=hl;g.userData.headR=hr;g.userData.len=L;
 /* 車前地面光束：隨車移動，晚上漸亮。 */
 var beamMat=new THREE.MeshBasicMaterial({map:headBeamTex(),color:'#ffe7aa',transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide});
 var beam=new THREE.Mesh(new THREE.CircleGeometry(3.2,48),beamMat);beam.rotation.x=-Math.PI/2;beam.position.set(L/2+3.2,.048,0);g.add(beam);g.userData.beam=beam;
 var bs=new THREE.Mesh(new THREE.PlaneGeometry(L*1.05,W*1.1),blobMat());bs.rotation.x=-Math.PI/2;bs.position.y=.03;g.add(bs);
 vb(g,.08,.16,W*.7,-L/2,.45,0,'#8a1010',{e:'#ff2020',ei:.3});
 return g;
}
