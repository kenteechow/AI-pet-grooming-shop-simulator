/* p_hands：落手做（v0.18）。你（老闆）負責嘅預約，撳「落手做」切換第一身近鏡，一步步做。
   - 難度：簡單（洗澡、修甲清耳）、中等（全剪、大狗）、困難（貓、老年／皮膚敏感）。難度越高，錯誤選項越似真，計時位越窄越快、計時步驟越多。
   - 每步三個做法，字數相近，唔可以靠長短估答案；次序對同一張預約固定。
   - 揀完：工具喺毛孩相應位置做動畫（梳背、花灑、吹風、剪甲、電剪、剪刀……），揀錯毛孩會掙扎、頭頂有紅色警告。
   - 計時（抓時間）：揀啱做法之後，有啲步驟要喺綠色位撳「而家」（或者空白鍵）：剪甲喺血線前停、剪刀趁佢唔郁、推剪節奏、困難難度仲有水溫同風口距離。
   - 客人滿意度：做啱、計時準會升；做錯、計時失手、毛孩太緊張會跌。最後換成主人評價星數：好評令口碑升少少，差評令口碑跌。
   - 做得好（滿意度 80 以上、冇出事）先可以問主人加做服務；接受機會跟滿意度。做得差就唔會推銷。
   - 做法根據一般寵物美容做法簡化，唔係獸醫建議；健康問題一律記低、通知主人、建議睇獸醫。 */
var HSTEP={
 file:{q:'開工之前',tool:'檔案',part:'whole',anim:'read',o:[['睇檔案，同主人核對近況',1],['即刻抱佢上枱開始做',0,10],['先叫主人埋單俾錢先',0,5]],oh:[['睇檔案，同主人核對近況',1],['照上次相片嘅做法做',0,8],['淨係問主人要剪幾短',0,6]],why:'檔案有上次嘅觀察（怕咩、敏感位），可以避免重複出事。'},
 check:{q:'檢查身體',tool:'手',part:'whole',anim:'pat',o:[['由頭到尾摸一次全身',1],['淨係睇吓有冇毛結',0,5],['主人冇講就唔使睇',0,10]],oh:[['由頭到尾摸一次全身',1],['淨係檢查皮膚同耳仔',0,5],['洗完澡先慢慢檢查',0,6]],why:'有問題要開工前講清楚，唔係會當咗係美容造成。'},
 finding:{q:'發現左耳有少少紅',tool:'手',part:'ear',anim:'pat',o:[['記低，通知主人睇醫生',1],['自己幫佢塗啲藥膏',0,10,'skin'],['當冇見到照樣做',0,5]],oh:[['記低，通知主人睇醫生',1],['清乾淨啲耳垢再算',0,10,'skin'],['塗少少潔耳液消毒',0,8,'skin']],why:'美容店唔做診斷；記低同通知主人係保護毛孩，亦保護自己。'},
 brush:{q:'落水之前',tool:'梳',part:'back',anim:'brush',o:[['先梳開毛結同死毛',1],['濕咗水先梳比較順',0,15],['唔使梳直接落水',0,10]],oh:[['先梳開毛結同死毛',1],['落護毛素再一齊梳',0,12],['淨係梳開大毛結',0,8]],why:'毛結一濕會縮得更緊，梳嗰陣會扯痛。'},
 temp:{q:'水溫',tool:'花灑',part:'back',anim:'shower',tm:2,o:[['手腕試吓，微暖就啱',1],['熱啲先洗得乾淨',0,15,'skin'],['凍水涼爽啲',0,15]],oh:[['手腕試吓，微暖就啱',1],['手指試吓唔熱就得',0,10,'skin'],['跟熱水爐預設溫度',0,10,'skin']],why:'手指冇手腕咁敏感；太熱會刺激皮膚，太凍會令佢震。',tw:{p:'水溫轉到微暖（綠色位）先撳',risk:'skin'}},
 wet:{q:'打濕次序',tool:'花灑',part:'back',anim:'shower',o:[['由頸向尾，避開眼耳',1],['先淋個頭一次過',0,20],['成隻浸落浴缸度',0,20]],oh:[['由頸向尾，避開眼耳',1],['由頭頂慢慢淋落去',0,15],['由尾開始，最後淋頭',0,12]],why:'水入耳容易發炎；淋頭會令佢好驚，頭最後用濕毛巾抹。'},
 soap:{q:'沐浴露',tool:'沐浴露',part:'back',anim:'lather',o:[['寵物專用，稀釋再用',1],['用人用洗頭水',0,5,'skin'],['大量直接倒落身',0,5]],oh:[['寵物專用，稀釋再用',1],['寵物專用，原液直落',0,5,'skin'],['嬰兒洗頭水最溫和',0,5,'skin']],why:'人用（包括嬰兒）洗頭水酸鹼度唔啱寵物皮膚；原液容易殘留。'},
 rinse:{q:'過水',tool:'花灑',part:'belly',anim:'shower',o:[['沖到完全冇泡為止',1],['大概沖吓就得',0,5,'skin'],['留啲泡當護毛',0,5,'skin']],oh:[['沖到完全冇泡為止',1],['沖到冇滑潺潺就得',0,5,'skin'],['背脊冇泡就收工',0,5,'skin']],why:'腋下、腳趾、尾下最易殘留，係皮膚痕、紅嘅常見原因。'},
 dry:{q:'吹乾',tool:'吹風機',part:'back',anim:'dry',tm:1,o:[['毛巾吸水，再由身吹起',1],['對住個頭吹，最快乾',0,25],['開最熱嘅風，快啲乾',0,15,'skin']],oh:[['毛巾吸水，再由身吹起',1],['由頭開始，吹落身度',0,20],['唔使毛巾，直接開吹',0,10]],why:'大風量吹風機好嘈，對住面吹最易令佢恐慌；怕聲嘅用低風速分段。',tw:{p:'風口距離啱啱好（綠色位）先撳',risk:'stress'}},
 hold:{q:'剪甲保定',tool:'手',part:'paw',anim:'hold',o:[['扶穩腳掌，身體貼住',1],['叫佢企好，唔使扶',0,10],['大力夾實佢隻腳',0,20]],oh:[['扶穩腳掌，身體貼住',1],['提高隻腳方便睇',0,12],['叫助手按住個頭',0,15]],why:'太鬆會亂郁剪到肉；太緊或者拗腳會令佢掙扎。'},
 quick:{q:'剪幾多',tool:'甲剪',part:'paw',anim:'clip',tm:1,o:[['見到血線前就停手',1],['一刀剪到貼肉',0,20,'minor'],['估吓位置就剪',0,15,'minor']],oh:[['見到血線前就停手',1],['黑甲照白甲咁剪',0,15,'minor'],['剪到見少少粉紅',0,15,'minor']],why:'黑甲睇唔到血線，要每次剪少少，見到切面中間深色點就停。',tw:{p:'甲剪移到血線前（綠色位）就撳',risk:'minor'}},
 file2:{q:'剪完之後',tool:'磨甲器',part:'paw',anim:'file',o:[['磨順，備定止血粉',1],['唔使理佢',0,0],['用剪刀修尖位',0,5]],oh:[['磨順，備定止血粉',1],['磨順就得唔使準備',0,3],['塗啲潤膚膏保護',0,3]],why:'磨順避免刮傷；止血粉係以防萬一。'},
 ear:{q:'清耳',tool:'潔耳液',part:'ear',anim:'ear',o:[['潔耳液加棉花清外耳',1],['棉花棒插入耳道',0,15,'minor'],['用水沖耳仔',0,10]],oh:[['潔耳液加棉花清外耳',1],['棉花棒輕輕清耳道',0,12,'minor'],['拔晒耳毛再清',0,15]],why:'棉花棒會將耳垢推入去，仲可能整傷耳道。'},
 pad:{q:'腳底毛',tool:'電剪',part:'paw',anim:'clipper',o:[['細刀頭剃肉墊之間',1],['用剪刀剪肉墊之間',0,10,'minor'],['唔使剃，留住佢',0,0]],oh:[['細刀頭剃肉墊之間',1],['大刀頭一次過剃',0,10,'minor'],['剃到肉墊見晒肉',0,12,'skin']],why:'腳底毛長會滑；刀頭太大容易刮傷肉墊。'},
 sani:{q:'衛生位（肚、肛門）',tool:'電剪',part:'belly',anim:'clipper',o:[['短刀頭順毛輕力剃',1],['逆毛大力剃快啲',0,10,'skin'],['用剪刀剪',0,15,'minor']],oh:[['短刀頭順毛輕力剃',1],['短刀頭逆毛剃乾淨',0,10,'skin'],['長刀頭順毛剃',0,6]],why:'嗰度皮膚薄，逆毛剃容易起紅疹。'},
 body:{q:'剪身型',tool:'電剪',part:'back',anim:'clipper',tm:2,o:[['跟主人要求揀梳套',1],['自己覺得靚就得',0,5],['剪到最短慳時間',0,5]],oh:[['跟主人要求揀梳套',1],['照上次相片剪',0,4],['跟品種標準造型剪',0,4]],why:'剪錯造型係最常見嘅投訴；主人今次要求可能同上次唔同。',tw:{p:'推剪節奏要穩，喺綠色位撳',risk:'skin'}},
 face:{q:'修面同耳邊',tool:'剪刀',part:'head',anim:'scissor',tm:2,o:[['圓頭剪，手指擋住眼',1],['尖頭剪刀，快啲修',0,15,'minor'],['唔修，留返原樣',0,0]],oh:[['圓頭剪，手指擋住眼',1],['尖頭剪，手指擋住眼',0,10,'minor'],['圓頭剪，直接修',0,10]],why:'面同耳邊最易剪傷；圓頭剪加手指擋住最安全。',tw:{p:'趁佢個頭唔郁（綠色位）先剪',risk:'minor'}},
 final:{q:'交返主人之前',tool:'相機',part:'whole',anim:'photo',o:[['睇對稱、影相、記觀察',1],['唔使睇，直接交返',0,0],['叫主人自己慢慢睇',0,0]],oh:[['睇對稱、影相、記觀察',1],['影相就得唔使記',0,0],['記低觀察唔使影相',0,0]],why:'前後相同觀察紀錄，可以做報告卡，亦係下次嘅參考。'},
 towel:{q:'貓咪保定',tool:'毛巾',part:'whole',anim:'towel',o:[['毛巾輕包，動作要慢',1],['頸圈綁實喺枱度',0,25],['大聲講嘢安撫',0,15]],oh:[['毛巾輕包，動作要慢',1],['捉住後頸提起佢',0,20],['毛巾包得越實越好',0,15]],why:'貓咪對束縛同聲音特別敏感。'},
 catbrush:{q:'貓咪毛結',tool:'梳',part:'back',anim:'brush',o:[['拉住皮膚慢慢梳開',1],['用力梳開佢',0,15],['剪刀剪走毛結',0,10,'minor']],oh:[['拉住皮膚慢慢梳開',1],['剪刀貼皮剪走毛結',0,10,'minor'],['先落水再梳開',0,12]],why:'貓皮好薄，用剪刀剪毛結好容易剪到皮。'},
 catwash:{q:'洗唔洗？',tool:'花灑',part:'back',anim:'shower',o:[['睇狀態，好驚就停',1],['一定要洗完佢',0,20],['花灑直接淋落去',0,20]],oh:[['睇狀態，好驚就停',1],['快手洗完減少時間',0,15],['用熱水令佢放鬆',0,15,'skin']],why:'有啲貓唔適合洗，強行做會出事。'},
 pant:{q:'佢開始張口喘氣',tool:'手',part:'head',anim:'pat',o:[['即刻停手讓佢冷靜',1],['繼續做埋佢',0,30,'stress'],['加快手做完佢',0,25,'stress']],oh:[['即刻停手讓佢冷靜',1],['開風扇繼續做',0,25,'stress'],['餵少少零食繼續',0,20,'stress']],why:'貓張口喘氣係緊張或者身體唔舒服嘅信號。'}};
var HPLAN={wash:['file','check','brush','temp','wet','soap','rinse','dry','final'],nail:['file','check','hold','quick','file2','ear','final'],
 cut:['file','check','brush','temp','wet','soap','rinse','dry','pad','sani','body','face','final'],cat:['file','towel','catbrush','catwash','catdry','pant','hold','catquick','final']};
var HDIFF=['','簡單','中等','困難'];
/* ---------- v0.19：按毛孩情況同主人要求變化嘅步驟 ----------
   每隻毛孩嘅題目由三樣嘢決定：品種（雙層毛、短鼻、淚痕、鬍鬚）、佢身上真實嘅特點（檔案紀錄嘅「事實」，包括未確認或者未寫低嘅，即場會發現）、主人今日嘅交代。
   情況步驟會取代對應嘅一般步驟（例如怕大風聲 → 吹乾變「低風速分段」），或者加插一步（怕陌生人 → 先打招呼；老狗氣喘 → 停低休息）。
   同主人要求有關嘅步驟（w:2）計雙倍滿意度：照主人講做，係客人最睇重嘅嘢。
   你親手做時揀啱情況步驟，會將嗰個特點寫入檔案（由你確認）；主人嘅造型或者健康交代，覆述啱都會記低。 */
var HVAR={
 greet:{q:'佢怕陌生人，點開始？',tool:'手',part:'head',anim:'pat',obs:'怕陌生人，先俾佢聞手先開始',o:[['蹲低俾佢聞手先',1],['即刻抱佢上枱',0,15],['大聲叫佢名安撫',0,10]],oh:[['蹲低俾佢聞手先',1],['餵零食即刻抱起',0,10],['由後面靜靜抱起',0,15]],why:'怕陌生人嘅毛孩，先俾佢聞同熟習，之後成個流程都會順好多。'},
 req:{q:function(a){return '主人今日交代：「'+handsReq(a).t+'」';},tool:'檔案',part:'whole',anim:'read',w:2,o:[['覆述一次，記入檔案',1],['點頭就得，記得住',0,5],['照檔案舊要求做',0,5]],oh:[['覆述一次，記入檔案',1],['記喺腦，交狗再對',0,4],['等做完先問清楚',0,5]],why:'口頭要求最易漏；覆述一次同記入檔案，交返主人時先對得返，下次都用得。'},
 req_rush:{q:'主人話：「一個鐘內要嚟接」',tool:'檔案',part:'whole',anim:'read',w:2,o:[['講清楚做唔做得切',1],['一口答應到時再算',0,6],['叫佢遲啲先嚟接',0,4]],why:'趕時間最易出事；做唔切寧願即刻講，減項目或者改時間。'},
 req_food:{q:'主人話：「佢最近唔肯食嘢」',tool:'檔案',part:'whole',anim:'read',w:2,o:[['記低，唔舒服就停手',1],['照做，做完先講',0,6],['餵罐頭試吓佢',0,6]],why:'食慾差可能係身體唔舒服；做嗰陣留意佢反應，有異樣就停，同主人講建議睇獸醫。'},
 check_flea:{q:'主人想你睇吓有冇蝨',tool:'梳',part:'back',anim:'brush',w:2,o:[['蚤梳梳耳後同尾根',1],['淨係望吓背脊表面',0,5],['洗完澡先慢慢睇',0,5]],why:'蝨同跳蚤多數喺耳後、頸、尾根；見到要即刻通知主人，用過嘅枱同工具要消毒。'},
 finding_chin:{q:'下巴有黑色粒粒',tool:'手',part:'head',anim:'pat',obs:'下巴有黑色粒粒',o:[['記低，通知主人睇醫生',1],['用手指擠走啲粒粒',0,10,'skin'],['當冇見到繼續做落去',0,5]],oh:[['記低，通知主人睇醫生',1],['用梳仔刮走啲黑粒',0,10,'skin'],['用酒精棉抹乾淨佢',0,10,'skin']],why:'貓下巴黑粒可能係粉刺或者其他皮膚問題；美容店唔診斷，記低同通知主人。'},
 brush_mat:{q:'腋下同耳後容易打結',tool:'梳',part:'back',anim:'brush',obs:'腋下同耳後容易打結，要先梳開',o:[['先梳開腋下同耳後',1],['淨係梳背脊就得',0,8],['直接剃走成片毛',0,10,'skin']],why:'呢兩個位最易打結；漏咗會喺水度縮實，最後要剃。'},
 brush_dbl:{q:function(a){return handsTags(a).shed?'換毛期，底毛好多':'雙層毛，落水之前';},tool:'梳',part:'back',anim:'brush',o:[['排梳先梳走底毛',1],['針梳刷吓面層就得',0,8],['唔使梳洗完先算',0,8]],why:'雙層毛嘅底毛唔先梳走，落水會黐埋一舊，吹都吹唔乾。'},
 catbrush_tail:{q:'尾巴附近有毛結',tool:'梳',part:'back',anim:'brush',obs:'尾巴附近有毛結',o:[['拉住皮膚慢慢梳開',1],['捉住條尾大力梳',0,15,'stress'],['剪刀貼皮剪走佢',0,10,'minor']],why:'貓尾根皮膚好薄又敏感，捉尾佢會反抗；拉住皮膚分小撮梳，梳唔開就用電剪，唔好用剪刀。'},
 soap_own:{q:'主人帶咗佢自己嘅沐浴露',tool:'沐浴露',part:'back',anim:'lather',w:2,o:[['睇清楚成分，稀釋用',1],['用返店舖嘅沐浴露',0,5],['唔使稀釋，原液用',0,5,'skin']],why:'主人指定嘅產品要用，但要睇清楚係咪寵物用、點稀釋；記低用咗乜，之後有事都分得清。'},
 soap_sens:{q:'皮膚敏感緊，點落沐浴露？',tool:'沐浴露',part:'back',anim:'lather',o:[['低敏配方，輕手唔擦',1],['藥用沐浴露洗多次',0,8,'skin'],['大力擦走啲皮屑',0,8,'skin']],oh:[['低敏配方，輕手唔擦',1],['低敏配方，留耐啲',0,8,'skin'],['藥用配方，洗兩次',0,8,'skin']],why:'敏感期皮膚好脆弱；藥用沐浴露要跟獸醫指示先用，唔好自己加。泡留耐咗、擦得大力都會更痕。'},
 rest:{q:'佢企耐咗開始氣喘',tool:'手',part:'head',anim:'pat',obs:'企耐咗會氣喘，要多啲休息',o:[['停低休息，飲啲水',1],['加快手做完佢',0,20,'stress'],['開大風扇繼續做',0,15,'stress']],why:'老狗心肺差，氣喘係身體到極限嘅信號；停低、休息、觀察，唔好趕。'},
 dry_noise:{q:'佢怕大風聲，點吹乾？',tool:'吹風機',part:'back',anim:'dry',tm:1,obs:'怕大風聲，低風速同分段休息會放鬆啲',o:[['低風速分段，停吓休息',1],['大風量一口氣吹完',0,20,'stress'],['塞住耳仔照開大風',0,12,'stress']],why:'怕大風聲嘅毛孩，低風速分段吹慢少少，但唔會驚到掙扎。',tw:{p:'低風速，風口距離啱啱好先撳',risk:'stress'}},
 dry_flat:{q:'短鼻品種，吹乾嗰陣',tool:'吹風機',part:'back',anim:'dry',tm:1,o:[['低溫，留意呼吸同舌色',1],['開熱風吹快啲收工',0,15,'stress'],['包住毛巾焗乾佢',0,15,'stress']],why:'八哥、法鬥、波斯貓呢類短鼻品種散熱差，焗熱好易氣促；舌頭變深色要即刻停。',tw:{p:'溫度同距離啱啱好先撳',risk:'stress'}},
 dry_cold:{q:'老人家怕冷，吹乾嗰陣',tool:'吹風機',part:'back',anim:'dry',tm:1,obs:'怕冷，吹乾要快啲',o:[['吸乾再暖風分段吹',1],['自然風乾唔使吹',0,10,'stress'],['開最熱風快手吹',0,10,'skin']],why:'老狗怕冷又易攰；先用毛巾吸乾，再用暖風分段吹，唔好用最熱。',tw:{p:'暖風距離啱啱好先撳',risk:'skin'}},
 dry_dbl:{q:'雙層毛，點樣吹？',tool:'吹風機',part:'back',anim:'dry',tm:1,o:[['吹到底毛都乾透',1],['面層乾咗就收工',0,8,'skin'],['用毛巾焗住自然乾',0,8,'skin']],why:'底毛未乾會焗住，容易出濕疹（熱點）；雙層毛要預多啲時間。',tw:{p:'風口貼近底毛（綠色位）先撳',risk:'skin'}},
 tear:{q:'眼角有淚痕同眼屎',tool:'棉花',part:'head',anim:'ear',o:[['濕棉花由內向外抹',1],['剪刀剪走眼角毛',0,10,'minor'],['用指甲摳走眼屎',0,10,'minor']],why:'眼角好近眼球；用濕棉花由內眼角向外抹，硬咗嘅眼屎先濕潤再抹。'},
 hold_spay:{q:'啱啱絕育，保定嗰陣',tool:'手',part:'paw',anim:'hold',o:[['避開肚仔，側身扶住',1],['攬住個肚最穩陣',0,12,'stress'],['反轉佢仰臥咁剪',0,15,'stress']],why:'絕育後傷口未好，肚仔唔好壓；側身扶住、動作慢。'},
 hold_hind:{q:'後腳無力，剪甲嗰陣',tool:'手',part:'paw',anim:'hold',obs:'後腳無力，要托住佢',o:[['托住後半身，坐低剪',1],['叫佢企直方便剪',0,12,'stress'],['抬高後腳快手剪',0,12,'stress']],why:'老狗後腳無力，企耐咗會震同跌；坐低或者伏低剪，托住後半身。'},
 hold_two:{q:'大隻狗，點上枱？',tool:'手',part:'whole',anim:'hold',obs:'大隻但好乖，洗澡要兩個人',o:[['兩個人一齊抬上去',1],['自己一個抱上去',0,10,'stress'],['叫佢自己跳上枱',0,10,'minor']],why:'大狗自己跳或者一個人抱，好易扭親或者跌落嚟；兩個人抬或者用升降枱。'},
 hold_paw:{q:'佢剪腳會縮腳',tool:'手',part:'paw',anim:'hold',obs:'剪腳毛會縮腳，要助手扶住',o:[['請助手扶，慢慢嚟',1],['趁佢唔覺意快手剪',0,12,'minor'],['拉直佢隻腳先剪',0,15,'stress']],why:'會縮腳嘅毛孩，硬拉會令佢更驚，突然郁更易剪傷。'},
 quick_black:{q:'黑色指甲，剪幾多？',tool:'甲剪',part:'paw',anim:'clip',tm:1,obs:'指甲黑色，要分幾次慢慢剪',o:[['每次剪少少睇切面',1],['照平時長度一刀剪',0,15,'minor'],['剪到貼肉先安全',0,15,'minor']],why:'黑甲睇唔到血線；每次剪少少，切面中間見到深色濕點就停。',tw:{p:'每刀剪少少，喺綠色位停手',risk:'minor'}},
 quick_bled:{q:'主人話上次剪到流血',tool:'甲剪',part:'paw',anim:'clip',tm:1,w:2,o:[['剪少啲，止血粉放手邊',1],['照舊剪，唔使理佢',0,8,'minor'],['今次剪短啲慳時間',0,12,'minor']],why:'主人擔心就更加要穩；寧願剪少啲下次再修，止血粉預先擺好。',tw:{p:'甲剪移到血線前（綠色位）就撳',risk:'minor'}},
 sani_spay:{q:'啱啱絕育，剃唔剃肚毛？',tool:'電剪',part:'belly',anim:'clipper',o:[['避開傷口，今次唔剃',1],['輕手剃埋傷口附近',0,12,'skin'],['用剪刀修短啲肚毛',0,10,'minor']],why:'絕育傷口附近唔好剃亦唔好洗；留返下次，同主人講一聲。'},
 body_short_dbl:{q:'主人要剃短（雙層毛）',tool:'電剪',part:'back',anim:'clipper',tm:2,w:2,o:[['解釋點解唔建議剃',1],['照主人講剃到最短',0,6,'skin'],['唔出聲照平時剪',0,8]],why:'雙層毛剃短可能長唔返原樣，亦失去隔熱、易曬傷；同主人講清楚，改做去底毛同修短。主人堅持就記低佢同意。',tw:{p:'修短嗰陣推剪要穩，喺綠色位撳',risk:'skin'}},
 body_short:{q:'主人今次要剪短啲',tool:'電剪',part:'back',anim:'clipper',tm:2,w:2,o:[['換短啲嘅梳套',1],['照上次長度剪',0,4],['剃到見皮最涼',0,6,'skin']],why:'主人今次要求同上次唔同；跟今次講嘅做，記低新長度，下次先唔會剪錯。',tw:{p:'推剪節奏要穩，喺綠色位撳',risk:'skin'}},
 body_same:{q:'主人要「同上次一樣」',tool:'電剪',part:'back',anim:'clipper',tm:2,w:2,o:[['睇上次紀錄同相片',1],['憑印象估吓上次',0,5],['跟品種標準造型',0,5]],why:'「同上次一樣」靠記憶最易出錯；有紀錄同相片就跟住做，冇紀錄要即刻問清楚。',tw:{p:'推剪節奏要穩，喺綠色位撳',risk:'skin'}},
 face_earlong:{q:'主人要耳仔留長',tool:'剪刀',part:'ear',anim:'scissor',tm:2,w:2,o:[['耳邊只修齊唔剪短',1],['耳仔剪短易打理',0,4],['跟平時長度修耳',0,4]],why:'耳仔留長係主人嘅要求；剪錯造型係最常見投訴，而且要等幾個月先長返。',tw:{p:'趁佢個頭唔郁（綠色位）先剪',risk:'minor'}},
 face_round:{q:'主人要面剪圓啲',tool:'剪刀',part:'head',anim:'scissor',tm:2,w:2,o:[['圓頭剪，修成圓面',1],['照品種標準修面',0,4],['尖頭剪快手修圓',0,10,'minor']],why:'跟主人要求做；近眼位用圓頭剪安全啲。',tw:{p:'趁佢個頭唔郁（綠色位）先剪',risk:'minor'}},
 face_beard:{q:'史納莎嘅鬍鬚點處理？',tool:'剪刀',part:'head',anim:'scissor',tm:2,o:[['保留鬍鬚，修齊外形',1],['剪短鬍鬚易打理',0,4],['剃走成撮鬍鬚',0,6]],why:'鬍鬚同眉毛係史納莎造型重點，主人冇講唔好剪短；食完嘢易污糟，洗乾淨修齊就得。',tw:{p:'趁佢個頭唔郁（綠色位）先剪',risk:'minor'}},
 catwash_water:{q:'佢怕水聲，點樣洗？',tool:'花灑',part:'back',anim:'shower',obs:'怕水聲，用毛巾包住先唔會掙扎',o:[['毛巾包住，細水慢沖',1],['開大花灑快手沖',0,20,'stress'],['浸落水盆洗晒佢',0,20,'stress']],why:'怕水聲嘅貓，毛巾包住、細水貼住身沖，聲細啲佢會冷靜好多。'},
 catface:{q:'修面嗰陣，佢啲鬚',tool:'剪刀',part:'head',anim:'scissor',obs:'唔好剪鬚',w:2,o:[['避開鬍鬚，只修面毛',1],['鬍鬚修短整齊啲',0,15,'stress'],['連鬍鬚一齊修短',0,15,'stress']],why:'貓鬚係感覺器官，剪短會令佢判斷唔到距離，好唔安；主人都講過唔好剪。'}};
for(var hk_ in HVAR)HSTEP[hk_]=HVAR[hk_];
/* v0.19.1 貓：自己嘅吹乾、剪爪做法，身體語言信號（每隻唔同），同埋貓專屬嘅特點同主人交代 */
var HCAT={
 catdry:{q:'貓咪點樣吹乾？',tool:'吹風機',part:'back',anim:'dry',tm:1,o:[['吸乾水，低風速遠吹',1],['大風量快手吹乾佢',0,20,'stress'],['放入烘箱焗乾佢',0,15,'stress']],oh:[['吸乾水，低風速遠吹',1],['低風速貼近皮膚吹',0,10,'skin'],['吹到半乾俾佢自己舔',0,8]],why:'貓怕吹風機聲同大風；先用毛巾吸乾，低風速保持距離。烘箱冇人睇住好危險，短鼻貓更加唔得。',tw:{p:'風口保持距離（綠色位）先撳',risk:'stress'}},
 catquick:{q:'貓爪點樣剪？',tool:'甲剪',part:'paw',anim:'clip',tm:1,o:[['按肉墊推出爪尖',1],['捉住隻腳直接剪',0,12,'stress'],['剪到見粉紅位止',0,15,'minor']],oh:[['按肉墊推出爪尖',1],['剪透明位再剪多啲',0,12,'minor'],['用狗甲剪大刀剪',0,10,'minor']],why:'貓爪平時收埋，要輕按肉墊推出嚟；只剪透明尖端，粉紅位係血管同神經。',tw:{p:'剪透明尖端（綠色位）就撳',risk:'minor'}},
 catquick_req:{q:'主人要爪剪短啲',tool:'甲剪',part:'paw',anim:'clip',tm:1,w:2,o:[['剪到透明尖端就停',1],['剪到貼近粉紅位',0,15,'minor'],['連爪鞘一齊剪走',0,15,'minor']],why:'爪剪得再短都唔可以剪到粉紅位；想佢少啲抓梳化，可以建議貓抓板同密啲剪。',tw:{p:'剪透明尖端（綠色位）就撳',risk:'minor'}},
 catsign:{q:'佢耳仔向後擰、條尾大力拍',tool:'手',part:'head',anim:'pat',o:[['停手，俾佢冷靜一陣',1],['加快手做埋最後',0,20,'stress'],['大聲喝止佢唔准郁',0,15,'stress']],oh:[['停手，俾佢冷靜一陣',1],['餵零食繼續做落去',0,15,'stress'],['按實佢快手做完',0,20,'stress']],why:'耳向後、尾大力拍係貓好唔耐煩、就快出手嘅信號；停一停比硬做安全。'},
 catgrowl:{q:'佢開始低聲咆哮',tool:'毛巾',part:'head',anim:'towel',o:[['停手，用毛巾蓋住頭',1],['繼續做，唔使理佢',0,20,'stress'],['同佢講嘢安撫佢',0,10,'stress']],oh:[['停手，用毛巾蓋住頭',1],['戴手套照樣做落去',0,15,'stress'],['捉住後頸繼續做',0,20,'stress']],why:'咆哮係警告；蓋住個頭減少刺激佢會靜啲，硬做好易被咬傷或者抓傷。'},
 towel_fierce:{q:'佢之前抓傷過人',tool:'毛巾',part:'whole',anim:'towel',obs:'會抓人，要戴手套同兩個人',o:[['戴手套，兩個人慢慢包',1],['一個人快手捉住佢',0,20,'stress'],['捉住後頸提起佢',0,20,'stress']],why:'有抓人紀錄嘅貓，戴手套、兩個人配合、毛巾包住；捉後頸會令成年貓更驚。'},
 catear:{q:'耳仔有好多啡色耳垢',tool:'潔耳液',part:'ear',anim:'ear',obs:'耳仔有好多啡色耳垢',o:[['記低，建議查吓耳蟎',1],['棉花棒挖乾淨佢',0,15,'minor'],['倒潔耳液落去搓',0,10]],why:'大量啡色耳垢可能係耳蟎或者耳仔發炎；美容店唔診斷，記低同建議主人睇獸醫。'},
 catbrush_fat:{q:'佢舔唔到背脊，打晒結',tool:'梳',part:'back',anim:'brush',obs:'有啲肥，背脊同尾根易打結',o:[['小撮梳，唔得就電剪',1],['剪刀剪走成舊毛結',0,10,'minor'],['大力一次過梳開',0,15,'stress']],why:'肥貓舔唔到背脊同尾根，容易打結；梳唔開用電剪，同主人講吓每日梳毛。'},
 catlion:{q:'主人想剃獅子裝',tool:'電剪',part:'back',anim:'clipper',tm:1,w:2,o:[['先講風險，電剪慢慢剃',1],['用剪刀剪走晒毛結',0,10,'minor'],['照講即刻剃到最短',0,10,'skin']],why:'貓皮薄又鬆，剃毛要用電剪、拉平皮膚慢慢嚟；太驚嘅貓要建議主人搵獸醫鎮靜先剃。',tw:{p:'電剪貼住皮膚要穩，喺綠色位撳',risk:'skin'}},
 hold_belly:{q:'佢一摸肚就咬',tool:'手',part:'paw',anim:'hold',obs:'一摸肚就咬',o:[['唔掂肚，側身扶住佢',1],['反轉佢仰臥剪後腳',0,15,'stress'],['攬住個肚抱實佢',0,15,'stress']],why:'好多貓唔鍾意人掂肚；側身扶住、由前腳開始，佢會放鬆啲。'}};
for(var hc_ in HCAT){HVAR[hc_]=HCAT[hc_];HSTEP[hc_]=HCAT[hc_];}

/* 主人今日嘅交代（約一半預約有；同一張預約固定）。rec：覆述啱會記入檔案 */
var HREQ=[{id:'short',t:'今次想剪短啲，天氣熱',svc:['cut'],kind:'style',rec:1},{id:'same',t:'上次返去好開心，想同上次一樣',svc:['cut'],kind:'style',rec:1},{id:'earlong',t:'耳仔留長，唔好剪短',svc:['cut'],kind:'style',rec:1},
 {id:'rush',t:'一個鐘內要嚟接',svc:['wash']},{id:'own',t:'用佢自己帶嘅沐浴露',svc:['wash','cut']},{id:'flea',t:'順便睇吓有冇蝨',svc:['wash','cut']},{id:'bled',t:'上次剪到流血，今次小心啲',svc:['nail'],kind:'care',rec:1},{id:'food',t:'佢最近唔肯食嘢',svc:['cat'],kind:'health',rec:1},
 {id:'nowash',t:'今次唔使洗，梳毛剪爪就得',svc:['cat'],kind:'care',rec:1},{id:'claw',t:'佢成日抓梳化，爪剪短啲',svc:['cat']},{id:'scratch',t:'佢上次抓傷咗美容師',svc:['cat'],kind:'care',rec:1},{id:'lion',t:'毛結太多，想剃獅子裝',svc:['cat'],when:function(a){return /波斯/.test(a.breed||'');}}];
function handsReq(a){if(a.hreq===undefined){var L=HREQ.filter(function(r){return r.svc.indexOf(a.svc)>=0&&(!r.when||r.when(a));});a.hreq=L.length&&hHash('req'+a.id)%100<55?L[hHash('rq'+a.id)%L.length].id:'';}
 return a.hreq?HREQ.filter(function(r){return r.id===a.hreq;})[0]||null:null;}
/* 毛孩特點：品種 + 佢身上嘅真實特點（紀錄嘅 truth，唔理有冇確認）+ 主人今日交代 */
var HTAG={shy:/怕陌生人/,mat:/腋下同耳後/,paw:/縮腳/,noise:/怕大風聲/,earlong:/耳仔留長/,round:/面部剪圓/,ear:/左耳有少少紅/,black:/指甲黑色/,catwater:/怕水聲/,whisker:/唔好剪鬚/,tailmat:/尾巴附近有毛結/,chin:/下巴有黑色粒粒/,pant:/氣喘/,hind:/後腳無力/,cold:/怕冷/,two:/兩個人/,shed:/換毛期/,spay:/絕育/,short:/剪短啲/,sens:/皮膚敏感/,same:/同上次一樣/,fierce:/抓傷|會抓人/,catear:/啡色耳垢/,fat:/背脊同尾根易打結/,belly:/一摸肚就咬/,nowash:/唔使洗/,lion:/獅子裝/,claw:/抓梳化/};
function handsTags(a){var p=a.pid&&clPet(a.pid),txt=(p?p.notes.map(function(n){return n.truth||n.txt;}):[]),rq=handsReq(a),T={};if(rq){txt.push(rq.t);T[rq.id]=1;}var j=txt.join('｜');
 for(var k in HTAG)if(HTAG[k].test(j))T[k]=1;var b=a.breed||'';
 if(/柴犬|柯基|哈士奇|金毛|拉布拉多/.test(b))T.dbl=1;if(/八哥|法鬥|波斯/.test(b))T.flat=1;if(/西施|比熊|約瑟爹利|貴婦|波斯/.test(b))T.tear=1;if(/史納莎/.test(b))T.beard=1;if(/敏感/.test(b))T.sens=1;
 if(a.seg!=='k')['catwater','whisker','tailmat','chin','fierce','catear','fat','belly','nowash','lion','claw'].forEach(function(x){delete T[x];});return T;}
/* 一般步驟 → 情況步驟（排前面嘅優先） */
var HSWAP={brush:[['mat','brush_mat'],['dbl','brush_dbl'],['shed','brush_dbl']],catbrush:[['lion','catlion'],['tailmat','catbrush_tail'],['fat','catbrush_fat']],towel:[['fierce','towel_fierce']],catdry:[['noise','dry_noise'],['flat','dry_flat']],catquick:[['claw','catquick_req']],soap:[['own','soap_own'],['sens','soap_sens']],
 dry:[['noise','dry_noise'],['flat','dry_flat'],['cold','dry_cold'],['dbl','dry_dbl']],hold:[['belly','hold_belly'],['spay','hold_spay'],['hind','hold_hind'],['two','hold_two'],['paw','hold_paw']],
 quick:[['bled','quick_bled'],['black','quick_black']],sani:[['spay','sani_spay']],body:[['short&dbl','body_short_dbl'],['short','body_short'],['same','body_same']],
 face:[['earlong','face_earlong'],['round','face_round'],['beard','face_beard']],catwash:[['catwater','catwash_water']],check:[['flea','check_flea']]};
function handsBuild(a){var st=(HPLAN[a.svc]||HPLAN.wash).slice(),T=handsTags(a),ins=function(after,k){var i=st.indexOf(after);st.splice(i>=0?i+1:1,0,k);};
 st=st.map(function(k){var L=HSWAP[k]||[];for(var i=0;i<L.length;i++){if(L[i][0].split('&').every(function(t){return T[t];}))return L[i][1];}return k;});
 if(a.svc==='cat'){if(!T.pant){var pi=st.indexOf('pant');if(pi>=0)st[pi]=['pant','catsign','catgrowl'][hHash('sig'+a.id)%3];}
  if(T.nowash)st=st.filter(function(k){return !/^(catwash|catdry|dry_)/.test(k);});
  if(T.catear){var ci=st.findIndex(function(k){return /^cat(brush|lion)/.test(k);});st.splice(ci>=0?ci+1:2,0,'catear');}}
 if(T.two&&!st.some(function(k){return /^hold/.test(k);}))ins(st[1]==='check'||st[1]==='check_flea'?st[1]:'file','hold_two');
 if(T.chin)ins(st.indexOf('towel')>=0?'towel':'file','finding_chin');
 else if(T.ear||(a.seg==='o'&&!T.pant&&!T.hind&&!T.cold))ins(st.indexOf('check')>=0?'check':st.indexOf('check_flea')>=0?'check_flea':'file','finding');
 var rq=handsReq(a);if(rq){if(rq.id==='rush')ins('file','req_rush');else if(rq.id==='food')ins('file','req_food');else if(rq.rec&&rq.id!=='bled')ins('file','req');}
 if(T.shy)ins('file','greet');
 if(T.pant&&st.indexOf('rinse')>=0)ins('rinse','rest');
 if(T.tear&&a.svc!=='nail'){var di=st.findIndex(function(k){return /^(dry|catdry)/.test(k);});if(di>=0)st.splice(di+1,0,'tear');else st.splice(st.indexOf('final'),0,'tear');}
 if(T.whisker&&a.svc==='cat')st.splice(st.indexOf('final'),0,'catface');
 return st;}
function hQ(a,k){var q=HSTEP[k].q;return typeof q==='function'?q(a):q;}
var HTIME={1:{w:.26,per:1.7},2:{w:.18,per:1.25},3:{w:.12,per:.95}};/* 綠色位闊度（0–1）、指針來回一次秒數 */
var HANDS={a:null};
function handsOwner(){return s.staff.filter(function(x){return x.role==='owner';})[0];}
function handsCan(a){var o=handsOwner();return !!(a&&o&&a.g===o.id&&(a.st==='arrived'||a.st==='doing')&&!a.handsDone&&!s.visit);}
function handsDiff(a){var d=a.svc==='cat'||a.seg==='k'?3:a.svc==='cut'?2:1;if(a.seg==='o')d=Math.min(3,d+1);if(a.seg==='l'&&d===1)d=2;return d;}
function handsSteps(a){return a.hsteps||handsBuild(a);}
function handsOpts(a,k){var S=HSTEP[k];return handsDiff(a)>=2&&S.oh?S.oh:S.o;}
/* 呢步要唔要計時：步驟標咗最低難度 tm */
function handsTimed(a,k){var S=HSTEP[k];return !!(S.tm&&handsDiff(a)>=S.tm);}
function hHash(str){var h=7;for(var i=0;i<str.length;i++)h=(h*31+str.charCodeAt(i))%1000003;return h;}
function handsOrder(a,k){var h=hHash(k+'#'+a.id),o=[0,1,2];for(var i=2;i>0;i--){var j=h%(i+1);h=Math.floor(h/3)+17;var t=o[i];o[i]=o[j];o[j]=t;}return o;}
/* 綠色位位置（0–1），固定 */
function handsZone(a,k,stress){var T=HTIME[handsDiff(a)],w=T.w*(stress>=55?.8:1),c=.25+(hHash(k+'z'+a.id)%50)/100;return [Math.max(0,c-w/2),Math.min(1,c+w/2)];}
function handsHints(a){var p=a.pid&&clPet(a.pid);return p?clConfirmed(p).map(clNoteText):[];}
function handsStart0(a){var base={s:15,c:15,m:15,l:20,k:35,o:30}[a.seg]||15;var p=a.pid&&clPet(a.pid);if(p&&clConfirmed(p).some(function(n){return /怕/.test(clNoteText(n));}))base+=10;return base;}
/* 計時結果：hit／near／miss */
function handsTimeGrade(pos,z){if(pos>=z[0]&&pos<=z[1])return 'hit';var w=z[1]-z[0];return (pos>=z[0]-w*.6&&pos<=z[1]+w*.6)?'near':'miss';}
/* 結果（唔郁 DOM，測試都用得）：ans 每步揀咗邊個（原始索引），tim 每步計時結果 */
function handsResult(a,ans,stress,tim,calm,upto){tim=tim||[];var steps=handsSteps(a),ok=0,risks=[],score=0,max=0;if(upto!=null)steps=steps.slice(0,upto);
 /* 滿意度：每步做法啱 1 分（主人要求相關步驟 2 分），計時步驟再加 1 分（準 1、差少少 0.5、失手 0）；換算 40–100，再扣出事、安撫、太緊張 */
 steps.forEach(function(k,i){var o=handsOpts(a,k)[ans[i]],w=HSTEP[k].w||1;max+=w;if(o&&o[1]){ok++;score+=w;}else if(o&&o[3])risks.push(o[3]);
  if(handsTimed(a,k)&&o&&o[1]){max++;var g=tim[i];if(g==='hit')score++;else if(g==='near')score+=.5;else if(g==='miss')risks.push(HSTEP[k].tw.risk);}else if(handsTimed(a,k))max++;});
 var sat=40+60*(max?score/max:0)-8*risks.length-(calm||0)*2;if(stress>=80){risks.push('stress');sat-=10;}sat=Math.max(0,Math.min(100,sat));
 var sev={minor:3,skin:2,stress:1},worst=null;risks.forEach(function(r){if(!worst||sev[r]>sev[worst])worst=r;});
 var stars=sat>=90?5:sat>=75?4:sat>=55?3:sat>=35?2:1;if(worst&&stars>3)stars=3;
 return {q:steps.length?ok/steps.length:0,ok:ok,n:steps.length,inc:worst,stress:stress,sat:Math.round(sat),stars:stars,hits:tim.filter(function(x){return x==='hit';}).length,timed:tim.filter(Boolean).length};}
function handsApply(a,R0,ans){var before=a.inc;a.handsDone=1;a.handsQ=R0.q;a.handsStars=R0.stars;a.handsSat=R0.sat;s.rep.hands=(s.rep.hands||0)+1;
 if(R0.inc){if(a.inc!=='serious')a.inc=R0.inc;}else if(R0.sat>=80&&(a.inc==='stress'||a.inc==='minor'||a.inc==='skin'))a.inc=null;
 var p=a.pid&&clPet(a.pid),steps=handsSteps(a);ans=ans||[];
 /* v0.19：你親手揀啱情況步驟 → 將特點寫入檔案（未確認嘅草稿就由你確認、寫錯就改正）；主人交代覆述啱就記低 */
 if(p)steps.forEach(function(k,i){var S=HSTEP[k],o=handsOpts(a,k)[ans[i]];if(!o||!o[1])return;
  if(S.obs){var n=p.notes.filter(function(x){return (x.truth||x.txt)===S.obs;})[0];if(!n)clAddNote(p,{txt:S.obs,truth:S.obs,kind:/氣喘|下巴|耳垢/.test(S.obs)?'health':'care',src:'groomer',st:'confirmed',by:'你（老闆）'});
   else if(n.st==='draft'){if(n.wrong){n.st='corrected';n.fix=n.truth;}else n.st='confirmed';n.by='你（老闆）';}}
  var rq=handsReq(a);if(rq&&rq.rec&&(k==='req'||k==='req_food'||k==='quick_bled')&&!p.notes.some(function(x){return (x.truth||x.txt)===rq.t;}))clAddNote(p,{txt:rq.t,truth:rq.t,kind:rq.kind,src:'owner',st:'owner',by:a.owner});});
 if(p&&steps.indexOf('finding')>=0){var fi=steps.indexOf('finding'),fo=handsOpts(a,'finding')[ans[fi]];if(fo&&fo[1]&&!p.notes.some(function(n){return (n.truth||n.txt)==='左耳有少少紅';}))clAddNote(p,{txt:'左耳有少少紅',truth:'左耳有少少紅',kind:'health',src:'groomer',st:'confirmed',by:'你（老闆）'});}
 news('落手做','你幫「'+a.pet+'」做'+(SVC[a.svc]?SVC[a.svc].n:'')+'（'+HDIFF[handsDiff(a)]+'）：'+R0.ok+'／'+R0.n+' 步做啱'+(R0.timed?'，計時 '+R0.hits+'／'+R0.timed+' 準':'')+'，客人滿意度 '+R0.sat+(R0.inc?'，出咗「'+({minor:'甲剪深',skin:'皮膚問題',stress:'寵物好緊張'}[R0.inc])+'」':before&&!a.inc?'，避免咗一次事故':''));
 return {before:before,after:a.inc};}
/* 加做服務：只係做得好先問；接受機會跟滿意度 */
var HADD=[{id:'teeth',n:'刷牙',p:60,m:10},{id:'tear',n:'去淚痕',p:80,m:10},{id:'spa',n:'護毛 SPA',p:120,m:15}];
function handsAddOK(sat){return sat>=80;}
function handsAddAccept(a,id,sat){return (hHash(id+'@'+a.id)%100)<Math.round(30+(sat-80)*3);}
/* ---------- 3D 工具動畫 ---------- */
var HPART={back:[-.04,.62,0],head:[.34,.78,0],paw:[.16,.1,.14],ear:[.3,.9,.16],belly:[0,.2,.2],whole:[0,.75,0]};
function hBox(g,w,h,d,x,y,z,c,o){return vb(g,w,h,d,x,y,z,c,o);}
function handsToolMesh(kind){var g=vgroup(),M=[];
 if(kind==='brush'){hBox(g,.06,.04,.3,0,.1,0,'#c0392b');for(var i=0;i<5;i++)hBox(g,.04,.06,.03,0,.05,-.12+i*.06,'#f5e6c8');}
 else if(kind==='shower'||kind==='lather'){if(kind==='shower'){hBox(g,.16,.04,.16,0,.35,0,'#cfd8dc');hBox(g,.03,.3,.03,0,.52,0,'#90a4ae');for(var d=0;d<8;d++)M.push(hBox(g,.025,.06,.025,(d%4-1.5)*.04,.25,(Math.floor(d/4)-.5)*.05,'#7ec8f0',{own:1}));}
  else for(var f=0;f<7;f++)M.push(hBox(g,.07,.07,.07,(f%4-1.5)*.08,0,(f%2-.5)*.1,'#ffffff',{own:1}));}
 else if(kind==='dry'){hBox(g,.14,.14,.22,0,0,.3,'#455a64');hBox(g,.08,.08,.16,0,0,.12,'#78909c');for(var l=0;l<5;l++)M.push(hBox(g,.012,.012,.14,(l-2)*.035,0,0,'#e3f2fd',{own:1}));}
 else if(kind==='clip'){hBox(g,.03,.03,.16,0,.04,.08,'#b0bec5');hBox(g,.03,.03,.16,0,-.02,.08,'#e53935');}
 else if(kind==='clipper'){hBox(g,.1,.08,.26,0,.06,0,'#eceff1');hBox(g,.1,.02,.04,0,.02,-.14,'#90a4ae');}
 else if(kind==='scissor'){M.push(hBox(g,.02,.02,.24,0,0,0,'#cfd8dc',{own:1}));M.push(hBox(g,.02,.02,.24,0,0,0,'#cfd8dc',{own:1}));hBox(g,.06,.03,.05,0,0,.13,'#ef6c00');}
 else if(kind==='towel'){M.push(hBox(g,.5,.04,.4,0,0,0,'#ffffff',{own:1}));}
 else if(kind==='file'){hBox(g,.04,.04,.18,0,.03,.06,'#8d6e63');}
 else if(kind==='ear'){hBox(g,.06,.12,.06,0,.06,.1,'#4fc3f7');hBox(g,.05,.05,.05,0,0,0,'#ffffff');}
 else if(kind==='photo'){hBox(g,.16,.11,.06,0,0,0,'#263238');hBox(g,.05,.05,.03,0,0,-.04,'#90a4ae');M.push(hBox(g,.3,.3,.01,0,0,-.06,'#ffffff',{own:1}));}
 else {hBox(g,.14,.07,.18,0,0,0,'#f2c9a0');for(var q=0;q<4;q++)hBox(g,.025,.03,.07,-.045+q*.03,0,-.1,'#f2c9a0');}/* 手 */
 g.userData.moving=M;g.traverse(function(m){if(m.isMesh)m.castShadow=false;});return g;}
function handsWarn(){var g=vgroup();hBox(g,.06,.18,.06,0,.12,0,'#ff5252',{own:1});hBox(g,.06,.06,.06,0,-.04,0,'#ff5252',{own:1});return g;}
function handsAnim(kind,part,ok){var A=HANDS.anim;if(A&&A.g)W3.sc.remove(A.g);if(A&&A.w)W3.sc.remove(A.w);
 var g=handsToolMesh(kind);W3.sc.add(g);var w=null;if(!ok){w=handsWarn();W3.sc.add(w);}HANDS.anim={g:g,w:w,kind:kind,part:part,ok:ok,t0:W3.t};}
function handsAnimClear(){var A=HANDS.anim;if(A){if(A.g)W3.sc.remove(A.g);if(A.w)W3.sc.remove(A.w);}if(HANDS)HANDS.anim=null;}
function handsAnimTick(pet){var A=HANDS.anim;if(!A||!pet)return;var sc=pet.userData.sc||1,P=HPART[A.part]||HPART.whole,t=W3.t-A.t0,base=new THREE.Vector3(pet.position.x+P[0]*sc,pet.position.y+P[1]*sc,pet.position.z+P[2]*sc),g=A.g,M=g.userData.moving,k=A.kind;
 g.position.copy(base);g.rotation.set(0,0,0);
 if(k==='brush'){g.position.x+=Math.sin(t*6)*.18*sc;g.rotation.y=Math.PI/2;g.position.y+=.06;}
 else if(k==='shower'){g.position.y+=.25;M.forEach(function(d,i){var ph=((t*1.6+i*.13)%1);d.position.y=.25-ph*.45;d.visible=ph<.95;});}
 else if(k==='lather'){M.forEach(function(f,i){var s1=.6+.4*Math.abs(Math.sin(t*3+i));f.scale.set(s1,s1,s1);f.position.y=.05+Math.abs(Math.sin(t*2+i))*.05;});}
 else if(k==='dry'){g.position.x+=.05;g.position.y+=.25;g.position.z+=.25;g.rotation.x=-.6;M.forEach(function(l,i){var ph=((t*2.2+i*.2)%1);l.position.z=-ph*.35;l.scale.z=.6+ph;l.visible=true;});}
 else if(k==='clip'){g.rotation.x=Math.sin(t*10)*.15;g.position.y+=.05;}
 else if(k==='clipper'){g.position.x+=Math.sin(t*3)*.2*sc;g.position.y+=.05;g.rotation.y=Math.PI/2;}
 else if(k==='scissor'){var op=Math.abs(Math.sin(t*7))*.5;M[0].rotation.y=op;M[1].rotation.y=-op;g.position.y+=.08;g.position.z+=.1;}
 else if(k==='towel'){M[0].position.y=.05;M[0].scale.y=1;g.position.y-=.15*sc;}
 else if(k==='file'){g.position.z+=Math.sin(t*12)*.03;g.position.y+=.04;}
 else if(k==='ear'){g.position.y+=.04;g.rotation.z=Math.sin(t*4)*.3;}
 else if(k==='photo'){g.position.y+=.4;g.position.z+=.5;var fl=(t%1.6)<.12;M[0].visible=fl;}
 else {g.position.y+=.14+Math.abs(Math.sin(t*4))*.04;g.position.z+=.12;g.position.x+=Math.sin(t*2)*.12;}
 if(A.w){A.w.position.set(pet.position.x+.1*sc,pet.position.y+.95*sc+Math.abs(Math.sin(t*5))*.05,pet.position.z+.15);A.w.visible=Math.sin(t*10)>-.3;}}
/* ---------- 介面 ---------- */
function handsOpen(id){var a=s.wk.appts.filter(function(x){return x.id===id;})[0];if(!handsCan(a))return;
 a.hsteps=handsBuild(a);HANDS={a:a,i:0,ans:[],tim:[],stress:handsStart0(a),picked:null,phase:'pick',cam:{tx:CT.tx,ty:CT.ty,tz:CT.tz,rad:CT.rad,th:CT.th,tilt:CT.tilt},wasPaused:s.paused,calm:0,addon:null,anim:null};
 s.paused=true;PANEL.id=null;renderPanel();s.sel=null;renderSel();
 var tb=SHOP.tables[a.tb]||SHOP.tables[0];CT.tx=tb[0];CT.tz=tb[1];CT.ty=SHOP.y+1.1;CT.rad=3.0;CT.tilt=.5;if(typeof camClamp==='function')camClamp(CT);
 document.getElementById('game').classList.add('handsmode');renderHands();renderHUD();}
function handsClose(apply){var a=HANDS.a;if(!a)return;if(apply){var R0=handsResult(a,HANDS.ans,HANDS.stress,HANDS.tim,HANDS.calm);handsApply(a,R0,HANDS.ans);}
 handsAnimClear();if(HANDS.cam){for(var ck in HANDS.cam)CT[ck]=HANDS.cam[ck];if(typeof camClamp==='function')camClamp(CT);}s.paused=HANDS.wasPaused;HANDS={a:null};handsStopTimer();
 document.getElementById('game').classList.remove('handsmode');renderHands();renderHUD();renderSel();}
function handsBump(a,m){var b=dayBusy(a.day)[a.g]||[],nx=b.filter(function(x){return x[2]!==a.id&&x[0]>=a.b;}).reduce(function(t,x){return Math.min(t,x[0]);},1e9);var add=Math.max(0,Math.min(m,nx-a.b));a.b+=add;b.forEach(function(x){if(x[2]===a.id)x[1]=a.b;});return add;}
function stressLbl(v){return v<30?'放鬆':v<55?'有啲緊張':v<80?'好緊張':'驚到掙扎';}
/* 計時：指針來回，撳「而家」或者空白鍵 */
var HT={raf:0,t0:0};
/* v0.18.1：親手做期間時間鎖死（主循環唔推時間，速度掣同快捷鍵無效）。萬一個預約已經唔喺度（換咗遊戲、被取消），自動收返個面板 */
HOOKS.init.push(function(){if(!HANDS||!HANDS.a)return;if(typeof W3!=='undefined'&&W3.sc)handsAnimClear();handsStopTimer&&handsStopTimer();HANDS={a:null};
 if(typeof document!=='undefined'){var g=document.getElementById('game');if(g)g.classList.remove('handsmode');var h=document.getElementById('hands');if(h)h.hidden=true;}});
function handsLock(){return !!(HANDS&&HANDS.a);}
function handsGone(a){return !s||!s.wk||s.wk.appts.indexOf(a)<0||(a.st!=='arrived'&&a.st!=='doing');}
function handsAbort(){var a=HANDS.a;handsClose(false);if(a&&s&&!s.bg)news('落手做',a.pet+'嘅預約已經唔喺度，收返親手做面板');}
function handsFlash(){var el=document.getElementById('hands');if(!el)return;var m=el.querySelector('.hd-lockmsg');if(!m){m=document.createElement('p');m.className='hd-lockmsg';el.insertBefore(m,el.firstChild);}
 m.textContent='親手做緊，時間停咗：做完或者撳右上角 × 收手先可以快進';clearTimeout(HT.fl);HT.fl=setTimeout(function(){if(m.parentNode)m.parentNode.removeChild(m);},2500);}
function handsCursor(){var a=HANDS.a,per=HTIME[handsDiff(a)].per,t=(performance.now()-HT.t0)/1000,x=(t/per)%2;return x<1?x:2-x;}
function handsStartTimer(){HT.t0=performance.now();handsStopTimer();(function f(){var c=document.querySelector('#hands .ht-cur');if(c&&HANDS.a&&HANDS.phase==='time'){c.style.left=(handsCursor()*100).toFixed(2)+'%';HT.raf=requestAnimationFrame(f);}})();}
function handsStopTimer(){if(HT.raf)cancelAnimationFrame(HT.raf);HT.raf=0;}
function handsPress(){var a=HANDS.a;if(!a||HANDS.phase!=='time')return;var k=handsSteps(a)[HANDS.i],pos=handsCursor(),z=handsZone(a,k,HANDS.stress),g=handsTimeGrade(pos,z);
 HANDS.tim[HANDS.i]=g;HANDS.stress=Math.max(0,Math.min(100,HANDS.stress+(g==='hit'?-3:g==='near'?6:18)));HANDS.phase='fb';HANDS.tpos=pos;handsStopTimer();if(g==='miss')handsAnim(HSTEP[k].anim,HSTEP[k].part,false);renderHands();}
/* 進行中嘅滿意度：只計做咗嘅步驟（未做嘅唔當錯） */
function handsLive(){var a=HANDS.a,n=handsSteps(a).length,upto=Math.min(n,HANDS.i+(HANDS.phase==='fb'?1:0));if(upto===0)return {sat:70,stars:4,ok:0,n:n,hits:0,timed:0};var R0=handsResult(a,HANDS.ans,HANDS.stress,HANDS.tim,HANDS.calm,upto);R0.n=n;return R0;}
function renderHands(){var el=document.getElementById('hands');if(!el)return;var a=HANDS.a;if(!a){el.hidden=true;return;}
 var steps=handsSteps(a),i=HANDS.i,done=i>=steps.length,p=a.pid&&clPet(a.pid),hints=handsHints(a),d=handsDiff(a),live=handsLive();
 var h='<div class="hd-h"><div><span class="lbl">落手做 · '+(SVC[a.svc]?SVC[a.svc].n:'')+' · <span class="hd-diff d'+d+'">'+HDIFF[d]+'</span></span><b>'+esc(a.pet)+'</b><small>'+esc(a.breed)+' · 主人 '+esc(a.owner)+'</small></div><button class="x" data-act="handsx" aria-label="唔做住">×</button></div>'+
  '<div class="hd-m"><span>毛孩：'+stressLbl(HANDS.stress)+'</span><span class="bar '+(HANDS.stress>=55?'hot':HANDS.stress>=30?'mid':'')+'"><i style="width:'+Math.min(100,HANDS.stress)+'%"></i></span><span class="num">'+Math.min(i,steps.length)+'／'+steps.length+'</span>'+
  '<span>客人滿意度</span><span class="bar sat"><i style="width:'+live.sat+'%"></i></span><span class="num">'+live.sat+'</span></div>'+
  '<div class="hd-dots">'+steps.map(function(k,j){var o=HANDS.ans[j]!=null?handsOpts(a,k)[HANDS.ans[j]]:null,tg=HANDS.tim[j];return '<i class="'+(j===i&&!done?'cur':o?(o[1]&&tg!=='miss'?'ok':'bad'):'')+(handsTimed(a,k)?' tm':'')+'" title="'+HSTEP[k].tool+'"></i>';}).join('')+'</div>';
 if(!done){var k=steps[i],S=HSTEP[k],O=handsOpts(a,k);
  h+='<div class="hd-q"><span class="tool">'+S.tool+'</span><b>'+esc(hQ(a,k))+'</b>'+(S.w>=2?'<span class="hd-tm hd-req">主人要求 · 計雙倍</span>':'')+(handsTimed(a,k)?'<span class="hd-tm">要計時</span>':'')+'</div>';
  if(k==='file'){var rq0=handsReq(a);h+='<div class="hd-hint">'+(hints.length?'檔案：'+esc(hints.slice(-3).join('；')):p&&p.cnt.done?'檔案：之前冇人寫低觀察':'檔案：第一次嚟，冇紀錄')+(rq0?'<br>主人今日交代：'+esc(rq0.t):'')+'</div>';}
  if(HANDS.phase==='pick')h+='<div class="hd-o">'+handsOrder(a,k).map(function(oi){return '<button class="btn" data-act="handspick" data-o="'+oi+'">'+esc(O[oi][0])+'</button>';}).join('')+'</div>'+
   (HANDS.stress>=40?'<button class="btn hd-calm" data-act="handscalm">安撫一陣（+5 分鐘，滿意度 −2）</button>':'');
  else if(HANDS.phase==='time'){var z=handsZone(a,k,HANDS.stress);h+='<div class="ht"><p>'+S.tw.p+'（空白鍵都得）</p><div class="ht-bar"><i class="ht-zone" style="left:'+(z[0]*100)+'%;width:'+((z[1]-z[0])*100)+'%"></i><i class="ht-cur"></i></div><button class="btn pri" data-act="handspress">而家！</button></div>';}
  else{var o=O[HANDS.picked],tg=HANDS.tim[i],bad=!o[1]||tg==='miss';
   h+='<div class="hd-fb '+(bad?'bad':tg==='near'?'mid':'ok')+'"><b>'+(!o[1]?'唔太啱':tg==='miss'?'做法啱，但時機失手':tg==='near'?'做法啱，時機差少少':tg==='hit'?'做法啱，時機準':'啱')+'</b>'+(!o[1]?'：'+esc(o[0]):'')+'<p>'+esc(S.why)+'</p></div><button class="btn pri" data-act="handsnext">'+(i+1>=steps.length?'睇結果':'下一步')+'</button>';}}
 else{var R0=live;
  h+='<div class="hd-r"><b>'+R0.ok+'／'+R0.n+' 步做啱'+(R0.timed?' · 計時 '+R0.hits+'／'+R0.timed+' 準':'')+' · 客人滿意度 '+R0.sat+'</b><p>預計主人評價：'+(typeof stars==='function'?stars(R0.stars):R0.stars+' 星')+' '+(R0.inc?'今次會出「'+({minor:'甲剪深',skin:'皮膚問題',stress:'寵物好緊張'}[R0.inc])+'」，口碑會受影響。':R0.stars>=5?'做得好，口碑會好啲。':R0.stars<=2?'主人好可能唔滿意，口碑會跌。':'冇大問題。')+'</p>';
  if(HANDS.addon)h+='<p class="hd-add">'+esc(HANDS.addon)+'</p>';
  else if(handsAddOK(R0.sat)&&!R0.inc)h+='<p>做得好，可以問主人要唔要加做：</p><div class="hd-addb">'+HADD.map(function(x){return '<button class="btn" data-act="handsadd" data-x="'+x.id+'">'+x.n+'（+'+hk(x.p)+'）</button>';}).join('')+'<button class="btn" data-act="handsadd" data-x="none">唔使問</button></div>';
  else h+='<p class="note">今次做得唔夠好，唔適合推銷加做。</p>';
  h+='</div><button class="btn pri" data-act="handsdone">完成，交返主人</button>';}
 el.innerHTML=h;el.hidden=false;if(HANDS.phase==='time')handsStartTimer();}
if(typeof document!=='undefined'){
 (function(){var _rh=renderHUD;renderHUD=function(){if(HANDS.a&&handsGone(HANDS.a)){handsAbort();return;}_rh.apply(this,arguments);var g=document.getElementById('game');if(!g||!document.getElementById('hudTL'))return;
  if(!document.getElementById('hands')){var d=document.createElement('div');d.id='hands';d.className='hands';d.hidden=true;g.appendChild(d);var c=document.createElement('button');c.id='handsCue';c.className='handscue';c.hidden=true;c.setAttribute('data-act','handscue');g.appendChild(c);}
  var cue=document.getElementById('handsCue'),a=!HANDS.a&&s&&!s.bg&&!s.demo&&todayAppts().filter(function(x){return handsCan(x)&&x.st==='doing';})[0];
  var sp=document.querySelector('#hudTL .spd');if(sp)sp.classList.toggle('hlock',!!HANDS.a);var sk=document.querySelector('#hudTL .skipline');if(sk&&HANDS.a)sk.hidden=true;
  if(HANDS.a&&sp&&!document.querySelector('#hudTL .hlockt')){var lt=document.createElement('span');lt.className='hlockt';lt.textContent='親手做緊 · 時間暫停';sp.parentNode.insertBefore(lt,sp.nextSibling);}
  if(a){var t='落手做：'+a.pet+'（'+(SVC[a.svc]?SVC[a.svc].n:'')+' · '+HDIFF[handsDiff(a)]+'）';if(cue.textContent!==t)cue.textContent=t;cue.setAttribute('data-id',a.id);cue.hidden=false;}else cue.hidden=true;};})();
 document.addEventListener('keydown',function(e){if(!HANDS.a||HANDS.vn)return;if(HANDS.phase==='time'&&e.key===' '){e.preventDefault();e.stopImmediatePropagation();handsPress();return;}
  /* v0.18.1：親手做緊唔准快進／暫停切換（之前快進會令客人做完走咗，但面板仲喺度） */
  if(/^[0-9 ]$/.test(e.key)&&!/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)){e.preventDefault();e.stopImmediatePropagation();handsFlash();}},true);
 document.addEventListener('click',function(e){if(!HANDS.a)return;var el=e.target.closest('[data-act]');if(!el)return;var act=el.getAttribute('data-act');
  if(act==='spd'||act==='skipnow'||act==='skipstop'){e.preventDefault();e.stopImmediatePropagation();handsFlash();}},true);
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var act=el.getAttribute('data-act');
  if(act==='handscue'||act==='handsgo'){handsOpen(+el.getAttribute('data-id'));return;}
  if(!HANDS.a)return;var a=HANDS.a,steps=handsSteps(a),k=steps[HANDS.i];
  if(act==='handspick'&&HANDS.phase==='pick'){var oi=+el.getAttribute('data-o'),o=handsOpts(a,k)[oi];HANDS.picked=oi;HANDS.ans[HANDS.i]=oi;HANDS.stress=Math.max(0,Math.min(100,HANDS.stress+(o[1]?-4:(o[2]||0))));
   handsAnim(HSTEP[k].anim,HSTEP[k].part,!!o[1]);HANDS.phase=o[1]&&handsTimed(a,k)?'time':'fb';renderHands();}
  if(act==='handspress')handsPress();
  if(act==='handsnext'){HANDS.i++;HANDS.picked=null;HANDS.phase='pick';handsAnimClear();renderHands();}
  if(act==='handscalm'){HANDS.stress=Math.max(0,HANDS.stress-20);HANDS.calm++;handsBump(a,5);handsAnim('pat','head',true);renderHands();}
  if(act==='handsadd'){var x=el.getAttribute('data-x'),R0=handsLive();if(x==='none'){HANDS.addon='冇問主人加做。';}else{var X=HADD.filter(function(y){return y.id===x;})[0];
    if(handsAddAccept(a,x,R0.sat)){var add=handsBump(a,X.m);if(add>=X.m){a.price+=X.p;HANDS.addon='主人同意加做'+X.n+'（+'+hk(X.p)+'）。';news('加做','WhatsApp 問咗'+a.owner+'，佢同意加做'+X.n+'（+'+hk(X.p)+'）');}else HANDS.addon='主人想加做'+X.n+'，但下一個預約就嚟，冇時間做。';}
    else HANDS.addon='主人話今次唔使加做'+X.n+'。';}renderHands();}
  if(act==='handsdone'){handsClose(true);}
  if(act==='handsx'){handsClose(false);}});
 var _rs=renderSel;renderSel=function(){_rs.apply(this,arguments);var el=document.getElementById('selCard');if(!el||el.hidden||!s||!s.sel||(s.sel.type!=='pet'&&s.sel.type!=='owner'))return;var a=s.wk.appts.filter(function(x){return x.id===s.sel.id;})[0];
  if(handsCan(a)&&!el.querySelector('[data-act=handsgo]')){var b=document.createElement('button');b.className='btn pri';b.setAttribute('data-act','handsgo');b.setAttribute('data-id',a.id);b.textContent='落手做（你負責 · '+HDIFF[handsDiff(a)]+'）';el.appendChild(b);}};
 var _ss=syncShop;syncShop=function(dt){_ss.apply(this,arguments);var a=HANDS.a;if(!a)return;if(handsGone(a)){handsAbort();return;}var me=W3.actors['s'+a.g];if(me)me.visible=false;
  /* v0.21.6：客人仲行緊入嚟（毛孩跟住主人、未擺入店）都要喺枱上出現；路上嗰隻收埋，唔好有兩隻 */
  var pet=W3.actors['p'+a.id]||actor('p'+a.id,function(){var m=makePet(a.seg,a.id);m.userData.pick={type:'pet',id:a.id};return m;});var qd=W3.actors['q'+a.id];if(qd)qd.visible=false;pet.userData.alive=W3.frame;
  /* v0.21.2：落手做期間毛孩一定喺美容枱上（之前有助手嘅店，前段時間會喺浴缸，枱上就冇嘢） */
  var tb=SHOP.tables[a.tb]||SHOP.tables[0];pet.position.copy(SP(tb[0],tb[1],SHOP.y+1.06));pet.rotation.y=0;pet.visible=true;
  var k=HANDS.stress/100,shake=HANDS.anim&&!HANDS.anim.ok&&(W3.t-HANDS.anim.t0)<1.2?.25:0;pet.rotation.z=Math.sin(W3.t*(8+k*20))*(.12*k+shake);pet.position.y+=Math.abs(Math.sin(W3.t*6))*(.05*k+shake*.2);handsAnimTick(pet);};}
