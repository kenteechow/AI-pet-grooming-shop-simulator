/* p_guide：第一週目標（v0.13）。新局先有（舊存檔、示範模式、初始界面背景唔顯示）。
   五步：睇排程 → 升級一個 AI 崗位 → 撳一隻寵物睇資料 → 睇客人紀錄 → 過咗第一個星期日睇財務。
   完成會自動剔；可以收埋或者略過。 */
var GUIDE=[
 {id:'sched',t:'打開「排程」睇本週預約',go:'sched',ok:function(){return PANEL.id==='sched';}},
 {id:'ai',t:'喺「AI 部署」升級一個崗位（有啲 L1 免費）',go:'ai',ok:function(){return ROLES.some(function(r){return s.lv[r.id]>0;});}},
 {id:'sel',t:'撳一隻寵物或者主人，睇佢嘅資料同紀錄',ok:function(){return !!(s.sel&&(s.sel.type==='pet'||s.sel.type==='owner'));}},
 {id:'rec',t:'打開「客人 → 客人紀錄」',go:'rec',ok:function(){return PANEL.id==='cust'&&PANEL.sub==='rec';}},
 {id:'fin',t:'過咗第一個星期日，睇「財務 → 今個月」',go:'fin',ok:function(){return s.day>=7&&PANEL.id==='fin';},wait:function(){return s.day<7;}}];
HOOKS.init.push(function(){s.gd={done:{},min:typeof window!=='undefined'&&window.innerWidth<860?1:0};});
function guideOn(){return !!(s&&s.gd&&!s.gd.off&&!s.bg&&!s.demo&&!s.visit);}
function guideTick(){if(!guideOn())return false;var ch=false;GUIDE.forEach(function(g){if(!s.gd.done[g.id]&&g.ok()){s.gd.done[g.id]=1;ch=true;}});return ch;}
function renderGuide(){var el=document.getElementById('guide');if(!el)return;if(!guideOn()){el.hidden=true;return;}
 var n=GUIDE.filter(function(g){return s.gd.done[g.id];}).length,all=n===GUIDE.length,next=GUIDE.filter(function(g){return !s.gd.done[g.id];})[0];
 var key=n+'|'+s.gd.min+'|'+(next&&next.wait&&next.wait()?1:0);if(el.dataset.k===key&&!el.hidden)return;el.dataset.k=key;
 var h='<div class="gd-h"><b>'+(all?'第一週目標完成':'第一週目標')+'</b><span class="num">'+n+'/'+GUIDE.length+'</span><button class="gd-x" data-act="gdmin" aria-label="'+(s.gd.min?'展開':'收埋')+'">'+(s.gd.min?'展開':'收埋')+'</button></div>';
 if(!s.gd.min){h+=all?'<p>你已經睇過排程、AI、客人紀錄同財務。之後每個月 1 號會有月結。</p><button class="btn" data-act="gdoff">收起</button>':
  '<ol>'+GUIDE.map(function(g){var d=s.gd.done[g.id],cur=g===next,w=g.wait&&g.wait();return '<li class="'+(d?'done':cur?'cur':'')+'"><span class="gd-c"></span><span>'+g.t+(cur&&w?'<small>而家星期'+WKD[s.day%7]+'，等到下星期一</small>':'')+'</span>'+(cur&&g.go&&!w?'<button class="btn pri" data-act="gdgo" data-g="'+g.go+'">去</button>':'')+'</li>';}).join('')+'</ol><button class="gd-skip" data-act="gdoff">略過</button>';}
 el.innerHTML=h;el.hidden=false;el.classList.toggle('min',!!s.gd.min);}
(function(){if(typeof document==='undefined')return;
 var _rh=renderHUD;renderHUD=function(){_rh.apply(this,arguments);guideTick();ensureGuide();renderGuide();};
 function ensureGuide(){if(document.getElementById('guide'))return;var g=document.getElementById('game');if(!g||!document.getElementById('hudTL'))return;var d=document.createElement('div');d.id='guide';d.className='guide';d.hidden=true;d.setAttribute('role','region');d.setAttribute('aria-label','第一週目標');g.appendChild(d);}
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s||!s.gd)return;var a=el.getAttribute('data-act');
  if(a==='gdmin'){s.gd.min=s.gd.min?0:1;renderGuide();}
  if(a==='gdoff'){s.gd.off=1;renderGuide();}
  if(a==='gdgo'){var g=el.getAttribute('data-g');if(g==='rec'){openPanel('cust');PANEL.sub='rec';renderPanel();}else openPanel(g);setTimeout(function(){guideTick();renderGuide();},0);}});
 document.addEventListener('click',function(){if(s&&s.gd&&guideTick())renderGuide();});})();
