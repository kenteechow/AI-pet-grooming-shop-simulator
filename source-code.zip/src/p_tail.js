/* p_tail：點擊分派、輸入、啟動。 */
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el)return;var a=el.getAttribute('data-act');
 if(a==='sandbox'){showSandbox();return;}
 if(a==='home'){showTitle();return;}
 if(a==='tab'){UI.tab=el.getAttribute('data-t');try{localStorage.setItem('pg_tab',UI.tab);}catch(err){}renderMain();var m=$('#sbMain');m.scrollTop=0;return;}
 if(a==='lv'){UI.P.lv[el.getAttribute('data-role')]=+el.getAttribute('data-lv');$('#sbSide').innerHTML=sideHTML();$('#sbSide').classList.toggle('shut',UI.shut);changed();return;}
 if(a==='model'){UI.F.model=el.getAttribute('data-m');$('#sbTop').innerHTML=topHTML();$('#sbSide').innerHTML=sideHTML();$('#sbSide').classList.toggle('shut',UI.shut);changed();return;}
 if(a==='reset'){resetParams();invalidate();UI.mc=null;recompute();renderAll();return;}
 if(a==='side'){UI.shut=!UI.shut;$('#sbSide').classList.toggle('shut',UI.shut);el.textContent=UI.shut?'顯示參數':'收起參數';return;}
 if(a==='sensT'){UI.sensT=el.getAttribute('data-t');renderMain();return;}
 if(a==='mcRun'&&!UI.mcBusy){UI.mcBusy=true;UI.mcProg=0;renderMain();
  mcRun(clone(UI.P),clone(UI.F),UI.mcN,function(res){UI.mc=res;UI.mcBusy=false;UI.mcStale=false;if(UI.tab==='mc')renderMain();},
   function(p){UI.mcProg=p;var bar=document.querySelector('.prog i');if(bar)bar.style.width=Math.round(p*100)+'%';});return;}
});
document.addEventListener('change',function(e){
 var el=e.target;
 if(el.id==='scen'){UI.scen=el.value;resetParams();invalidate();UI.mc=null;recompute();renderAll();return;}
 if(el.id==='mcN'){UI.mcN=+el.value;return;}
 if(el.matches('input[type=checkbox][data-k]')){var r=pget(el.getAttribute('data-k'));r[0][r[1]]=el.checked?1:0;changed();}
});
document.addEventListener('input',function(e){
 var el=e.target;if(!el.matches('input[type=range][data-k]'))return;
 var k=el.getAttribute('data-k'),v=+el.value,r=pget(k);
 r[0][r[1]]=el.getAttribute('data-inv')?1/v:v;
 var it=null;PG.forEach(function(G){(G.items||[]).forEach(function(x){if(x.k===k)it=x;});});
 var o=document.getElementById('o-'+el.id);if(o&&it)o.textContent=pshow(it,v);
 changed();
});
var rsz=0;window.addEventListener('resize',function(){clearTimeout(rsz);rsz=setTimeout(function(){if(!$('#sb').hidden)drawCharts($('#sbMain'));},150);});
(function boot(){
 try{var t=localStorage.getItem('pg_tab');if(t&&TABS.some(function(x){return x[0]===t;}))UI.tab=t;}catch(err){}
 showTitle();
})();
