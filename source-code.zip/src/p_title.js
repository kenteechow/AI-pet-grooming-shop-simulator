/* p_title：初始界面。背景係一間真係運行緊嘅全 AI 美容店（鏡頭慢慢轉），左邊一張深色圓角卡：繼續、新遊戲、全 AI 示範店、示範模式、沙盒、玩法說明、選項。 */
var OPTS={speed:1,shadow:1,labels:1,edge:1,fixed:0,seed:2027,skip:1};
try{var _o=JSON.parse(localStorage.getItem('petgroom_opts')||'null');if(_o)for(var _k in _o)OPTS[_k]=_o[_k];}catch(e){}
function optsSave(){try{localStorage.setItem('petgroom_opts',JSON.stringify(OPTS));}catch(e){}}
var TV='main';
function ensureShell(){
 if(W3.tried)return;W3.tried=1;$('#game').innerHTML=hudHTML();init3D($('#view'));
 var pn=$('#panel');pn.addEventListener('mouseenter',function(){PANEL.hover=1;});pn.addEventListener('mouseleave',function(){PANEL.hover=0;});
 /* 手機冇 mouseenter：手指撳落面板之後 2.5 秒內唔好重畫，免得撳緊嘅掣被換走 */
 pn.addEventListener('pointerdown',function(){PANEL.tap=performance.now();},true);
}
function clearActors(){if(!W3.on)return;Object.keys(W3.actors).forEach(function(k){W3.sc.remove(W3.actors[k]);});W3.actors={};W3.pick=[];}
function startBg(){
 newGame('allai');s.bg=1;s.speed=3;s.paused=false;s.labels=1;s.modal=null;s.evQ=[];
 var n=0;while(s.t<660&&n++<500)advance(5);
 if(W3.on){camJump({tx:-7,ty:3.2,tz:-4,rad:30,th:.55,ph:.78});if(W3.sun)W3.sun.castShadow=!!OPTS.shadow;}
}
function showTitle(){
 if(GAME.on&&s&&!s.bg)save();
 $('#sb').hidden=true;$('#openings').hidden=true;$('#game').hidden=false;
 ensureShell();clearActors();PANEL.id=null;startBg();
 $('#game').classList.add('titlemode');renderPanel();renderModal();renderSel();if(window.renderDemo)renderDemo();
 TV='main';renderTitle();$('#title').hidden=false;
 startLoop();
}
function showOpenings(){TV='new';renderTitle();}
function showSandbox(){GAME.on=false;$('#title').hidden=true;$('#game').hidden=true;$('#sb').hidden=false;if(!UI.P)resetParams();recompute();renderAll();}
function saveInfo(){try{var t=localStorage.getItem(SAVE_KEY);if(!t)return null;var o=JSON.parse(t);if(o.v!==3)return null;return o.openName+' · '+dateStr(o.day)+' · 現金 '+hk(o.cash);}catch(e){return null;}}
function tItem(act,title,sub,cls,extra){return '<button class="titem'+(cls?' '+cls:'')+'" data-act="'+act+'"'+(extra||'')+'><b>'+title+'</b><span>'+sub+'</span></button>';}
function renderTitle(){
 var el=$('#title'),h='<div class="tp-head"><span class="seal tbig">毛</span><div><h1>AI 重構寵物美容</h1><p>香港寵物美容店經營模擬</p></div></div>';
 if(TV==='main'){var si=saveInfo();
  h+='<p class="tp-lede">你係觀塘一間樓上舖美容店嘅老闆，自己都要剪狗。由收工後嘅 WhatsApp、no-show、新年爆滿到美容師被咬，睇吓用 AI 重構之後，可以慳幾多時間、多賺幾多，同埋邊度一定要人把關。</p><div class="tlist">'+
   (si?tItem('cont','繼續遊戲',esc(si),'hot'):'')+
   tItem('openings','新遊戲','揀一個開局：社區美容店、一人工作室、人手過多嘅老店',si?'':'hot')+
   tItem('start','直接睇：全 AI 示範店','開局 6 個崗位全部 L3，同隔籬唔用 AI 嘅店並排比較','',' data-id="allai"')+
   tItem('demostart','示範模式（約 10 分鐘）','一步步睇 AI 點幫一間社區美容店：收工後查詢、部署 AI、新年爆滿、毛孩服務故事、人工審核同營運比較')+
   tItem('sandbox','沙盒模擬器','唔玩遊戲，直接試數：12 個月現金、敏感度、蒙地卡羅、四種商業模式')+
   tItem('tview','玩法說明','時間、人手、AI 等級、事件、鏡頭','',' data-v="help"')+
   tItem('tview','選項','預設速度、陰影、標籤、音效、音樂','',' data-v="opts"')+
   '</div><p class="tp-foot">遊戲內數字係示範估算，唔係行業標準。背景嗰間店可以用滑鼠拖曳旋轉。<span id="ver">'+VERSION+'</span></p>';}
 else if(TV==='new'){
  h+='<button class="tback" data-act="tview" data-v="main">‹ 返回</button><h2 class="tp-h2">揀開局</h2><div class="tlist">'+
   OPENINGS.map(function(o){return '<button class="titem'+(o.id==='community'?' hot':'')+'" '+(o.ok?'data-act="start" data-id="'+o.id+'"':'disabled')+'><b>'+o.name+'<i class="tdiff d-'+(o.diff==='難'?'h':o.diff==='示範'?'x':o.diff==='中'?'m':'e')+'">'+o.diff+'</i></b><span>'+o.desc+'</span></button>';}).join('')+'</div>';}
 else if(TV==='help'){
  h+='<button class="tback" data-act="tview" data-v="main">‹ 返回</button><h2 class="tp-h2">玩法說明</h2><div class="thelp">'+
   [['時間','1× 一日約 120 秒。白天逐分鐘顯示，高倍速實際速度受畫面更新速度限制。空白鍵暫停，1–4 轉 1×／3×／10×／30×。現金每日午夜先更新，每月 1 號月結。'],
    ['預約同排程','每星期一按客源排一週預約。灰色「行政」係老闆覆 WhatsApp、排程、對數嘅時間。可以拖預約調位、互換，撳空格由候補名單加人。'],
    ['人手','美容師時數係硬上限。請人要等到下星期一，入職 3 週先知佢真正特點；士氣低會遞信，走嗰陣會帶走熟客。'],
    ['AI 等級','每個崗位 L1／L2／L3：有建置費、月費、部署週數，之後 4 週磨合。關咗人工審核會慳時間，但會報錯價、答應咗冇位嘅時段。'],
    ['事件','新年爆滿、八號風球、美容師被咬、剪錯造型、對手減價……每個選擇都寫明優點、缺點，同埋「如果有 AI 會點」。'],
    ['隔籬','同一條街有間唔用 AI、做唔切就請人嘅店。設定入面可以「參觀隔籬」並排比較。'],
    ['創辦人層','自己間店連續 3 個月 no-show 低過 7%，同行會嚟問你點做，可以開副業賣 AI。但副業時數會食你剪狗時間。'],
    ['鏡頭','左鍵拖曳移動、右鍵拖曳旋轉、滾輪縮放、雙擊飛過去；WASD、Q／E、R／F；滑鼠去到畫面邊緣會推鏡。']].map(function(x){return '<div><b>'+x[0]+'</b><p>'+x[1]+'</p></div>';}).join('')+'</div>';}
 else if(TV==='opts'){
  function tg(k,lbl,on){return '<button class="topt'+(on?' on':'')+'" data-act="opt" data-k="'+k+'"><span>'+lbl+'</span><i>'+(on?'開':'關')+'</i></button>';}
  h+='<button class="tback" data-act="tview" data-v="main">‹ 返回</button><h2 class="tp-h2">選項</h2><div class="topts">'+
   '<div class="trow"><span>開局速度</span><div class="tseg">'+[1,3,10].map(function(v){return '<button class="'+(OPTS.speed===v?'on':'')+'" data-act="optspd" data-v="'+v+'">'+v+'×</button>';}).join('')+'</div></div>'+
   tg('shadow','陰影（舊電腦可以關）',OPTS.shadow)+tg('labels','名字同狀態標籤',OPTS.labels)+tg('edge','滑鼠去畫面邊緣推鏡',OPTS.edge)+tg('skip','自動跳過非營業時間（收工後到朝早 9:30）',OPTS.skip)+tg('fixed','固定隨機（拍片用：同一個玩法每次結果一樣）',OPTS.fixed)+(OPTS.fixed?'<label class="trow"><span>種子編號</span><input type="number" min="1" max="99999" value="'+OPTS.seed+'" data-act="seed" class="tseed"></label>':'')+tg('sound','按鍵同關閉音效',SND.on)+tg('music','背景音樂',SND.music)+
   '<label class="trow"><span>音效音量</span><input type="range" min="0" max="1" step=".05" value="'+SND.vol+'" data-act="vol" data-k="sfx"></label>'+
   '<label class="trow"><span>音樂音量</span><input type="range" min="0" max="1" step=".05" value="'+SND.mvol+'" data-act="vol" data-k="mus"></label>'+
   '<p class="tp-foot">顯示卡：'+esc(W3.gpu||'—')+'</p></div>';}
 el.innerHTML=h;
}
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el)return;var a=el.getAttribute('data-act');
 if(a==='tview'){TV=el.getAttribute('data-v');renderTitle();return;}
 if(a==='optspd'){OPTS.speed=+el.getAttribute('data-v');optsSave();renderTitle();return;}
 if(a==='opt'){var k=el.getAttribute('data-k');
  if(k==='sound'){SND.on=SND.on?0:1;sndSave();}else if(k==='music'){musicSet(!SND.music);}else{OPTS[k]=OPTS[k]?0:1;optsSave();if(k==='shadow'&&W3.sun)W3.sun.castShadow=!!OPTS.shadow;if(k==='edge')EDGE.on=OPTS.edge;}
  renderTitle();return;}
});

document.addEventListener('change',function(e){if(e.target.matches('[data-act=seed]')){var v=Math.max(1,Math.min(99999,Math.round(+e.target.value)||1));OPTS.seed=v;optsSave();}});
