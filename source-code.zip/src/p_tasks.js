/* p_tasks：事件寫明「老闆用 X 小時」嘅行動，變成排程入面真係佔用嘅時段（v0.12）。
   - 揀咗之後，喺本週老闆嘅空檔（最少 30 分鐘一段）由近至遠排；唔會同預約、午飯、行政重疊，喺排程表顯示。
   - 本週空檔唔夠：彈出選擇——收工後做（犧牲休息，士氣跌）、延到下星期、取消行動（冇效果）。
   - 只有做完先有效果；成本（士氣）喺真係做嘅時候先扣，唔會重複扣。
   - 存檔只存資料（kind），效果寫喺 TASK_FX，讀檔後照樣運作。 */
var TASK_FX={
 dormantCall:{lbl:'打電話',n:'逐個打電話問沉睡客原因',
  done:function(T){var n=Math.min(4,s.S.dorm[0]);s.S.dorm[0]-=n;addAct(s.S,n);news('客人','打完 '+(T.need/60).toFixed(0)+' 小時電話：救返 '+Math.round(n)+' 位沉睡客；其他人有講原因（搬屋、轉店、隻狗老咗），亦有人唔想講');},
  cancel:function(){news('客人','取消打電話，沉睡客照舊')}},
 modelTest:{lbl:'測試 AI',n:'重新測試更新咗嘅 AI 模型',
  done:function(){news('AI','測試完成：新模型嘅報價同語氣已經核對，錯誤率維持');},
  cancel:function(){addMod('replyErrMult','mul',2,2,false,'模型更新未測試');news('AI','冇做測試，新模型直接上線，兩星期內出錯機會加倍');}}};
function ownerSt(){return s.staff.filter(function(x){return x.role==='owner';})[0]||s.staff[0];}
/* 某日某人由 from 開始嘅空檔 [[a,b],...] */
function freeGaps(day,gid,from){var b=(dayBusy(day)[gid]||[]).slice().sort(function(x,y){return x[0]-y[0];}),out=[],t=Math.max(OPEN_MIN,from);
 b.forEach(function(x){if(x[2]!=null&&typeof x[2]!=='string'){var a=apptById(x[2]);if(a&&((a.st==='cancel'&&!a.refill)||a.st==='noshow'||a.st==='lost'))return;}if(x[0]>t)out.push([t,Math.min(x[0],CLOSE_MIN)]);t=Math.max(t,x[1]);});
 if(t<CLOSE_MIN)out.push([t,CLOSE_MIN]);return out.filter(function(g){return g[1]-g[0]>=30;});}
function taskFit(T){var o=ownerSt(),lbl=TASK_FX[T.kind].lbl;
 for(var d=s.day;d<s.wk.start+7&&T.unplanned>0;d++){if(!staffWorks(o,d))continue;
  var from=d===s.day?Math.ceil((s.t+15)/5)*5:OPEN_MIN;
  freeGaps(d,o.id,from).forEach(function(g){if(T.unplanned<=0)return;var use=Math.min(T.unplanned,Math.floor((g[1]-g[0])/5)*5);if(use<30&&use<T.unplanned)return;
   T.blocks.push({day:d,a:g[0],b:g[0]+use,done:0});dayBusy(d)[o.id].push([g[0],g[0]+use,lbl]);T.unplanned-=use;});}
}
function taskDesc(T){return T.blocks.filter(function(b){return !b.done;}).map(function(b){return '星期'+WKD[b.day%7]+' '+hm(b.a)+'–'+hm(b.b)+(b.after?'（收工後）':'');}).join('、');}
function planTask(kind,need){
 s.tasks=s.tasks||[];var T={id:'t'+(s.nextId++),kind:kind,need:need,left:need,unplanned:need,blocks:[],st:'planned',made:s.day};
 s.tasks.push(T);taskFit(T);
 if(T.unplanned>0){T.st='short';queueEvent('taskShort',{tid:T.id});}
 news('排程','安排咗「'+TASK_FX[kind].n+'」共 '+(need/60).toFixed(1)+' 小時：'+(taskDesc(T)||'本週冇空檔'));
 return T;}
function taskById(id){return (s.tasks||[]).filter(function(x){return x.id===id;})[0];}
/* 每次推進時間：完成咗嘅時段計入，做齊先生效 */
function taskTick(t){if(!s.tasks||!s.tasks.length)return;
 s.tasks.forEach(function(T){if(T.st!=='planned'&&T.st!=='short')return;
  T.blocks.forEach(function(b){if(b.done||b.day!==s.day||t<b.b)return;b.done=1;T.left-=b.b-b.a;if(b.after){ownerSt().morale=Math.max(.1,ownerSt().morale-.02*(b.b-b.a)/60);}});
  if(T.left<=0&&T.unplanned<=0){T.st='done';T.doneDay=s.day;TASK_FX[T.kind].done(T);}});}
function taskMinWeek(){var w=s.wk,m=0;(s.tasks||[]).forEach(function(T){T.blocks.forEach(function(b){if(b.day>=w.start&&b.day<w.start+7&&!b.after)m+=b.b-b.a;});});return m;}
/* 下星期一：「延到下星期」嘅任務再排 */
HOOKS.plan=HOOKS.plan||[];HOOKS.plan.push(function(){(s.tasks||[]).forEach(function(T){if(T.st==='later'){T.st='planned';taskFit(T);if(T.unplanned>0){T.st='short';queueEvent('taskShort',{tid:T.id});}news('排程','「'+TASK_FX[T.kind].n+'」排咗：'+(taskDesc(T)||'仲係冇空檔'));}});
 if(s.tasks&&s.tasks.length>40)s.tasks=s.tasks.filter(function(T){return T.st==='planned'||T.st==='short'||T.st==='later'||s.day-(T.doneDay||T.made)<60;});});
/* 空檔唔夠嘅選擇 */
EVENTS.taskShort={title:'本週冇足夠空檔',body:function(c){var T=taskById(c.tid);if(!T)return '';return '「'+TASK_FX[T.kind].n+'」要 '+(T.need/60).toFixed(1)+' 小時，本週老闆嘅空檔只排到 '+((T.need-T.unplanned)/60).toFixed(1)+' 小時'+(T.blocks.length?'（'+taskDesc(T)+'）':'')+'，仲差 '+(T.unplanned/60).toFixed(1)+' 小時。';},
 ai:'AI 唔會變出時間：排程滿就係滿。可以揀犧牲休息、延遲，或者唔做。',
 ch:[{t:'收工後做（犧牲休息）',pro:['今個星期做完'],con:['老闆士氣每小時 −2%'],f:function(c){var T=taskById(c.tid);if(!T)return;var o=ownerSt(),d=s.day;if(s.t>=CLOSE_MIN||!staffWorks(o,d)){d++;while(!staffWorks(o,d)&&d<s.day+7)d++;}
   T.blocks.push({day:d,a:CLOSE_MIN,b:CLOSE_MIN+T.unplanned,done:0,after:1});T.unplanned=0;T.st='planned';news('排程','「'+TASK_FX[T.kind].n+'」餘下部分收工後做：'+taskDesc(T));}},
     {t:'延到下星期',pro:['唔使犧牲休息'],con:['效果遲一星期先有'],f:function(c){var T=taskById(c.tid);if(!T)return;T.st='later';news('排程','「'+TASK_FX[T.kind].n+'」餘下 '+(T.unplanned/60).toFixed(1)+' 小時延到下星期');}},
     {t:'取消行動',pro:['唔使時間'],con:['冇效果；已經做咗嘅時間唔會退返'],f:function(c){var T=taskById(c.tid);if(!T)return;T.st='cancel';var o=ownerSt();T.blocks.forEach(function(b){if(b.done)return;var bb=dayBusy(b.day)[o.id]||[];for(var i=bb.length-1;i>=0;i--)if(bb[i][0]===b.a&&bb[i][1]===b.b&&typeof bb[i][2]==='string'&&bb[i][2]===TASK_FX[T.kind].lbl)bb.splice(i,1);});T.blocks=T.blocks.filter(function(b){return b.done;});TASK_FX[T.kind].cancel(T);}}]};
/* 兩個有明確時間成本嘅事件改用真排程 */
(function(){var d=EVENTS.dormant.ch[0];d.con=['老闆用 3 小時（排入本週空檔，做完先有效果）'];d.f=function(){planTask('dormantCall',180);};
 var m=EVENTS.model.ch[0];m.con=['老闆用 3 小時（排入本週空檔）'];m.f=function(){planTask('modelTest',180);};})();
/* ---------- v0.13 市場壓力：連鎖店開張（第 16 週，老店除外） ----------
   兩間店（你同隔籬）一齊受影響：查詢少一成、價錢敏感客流失加快，持續半年。示範估算，唔係實際市場數據。
   冇一個選擇係「用 AI 就一定贏」：減價蝕毛利；加強服務要老闆 4 小時；唔理就慢慢流失。 */
TASK_FX.serviceRevamp={lbl:'改流程',n:'重新整理服務流程（到店前確認、完成後報告）',
 done:function(){addMod('ret90','add',.02,26,false,'服務流程改善');news('客人','服務流程改好咗：熟客回頭率半年內 +2 個百分點（示範估算）');},
 cancel:function(){news('客人','冇改服務流程')}};
EVENTS.chain={title:'連鎖寵物店開張',body:function(){return '區內新開一間連鎖寵物店，有美容服務，開張價平兩成，仲有會員積分。附近幾間美容店（包括隔籬）都話查詢少咗。';},
 when:function(){return s.open!=='old';},
 ai:'AI 前台快啲覆、報告卡做得好，可以留住部分客；但連鎖店嘅價錢同會員制度，AI 改變唔到。效果要睇你點做，唔係有 AI 就贏。',
 ch:[{t:'跟減 8%',pro:['價錢敏感客流失少啲'],con:['每隻少收，半年毛利跌'],f:function(){addMod('inqMult','mul',.9,26,true,'連鎖店開張');addMod('compGap','set',.12,26,true,'連鎖店開張');addMod('compGap','set',.06,26,false,'連鎖店（有跟減）');addMod('priceIdx','mul',.92,26,false,'跟連鎖店減價');}},
     {t:'唔減價，加強服務（老闆用 4 小時改流程）',pro:['做完之後熟客回頭率升'],con:['要排老闆時間','做完先有效果；價錢敏感客照走'],f:function(){addMod('inqMult','mul',.9,26,true,'連鎖店開張');addMod('compGap','set',.12,26,true,'連鎖店開張');planTask('serviceRevamp',240);}},
     {t:'唔理',pro:['唔使用時間同錢'],con:['價錢敏感客流失加快'],f:function(){addMod('inqMult','mul',.9,26,true,'連鎖店開張');addMod('compGap','set',.12,26,true,'連鎖店開張');}}]};
HOOKS.day.push(function(){if(s.day===105&&!s.evSeen.chain&&!s.demoFF&&EVENTS.chain.when())queueEvent('chain');});
