/* p_street：觀塘街景。唐樓、商廈、屋邨感嘅高樓、招牌、雙黃線、斑馬線、紅綠燈、巴士站、港鐵出口、街燈、車同行人。左上落車。 */
var FAC={};
function facadeTex(style){
 FAC[style]=FAC[style]||[];if(FAC[style].length<3){var cc=facadeCanvas(style),tt=new THREE.CanvasTexture(cc[0]),tl=new THREE.CanvasTexture(cc[1]);tt.wrapS=tt.wrapT=tl.wrapS=tl.wrapT=THREE.RepeatWrapping;tt.anisotropy=4;FAC[style].push([tt,tl]);}
 return FAC[style][Math.floor(Math.random()*FAC[style].length)];
}
W3.winMats=[];
/* 天台：純灰色（每棟一個，因為半透明會逐棟設定） */
function roofMat(){return new THREE.MeshLambertMaterial({color:'#8e9194'});}
function building(sc,x,z,w,d,floors,style,opt){
 opt=opt||{};var h=floors*3,g=vgroup(sc,x,0,z),tx=facadeTex(style);
 var t=tx[0].clone(),tl=tx[1].clone();t.needsUpdate=tl.needsUpdate=true;t.repeat.set(w/6,(floors-1)/2);tl.repeat.set(w/6,(floors-1)/2);
 var m=new THREE.MeshLambertMaterial({map:t,emissive:new THREE.Color('#ffffff'),emissiveMap:tl,emissiveIntensity:0});W3.winMats.push(m);
 /* 天台同底面用純灰色（v0.16），外牆貼圖只貼四邊；BoxGeometry 面次序：+x −x +y（天台）−y +z −z */
 var rm=roofMat();var top=new THREE.Mesh(vbox(w,h-3.2,d),[m,m,rm,rm,m,m]);top.position.set(0,3.2+(h-3.2)/2,0);g.add(top);
 var gm=new THREE.MeshLambertMaterial({color:opt.shop||pick3(['#5b6b73','#7b5b4a','#4f6b5a','#6b5b7b'])});
 var front=opt.front||1,garage=/車房|車行/.test(opt.sign||'');
 if(garage){vb(g,1,3.2,d,-w/2+.5,1.6,0,'#5b6b73');vb(g,1,3.2,d,w/2-.5,1.6,0,'#5b6b73');vb(g,w-2,3.2,.2,0,1.6,-front*(d/2-.1),'#293339');vb(g,w-2,.12,d,0,.06,0,'#6e7775');}
 else{var gf=new THREE.Mesh(vbox(w,3.2,d),gm);gf.position.set(0,1.6,0);g.add(gf);}
 var sh;
 if(opt.sign){
  /* 面向街道嘅簡化店面：玻璃櫥窗、門、貨架和按行業變化嘅陳列。 */
  var fz=front*(d/2+.05),doorX=w*.29,winX=-w*.12,winW=w*.55;
  sh=vb(g,w*.86,2.45,.12,0,1.25,garage?front*(d/2-2.8):fz,'#33494a',{own:1});
  if(!garage){vb(g,winW,1.95,.12,winX,1.32,front*(d/2+.14),'#a8ccd0');
  vb(g,w*.19,2.25,.14,doorX,1.19,front*(d/2+.15),'#d1d4c7');
  vb(g,w*.15,1.55,.04,doorX,1.43,front*(d/2+.24),'#87afb1');
  vb(g,.07,.25,.06,doorX-w*.045,1.15,front*(d/2+.28),'#d9b876');}
  var clr=/藥|診所|牙/.test(opt.sign)?['#f3e7ce','#de6b60','#a2cfbd']:/餅|冰室|茶樓|酒樓/.test(opt.sign)?['#d8a55d','#efdab1','#bd7252']:/銀行|地產/.test(opt.sign)?['#e4e8df','#6d9fa1','#d5bea2']:['#d7b884','#759f8b','#d9775e'];
  var zshow=front*(d/2+.32);
  if(/車房|車行/.test(opt.sign)){
   /* 車房係闊出入口，後方放工具櫃及維修設備，唔設玻璃門。 */
   vb(g,w*.76,2.45,.2,0,1.25,front*(d/2-2.9),'#293339');
   vb(g,.9,1.1,.12,-w*.22,.58,front*(d/2-2.72),'#ba5040');
   for(var tr=0;tr<3;tr++)vb(g,.76,.06,.05,-w*.22,.38+tr*.3,front*(d/2-2.64),'#e0d8bc');
   vb(g,1.5,.1,.4,w*.14,.14,front*(d/2-1.0),'#839299');vb(g,.16,1.4,.16,w*.32,.75,front*(d/2-1.0),'#e6b544');
  }else if(/髮型/.test(opt.sign)){
   /* 髮型屋：鏡、理髮椅及工作台。 */
   vb(g,winW*.45,1.05,.06,winX-.3,1.55,zshow,'#dbe9e4');vb(g,1,.13,.2,winX-.3,.85,front*(d/2+.4),'#ad8261');
   vb(g,.7,.6,.35,winX+.45,.55,front*(d/2+.4),'#9e4e43');vb(g,.7,.65,.12,winX+.45,1.05,front*(d/2+.42),'#7c3934');vb(g,.14,.4,.16,winX+.45,.2,front*(d/2+.4),'#778689');
  }else if(/銀行|地產|找換/.test(opt.sign)){
   /* 銀行和地產：櫃台、玻璃分隔與海報。 */
   vb(g,winW*.85,.72,.22,winX,.59,zshow,'#c6b59c');vb(g,winW*.85,.08,.28,winX,.98,front*(d/2+.4),'#e9dfce');
   vb(g,.9,.75,.04,winX-.4,1.65,front*(d/2+.39),'#d9e9e1');vb(g,.5,.28,.07,winX+.65,1.25,front*(d/2+.4),'#435c68');
  }else if(/餅|冰室|茶樓|酒樓/.test(opt.sign)){
   /* 食店：櫥櫃、麵包與餐枱。 */
   vb(g,winW*.8,.65,.18,winX,.6,zshow,'#a9704e');vb(g,winW*.82,.06,.22,winX,.95,front*(d/2+.4),'#e9d6b9');
   for(var si=0;si<5;si++)vb(g,.35,.18,.12,winX-winW*.32+si*winW*.16,1.08,front*(d/2+.43),clr[si%3]);
  }else{
   /* 其餘店舖：按行業色彩擺貨。 */
   for(var sj=0;sj<3;sj++){var sy=.65+sj*.5;vb(g,winW*.9,.07,.18,winX,sy,front*(d/2+.25),'#c8ad87');for(var sk=0;sk<4;sk++)vb(g,winW*.12,.24,.1,winX-winW*.34+sk*winW*.22,sy+.15,zshow,clr[(sj+sk)%3]);}
  }
  vb(g,w*.92,.16,.6,0,2.78,front*(d/2+.3),'#526565');
 }else sh=vb(g,w*.8,2.2,.1,0,1.25,front*(d/2+.05),opt.shutter||'#9aa3a8',{own:1});
 vb(g,w,.15,.6,0,3.1,front*(d/2+.3),'#5a5a5a');
 /* 天台：女兒牆、水缸、冷氣機、天線 */
 vb(g,w,.5,.15,0,h+.25,d/2-.08,'#b8b2a6');vb(g,w,.5,.15,0,h+.25,-d/2+.08,'#b8b2a6');vb(g,.15,.5,d,w/2-.08,h+.25,0,'#b8b2a6');vb(g,.15,.5,d,-w/2+.08,h+.25,0,'#b8b2a6');
 vb(g,1.3,1.1,1.3,w*.22,h+.55,-d*.18,'#d9dcde');vb(g,1.4,.12,1.4,w*.22,h+1.16,-d*.18,'#9aa0a4');vb(g,.15,.8,.15,w*.22+.5,h+.4,-d*.18+.5,'#7a7f83');
 if(w>7)vb(g,1.1,1,1.1,-w*.25,h+.5,d*.15,'#c9cdd0');
 vb(g,.8,.5,.5,-w*.1,h+.25,-d*.3,'#e4e4df');vb(g,.06,1.6,.06,w*.38,h+.8,d*.3,'#555');vb(g,.8,.04,.04,w*.38,h+1.4,d*.3,'#555');
 var roof=vb(g,w*.3,1.2,d*.3,-w*.2,h+.6,-d*.05,'#8a8a85');
 W3.blds.push({box:new THREE.Box3(new THREE.Vector3(x-w/2,0,z-d/2),new THREE.Vector3(x+w/2,h+1.2,z+d/2)),mats:[m,gm,sh.material,rm],faded:false});
 if(opt.sign)W3.neons.push(sign(g,opt.sign,Math.min(w*.8,opt.sign.length*1.1),.9,0,2.75,front*(d/2+.62),'#fff5d6',opt.signBg||'#a3242a'));
 /* 香港式凸出招牌（鐵架） */
 if(opt.psign){var py=4+((x*7+z)%3+3)%3*1.6,pz=front*(d/2+1.3);vb(g,.06,.06,2.4,w*.3,py+.9,front*(d/2+1.1),'#3c3c3c');vb(g,.06,.06,2.4,w*.3,py-.9,front*(d/2+1.1),'#3c3c3c');
  W3.neons.push(sign(g,opt.psign,2.2,1.6,w*.3,py,pz,'#fff3c0',opt.pbg||'#1c4f8a',false,Math.PI/2));}
 if(opt.vsign)W3.neons.push(sign(g,opt.vsign,.9,opt.vsign.length*.9+.4,w/2-.6,4.8+opt.vsign.length*.45,front*(d/2+1),opt.vfg||'#ffe8f0',opt.vbg||'#b0206a',true,Math.PI/2));
 return g;
}
function pick3(a){return a[Math.floor(Math.random()*a.length)];}
function buildCity(sc){
 /* 地面：馬路、行人路，分段唔重疊 */
 /* 地面：馬路、行人路（磚）、分段唔重疊 */
 flatTex(sc,320,260,0,-.05,10,concreteCanvas(),4,.1);
 W3.road=flatTex(sc,240,7,0,.01,9.5,asphaltCanvas(),6);
 flatTex(sc,8,60,24,.012,-24,asphaltCanvas(),6);
 [[-120,20],[28,39],[47,120]].forEach(function(r){var w=r[1]-r[0],cx=(r[0]+r[1])/2;flatTex(sc,w,6,cx,.08,3,paverCanvas(),2.4,.16);vb(sc,w,.2,.3,cx,.1,6.05,'#c9c6bd');});
 flatTex(sc,240,5,0,.08,15.5,paverCanvas(),2.4,.16);vb(sc,240,.2,.3,0,.1,13.05,'#c9c6bd');
 [[18,-27],[30,-27]].forEach(function(p){flatTex(sc,4,54,p[0],.08,p[1],paverCanvas(),2.4,.16);});
 /* 車房前路面同行人路有高低差，留出車輛通道。 */
 flatTex(sc,8,6,43,.075,3,asphaltCanvas(),3,.15);
 vb(sc,.3,.2,54,20.15,.1,-27,'#c9c6bd');vb(sc,.3,.2,54,27.85,.1,-27,'#c9c6bd');
 /* 行車線：中間白虛線、兩邊雙黃線 */
 for(var x=-118;x<118;x+=6)if(x<12||x>22)vb(sc,3,.01,.15,x,.025,9.5,'#e8e8e8');
 [[-120,14.2],[20.4,39],[47,120]].forEach(function(r){var w=r[1]-r[0],cx=(r[0]+r[1])/2;vb(sc,w,.01,.1,cx,.026,6.45,'#e8c21a');vb(sc,w,.01,.1,cx,.026,6.7,'#e8c21a');});
 [[-120,14.2],[20.4,120]].forEach(function(r){var w=r[1]-r[0],cx=(r[0]+r[1])/2;vb(sc,w,.01,.1,cx,.026,12.55,'#e8c21a');vb(sc,w,.01,.1,cx,.026,12.3,'#e8c21a');});
 /* 停車白線 */
 vb(sc,.35,.012,3,13.6,.028,8,'#f2f2f2');vb(sc,.35,.012,3,20.9,.028,11,'#f2f2f2');vb(sc,3.6,.012,.35,22,.028,-5.4,'#f2f2f2');
 /* 過路處：黃色斑紋＋「望右 LOOK RIGHT」 */
 for(var zz=6.9;zz<12.6;zz+=.85)vb(sc,4.2,.012,.42,17,.027,zz+.2,'#d6a22a');
 decal(sc,roadText('望右','LOOK RIGHT'),2.8,1.4,12.4,.03,8,Math.PI/2);decal(sc,roadText('望右','LOOK RIGHT'),2.8,1.4,21.6,.03,11,-Math.PI/2);
 for(var xx=20.6;xx<27.6;xx+=.85)vb(sc,.42,.012,3.4,xx+.2,.027,-2.4,'#d6a22a');
 decal(sc,roadText('望右','LOOK RIGHT'),2.6,1.3,25.8,.03,-5,Math.PI);
 /* 行人燈（紅綠公仔） */
 W3.pl=[];[[14.6,5.6,0],[19.4,13.6,Math.PI],[20.4,-.4,-Math.PI/2],[27.6,-4.4,Math.PI/2]].forEach(function(p){var g=vgroup(sc,p[0],0,p[1]);vb(g,.12,2.6,.12,0,1.3,0,'#2a2a2a');var bx=vgroup(g,0,2.5,0);vb(bx,.34,.62,.3,0,0,0,'#1d1d1d');
  var r=vb(bx,.2,.2,.04,0,.14,.16,'#400',{own:1}),gr=vb(bx,.2,.2,.04,0,-.14,.16,'#040',{own:1});vb(g,.3,.3,.16,0,1.1,.12,'#e0b020');g.rotation.y=p[2];W3.pl.push({r:r,g:gr});});
 /* 欄杆（路口附近） */
 function rail(x0,x1,z){for(var x=x0;x<=x1;x+=1.2)vb(sc,.06,1,.06,x,.66,z,'#8e979c');vb(sc,x1-x0,.06,.05,(x0+x1)/2,1.1,z,'#a6aeb2');vb(sc,x1-x0,.05,.05,(x0+x1)/2,.65,z,'#a6aeb2');}
 rail(-8,14,5.75);rail(20.6,38,5.75);rail(48,58,5.75);rail(0,14.2,13.35);rail(20.4,42,13.35);
 (function(){for(var z=-40;z<=-4;z+=1.2){vb(sc,.06,1,.06,20.5,.66,z,'#8e979c');vb(sc,.06,1,.06,27.5,.66,z,'#8e979c');}vb(sc,.05,.06,36,20.5,1.1,-22,'#a6aeb2');vb(sc,.05,.06,36,27.5,1.1,-22,'#a6aeb2');})();
 /* 紅綠燈 */
 W3.tl=[];[[13.6,6.4,0],[20.4,12.8,Math.PI]].forEach(function(p){var g=vgroup(sc,p[0],0,p[1]);vb(g,.15,3.4,.15,0,1.7,0,'#2a2a2a');var box=vgroup(g,0,3.6,0);vb(box,.4,1.1,.35,0,0,0,'#1f1f1f');
  var r=vb(box,.26,.26,.05,.0,.32,.18,'#400',{own:1}),y=vb(box,.26,.26,.05,0,0,.18,'#430',{own:1}),gr=vb(box,.26,.26,.05,0,-.32,.18,'#040',{own:1});g.rotation.y=p[2];W3.tl.push({r:r,y:y,g:gr});});
 W3.light={ph:'g',t:0};
 /* 街燈 */
 for(var lx=-110;lx<=110;lx+=13){[[5.6,1],[13.5,-1]].forEach(function(q){if(q[0]===5.6&&((lx>18&&lx<30)||(lx>=39&&lx<=47)))return;var g=vgroup(sc,lx+(q[1]<0?6:0),0,q[0]);vb(g,.12,5.2,.12,0,2.6,0,'#3c4146');vb(g,.1,.1,1.2,0,5.15,q[1]*.6,'#3c4146');
  var b=vb(g,.45,.15,.35,0,5.05,q[1]*1.15,'#ffe2a8',{e:'#ffcf80',ei:0,own:1});W3.lamps.push(b);});}
 /* 近邊一排（我哋間舖喺 x -5→5，橫街 x 20→28） */
 var near=[[-58,8,6,'tong','tong','藥房',null],[-49,10,14,'tile',null,'地產',null],[-39,9,5,'tong','pink','找換','麻雀'],[-30,8,6,'tong',null,'士多',null],[-21,10,16,'glass',null,'銀行',null],[-11,8,5,'tong',null,'五金','診所'],
  [9.6,8.6,6,'tong',null,'髮型屋','卡拉OK'],[16.4,4.8,5,'tong',null,'報紙',null],[33,10,18,'estate',null,'超市',null],[43,10,6,'tong',null,'車房',null],[53,10,12,'tile',null,'酒樓','海鮮酒家']];
 var PS=[['金行','#a3242a'],['涼茶','#2e6b3a'],['牙科','#1c4f8a'],['當押','#5a2a6a'],['眼鏡','#1c4f8a'],['火鍋','#a3242a'],['電器','#2e5f7a'],['跌打','#7a4a1c']];
 near.forEach(function(b,i){var ps=i%2===0?PS[i%PS.length]:null;building(sc,b[0],-5,b[1]-.2,10,b[2],b[3],{sign:b[5],vsign:b[6],psign:ps&&ps[0],pbg:ps&&ps[1]});});
 /* 對面一排 */
 var far=[[-55,12,8,'tong','冰室','冰室'],[-42,10,22,'estate','超級市場',null],[-30,12,6,'tong','跌打',null],[-17,12,15,'tile','茶樓','點心'],[-4,12,7,'tong','雜貨',null],[8,12,20,'glass','商場',null],[22,10,6,'tong','車行',null],[33,12,18,'estate','餅店','麵包'],[46,12,7,'tong','書局',null],[58,10,12,'tile','眼鏡',null]];
 far.forEach(function(b,i){var ps=i%2===1?PS[(i+3)%PS.length]:null;var g=building(sc,b[0],23,b[1]-.2,10,b[2],b[3],{front:-1,sign:b[4],vsign:b[5],psign:ps&&ps[0],pbg:ps&&ps[1]});g.rotation.y=0;});
 /* 背景塞滿高樓，鏡頭見唔到地圖外面 */
 for(var bx=-110;bx<=110;bx+=12){[[-20,8,14],[-34,10,22],[40,10,18],[54,12,26]].forEach(function(r){if(Math.abs(bx-24)<5&&r[0]<0&&r[0]>-30)return;var fl=r[1]+Math.floor(Math.random()*r[2]);building(sc,bx+(Math.random()-.5)*2,r[0],10,11,fl,pick3(['estate','tile','grey','glass','pink']),{front:r[0]>0?-1:1});});}
 for(var ex=-1;ex<=1;ex+=2)for(var ez=0;ez<4;ez++)building(sc,ex*(70+ez*6),ez%2?-5:23,10,10,6+ez*3,pick3(['tong','tile']),{front:ez%2?1:-1});
 /* 巴士站、港鐵出口 */
 var bs=vgroup(sc,-14,0,16.2);vb(bs,4,.1,1.4,0,2.6,0,'#c7302a');vb(bs,.1,2.6,.1,-1.9,1.3,.6,'#888');vb(bs,.1,2.6,.1,1.9,1.3,.6,'#888');vb(bs,3.8,2,.06,0,1.4,.65,'#9fc7d9',{op:.4});vb(bs,2.4,.12,.5,0,.6,.3,'#555');
 W3.neons.push(sign(bs,'巴士站',1.6,.5,0,2.95,-.72,'#ffffff','#c7302a',false,Math.PI));
 var mtr=vgroup(sc,30,0,15.6);vb(mtr,3.6,3,2.4,0,1.5,0,'#d8d8d8');vb(mtr,3,2.2,.1,0,1.2,-1.22,'#2a2a2a');W3.neons.push(sign(mtr,'港鐵站 A 出口',3.2,.6,0,3.3,-1.25,'#ffffff','#a32b33',false,Math.PI));
 /* 樹（體素樹冠）同樹池、長櫈 */
 [[-34,15.6],[-6,15.8],[24,15.8],[44,15.8],[-46,15.6],[56,15.8]].forEach(function(p,i){vb(sc,1.4,.2,1.4,p[0],.18,p[1],'#6b5b4a');vb(sc,.3,2.2,.3,p[0],1.2,p[1],'#5a4636');
  [[0,3,0,1.8],[.6,2.6,.4,1.2],[-.6,2.7,-.3,1.3],[.2,3.7,-.2,1.1],[-.3,2.4,.6,1]].forEach(function(q,k){vb(sc,q[3],q[3],q[3],p[0]+q[0],q[1],p[1]+q[2],['#4f8a3c','#5f9c46','#447a35','#6aa84f','#3f7230'][(k+i)%5]);});});
 [[-18,16.6],[-10,16.6],[38,16.6]].forEach(function(p){vb(sc,1.8,.1,.5,p[0],.55,p[1],'#a0703f');vb(sc,1.8,.5,.08,p[0],.85,p[1]+.25,'#a0703f');vb(sc,.1,.45,.4,p[0]-.8,.32,p[1],'#444');vb(sc,.1,.45,.4,p[0]+.8,.32,p[1],'#444');});
 /* 街道設施：垃圾桶、消防栓、郵筒、小巴站牌、報紙檔、禁止停車牌 */
 [[-26,1.2],[8,1.2],[33,1.2],[-12,17.3],[18,17.3],[46,17.3]].forEach(function(p){var b=vgroup(sc,p[0],.16,p[1]);vb(b,.6,.9,.5,0,.45,0,'#2f7d4f');vb(b,.62,.25,.52,0,.95,0,'#e07b2a');vb(b,.3,.04,.1,0,1.08,.2,'#222');});
 [[-17,5.2],[38,14]].forEach(function(p){var h=vgroup(sc,p[0],.16,p[1]);vb(h,.3,.5,.3,0,.25,0,'#c62f2f');vb(h,.36,.12,.36,0,.55,0,'#c62f2f');vb(h,.12,.12,.5,0,.3,0,'#a52020');});
 (function(){var pb=vgroup(sc,-30,.16,17.1);vb(pb,.6,1.1,.5,0,.55,0,'#2e7d4f');vb(pb,.66,.12,.56,0,1.15,0,'#256a42');vb(pb,.35,.05,.05,0,.85,-.26,'#111');})();
 (function(){var ms=vgroup(sc,-6,.16,16.9);vb(ms,.08,2.6,.08,0,1.3,0,'#666');var mm=new THREE.MeshLambertMaterial({map:textTex('專線小巴','#ffffff','#2e7d4f',false,256,64)});var mb=new THREE.Mesh(vbox(1.1,.35,.04),mm);mb.position.set(0,2.45,0);ms.add(mb);})();
 (function(){var ns=vgroup(sc,26,.16,17);vb(ns,2.2,1.6,1.2,0,.8,0,'#3c6e5a');vb(ns,2.4,.12,1.5,0,1.7,-.1,'#2a4f40');[0,1,2,3,4].forEach(function(k){vb(ns,.35,.45,.04,-.8+k*.4,1.1,-.62,['#e8e4d6','#d9534f','#f2d16b','#e8e4d6','#5b8ed6'][k]);});})();
 [[-2,5.6],[30,5.6]].forEach(function(p){var g=vgroup(sc,p[0],.16,p[1]);vb(g,.07,2.2,.07,0,1.1,0,'#777');var m=new THREE.MeshLambertMaterial({map:textTex('禁止停車','#ffffff','#c62f2f',false,128,64)});var b=new THREE.Mesh(vbox(.6,.4,.03),m);b.position.set(0,2.1,0);g.add(b);});
 buildTraffic(sc);
}
/* ---------- 交通：近線向 +x、遠線向 −x（左上落車），紅綠燈同前車距離 ---------- */
function buildTraffic(sc){
 W3.cars=[];var types=['taxi','taxi','car','mini','car','bus','taxi','car','mini','taxi'];
 for(var i=0;i<10;i++){var lane=i%2,c=makeCar(types[i],i);c.position.set(-110+i*22,0,lane?11.4:7.7);c.rotation.y=lane?Math.PI:0;sc.add(c);W3.heads.push(c.userData.head,c.userData.headR);
  W3.cars.push({m:c,lane:lane,v:0,max:types[i]==='bus'?7:10});}
 W3.peds=[];W3.umb=[];for(var j=0;j<18;j++){var p=makePerson({i:j+3,long:j%3===0,bag:j%4===1});addUmbrella(p,j);var side=j%2;p.position.set(-100+j*11,side?.16:.16,side?15.2+(j%3)*.5:2+(j%3)*.9);p.userData.dir=j%4<2?1:-1;p.rotation.y=p.userData.dir>0?Math.PI/2:-Math.PI/2;sc.add(p);W3.peds.push(p);}
 W3.cross=[];for(var q=0;q<4;q++){var cp=makePerson({i:q+30,long:q%2});addUmbrella(cp,q+5);cp.userData.side=q%2;cp.userData.wait=1;cp.position.set(15.6+q*.9,.16,q%2?13.9:5.3);sc.add(cp);W3.cross.push(cp);}
}
function updateTraffic(dt){
 var gs=Math.min(s.speed||1,4)*(s.paused||s.modal?0:1),L=W3.light;L.t+=dt*Math.max(gs,.0001);
 var dur={g:14,y:3,r:12};if(L.t>dur[L.ph]){L.t=0;L.ph=L.ph==='g'?'y':L.ph==='y'?'r':'g';}
 W3.tl.forEach(function(t){t.r.material.color.set(L.ph==='r'?'#ff3030':'#400');t.y.material.color.set(L.ph==='y'?'#ffb020':'#430');t.g.material.color.set(L.ph==='g'?'#30e060':'#040');
  t.r.material.emissive=new THREE.Color(L.ph==='r'?'#ff2020':'#000');t.g.material.emissive=new THREE.Color(L.ph==='g'?'#20d050':'#000');});
 var stop=L.ph!=='g';
 if(W3.pl)W3.pl.forEach(function(p){var walk=L.ph==='r';p.r.material.color.set(walk?'#400':'#ff3030');p.g.material.color.set(walk?'#30e060':'#040');p.r.material.emissive=new THREE.Color(walk?'#000':'#ff2020');p.g.material.emissive=new THREE.Color(walk?'#20d050':'#000');});
 W3.cars.forEach(function(c){
  var dir=c.lane?-1:1,x=c.m.position.x,ahead=1e9;
  W3.cars.forEach(function(o){if(o===c||o.lane!==c.lane)return;var d=(o.m.position.x-x)*dir;if(d>0&&d<ahead)ahead=d-(o.m.userData.len+c.m.userData.len)/2;});
  var stopX=dir>0?13.2:20.8,toStop=(stopX-x)*dir;
  var want=c.max;if(stop&&toStop>0&&toStop<14)want=Math.min(want,Math.max(0,(toStop-1)*1.2));if(ahead<12)want=Math.min(want,Math.max(0,(ahead-2)*1.5));
  c.v+=(want-c.v)*Math.min(1,dt*2);c.m.position.x+=dir*c.v*dt*gs;
  if(c.m.position.x>115)c.m.position.x=-115;if(c.m.position.x<-115)c.m.position.x=115;});
 var walk=L.ph==='r';
 W3.cross.forEach(function(p,i){var to=p.userData.side?5.3:13.9;
  if(p.userData.wait){if(walk&&L.t<9){p.userData.wait=0;}stride(p,0,dt);turnTo(p,p.userData.side?Math.PI:0,dt);return;}
  var dz=to-p.position.z,st=1.3*dt*Math.sqrt(Math.max(gs,0));if(Math.abs(dz)<=st){p.position.z=to;p.userData.side=1-p.userData.side;p.userData.wait=1;}else{p.position.z+=Math.sign(dz)*st;turnTo(p,dz>0?0:Math.PI,dt);}
  stride(p,Math.abs(dz)<=st?0:st,dt);});
 if(W3.umb)W3.umb.forEach(function(u){u.visible=s.rain>0;});
 W3.peds.forEach(function(p,i){p.position.x+=p.userData.dir*1.2*dt*Math.sqrt(Math.max(gs,0));if(p.position.x>110)p.position.x=-110;if(p.position.x<-110)p.position.x=110;
  if(p.position.z<6&&p.position.x>19&&p.position.x<29)p.position.x+=p.userData.dir*9;
  stride(p,1.2*dt*Math.sqrt(Math.max(gs,0)),dt);});
}
function addUmbrella(p,i){var u=vgroup(p,.18,0,0);vb(u,.04,.9,.04,0,1.45,0,'#333');vb(u,1,.08,1,0,1.92,0,['#2d6cdf','#e04f5f','#3fbf7f','#f2b134','#7b5cd6'][i%5]);vb(u,.7,.08,.7,0,2,0,['#2d6cdf','#e04f5f','#3fbf7f','#f2b134','#7b5cd6'][i%5]);u.visible=false;W3.umb.push(u);}
