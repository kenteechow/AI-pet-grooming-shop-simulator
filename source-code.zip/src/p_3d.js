/* p_3d：renderer、鏡頭、燈光、日夜、落雨、大廈半透明、點擊、標籤。冇 THREE 就唔開 3D（測試用）。 */
var W3={on:false,blds:[],lamps:[],lampPool:[],neons:[],heads:[],pick:[],actors:{},rainOn:false,t:0,gpu:'—'};
function init3D(el){
 if(!window.THREE){W3.on=false;el.innerHTML='<div class="no3d">3D 載入唔到（要連網載入 three.js）。其他功能照用得。</div>';return;}
 var r=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 r.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));r.shadowMap.enabled=true;r.shadowMap.type=THREE.PCFSoftShadowMap;r.setSize(el.clientWidth,el.clientHeight);el.appendChild(r.domElement);
 try{var gl=r.getContext(),ext=gl.getExtension('WEBGL_debug_renderer_info');W3.gpu=ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);}catch(e){}
 var sc=new THREE.Scene();sc.fog=new THREE.Fog('#a9cfe6',70,170);
 var cam=new THREE.PerspectiveCamera(45,el.clientWidth/el.clientHeight,.1,400);
 W3.on=true;W3.r=r;W3.sc=sc;W3.cam=cam;W3.el=el;
 W3.hemi=new THREE.HemisphereLight('#d6e8ff','#7a6f62',.75);sc.add(W3.hemi);
 W3.sun=new THREE.DirectionalLight('#fff4e0',.85);W3.sun.position.set(-18,40,22);W3.sun.target.position.set(0,2,-5);sc.add(W3.sun);sc.add(W3.sun.target);
 W3.sun.castShadow=true;W3.sun.shadow.mapSize.set(1024,1024);var shc=W3.sun.shadow.camera;shc.left=-14;shc.right=14;shc.top=14;shc.bottom=-14;shc.near=5;shc.far=90;W3.sun.shadow.bias=-.0008;W3.sun.shadow.normalBias=.02;
 W3.amb=new THREE.AmbientLight('#ffffff',.15);sc.add(W3.amb);
 for(var i=0;i<17;i++){var pl=new THREE.PointLight('#ffd9a0',0,16,1.3);pl.visible=false;sc.add(pl);W3.lampPool.push(pl);}
 /* 只用少量投影燈跟住鏡頭，避免每盞街燈都產生昂貴陰影。 */
 W3.streetSpot=new THREE.SpotLight('#ffe0a8',0,17,Math.PI/3,.55,1.2);W3.streetSpot.castShadow=true;W3.streetSpot.shadow.mapSize.set(512,512);W3.streetSpot.shadow.bias=-.001;sc.add(W3.streetSpot);sc.add(W3.streetSpot.target);
 W3.carSpots=[];for(var j=0;j<2;j++){var cs=new THREE.SpotLight('#fff0c3',0,15,Math.PI/5,.55,1.3);cs.castShadow=true;cs.shadow.mapSize.set(512,512);cs.shadow.bias=-.001;sc.add(cs);sc.add(cs.target);W3.carSpots.push(cs);}
 var skyG=new THREE.SphereGeometry(260,24,12),skyM=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,uniforms:{top:{value:new THREE.Color('#7fb4e6')},bot:{value:new THREE.Color('#dcebf5')}},
  vertexShader:'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
  fragmentShader:'uniform vec3 top;uniform vec3 bot;varying float h;void main(){gl_FragColor=vec4(mix(bot,top,clamp(h*1.6,0.0,1.0)),1.0);}'});
 W3.sky=new THREE.Mesh(skyG,skyM);W3.sky.renderOrder=-1;sc.add(W3.sky);
 buildCity(sc);buildShop(sc);initRain(sc);initPuddles(sc);
 var skip=new Set([W3.shop,W3.rain]);W3.cars.forEach(function(c){skip.add(c.m);});W3.peds.forEach(function(p){skip.add(p);});(W3.cross||[]).forEach(function(p){skip.add(p);});(W3.pud||[]).forEach(function(p){skip.add(p);});mergeStatic(sc,skip);
 var sk2=new Set([W3.table3]);mergeStatic(W3.f1,sk2);var C=W3.cafe,sk3=new Set([W3.f1,W3.cafeFront,W3.cafeRoof,W3.ourUpper,C.cashier,C.waiter]);C.cust.forEach(function(x){sk3.add(x);});C.fans.forEach(function(x){sk3.add(x);});mergeStatic(W3.shop,sk3);
 camReset();camControls(r.domElement);
 window.addEventListener('resize',resize3D);
}
function resize3D(){if(!W3.on)return;var el=W3.el;W3.r.setSize(el.clientWidth,el.clientHeight);W3.cam.aspect=el.clientWidth/Math.max(1,el.clientHeight);W3.cam.updateProjectionMatrix();}
function pick3D(px,py){
 var rc=new THREE.Raycaster(),r=W3.r.domElement.getBoundingClientRect();rc.setFromCamera({x:(px-r.left)/r.width*2-1,y:-(py-r.top)/r.height*2+1},W3.cam);
 var hit=rc.intersectObjects(W3.pick,true)[0];
 if(!hit){if(s.sel){s.sel=null;renderSel();}return;}
 var o=hit.object;while(o&&!o.userData.pick)o=o.parent;if(o){s.sel=o.userData.pick;renderSel();}
}
/* ---------- 燈光、日夜 ---------- */
function dayLight(t){/* 凌晨到日出、黃昏到夜晚，連續過渡 */if(t<330||t>=1150)return 0;if(t<450)return (t-330)/120;if(t<1050)return 1;return 1-(t-1050)/100;}
function lerpC(a,b,k){return new THREE.Color(a).lerp(new THREE.Color(b),k);}
function update3D(dt){
 if(!W3.on||!s)return;W3.t+=dt;camUpdate(dt);
 var t=s.t,targetLight=dayLight(t),rain=s.rain>0;if(W3.lightLevel==null)W3.lightLevel=targetLight;W3.lightLevel+=(targetLight-W3.lightLevel)*(1-Math.exp(-dt*3));var L=W3.lightLevel,dusk=L>0&&L<1?Math.sin(L*Math.PI):0;
 var sky=L>0?lerpC('#0b1424',rain?'#8b959c':'#a9cfe6',L):new THREE.Color('#0b1424');if(dusk>0&&!rain)sky.lerp(new THREE.Color('#e3a27c'),dusk*.45);
 W3.sc.background=sky;W3.sc.fog.color=sky;
 if(W3.sky){var tc=L>0?lerpC('#0a1530',rain?'#7d8a94':'#6fa8e0',L):new THREE.Color('#0a1530');if(dusk>0&&!rain)tc.lerp(new THREE.Color('#5a6fb0'),dusk*.5);W3.sky.material.uniforms.top.value.copy(tc);W3.sky.material.uniforms.bot.value.copy(sky);W3.sky.position.copy(W3.cam.position);}
 W3.sun.intensity=(rain?.38:.66)*L+.02;W3.hemi.intensity=.18+(rain?.34:.46)*L;W3.amb.intensity=.12+.05*L;
 var night=1-L;
 W3.neons.forEach(function(m){(m.userData.signFace||m.material).emissiveIntensity=.12+night*.95;});
 W3.lamps.forEach(function(m){m.material.emissive.set('#ffcf80');m.material.emissiveIntensity=night*1.2;});
 W3.heads.forEach(function(m){m.material.emissive.set('#fff3b0');m.material.emissiveIntensity=.15+night*1.3;});
 W3.cars.forEach(function(c){c.m.userData.beam.material.opacity=night*.4;});
 if(W3.winMats)W3.winMats.forEach(function(m){m.emissiveIntensity=night*.9;});
 /* 可照到美容店嘅街燈固定；其餘燈位先跟鏡頭。總數維持 20。 */
 if(Math.floor(W3.t*2)!==W3.lastLamp){W3.lastLamp=Math.floor(W3.t*2);
  var lampPositions=W3.lamps.map(function(m){return {mesh:m,pos:m.getWorldPosition(new THREE.Vector3())};});
  function shopDistance(p){var dx=Math.max(0,Math.abs(p.x)-5),dz=p.z>0?p.z:p.z< -10?-10-p.z:0;return dx*dx+dz*dz;}
  var fixed=lampPositions.filter(function(o){return shopDistance(o.pos)<16*16;}).sort(function(a,b){return shopDistance(a.pos)-shopDistance(b.pos)||a.pos.x-b.pos.x;});
  var extra=lampPositions.filter(function(o){return shopDistance(o.pos)>=16*16;}).sort(function(a,b){return dist2(a.pos)-dist2(b.pos);});
  var shadow=fixed.shift()||extra.shift(),near=fixed.concat(extra);
  W3.lampPool.forEach(function(pl,i){var m=near[i];if(m){pl.position.copy(m.pos);pl.position.y-=.3;}});
  if(shadow){W3.streetSpot.position.copy(shadow.pos);W3.streetSpot.target.position.copy(shadow.pos);W3.streetSpot.target.position.y=0;}
  /* 對照美容店位置選車，鏡頭移動唔會突然換車燈；車輛行駛仍會移動光源。 */
  var cars=W3.cars.slice().sort(function(a,b){var x=a.m.position,z=b.m.position;return (x.x*x.x+(x.z+5)*(x.z+5))-(z.x*z.x+(z.z+5)*(z.z+5));});
  W3.carSpots.forEach(function(light,i){var c=cars[i];if(!c)return;var dir=c.lane?-1:1;light.position.set(c.m.position.x+dir*(c.m.userData.len/2),.7,c.m.position.z);light.target.position.set(light.position.x+dir*8,.1,light.position.z);});}
 W3.lampPool.forEach(function(pl){pl.intensity=night*1.6;pl.visible=night>.05;});W3.streetSpot.intensity=night*2;W3.streetSpot.visible=night>.05;W3.carSpots.forEach(function(pl){pl.intensity=night*2.2;pl.visible=night>.05;});
 W3.shopLights.forEach(function(pl){pl.intensity=.14+night*.8;});
 W3.floorMat.emissiveIntensity=.02;
 W3.road.material.color.set(rain?'#2a2c2e':'#3b3e42');
 W3.ourUpper.visible=!!s.exterior&&!s.floorG;W3.frontTop.visible=!!s.exterior;if(W3.f1)W3.f1.visible=!s.floorG;if(W3.cafeFront)W3.cafeFront.visible=!s.floorG;if(W3.cafeRoof)W3.cafeRoof.visible=!s.floorG;updateCafe(dt);
 var wet=rain||(s.wetDay===s.day&&s.t<s.wetT);updatePuddles(wet,rain?1:clamp((s.wetT-s.t)/180,0,1),night);
 W3.fr=(W3.fr||0)+1;if(W3.fr%4===0)updateFade();updateRain(dt,rain,s.rain===2);updateTraffic(dt);syncShop(dt);if(W3.fr%2===0)updateLabels();
 W3.r.render(W3.sc,W3.cam);
}
function dist2(p){var dx=p.x-CAM.tx,dz=p.z-CAM.tz;return dx*dx+dz*dz;}
/* 鏡頭同目標之間嘅大廈變半透明 */
function updateFade(){
 var c=W3.cam.position,tg=new THREE.Vector3(CAM.tx,CAM.ty,CAM.tz),dir=tg.clone().sub(c),len=dir.length();dir.normalize();
 var ray=new THREE.Ray(c,dir),p=new THREE.Vector3();
 W3.blds.forEach(function(b){var hit=ray.intersectBox(b.box,p),f=hit&&c.distanceTo(p)<len-1&&!(b.ours&&s.exterior);if(f!==b.faded){b.faded=f;b.mats.forEach(function(m){m.transparent=f;m.opacity=f?.22:1;m.depthWrite=!f;m.needsUpdate=true;});}});
}
/* ---------- 落雨 ---------- */
function initRain(sc){var n=1400,pos=new Float32Array(n*6);for(var i=0;i<n;i++){var x=(Math.random()-.5)*50,y=Math.random()*25,z=(Math.random()-.5)*50;pos.set([x,y,z,x+.05,y+.6,z],i*6);}
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));
 W3.rain=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:'#b8c8d8',transparent:true,opacity:.45}));W3.rain.visible=false;W3.rain.frustumCulled=false;sc.add(W3.rain);}
function updateRain(dt,on,heavy){W3.rain.visible=on;if(!on)return;var a=W3.rain.geometry.attributes.position,v=a.array,sp=(heavy?32:22)*dt;
 for(var i=0;i<v.length;i+=6){v[i+1]-=sp;v[i+4]-=sp;if(v[i+1]<0){var y=25;v[i+1]=y;v[i+4]=y+.6;}}a.needsUpdate=true;W3.rain.position.set(CAM.tx,0,CAM.tz);W3.rain.material.opacity=heavy?.6:.4;}
/* ---------- 標籤 ---------- */
function updateLabels(){
 var box=document.getElementById('labels');if(!box)return;
 if(!s.labels||s.exterior){box.innerHTML='';return;}
 var out='',tl=[],w=W3.el.clientWidth,h=W3.el.clientHeight,v=new THREE.Vector3();
 Object.keys(W3.actors).forEach(function(k){var a=W3.actors[k];if(!a.visible||!a.userData.label)return;v.setFromMatrixPosition(a.matrixWorld);v.y+=a.userData.lh||1.1;v.project(W3.cam);
  if(v.z>1||v.x<-1||v.x>1||v.y<-1||v.y>1)return;out+='<span class="lab3d'+(a.userData.lcls?' '+a.userData.lcls:'')+'" style="left:'+((v.x+1)/2*w).toFixed(0)+'px;top:'+((1-v.y)/2*h).toFixed(0)+'px">'+esc(a.userData.label)+'</span>';});
 (W3.tags||[]).forEach(function(tg){if(s.visit&&tg.cls==='ai')return;var txt=tg.f();if(!txt)return;v.setFromMatrixPosition(tg.o.matrixWorld);v.project(W3.cam);if(v.z>1||v.x<-1||v.x>1||v.y<-1||v.y>1)return;
  var plain=String(txt).replace(/<[^>]*>/g,'');tl.push({x:(v.x+1)/2*w,y:(1-v.y)/2*h,w:plain.replace(/[\u3000-\uffff]/g,'mm').length*6.4+20,cls:tg.cls,txt:txt});});
 /* 避免標籤疊埋一齊：由下而上排，撞到就向上移一格 */
 tl.sort(function(a,b){return b.y-a.y;});var put=[];
 tl.forEach(function(L){for(var n=0;n<6;n++){var hit=put.some(function(P){return Math.abs(P.x-L.x)<(P.w+L.w)/2+4&&Math.abs(P.y-L.y)<24;});if(!hit)break;L.y-=25;}put.push(L);
  out+='<span class="tag3d '+L.cls+'" style="left:'+L.x.toFixed(0)+'px;top:'+L.y.toFixed(0)+'px">'+L.txt+'</span>';});
 box.innerHTML=out;
}
/* 水氹：略高過地面（polygonOffset 防閃），雨停 3 小時先乾，夜晚有霓虹倒影色 */
function initPuddles(sc){W3.pud=[];var m=new THREE.MeshPhongMaterial({color:'#2b3540',shininess:90,specular:new THREE.Color('#9fb4c8'),transparent:true,opacity:0,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2,depthWrite:false});W3.pudMat=m;
 [[-8,3.2,.175,1.6],[6,2.4,.175,1.1],[-20,4.4,.175,1.3],[14,1.8,.175,.9],[-3,8.4,.035,2.2],[10,10.8,.035,1.8],[-15,11.6,.035,1.5],[24,8,.035,1.4],[-30,15.4,.175,1.4],[2,15.8,.175,1.2],[30,3.5,.175,1],[-40,8.8,.035,2]].forEach(function(p){
  var g=new THREE.CircleGeometry(p[3],18);var c=new THREE.Mesh(g,m);c.rotation.x=-Math.PI/2;c.position.set(p[0],p[2],p[1]);c.scale.set(1,.6+Math.random()*.4,1);sc.add(c);W3.pud.push(c);});}
function updatePuddles(wet,k,night){if(!W3.pudMat)return;W3.pudMat.opacity=wet?.65*k:0;W3.pudMat.emissive=new THREE.Color(night>.5?'#3a1838':'#000000');W3.pud.forEach(function(c){c.visible=wet&&k>0;});}

