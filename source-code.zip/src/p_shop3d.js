/* p_shop3d：我哋棟唐樓（地下茶餐廳、1 樓美容店），店內設備，人同寵物跟排程郁。 */
/* SHOP 用世界座標（房 z −9.9→−0.1）；buildShop 入面 local z = 世界 z + 5 */
var SHOP={y:3.2,tables:[[-1.2,-6.6],[2,-6.6],[-1.2,-4.3]],tub:[3.7,-8.8],recep:[-2.6,-1.9],door:[-4.1,-.8],bench:[1.2,-.9],lunch:[3.6,-2.6],cages:[]};
for(var ci=0;ci<10;ci++)SHOP.cages.push([-4.25,(ci%2)?1.35:.55,-3.6-Math.floor(ci/2)*1.25]);
function buildShop(sc){
 var y0=SHOP.y,g=vgroup(sc,0,0,-5);W3.shop=g;
 /* 地下茶餐廳 */
 buildCafe(g);
 var n0=g.children.length;
 /* 1 樓 */
 var fm=new THREE.MeshLambertMaterial({map:repTex(floorCanvas(),4.9,4.9),emissive:new THREE.Color('#ffffff'),emissiveIntensity:.02,color:'#c4d4ce'});W3.floorMat=fm;
 var fl=new THREE.Mesh(vbox(9.8,.2,9.8),fm);fl.position.set(0,y0+.1,0);g.add(fl);

 vb(g,10,3,.2,0,y0+1.7,-4.9,'#f2e4d8');vb(g,.2,3,9.6,-4.9,y0+1.7,0,'#ecdccf');vb(g,.2,3,9.6,4.9,y0+1.7,0,'#ecdccf');vb(g,10,.9,.22,0,y0+.65,-4.88,'#0d655f');vb(g,.22,.9,9.57,-4.88,y0+.65,.015,'#0d655f');vb(g,.22,.9,9.57,4.88,y0+.65,.015,'#0d655f');
 vb(g,10,.9,.2,0,y0+.65,4.9,'#d6ddd9');
 var glass=vb(g,9.6,1.9,.05,0,y0+2.05,4.95,'#a8d0e0',{op:.25});
 W3.frontTop=vb(g,10,.35,.2,0,y0+3.05,4.9,'#d6ddd9',{own:1});
 /* 上面幾層（室內模式收埋） */
 var up=vgroup(g,0,0,0);W3.ourUpper=up;
 var tx2=facadeTex('tong'),t2=tx2[0].clone();t2.needsUpdate=true;t2.repeat.set(3.3,3);
 var um=new THREE.MeshLambertMaterial({map:t2}),urm=roofMat();var u=new THREE.Mesh(vbox(10,9,10),[um,um,urm,urm,um,um]);u.position.set(0,y0+3.2+4.5,0);up.add(u);vb(up,3,1.2,3,2,y0+12.8,-2,'#8a8a85');
 /* 直身霓虹招牌 */
 W3.neons.push(sign(g,'毛孩美容',.9,4.2,4.4,y0+3.6,6.2,'#ffe7f3','#0d655f',true,Math.PI/2));
 vb(g,.1,.1,1.4,4.4,y0+5.8,5.5,'#555');
 /* 前台、等候、美容枱、浴缸、吹水機、籠、貨架、冷氣 */
 var R0=SHOP.recep;var Rz=R0[1]+5;vb(g,2.2,1,.8,R0[0],y0+.7,Rz,'#0d655f');vb(g,2.3,.08,.9,R0[0],y0+1.24,Rz,'#f2f2f2');vb(g,.5,.35,.05,R0[0]-.4,y0+1.48,Rz-.1,'#222');
 var bz=SHOP.bench[1]+5;vb(g,2.6,.42,.7,SHOP.bench[0],y0+.42,bz,'#5f8f88');vb(g,2.6,.55,.18,SHOP.bench[0],y0+.85,bz+.28,'#4f7d77');vb(g,.2,.6,.7,SHOP.bench[0]-1.3,y0+.6,bz,'#4f7d77');vb(g,.2,.6,.7,SHOP.bench[0]+1.3,y0+.6,bz,'#4f7d77');
 vb(g,3.2,.02,1.6,SHOP.bench[0],y0+.215,bz-1,'#d9b38c');vb(g,.7,.4,.5,SHOP.bench[0],y0+.4,bz-1.1,'#a0703f');
 /* 盆栽 */
 [[-4.3,4.3],[4.3,4.3],[4.3,-1],[-1.5,-4.4],[3.2,1.6]].forEach(function(q,i){vb(g,.4,.4,.4,q[0],y0+.4,q[1],'#b8653c');[[0,.85,0,.55],[.12,1.1,.1,.4],[-.1,1.15,-.08,.35]].forEach(function(r,k){vb(g,r[3],r[3],r[3],q[0]+r[0],y0+r[1],q[1]+r[2],['#4f8a3c','#5f9c46','#447a35'][(k+i)%3]);});});
 /* 洗衣機同乾衣機、毛巾架、零售貨架、海報、工具、手推車 */
 vb(g,.8,.85,.75,-.6,y0+.62,-4.45,'#e9edf0');vb(g,.8,.85,.75,-.6,y0+1.48,-4.45,'#e3e7ea');vb(g,.45,.45,.03,-.6,y0+.62,-4.06,'#4a5a66');vb(g,.45,.45,.03,-.6,y0+1.48,-4.06,'#4a5a66');
 vb(g,.9,1.4,.35,.6,y0+.9,-4.7,'#c9a27a');[0,1,2].forEach(function(r){[0,1,2].forEach(function(c){vb(g,.26,.12,.28,.32+c*.28,y0+.45+r*.42,-4.65,['#f4b6c2','#9fd3e6','#fff3c4','#c7e8b6'][(r+c)%4]);});});
 vb(g,.4,1.6,1.8,4.6,y0+1,3,'#d9c2a5');[0,1,2,3].forEach(function(r){vb(g,.42,.04,1.8,4.6,y0+.4+r*.45,3,'#b89a78');[0,1,2,3].forEach(function(c){vb(g,.18,.26,.14,4.55,y0+.56+r*.45,2.35+c*.42,['#e85d75','#4fa3e0','#f2c14e','#6cc08b','#a07be0'][(r*2+c)%5]);});});
 var pst=new THREE.MeshLambertMaterial({map:textTex('定期美容　皮膚更健康','#0d655f','#fff8ee',false,512,64)});var ps=new THREE.Mesh(vbox(.04,.5,2.4),pst);ps.position.set(-4.78,y0+2.2,-1.2);g.add(ps);
 [-1.2,2].forEach(function(x){vb(g,.22,.06,.1,x+.35,y0+1.1,-1.45,'#2c2c2c');vb(g,.06,.06,.3,x-.4,y0+1.1,-1.5,'#c0c0c0');});
 vb(g,.6,.5,.9,3,y0+.55,4.2,'#e48aa0');vb(g,.62,.06,.92,3,y0+.82,4.2,'#c86a82');[[-.25,-.4],[.25,-.4],[-.25,.4],[.25,.4]].forEach(function(q){vb(g,.08,.16,.08,3+q[0],y0+.28,4.2+q[1],'#333');});
 /* 窗貼 */
 var wd=new THREE.MeshBasicMaterial({map:textTex('毛孩美容  PET GROOMING','#ffffff','rgba(0,0,0,0)',false,512,64),transparent:true,depthWrite:false});var wdm=new THREE.Mesh(new THREE.PlaneGeometry(4.4,.55),wd);wdm.position.set(1.2,y0+2.6,4.99);g.add(wdm);
 /* 牆上價目板同時鐘 */
 var pb=new THREE.MeshLambertMaterial({map:textTex('價目　洗澡 $280 起　全剪 $440 起','#12201e','#f7f2e8',false,512,64)});var pm=new THREE.Mesh(vbox(3.4,.45,.04),pb);pm.position.set(-1.6,y0+2.55,-4.78);g.add(pm);
 vb(g,.5,.5,.05,2.6,y0+2.55,-4.78,'#ffffff');vb(g,.04,.18,.06,2.6,y0+2.6,-4.75,'#222');
 SHOP.tables.forEach(function(t0,i){if(i>=2)return;var t=[t0[0],t0[1]+5];vb(g,.15,.8,.15,t[0],y0+.6,t[1],'#888');vb(g,1.4,.12,.8,t[0],y0+1.02,t[1],'#5d6d74');vb(g,1.2,.02,.6,t[0],y0+1.09,t[1],'#2f3b40');vb(g,1.7,.02,1.4,t[0],y0+.21,t[1],'#3c4a4f');vb(g,.06,1.3,.06,t[0]-.6,y0+1.7,t[1]-.3,'#999');vb(g,.5,.06,.06,t[0]-.35,y0+2.33,t[1]-.3,'#999');
  vb(g,.25,1.4,.25,t[0]+.95,y0+.9,t[1]-.35,'#e8e8e8');vb(g,.35,.3,.35,t[0]+.95,y0+1.7,t[1]-.35,'#2c6fa8');});
 W3.table3=vgroup(g,0,0,0);var t3=[SHOP.tables[2][0],SHOP.tables[2][1]+5];vb(W3.table3,.15,.8,.15,t3[0],y0+.6,t3[1],'#888');vb(W3.table3,1.4,.12,.8,t3[0],y0+1.02,t3[1],'#5d6d74');
 var T=[SHOP.tub[0],SHOP.tub[1]+5];vb(g,1.8,.9,1.1,T[0],y0+.65,T[1],'#e9eef0');vb(g,1.6,.1,.9,T[0],y0+1.12,T[1],'#7fb7d0');vb(g,.08,.8,.08,T[0]+.7,y0+1.5,T[1]-.4,'#aaa');
 vb(g,1.2,1.5,.9,4,y0+.95,-1.4,'#d9dee0');vb(g,1,1.1,.05,4,y0+.95,-.94,'#9fb6c0',{op:.5});
 SHOP.cages.forEach(function(c){var cz=c[2]+5,cy=y0+c[1]+.05;vb(g,.8,.75,1.1,c[0],cy,cz,'#b8c2c6',{op:.25});vb(g,.84,.05,1.14,c[0],cy-.38,cz,'#59656a');vb(g,.84,.05,1.14,c[0],cy+.38,cz,'#59656a');[-.53,0,.53].forEach(function(dz){vb(g,.05,.75,.05,c[0]+.4,cy,cz+dz,'#59656a');});});
 vb(g,3.2,2.2,.4,1,y0+1.3,-4.6,'#c6b49a');[0,1,2,3].forEach(function(k){vb(g,.25,.3,.2,-.2+k*.8,y0+.9+(k%2)*.7,-4.45,['#e07b39','#2c6fa8','#6b9b5a','#c9466b'][k]);});
 vb(g,1.6,.45,.4,-2,y0+2.7,-4.65,'#f4f4f4');
 vb(g,1,.6,.6,SHOP.lunch[0],y0+.5,SHOP.lunch[1]+5,'#8a7a66');
 /* 店內燈 */
 W3.shopLights=[];[[-2,-2.5],[2,2]].forEach(function(p){var pl=new THREE.PointLight('#fff1dc',.5,12,1.5);pl.position.set(p[0],y0+2.9,p[1]-5);sc.add(pl);W3.shopLights.push(pl);});
 /* 1 樓所有嘢放入 W3.f1，睇地下時收埋 */
 var f1=vgroup(null,0,0,0);g.children.slice(n0).forEach(function(ch){g.remove(ch);f1.add(ch);});g.add(f1);W3.f1=f1;fl.receiveShadow=true;
 /* 3D 標籤：AI 崗位狀態同設備 */
 W3.tags=[];function tag(x,y,z,cls,f){var o=new THREE.Object3D();o.position.set(x,y,z);sc.add(o);W3.tags.push({o:o,cls:cls,f:f});}
 var aiPos={reply:[-2.6,-1.9,0],sched:[-3.6,-3.4,.2],acct:[-1.2,-2.8,.75],recall:[-3.2,-1.2,.7],file:[.4,-7.6,.3],media:[1.2,-9.4,0]};
 ROLES.forEach(function(r,i){var p=aiPos[r.id];tag(p[0],y0+2.1+p[2],p[1],'ai',function(){var l=s.lv[r.id];if(!l||s.floorG)return null;return '<span class="sl">'+r.seal+'</span>'+Math.round(rampPct(r.id)*100)+'% AI L'+l;});});
 SHOP.tables.forEach(function(tb,i){tag(tb[0],y0+1.6,tb[1]+.5,'eq',function(){if(i>=s.base.tables||s.floorG)return null;var V=shopView(),ap=(V?V.appts:todayAppts()).filter(function(a){return a.tb===i&&a.g!=null&&a.st!=='lost'&&a.st!=='cancel'&&a.st!=='noshow';}).sort(function(a,b){return a.a-b.a;});
  var cur=ap.filter(function(a){return a.st==='doing';})[0],nx=ap.filter(function(a){return a.a>s.t&&(a.st==='booked'||a.st==='arrived');})[0];
  return '美容枱 '+(i+1)+(cur?' · '+esc(cur.pet)+' 做緊':'')+(nx?' · 下一隻 '+hm(nx.a)+' '+esc(nx.pet):'');});});
 tag(SHOP.tub[0],y0+1.7,SHOP.tub[1],'eq',function(){return s.floorG?null:'浴缸';});
 tag(.6,2.4,-1,'eq',function(){return s.floorG||s.exterior?'好運茶餐廳 · 而家 '+((W3.cafe&&W3.cafe.n)||0)+' 位客':null;});
 tag(-4.25,y0+2.1,-6,'eq',function(){if(s.floorG)return null;var ap=(shopView()?shopView().appts:todayAppts()).filter(function(a){return a.st==='arrived'||a.st==='done';}).length;return '籠位 '+ap+'／'+SHOP.cages.length;});
 W3.blds.push({box:new THREE.Box3(new THREE.Vector3(-5,y0+3.2,-10),new THREE.Vector3(5,y0+12.2,0)),mats:[um,urm],faded:false,ours:1});
}
/* 世界座標（棟樓 group 喺 z −5） */
function SP(x,z,y){return new THREE.Vector3(x,(y==null?SHOP.y+.2:y),z);}
function actor(key,mk){var a=W3.actors[key];if(!a){a=mk();W3.sc.add(a);W3.actors[key]=a;W3.pick.push(a);a.userData.seen=1;}a.visible=true;a.userData.alive=W3.frame;return a;}
function moveTo(a,p,dt,inst,v){var d=p.clone().sub(a.position);d.y=0;var len=d.length(),sp=(v||staffV())*dt,moved=0;
 if(inst||len>12){a.position.copy(p);}else if(len<=sp){moved=len;a.position.copy(p);}else{moved=sp;a.position.add(d.normalize().multiplyScalar(sp));a.position.y=p.y;turnTo(a,Math.atan2(d.x,d.z),dt);}
 if(a.userData.legs)stride(a,moved,dt);}
/* 人物用水平圓形碰撞體；樓上同街道分開計，避免不同樓層互相推開。 */
function separatePeople(){var people=[],origin={};Object.keys(W3.actors).sort().forEach(function(k){var a=W3.actors[k],p=a.userData.pick;if(a.visible&&a.userData.alive===W3.frame&&p&&(p.type==='staff'||p.type==='owner')){people.push(a);if(/^w/.test(k))origin[k]=a.position.clone();}});
 (W3.peds||[]).concat(W3.cross||[]).forEach(function(a){if(a.visible)people.push(a);});
 var minDist=.82;for(var pass=0;pass<16;pass++){var changed=false;
  for(var i=0;i<people.length;i++)for(var j=i+1;j<people.length;j++){var a=people[i].position,b=people[j].position;if(Math.abs(a.y-b.y)>1)continue;var dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz);if(d>=minDist)continue;
   if(d<.0001){var angle=((i*17+j*31)%32)*Math.PI/16;dx=Math.cos(angle);dz=Math.sin(angle);d=1;}else{dx/=d;dz/=d;}
   var push=(minDist-Math.min(d,minDist))/2;if(push<.0001)push=minDist/2;
   a.x-=dx*push;a.z-=dz*push;b.x+=dx*push;b.z+=dz*push;
   [a,b].forEach(function(p){if(p.y>2){p.x=clamp(p.x,-4.45,4.45);p.z=clamp(p.z,-9.45,-.52);}});changed=true;
  }if(!changed)break;
 }
 Object.keys(origin).forEach(function(k){var a=W3.actors[k],pet=W3.actors['q'+k.slice(1)],dx=a.position.x-origin[k].x,dz=a.position.z-origin[k].z;a.userData.collisionX=(a.userData.collisionX||0)+dx;a.userData.collisionZ=(a.userData.collisionZ||0)+dz;var prev=a.userData.collisionPrev;if(prev&&Math.abs(prev.y-a.position.y)<1){var mx=a.position.x-prev.x,mz=a.position.z-prev.z,dist=Math.hypot(mx,mz);if(dist>.001&&dist<1)a.rotation.y=Math.atan2(mx,mz);}if(!pet||!pet.visible||pet.userData.alive!==W3.frame)return;pet.position.x+=dx;pet.position.z+=dz;if(pet.position.y>2){pet.position.x=clamp(pet.position.x,-4.45,4.45);pet.position.z=clamp(pet.position.z,-9.45,-.52);}});
}
function syncShop(dt){
 W3.frame=(W3.frame||0)+1;if(s&&!s.paused&&!s.modal)trackRate(dt);if(s.floorG){Object.keys(W3.actors).forEach(function(k){W3.actors[k].visible=false;});return;}var V=shopView(),t=s.t,ap=V?V.appts:todayAppts(),gs=V?V.gs:groomers(),busyTab={},cageI=0;
 W3.table3.visible=s.base.tables>=3;
 var shifts=V?V.shifts.filter(function(){return t>=OPEN_MIN-20&&t<=CLOSE_MIN+20;}):activeStaff().filter(function(x){var shift=staffShift(x,s.day);return shift&&(x.role==='asst'?t>=shift.start&&t<shift.end:t>=shift.start-20&&t<=shift.end+20);});
 var pre=V?'v':'';
 var bathing=null;
 ap.forEach(function(a){
  if(a.st==='lost'||a.g==null)return;var show=(a.st==='arrived'||a.st==='doing'||a.st==='done');
  if(!show)return;
  /* 主人仲拖住佢喺路上（未到前台，或者已經接走），籠入面就唔好再出現多一隻 */
  if(!V&&W3.jr&&W3.jrDay===s.day&&W3.jrS===s){var Jd=W3.jr['d'+a.id],Jk=W3.jr['k'+a.id];if((Jd&&Jd.st==='in')||(Jk&&(Jk.st==='out'||Jk.st==='gone'))){if(W3.actors['p'+a.id])W3.actors['p'+a.id].visible=false;return;}}
  var pet=actor(pre+'p'+a.id,function(){var m=makePet(a.seg,a.id);m.userData.pick={type:'pet',id:a.id};return m;});
  pet.userData.label=a.pet;pet.userData.lh=.9;pet.userData.lcls=a.inc?'bad':'';
  var tb=SHOP.tables[a.tb]||SHOP.tables[0],gi=gs.map(function(g){return g.id;}).indexOf(a.g);
  if(a.st==='doing'){
   var frac=(t-a.a)/Math.max(1,a.b-a.a),asst=shifts.filter(function(x){return x.role==='asst';})[0];
   if(asst&&frac<.35&&!bathing){bathing=a;moveTo(pet,SP(SHOP.tub[0],SHOP.tub[1],SHOP.y+1.1),dt,1);}
   else{moveTo(pet,SP(tb[0],tb[1],SHOP.y+1.06),dt,1);busyTab[a.g]=a;}
   setGroomed(pet,frac>.6);pet.rotation.y=0;
  } else {var c=SHOP.cages[cageI++%SHOP.cages.length];moveTo(pet,SP(c[0],c[2],SHOP.y+c[1]-.5+.2),dt,1);setGroomed(pet,a.st==='done');pet.rotation.y=Math.PI/2;}
 });
 /* 主人：落狗同接狗 */
 ap.forEach(function(a){
  if(a.out!=='ok'||a.g==null||!V)return;var phase=null;
  if(t>=a.a-25&&t<a.a-5)phase=[(t-(a.a-25))/20,'drop'];else if(t>=a.b+15&&t<a.b+40)phase=[(t-(a.b+15))/25,'pick'];
  var key=pre+'o'+a.id;if(!phase){if(W3.actors[key])W3.actors[key].visible=false;return;}
  var o=actor(key,function(){var m=makePerson({i:a.id,long:a.id%2});m.userData.pick={type:'owner',id:a.id};return m;});
  o.userData.label=a.owner;o.userData.lh=1.5;var k=phase[0],p=k<.35?SP(SHOP.door[0],SHOP.door[1]):k<.7?SP(SHOP.recep[0]+.3,SHOP.recep[1]+1.1):SP(SHOP.door[0],SHOP.door[1]);
  if(k<.05)o.position.copy(SP(SHOP.door[0],SHOP.door[1]));moveTo(o,p,dt);
 });
 /* 自己間店：主人一程路（街 → 樓梯 → 1 樓前台 → 原路出返街），落狗嗰程拖住狗入嚟，接狗嗰程拖住剪好嘅狗出去 */
 ap.forEach(function(a){
  if((a.out!=='ok'&&a.out!=='cancel')||a.g==null||V)return;
  var J=custTrip(a,'d',dt);if((!J||J.st==='gone')&&a.out==='ok'&&a.st!=='cancel')J=custTrip(a,'k',dt)||J;
  var kw='w'+a.id,kq='q'+a.id;if(!J||J.st==='gone'){[kw,kq].forEach(function(k){if(W3.actors[k])W3.actors[k].visible=false;});return;}
  var pick=J===(W3.jr||{})['k'+a.id];
  var o=actor(kw,function(){var m=makePerson({i:a.id,long:a.id%2});m.userData.pick={type:'owner',id:a.id};return m;});
  o.userData.label=a.owner+(J.abort?' · 取消咗預約':'');o.userData.lh=1.5;
  var prev=o.position.clone(),jump=prev.distanceTo(J.pos)>2.5||!o.userData.walked;o.userData.collisionPrev=prev;if(jump){o.userData.collisionX=0;o.userData.collisionZ=0;}
  var ease=Math.max(0,1-dt*1.5);o.userData.collisionX=(o.userData.collisionX||0)*ease;o.userData.collisionZ=(o.userData.collisionZ||0)*ease;
  o.position.copy(J.pos);o.position.x+=o.userData.collisionX;o.position.z+=o.userData.collisionZ;o.userData.walked=1;
  var moved=jump?0:Math.hypot(o.position.x-prev.x,o.position.z-prev.z);
  if(J.st==='desk')turnTo(o,Math.PI,dt);else if(jump)o.rotation.y=Math.atan2(J.dir.x,J.dir.z);else if(moved>1e-4)turnTo(o,Math.atan2(o.position.x-prev.x,o.position.z-prev.z),dt);
  stride(o,moved,dt);
  /* 狗跟喺主人後面少少：落狗嗰程到前台之前、接狗嗰程離開前台之後 */
  if(J.st==='phone'&&o.userData.arms){o.userData.arms[1].rotation.x=-2.5;o.userData.arms[1].rotation.z=.35;}else if(o.userData.arms)o.userData.arms[1].rotation.z=0;
  var withPet=J.abort?true:pick?J.st==='out':J.st!=='out';
  if(!withPet){if(W3.actors[kq])W3.actors[kq].visible=false;return;}
  var pet=actor(kq,function(){var m=makePet(a.seg,a.id);m.userData.pick={type:'pet',id:a.id};return m;});
  setGroomed(pet,pick);pet.userData.label=a.pet;pet.userData.lh=.8;
  var ry=o.rotation.y,fw=new THREE.Vector3(Math.sin(ry),0,Math.cos(ry)),rt=new THREE.Vector3(fw.z,0,-fw.x);
  var want=o.position.clone().addScaledVector(fw,-.75).addScaledVector(rt,.3),pp=pet.position.clone();
  /* 狗到咗樓上就留喺房間邊界內，唔好因跟隨偏移而穿出前牆。 */
  if(o.position.y>2){want.x=clamp(want.x,-4.45,4.45);want.z=clamp(want.z,-9.45,-.52);}pp.y=want.y;
  if(jump||pp.distanceTo(want)>2.5||!pet.userData.walked){pet.position.copy(want);pet.rotation.y=ry-Math.PI/2;pet.userData.walked=1;stride(pet,0,dt);}
  else{var step=want.clone().sub(pp),k=Math.min(1,dt*8);step.multiplyScalar(k);var mv=Math.hypot(step.x,step.z);pet.position.copy(pp.add(step));
   if(mv>1e-4)turnTo(pet,Math.atan2(step.x,step.z)-Math.PI/2,dt);else if(J.st==='desk')turnTo(pet,ry-Math.PI/2,dt);stride(pet,mv,dt);}
  pet.position.y=want.y+(pet.userData.bob||0);
 });
 /* 員工 */
 shifts.forEach(function(x,i){
  var key=pre+'s'+x.id,ap2=busyTab[x.id];
  var m=actor(key,function(){var pp=makePerson({i:x.id+7,apron:x.role==='owner'?'#0d655f':x.role==='groomer'?'#d47c9c':'#e0a33a',long:x.name.length%2});pp.userData.pick={type:'staff',id:x.id};return pp;});
  m.userData.label=x.name.replace('（老闆）','');m.userData.lh=1.5;m.userData.lcls='staff';
  var gi=gs.indexOf(x),tb=SHOP.tables[(gi<0?0:gi)%SHOP.tables.length],p;
  var lunch=t>=LUNCH[0]&&t<LUNCH[1];
  if(lunch)p=SP(SHOP.lunch[0]+(i%2)*.7,SHOP.lunch[1]+.8);
  else if(ap2)p=SP(tb[0],tb[1]+.75);
  else if(x.role==='asst')p=bathing?SP(SHOP.tub[0]-1.2,SHOP.tub[1]+.2):SP(-3.2,-4.2);
  else if(x.role==='owner')p=SP(SHOP.recep[0]+1.5,SHOP.recep[1]-.2);
  else p=SP(tb[0]+.8,tb[1]+.9);
  moveTo(m,p,dt);if(ap2&&!lunch)m.rotation.y=Math.PI;
 });
 Object.keys(W3.actors).forEach(function(k){var a=W3.actors[k];if(a.userData.alive!==W3.frame){a.visible=false;if(/^v?[poqw]/.test(k)){if(W3.frame-a.userData.alive>600){W3.sc.remove(a);W3.pick.splice(W3.pick.indexOf(a),1);delete W3.actors[k];}}}});
 separatePeople();
}
