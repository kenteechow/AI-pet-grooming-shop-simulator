/* p_main：開局選擇、遊戲主循環、快捷鍵、遊戲點擊分派。 */
var GAME={on:false,last:0,hudT:0,panT:0,lastModal:null};
function startGame(id,seed){
 $('#openings').hidden=true;$('#title').hidden=true;$('#sb').hidden=true;$('#game').hidden=false;$('#game').classList.remove('titlemode');
 if(id==='cont'){if(!load())newGame('community');}else newGame(id,seed);
 if(id==='solo')s.modal={type:'soloIntro'};
 W3.lightLevel=null;
 if(s.fd&&!DOCK.some(function(d){return d[0]==='fd';}))DOCK.push(['fd','創','創辦人']);if(!s.fd)DOCK=DOCK.filter(function(d){return d[0]!=='fd';});
 if(!W3.tried){W3.tried=1;$('#game').innerHTML=hudHTML();init3D($('#view'));var pn=$('#panel');pn.addEventListener('mouseenter',function(){PANEL.hover=1;});pn.addEventListener('mouseleave',function(){PANEL.hover=0;});}
 else{resize3D();Object.keys(W3.actors).forEach(function(k){W3.sc.remove(W3.actors[k]);});W3.actors={};W3.pick=[];}
 PANEL.id=null;s.sel=null;if(!s.months.length&&s.day<7)s.newFlag.ai=1;renderDemo();
 if(typeof OPTS!=='undefined'){if(id!=='cont')s.speed=OPTS.speed;s.labels=OPTS.labels;EDGE.on=OPTS.edge;if(W3.sun)W3.sun.castShadow=!!OPTS.shadow;}if(W3.on)camJump(CAM_DEF);
 renderHUD();renderPanel();renderModal();renderSel();
 startLoop();
}
/* 只准有一個 loop 喺度跑（之前由標題入遊戲會開多一個，每幀畫兩次） */
function startLoop(){if(GAME.raf)cancelAnimationFrame(GAME.raf);GAME.on=true;GAME.last=performance.now();GAME.raf=requestAnimationFrame(loop);}
function loop(ts){
 if(!GAME.on)return;var dt=Math.min(.1,(ts-GAME.last)/1000);GAME.last=ts;
 if(s&&s.bg){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;}s.evQ=[];CT.th=.55+.35*Math.sin(W3.t*.05);CT.tx=-7;CT.tz=-4;}
 if(s&&!s.paused&&!s.modal&&!s.demoFF&&!(typeof handsLock==='function'&&handsLock())){var m=dt*12*s.speed;
  /* 白天每次畫面最多跨過一個分鐘；晚間可加快。 */
  /* 非營業時間（v0.14）：快速推過去，光線照樣跟時間漸變 */
  if(skipOn()){m=Math.min(Math.max(m,dt*SKIP.rate),skipCap());}
  else if(s.t>=DAY0&&s.t<1260)m=Math.min(m,Math.floor(s.t)+1-s.t);
  else if(s.t<DAY0)m=Math.min(m,DAY0-s.t);
  else m=Math.min(m,DAY1-s.t);
  /* 保險：可推嘅時間細到冇意義（浮點殘餘）都至少推一點，唔會原地踏步 */
  if(m<1e-6)m=1e-3;
  while(m>1e-8&&!s.modal){var st=Math.min(m,5);advance(st);m-=st;}
 }
 if(s&&!s.bg){var clk=document.querySelector('#hudTL .clock .big');if(clk){var cv=hm(Math.floor(s.t));if(clk.textContent!==cv)clk.textContent=cv;}}
 if(W3.on)update3D(dt);
 GAME.hudT+=dt;GAME.panT+=dt;
 if(GAME.lastModal!==s.modal){GAME.lastModal=s.modal;renderModal();renderHUD();renderPanel();}
 if(GAME.hudT>.25&&!s.bg){GAME.hudT=0;renderHUD();if(s.sel)renderSel();}
 if(GAME.panT>1&&PANEL.id){GAME.panT=0;if(!document.querySelector('#panel :focus')&&!PANEL.hover&&!(PANEL.tap&&performance.now()-PANEL.tap<2500)&&(typeof DRAG==='undefined'||DRAG==null))renderPanel();}
 GAME.raf=requestAnimationFrame(loop);
}
document.addEventListener('keydown',function(e){
 if(!GAME.on||!s||/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))return;
 var k=e.key;
 if(k==='Escape'){e.preventDefault();if(s.modal&&s.modal.type==='settings')s.modal=null;else if(!s.modal)s.modal={type:'settings'};return;}
 if(s.modal)return;
 if(k===' '){e.preventDefault();s.paused=!s.paused;renderHUD();if(s.demo)renderDemo();return;}
 var sp={'1':1,'2':3,'3':10,'4':30}[k];if(sp){s.speed=sp;s.paused=false;s.demoAuto=false;renderHUD();if(s.demo)renderDemo();return;}
 if(k==='0'&&s.demo){s.demoAuto=true;s.paused=false;renderHUD();renderDemo();return;}

});
document.addEventListener('change',function(e){if(e.target.matches('[data-act=review]')&&s){s.review=e.target.checked?1:0;news('AI','人工審核：'+(s.review?'開':'關'));renderPanel();}});
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el)return;var a=el.getAttribute('data-act');
 if(a==='openings'){showOpenings();return;}
 if(a==='otitle'){$('#openings').hidden=true;$('#title').hidden=false;return;}
 if(a==='start'){startGame(el.getAttribute('data-id'));return;}
 if(a==='cont'){startGame('cont');return;}
 if(!GAME.on||!s)return;
 if(a==='spd'){var v=+el.getAttribute('data-v');if(v===0)s.paused=!s.paused;else if(v===-1){s.demoAuto=true;s.paused=false;}else{s.speed=v;s.paused=false;s.demoAuto=false;}renderHUD();if(s.demo)renderDemo();return;}
 if(a==='panel'){openPanel(el.getAttribute('data-p'));return;}
 if(a==='pclose'){PANEL.id=null;renderPanel();renderHUD();return;}
 if(a==='psub'){PANEL.sub=el.getAttribute('data-s');var b=$('#panel .p-body');if(b)b.scrollTop=0;renderPanel();return;}
 if(a==='sfil'){var k=el.getAttribute('data-k');SCHED.filter[k]=SCHED.filter[k]?0:1;renderPanel();return;}
 if(a==='sprob'){SCHED.probOnly=SCHED.probOnly?0:1;renderPanel();return;}
 if(a==='appt'){SCHED.sel=+el.getAttribute('data-id');s.sel={type:'pet',id:SCHED.sel};renderPanel();renderSel();return;}
 if(a==='hire'){hire(+el.getAttribute('data-id'));renderPanel();renderHUD();return;}
 if(a==='fire'){fire(+el.getAttribute('data-id'));renderPanel();return;}
 if(a==='deploy'){deploy(el.getAttribute('data-r'),+el.getAttribute('data-l'));renderPanel();renderHUD();return;}
 if(a==='evch'){chooseEvent(+el.getAttribute('data-i'));return;}
 if(a==='mclose'){s.modal=null;nextEvent();return;}
 if(a==='mopen'){s.modal={type:'month',rec:s.months[+el.getAttribute('data-i')]};return;}
 if(a==='settings'){s.modal={type:'settings'};return;}
 if(a==='shadowpanel'){s.modal=null;renderModal();if(PANEL.id==='shadow')PANEL.id=null;openPanel('shadow');return;}
 if(a==='labels'){s.labels=s.labels?0:1;renderModal();return;}
 if(a==='camreset'){if(W3.on)camReset();return;}
 if(a==='savenow'){save();news('存檔','已儲存');renderHUD();return;}
 if(a==='ext'){s.exterior=s.exterior?0:1;renderHUD();return;}
 if(a==='floor'){s.floorG=s.floorG?0:1;s.exterior=0;CT.ty=s.floorG?.4:3.2;camFly(0,-4.5,Math.min(CT.rad,18));if(s.floorG){CT.tilt=-.3;CT.th=.25;}else CT.tilt=0;renderHUD();return;}
 if(a==='shadow'){if(W3.sun)W3.sun.castShadow=!W3.sun.castShadow;renderModal();return;}
 if(a==='edge'){EDGE.on=EDGE.on?0:1;renderModal();return;}
 if(a==='selx'){s.sel=null;renderSel();return;}
});
