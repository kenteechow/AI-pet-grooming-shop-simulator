/* p_events：事件。每個事件有選擇（優點／缺點）同「如果有 AI 會點」。when 過濾，只出跟你真係有做嘅生意有關嘅事件。 */
var EVENTS={
 afterhours:{title:'收工後嘅查詢',when:function(){return !s.lv.reply;},body:function(){return '晚上 11 點，有主人 WhatsApp 問：「比熊全剪幾錢？聽日有冇位？」你已經收咗工。';},
  ai:'「覆」L1 會即刻發離線訊息同價目；L2 會按相片估價錢範圍，你聽朝一撳確認；L3 會直接開位收訂金。',
  ch:[{t:'而家即刻覆',pro:['個客多數會訂'],con:['老闆士氣 −5%'],f:function(){own().morale-=.05;s.S.backlog+=1;}},
      {t:'聽朝先覆',pro:['休息到'],con:['約三成機會個客去咗第二間'],f:function(){}},
      {t:'部署「覆」L1 離線訊息（免費）',pro:['以後收工後都有自動回覆','冇建置費'],con:['只係目錄同價目，唔會報價'],f:function(){deploy('reply',1);}}]},
 dormant:{title:'第一批沉睡客',body:function(){return '你翻查紀錄，有 '+Math.round(sum(s.S.dorm))+' 位客人超過週期冇再嚟。佢哋點解唔嚟？';},
  ai:'「回」L3 會讀對話同紀錄，將沉睡客分成忘記、價錢、搬屋、體驗、健康、轉店六類。AI 提醒只救到「忘記」同部分「價錢」。',
  ch:[{t:'逐個打電話問原因',pro:['知道真正原因','救返幾位'],con:['老闆用 3 小時'],f:function(){var n=Math.min(4,s.S.dorm[0]);s.S.dorm[0]-=n;addAct(s.S,n);own().morale-=.03;news('客人','打電話救返 '+Math.round(n)+' 位沉睡客');}},
      {t:'全部發 9 折優惠',pro:['救返啲價錢敏感客'],con:['已經過身或者搬咗嘅寵物主人會覺得唔舒服','蝕毛利'],f:function(){var n=s.S.dorm[0]*.05+s.S.dorm[1]*.06;s.S.dorm[0]*=.95;s.S.dorm[1]*=.94;addAct(s.S,n);s.cash-=n*48;s.S.rating-=.02;news('客人','發咗優惠，救返 '+Math.round(n)+' 位');}},
      {t:'暫時唔理',pro:['唔使用時間'],con:['沉睡客會慢慢永久流失'],f:function(){}}]},
 oldDog:{title:'老狗唔舒服',body:function(){return '14 歲西施「冬菇」洗澡洗到一半開始氣喘，舌頭有啲紫。';},
  ai:'AI 唔可以判斷健康風險。「檔」L3 只會喺開工前提示「有心臟病紀錄」，停唔停一定要美容師決定。',
  ch:[{t:'即刻停手，通知主人，建議睇獸醫',pro:['安全第一','主人信任升'],con:['今次少收 HK$300'],f:function(){s.cash-=300;s.S.rating=Math.min(5,s.S.rating+.03);news('事件','停手通知主人，冬菇主人多謝你');}},
      {t:'放慢啲做埋佢',pro:['唔使退錢'],con:['有機會出大事'],f:function(){if(R()<.3)queueEvent('serious',{a:{pet:'冬菇',owner:'梁太'}});else news('事件','冬菇做完，主人唔知發生咩事');}}]},
 bite:{title:'美容師被咬',body:function(){var g=emp();return (g?g.name:'美容師')+'幫一隻柴犬剪甲，手被咬傷，流咗唔少血。';},when:function(){return !!emp();},
  ai:'「檔」L2 嘅「咬人」標籤可以預先提醒戴口罩、兩個人做，但安撫寵物要靠人。',
  ch:[{t:'即刻睇醫生，放 3 日病假',pro:['士氣升','工傷要向保險公司申報，按《僱員補償條例》處理醫藥費同病假錢'],con:['下週預估產能少約 12%（本週已排嘅預約不變）','病假期間要先照條例出錢，保險公司審核後先賠'],f:function(){addMod('capMult','mul',.88,2,false,'美容師病假');var g=emp();if(g)g.morale=Math.min(1,g.morale+.08);}},
      {t:'包紮後叫佢頂住',pro:['產能唔受影響'],con:['士氣大跌','下週事故率上升'],f:function(){var g=emp();if(g)g.morale-=.15;addMod('incidentMult','mul',1.4,2,false,'美容師手傷');}}]},
 equipment:{title:'吹水機出現耗損',body:function(){return '店內一部吹水機用久咗，風力變弱，仲有異聲。要安排檢查或更換，否則會拖慢吹乾時間。';},
  ai:'AI 可以幫手記錄使用時間、整理維修紀錄同提醒檢查；設備安全同實際維修仍要由人處理。',
  ch:[{t:'停用檢查並維修',pro:['處理設備問題'],con:['維修費 HK$600（遊戲估算）','下週預估產能少 4%（本週已排嘅預約不變）'],f:function(){s.cash-=600;addMod('capMult','mul',.96,2,false,'設備維修');}},
      {t:'更換吹水機',pro:['換上新設備'],con:['設備費 HK$1,800（遊戲估算）'],f:function(){s.cash-=1800;}},
      {t:'暫時停用，稍後再處理',pro:['即時唔使支出'],con:['下週預估產能少 10%（本週已排嘅預約不變）'],f:function(){addMod('capMult','mul',.90,2,false,'設備停用');}}]},
 style:{title:'剪錯造型投訴',body:function(){return '黃小姐喺 IG 出 post：「隻貴婦剪到好似老鼠，同講好嘅唔同」，有 40 個 like。';},
  ai:'「影」L2 報告卡有美容前後相，L3 可以喺開剪前發參考相畀主人確認，減少誤會。',
  ch:[{t:'退一半錢，私訊道歉',pro:['口碑損失細'],con:['少收 HK$260'],f:function(){s.cash-=260;s.S.rating=Math.min(5,s.S.rating+.01);}},
      {t:'下次免費修剪',pro:['留住個客'],con:['下次少收一單'],f:function(){s.cash-=200;}},
      {t:'解釋係主人自己要求，唔退錢',pro:['唔使退錢'],con:['IG 負評擴散，評分跌'],f:function(){s.S.rating-=.06;addMod('inqMult','mul',.92,2,false,'IG 負評');}}]},
 typhoon:{title:'八號風球',body:function(){return '天文台預告今日上午改掛八號風球，今日 '+todayAppts().filter(function(a){return a.st!=='lost';}).length+' 個預約要全部改期。';},
  ai:'「覆」L3 會自動 WhatsApp 全部主人改期，畀返新時段；冇 AI 就要老闆逐個打電話（大約 2 小時）。',
  ch:[{t:'停業，通知全部主人改期',pro:['安全'],con:['今日冇收入','冇 AI 嘅話老闆要打 2 小時電話'],f:function(){var ap=todayAppts().filter(function(a){return a.st==='booked'&&a.out!=='noshow';});ap.forEach(function(a){a.st='cancel';a.out='cancel';a.refill=false;});s.S.backlog+=ap.length*(s.lv.reply>=3?.85:s.lv.reply>=1?.6:.5);if(!s.lv.reply)own().morale-=.05;news('天氣','八號風球停業，'+ap.length+' 個預約改期');}}]},
 cny:{title:'農曆新年前爆滿',body:function(){return '新年前三個星期，查詢多咗五成，個個都想「新年新造型」。';},
  ai:'「排」L3 會保住熟客時段，新客超出產能就婉拒並畀年後時段；冇 AI 好容易超額接單，令美容師做到夜。',
  ch:[{t:'新年價加 10%',pro:['每隻多收'],con:['價錢敏感客會走'],f:function(){addMod('priceIdx','mul',1.1,3,false,'新年價');addMod('inqMult','mul',1.35,3,false,'新年前');}},
      {t:'延長營業 1 小時',pro:['多做幾隻'],con:['員工士氣跌','趕工事故率升'],f:function(){addMod('openH','add',1,3,false,'新年延長營業');addMod('inqMult','mul',1.5,3,false,'新年前');activeStaff().forEach(function(x){x.morale-=.08;});}},
      {t:'照舊',pro:['唔使改'],con:['好多查詢接唔到'],f:function(){addMod('inqMult','mul',1.5,3,false,'新年前');}}]},
 shed:{title:'換毛季',body:function(){return '天氣轉，柴犬、柯基、金毛開始大量甩毛，去底毛嘅查詢多咗。';},ai:'「回」L2 可以按品種預先提醒雙層毛犬主人預約去底毛。',
  ch:[{t:'知道',pro:['查詢多一成半，持續 4 週'],con:['去底毛好花時間'],f:function(){addMod('inqMult','mul',1.15,4,true,'換毛季');}}]},
 humid:{title:'黃梅天',body:function(){return '連續幾日濕度 95%，皮膚敏感、真菌嘅狗多咗。';},ai:'「檔」L3 會提示有皮膚紀錄嘅寵物用低敏洗頭水，但唔會診斷。',
  ch:[{t:'知道',pro:[],con:['皮膚問題機率升 5 成，持續 4 週'],f:function(){addMod('skinRate','mul',1.5,4,true,'黃梅天');}}]},
 rent:{title:'業主加租',body:function(){return '業主通知續租要加 10%，月租由 '+hk(s.base.rent)+' 加到 '+hk(s.base.rent*1.1)+'。';},ai:'AI 改變唔到租金，但「數」L3 可以試算加租後要多做幾多隻先打和。',
  ch:[{t:'接受',pro:['唔使搬'],con:['每月多 '+'10% 租'],f:function(){s.base.rent*=1.1;}},
      {t:'講價',pro:['一半機會只加 5%'],con:['一半機會業主唔讓步'],f:function(){s.base.rent*=R()<.5?1.05:1.1;news('事件','續租後月租 '+hk(s.base.rent));}}]},
 comp:{title:'對面開咗新店',body:function(){return '對面街新開一間寵物美容，開張價平兩成。';},ai:'AI 前台回覆快啲可以留住新客，但價錢敏感客始終會試。「回」L3 會分出「轉咗第二間」嘅客。',
  ch:[{t:'跟減 10%',pro:['價錢敏感客留低'],con:['每隻少收'],f:function(){addMod('compGap','set',.1,8,true,'對手開張');addMod('priceIdx','mul',.9,8,false,'跟減');}},
      {t:'加值：免費刷牙、報告卡',pro:['唔使減價'],con:['每隻多啲用品同時間'],f:function(){addMod('compGap','set',.14,8,true,'對手開張');addMod('addonRate','add',.1,8,false,'加值服務');addMod('consum','add',6,8,false,'加值服務');}},
      {t:'唔理',pro:['唔使改'],con:['價錢敏感客流失加快'],f:function(){addMod('compGap','set',.2,8,true,'對手開張');}}]},
 waBan:{title:'WhatsApp 帳號被限制',body:function(){return '太多客人封鎖你嘅推廣訊息，WhatsApp 限制咗你嘅帳號一星期唔可以發推廣。';},when:function(){return s.lv.recall>=2;},
  ai:'推廣訊息要有上限，冇同意直銷嘅客唔好發。「回」L3 會按原因篩選，寵物健康類唔發優惠。',
  ch:[{t:'知道，減少推廣',pro:['帳號安全'],con:['今個星期查詢少兩成'],f:function(){addMod('inqMult','mul',.8,1,false,'WhatsApp 限制');}}]},
 aiPrice:{title:'AI 報錯價',body:function(){return '客人截圖：AI 話大狗去底毛 HK$400，實際應該 HK$850。冇人審核就發咗出去。';},when:function(){return s.lv.reply>=2&&!s.review;},
  ai:'呢個就係冇人工審核嘅代價。開返審核，報價超出範圍要轉人。',
  ch:[{t:'照 AI 報價做',pro:['客人滿意'],con:['蝕 HK$450'],f:function(){s.cash-=450;}},
      {t:'解釋後收返原價',pro:['唔蝕錢'],con:['客人覺得被呃，評分跌'],f:function(){s.S.rating-=.04;}},
      {t:'開返人工審核',pro:['之後錯少好多'],con:['老闆每日要睇 AI 回覆'],f:function(){s.review=1;}}]},
 poach:{title:'美容師被挖角',body:function(){var g=lowMorale();return (g?g.name:'美容師')+'話隔籬區有間店出多 15% 人工請佢。';},when:function(){return !!lowMorale();},
  ai:'AI 留唔住人。但如果 AI 幫佢減少打字同覆訊息，工作壓力會細啲。',
  ch:[{t:'加薪 15%',pro:['留住佢同佢嘅熟客'],con:['每月人工多'],f:function(){var g=lowMorale();if(g){g.wage*=1.15;g.morale=Math.min(1,g.morale+.25);}}},
      {t:'由佢走',pro:['慳人工'],con:['熟客會跟佢走','要請人'],f:function(){var g=lowMorale();if(g)g.leaving=s.day+7;}}]},
 fungus:{title:'皮膚真菌',body:function(){return '有隻狗帶咗皮膚真菌嚟，你懷疑美容枱同大風量吹風機（業內叫吹水機）可能沾到。';},
  ai:'「檔」L2 標籤會記低邊隻有皮膚問題，下次排喺最後一個，用完即刻消毒。',
  ch:[{t:'全面消毒，停一張枱一日',pro:['唔會傳開'],con:['用品 HK$800','今個星期產能少少'],f:function(){s.cash-=800;addMod('capMult','mul',.95,1,false,'消毒');}},
      {t:'抹一抹照做',pro:['唔停工'],con:['2 週內皮膚問題機率升'],f:function(){addMod('skinRate','mul',2,2,false,'真菌');}}]},
 model:{title:'AI 供應商更新模型',body:function(){return 'AI 供應商更新咗模型，回覆語氣同報價方式都變咗少少。';},when:function(){return s.lv.reply>=2||s.lv.recall>=3;},
  ai:'每次模型更新都要重新測試。冇測試就上線，錯誤率會升。',
  ch:[{t:'用一星期重新測試',pro:['錯誤率唔變'],con:['老闆用 3 小時'],f:function(){own().morale-=.03;}},
      {t:'唔理',pro:['唔使用時間'],con:['2 週內 AI 錯誤率加倍'],f:function(){addMod('replyErrMult','mul',2,2,false,'模型更新未測試');}}]},
 serious:{title:'嚴重事故',body:function(c){return '「'+c.a.pet+'」美容期間'+['中暑暈低','被剪刀剪傷要縫針','喺美容枱跌落嚟'][((c.a&&c.a.id)||0)%3]+'，要即刻送獸醫。'+c.a.owner+'好激動。';},
  ai:'AI 唔可以判斷健康風險，亦處理唔到事故。「檔」L3 只係提示紀錄；美容師唔好做到使用率超過 9 成。',
  ch:[{t:'全數負責獸醫費，公開交代',pro:['口碑恢復得快'],con:['額外 HK$2,000'],f:function(){s.cash-=2000;s.S.rating=Math.min(5,s.S.rating+.08);}},
      {t:'只賠獸醫費',pro:['慳錢'],con:['主人喺網上講，評分跌'],f:function(){s.S.rating-=.06;}}]}
};
var EV_RANDOM=[['oldDog',.08],['bite',.10],['equipment',.12],['style',.06],['rent',.03],['comp',.04],['waBan',.05],['aiPrice',.3],['poach',.25],['fungus',.04],['model',.04]];
var EV_REPEAT={bite:28,equipment:28};
function own(){return s.staff[0];}
function emp(){return activeStaff().filter(function(x){return x.role==='groomer';})[0];}
function lowMorale(){return activeStaff().filter(function(x){return x.role==='groomer'&&x.morale<.6&&x.leaving<0;})[0];}
function queueEvent(id,ctx){s.evQ.push({id:id,ctx:ctx||{}});if(!s.modal)nextEvent();}
function nextEvent(){if(s.modal||!s.evQ.length)return;var e=s.evQ.shift();s.modal={type:'event',id:e.id,ctx:e.ctx};}
function chooseEvent(i){var m=s.modal;if(!m||m.type!=='event')return;var E=EVENTS[m.id],c=E.ch[i];s.mled=s.mled||[];var c0=s.cash,n0=s.mled.length;c.f(m.ctx);
 /* 事件直接改現金嘅部分記入一次性收支（注資、借貸等已經自己記咗） */
 var rest=s.cash-c0-sum(s.mled.slice(n0).map(function(x){return x.amt;}));if(Math.abs(rest)>.5)s.mled.push({day:s.day,amt:rest,why:E.title+'：'+c.t,cat:'event'});news('事件',E.title+'：你揀咗「'+c.t+'」');s.evSeen[m.id]=(s.evSeen[m.id]||0)+1;s.evLast=s.evLast||{};s.evLast[m.id]=s.day;s.modal=null;nextEvent();}
function dayEvents(){
 var d=s.day,dt=dateOf(d),mo=dt.getMonth()+1,dd=dt.getDate();
 if(d===8&&!s.evSeen.afterhours&&!s.lv.reply)queueEvent('afterhours');
 if(d===35&&!s.evSeen.dormant)queueEvent('dormant');
 if(mo===1&&dd>=15&&dd<=21&&dt.getFullYear()===2027&&!s.evSeen.cny)queueEvent('cny');
 if(mo===1&&dd>=7&&dd<=13&&dt.getFullYear()===2028&&(s.evSeen.cny||0)<2)queueEvent('cny');
 if((mo===3||mo===9)&&dd===15)queueEvent('shed');
 if(mo===5&&dd===20)queueEvent('humid');
 if(mo>=7&&mo<=9&&!s.demoFF&&R()<.025)queueEvent('typhoon');
 if(d%7===0&&d>=14&&!s.demoFF){var cand=EV_RANDOM.filter(function(x){var E=EVENTS[x[0]],last=s.evLast&&s.evLast[x[0]],repeat=EV_REPEAT[x[0]];return (!E.when||E.when())&&(x[0]!=='rent'||d>=180)&&(repeat?(last==null||d-last>=repeat):(s.evSeen[x[0]]||0)<3);});
  for(var i=0;i<cand.length;i++){if(R()<cand[i][1]){queueEvent(cand[i][0]);break;}}}
}
