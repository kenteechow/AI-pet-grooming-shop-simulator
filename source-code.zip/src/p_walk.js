/* p_walk：人同寵物點行路。
   - 腳步跟「實際行咗幾遠」擺動（唔再固定頻率），快行慢行腳步都對得上，唔會似溜冰。
   - 轉身係順滑轉（約 0.1 秒），永遠面向行緊嘅方向。
   - 客人行路速度係固定嘅真實步速（約 1.25 格／秒），遊戲加速只會開方咁快少少，唔會變跑。
   - 客人一程路（街 → 樓梯口 → 1 樓門口 → 前台 → 等 → 原路返出街）用狀態記住，唔再跟遊戲分鐘硬 lerp。 */
var WALK={cust:1.25,staff:1.5,stride:7};
/* 實際時間流速（遊戲分鐘／真實秒）：示範快進同跳過夜晚時會遠高過 12×速度 */
function trackRate(dt){var t=s.day*1440+s.t;if(W3.trT!=null&&dt>0){var r=(t-W3.trT)/dt;if(!(r>=0&&r<1e5))r=0;W3.trS=(W3.trS==null?12:W3.trS)*.85+r*.15;}W3.trT=t;}
function gameRate(){return Math.max(12*Math.max(s.speed,1),W3.trS||0);}
/* 步速：1× 正常行（1.25 格／秒）；時間越快行得越快，但最多 3 倍（快步），唔會瞬移 */
function walkV(){return WALK.cust*Math.min(Math.pow(gameRate()/12,.35),3);}
/* 只計最近 30 幀有更新嘅路程（預約消失咗嘅舊路程唔計） */
function activeTrips(){var n=0;for(var k in W3.jr){var J=W3.jr[k],st=J.st;if((st==='in'||st==='desk'||st==='out'||st==='phone')&&W3.frame-(J.f||0)<30)n++;}return n;}
function staffV(){return WALK.staff*Math.pow(Math.min(Math.max(s.speed,1),10),.75);}
function turnTo(a,ang,dt){var d=ang-a.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));a.rotation.y+=d*Math.min(1,dt*12);}
/* 腳步：moved = 呢幀行咗幾遠 */
function stride(a,moved,dt){var u=a.userData;u.ph=(u.ph||0)+moved*WALK.stride;var on=moved>1e-4;
 u.amp=(u.amp||0)+((on?.55:0)-(u.amp||0))*Math.min(1,dt*10);var sw=Math.sin(u.ph)*u.amp;
 if(u.legs){u.legs[0].rotation.x=sw;u.legs[1].rotation.x=-sw;}
 if(u.arms){u.arms[0].rotation.x=-sw*.7;u.arms[1].rotation.x=sw*.7;}
 if(u.plegs){u.plegs.forEach(function(l,i){l.rotation.z=(i===0||i===3?1:-1)*sw*.8;});}
 u.bob=Math.abs(Math.sin(u.ph))*.04*u.amp;}
/* 沿住一條路線計位置。tp=true 嘅一段係「行樓梯」（樓梯喺牆後面睇唔到），長度當 0，直接跳 */
function pathLen(P){var L=0;for(var i=1;i<P.length;i++)if(!P[i].tp)L+=P[i].p.distanceTo(P[i-1].p);return L;}
function pathAt(P,d){for(var i=1;i<P.length;i++){if(P[i].tp)continue;var a=P[i-1].p,b=P[i].p,l=a.distanceTo(b);if(d<=l||i===P.length-1){var k=l?Math.min(1,Math.max(0,d/l)):1;return {p:a.clone().lerp(b,k),dir:b.clone().sub(a),i:i};}d-=l;}
 var e=P[P.length-1].p;return {p:e.clone(),dir:new THREE.Vector3(0,0,1),i:P.length-1};}
function revPath(P){var R=[];for(var i=P.length-1;i>=0;i--)R.push({p:P[i].p,tp:i+1<P.length?P[i+1].tp:false});R[0].tp=false;return R;}
/* 客人路線：街遠處 → 門口前面 → 樓梯口 →（樓梯）→ 1 樓門口 → 前台 */
function custPath(a){var sx=a.id%2?-13:11,z=2.3+(a.id%3)*.55,V3=THREE.Vector3,slot=a.id%3;
 return [{p:new V3(sx,.16,z)},{p:new V3(-4.15+(sx>0?.8:-.8),.16,1.5+(slot-1)*.18)},{p:new V3(-4.15,.16,.45)},{p:SP(SHOP.door[0],SHOP.door[1]),tp:true},{p:SP(-3.3+slot*.9,-.82)}];}
/* 一程客人：kind 'd' 落狗、'k' 接狗。返回 {st,pos,...}；st: wait0（未出發）in → desk → out → gone */
function custTrip(a,kind,dt){
 /* 換咗一局（例如由初始界面背景局入新遊戲）或者過咗日，就清走舊嘅客人路程 */
 W3.jr=W3.jr||{};if(W3.jrDay!==s.day||W3.jrS!==s){W3.jr={};W3.jrDay=s.day;W3.jrS=s;}
 if(s.paused||s.modal)dt=0;var key=kind+a.id,J=W3.jr[key],gpm=gameRate(),v=walkV();
 var at=kind==='d'?a.a-15:a.b+15,leave=kind==='d'?a.a-15:a.b+25;
 var off=a.st==='cancel'||a.st==='noshow'||a.st==='lost';
 /* v0.15：時間行得快（示範快進、30×）嘅時候，客人唔再被時間追到打回頭或者即刻消失：
    一出發就行完成程路（最少行四成路），遲咗都照行；只係錯過咗就唔再出現，同一時間最多 10 程。 */
 if(!J){if(off)return null;if(typeof skipOn==='function'&&skipOn())return null;var P=custPath(a),L=pathLen(P),lead=Math.min(150,L/v*gpm);if(s.t<at-lead)return null;
  if(s.t>leave+(kind==='d'?0:30)||activeTrips()>=10)return null;
  J=W3.jr[key]={P:P,L:L,st:'in',d:Math.max(0,Math.min(L*.6,L-(at-s.t)/gpm*v)),w:0};}
 J.f=W3.frame;if(J.st==='gone')return J;
 /* 臨時取消：停低打電話，再原路行返出街，狗仍然跟住佢（v0.13） */
 if(off&&kind==='d'&&(J.st==='in'||J.st==='desk')){J.st='phone';J.ph=0;J.abort=1;}
 if(J.st==='phone'){J.ph+=dt;if(J.ph>1.8){J.st='out';J.d=J.L-J.d;}var rp=pathAt(J.P,J.d);J.pos=rp.p;J.dir=rp.dir;return J;}
 if(J.st==='in'){J.d+=v*dt;if(J.d>=J.L){J.d=J.L;J.st='desk';}}
 else if(J.st==='desk'){J.w+=dt;if(s.t>=leave&&J.w>(s.t>leave+20?.6:1)){J.st='out';J.d=0;}}
 else if(J.st==='out'){J.d+=v*dt;if(J.d>=J.L)J.st='gone';}
 var Q=J.st==='out'?revPath(J.P):J.P,r=pathAt(Q,J.st==='desk'?J.L:J.d);J.pos=r.p;J.dir=r.dir;return J;}
