/* p_founder：創辦人層。四種模式 A/B/C/D。客戶店用 cohort（同月簽嘅店一組，w=店數），每組有「用 AI」同「唔用 AI」兩個雙胞胎店，用嚟計店家真正得到嘅價值。 */
/* 客戶店類型：x 開頭係相對基準店嘅倍數 */
var ARCH=[
 {name:'社區店',xGroom:1,xNs:1,xAfter:1,xInq:1,xAct:1,tech:.8},
 {name:'一人工作室',groomers:1,tables:1,assistantH:0,rent:11000,xNs:1.15,xAfter:1.2,xInq:.6,xAct:.5,tech:.6},
 {name:'三人店',groomers:3,tables:3,tubs:2,assistantH:40,rent:26000,xNs:.85,xAfter:.85,xInq:1.5,xAct:1.5,tech:.9},
 {name:'老派店',xNs:1.25,xAfter:1.3,xInq:.8,xAct:1.05,tech:.45}
];
function archParams(base,idx,r,det){
 var a=ARCH[idx%ARCH.length],P=clone(base);
 for(var k in a)if(k!=='name'&&k!=='tech'&&k.charAt(0)!=='x')P[k]=a[k];
 P.noShow*=a.xNs||1;P.afterHours=clamp(P.afterHours*(a.xAfter||1),.05,.8);P.inq*=a.xInq||1;P.active*=a.xAct||1;
 P.willSec=15+30*a.tech;P.startCash=0;P.forceQuitWeek=-1;P.forceSeriousWeek=-1;
 if(!det){P.noShow*=.75+.5*r();P.afterHours=clamp(P.afterHours*(.8+.4*r()),.1,.7);P.inq*=.8+.4*r();P.ret90=clamp(P.ret90+(r()-.5)*.08,.6,.95);}
 ROLES.forEach(function(x){P.lv[x.id]=0;});
 return {P:P,name:a.name};
}
/* 店家月流失率：按價值倍數線性插值 */
function churnFor(F,mult){var t=F.churnByMult;if(mult<=t[0][0])return t[0][1];for(var i=1;i<t.length;i++)if(mult<=t[i][0]){var a=t[i-1],b=t[i];return a[1]+(b[1]-a[1])*(mult-a[0])/(b[0]-a[0]);}return t[t.length-1][1];}
function drawF(x,det,r){return det?x:poisson(x,r);}
function binF(n,p,det,r){return det?n*p:binom(n,p,r);}

function founderInit(F,shopBase,o){
 o=o||{};return{F:F,shopBase:shopBase,o:o,det:o.det!==false,r:rngMake(o.seed||7),model:F.model,
  cohorts:[],cash:F.startCash,out:[],morale:1,overM:0,arch:0,members:0,partners:0,seeds:0,pipe:[],wkDone:0,mo:0};
}
/* 推一個月（遊戲每次月結 call 一次；runFounder 連續 call 12 次） */
function founderStep(st,extraH){
 var F=st.F,shopBase=st.shopBase,o=st.o,det=st.det,r=st.r,model=st.model,cohorts=st.cohorts,out=st.out,pipe=st.pipe;
 var cash=st.cash,morale=st.morale,overM=st.overM,arch=st.arch,members=st.members,partners=st.partners,seeds=st.seeds,wkDone=st.wkDone,mo=st.mo;

  var wEnd=Math.round((mo+1)*WPM),wN=wEnd-wkDone;
  var availH=Math.max(0,F.hoursAvail*morale-(extraH||0)),fixedH=F.contentH+F.devH,maxH=availH*1.4;
  /* 支援需要 */
  var supNeed=0,accts=0;
  cohorts.forEach(function(c){if(c.w<=0)return;var cf=F[c.mod];supNeed+=c.w*(c.age<2?cf.supportH1:cf.supportH);if(!c.trial)accts+=c.w;});
  var Cc=F.C;
  if(model==='C')supNeed=partners*Cc.partnerSupportH+members/100*Cc.csPer100;
  if(model==='D')supNeed+=members/100*Cc.csPer100;
  /* 新客 */
  var accNow=model==='C'?partners:0;cohorts.forEach(function(c){accNow+=c.w;});
  var sat=Math.max(0,1-accNow/F.market);
  var leads=drawF((F.leadsContent+F.ads/F.cpl)*sat,det,r),mod,cf2,salesH,setupH,conv,cyc;
  if(model==='C'){salesH=Cc.partnerSalesH;setupH=Cc.partnerSetupH;conv=Cc.partnerConv;leads=drawF(F.leadsContent*sat,det,r);cyc=1;}
  else{mod=model==='D'?(seeds<F.D.seedShops-1e-6?'B':'A'):model;cf2=F[mod];salesH=cf2.salesH;setupH=cf2.setupH;
   conv=mod==='A'?F.trialTake:cf2.conv;if(model==='D'&&mod==='A')conv=Math.min(.95,conv+F.D.caseBoost);cyc=cf2.cycle||1;}
  /* 銷售週期：今個月傾嘅 lead，cyc 個月後先簽 */
  var due=0;for(var pi=0;pi<pipe.length;pi++)if(pipe[pi].at===mo){due+=pipe[pi].n;}
  var signed=Math.max(0,due);
  if(model==='D'&&mod==='B')signed=Math.min(signed,F.D.seedShops-seeds);
  var room=Math.max(0,maxH-fixedH-supNeed-signed*setupH);
  var leadsProc=Math.min(leads,room/salesH);
  if(!det)leadsProc=Math.floor(leadsProc);
  var won=binF(leadsProc,clamp(conv*shopBase.econ,0,1),det,r);
  if(won>0)pipe.push({at:mo+cyc,n:won});
  var needH=fixedH+supNeed+leadsProc*salesH+signed*setupH;
  var worked=Math.min(needH,maxH);
  var deficit=supNeed>0?Math.max(0,fixedH+supNeed-maxH)/supNeed:0;
  if(worked>availH*1.02)overM++;else overM=0;
  morale=overM>=3?Math.max(.75,morale-.08):Math.min(1,morale+.04);
  var rev=0,varCost=0,newPaid=0,setupRev=0,churned=0,startAccts=accts;
  /* 開新 cohort */
  if(model!=='C'&&signed>0){
   var ap=archParams(shopBase,arch++,r,det),pk=F[mod].pkg;
   for(var kk in pk)ap.P.lv[kk]=pk[kk];
   var disc=(model==='D'&&mod==='B')?F.D.seedDisc:0;
   var fee=F[mod].fee*(1-disc),setup=F[mod].setup*(1-disc);
   var trial=mod==='A';
   ap.P.aiFeeOverride=trial?0:fee;ap.P.aiSetupOverride=trial?0:setup;
   var seedN=mo*977+arch*13+(o.seed||7);
   var c={w:signed,mod:mod,fee:fee,setup:setup,trial:trial,age:0,start:mo,name:ap.name,
    ai:newShop(ap.P,{det:det,seed:seedN}),base:newShop(lvZero(ap.P),{det:det,seed:seedN}),mult:[],w0:signed,wPaid:trial?0:signed};
   c.ai.cash=0;c.base.cash=0;cohorts.push(c);
   if(!trial){newPaid+=signed;setupRev+=signed*setup;}
   if(mod==='B'&&model==='D')seeds+=signed;
  }
  if(model==='C'){partners+=signed;newPaid=0;}
  /* 跑呢個月嘅週 */
  cohorts.forEach(function(c){if(c.w<=1e-6)return;c.h0=c.ai.hist.length;for(var i=0;i<wN;i++){shopStep(c.ai);shopStep(c.base);}});
  wkDone=wEnd;
  /* 月尾：價值、轉付費、流失、收入 */
  var multSum=0,multW=0,msgSum=0;
  cohorts.forEach(function(c){
   if(c.w<=1e-6)return;
   var hA=c.ai.hist.slice(c.h0),hB=c.base.hist.slice(c.h0);
   var gain=sum(hA.map(function(h){return h.profit+h.aiCost;}))-sum(hB.map(function(h){return h.profit;}));
   var msg=sum(hA.map(function(h){return h.msgCost;}));
   var mult=gain/Math.max(1,c.fee);c.mult.push(mult);c.lastGain=gain;
   varCost+=c.w*(msg+F.baseSupportPlat);msgSum+=c.w*msg;
   if(c.trial){
    var p=clamp(F.A.conv*clamp(mult/1.5,.6,1.4)*shopBase.econ,0,1)*(model==='D'?1+F.D.caseBoost:1);
    var nw=binF(c.w,clamp(p,0,1),det,r);c.w=nw;c.wPaid=nw;c.trial=false;c.ai.P.aiFeeOverride=c.fee;c.ai.P.aiSetupOverride=c.setup;delete c.ai.setupDone.__ov;
    newPaid+=nw;setupRev+=nw*c.setup;
   } else {
    var mm=c.mult.length>1?(c.mult[c.mult.length-1]+c.mult[c.mult.length-2])/2:mult;
    var ch=churnFor(F,mm)*(c.age<2?.5:1)*(1+1.5*deficit)*(F.churnMult||1)*(1+2*(1-shopBase.econ))*(1+(shopBase.compGap||0));
    var keep=binF(c.w,1-clamp(ch,0,1),det,r);churned+=c.w-keep;c.w=keep;
    rev+=c.w*c.fee;
   }
   multSum+=mult*c.w;multW+=c.w;c.age++;
  });
  rev+=setupRev;
  var mrr=0;cohorts.forEach(function(c){if(!c.trial&&c.w>0)mrr+=c.w*c.fee;});
  /* 會員（C／D） */
  var memRev=0,memCost=0,overflow=0,newMem=0,memCh=0,refundC=0,adsX=0;
  if(model==='C'||model==='D'){
   if(model==='C'){newMem=drawF(Cc.memberAds/Cc.memberCAC+F.leadsContent*3,det,r);adsX=Cc.memberAds;}
   else{var seedAct=0;cohorts.forEach(function(c){if(c.mod==='B'&&c.w>0)seedAct+=c.w*sum(c.ai.act);});
    var targetM=seedAct*F.D.memberAtSeed*Math.min(1,Math.max(0,mo-1)/3);newMem=Math.max(0,targetM-members);}
   var visits=members*Cc.visitsPerMember,spare=(model==='C'?partners:Math.max(1,seeds))*Cc.partnerSpare;
   overflow=visits>0?Math.max(0,visits-spare)/visits:0;
   memCh=binF(members,clamp(Cc.memberChurn*(1+2*overflow)*(1+deficit),0,1),det,r);
   members=Math.max(0,members-memCh+newMem);
   visits=members*Cc.visitsPerMember;var served=Math.min(visits,spare);
   var comm=model==='C'?Cc.comm:F.D.refComm;
   memRev=members*Cc.memberFee+comm*served*Cc.ticket;
   memCost=members*Cc.benefit;
   refundC=served*(shopBase.minorRate+shopBase.skinRate)*Cc.refundShare*600*(model==='C'?1:.3);
   rev+=memRev;varCost+=memCost+refundC;
   mrr+=members*Cc.memberFee+comm*served*Cc.ticket;
  }
  var adsCost=F.ads+adsX;
  var net=rev-varCost-F.tools-adsCost-F.draw;
  cash+=net;
  var acctsNow=model==='C'?partners:0;cohorts.forEach(function(c){if(!c.trial)acctsNow+=c.w;});
  var trialsNow=0;cohorts.forEach(function(c){if(c.trial)trialsNow+=c.w;});
  var payAcc=model==='C'?members:acctsNow;
  var newCust=model==='C'?newMem:newPaid;
  var cacCash=newCust>0?adsCost/newCust:null;
  var cacFull=newCust>0?(adsCost+(leadsProc*salesH+signed*setupH)*F.hourValue)/newCust:null;
  var gm=rev>0?(rev-varCost)/rev:0;
  var arpa=payAcc>0?mrr/payAcc:0;
  var chRate=model==='C'?(members+memCh>0?memCh/(members+memCh-newMem||1):0):(startAccts>0?churned/startAccts:0);
  var ltv=arpa*gm/Math.max(.01,chRate);
  out.push({m:mo+1,rev:rev,varCost:varCost,fixed:F.tools+adsCost+F.draw,net:net,cash:cash,mrr:mrr,arr:mrr*12,accts:acctsNow,trials:trialsNow,
   members:members,newPaid:newCust,churned:model==='C'?memCh:churned,chRate:chRate,needH:needH,availH:availH,worked:worked,deficit:deficit,morale:morale,
   supNeed:supNeed,leads:leads,leadsProc:leadsProc,signed:signed,cacCash:cacCash,cacFull:cacFull,gm:gm,arpa:arpa,ltv:ltv,
   ltvcac:cacFull?ltv/cacFull:null,payback:cacFull&&arpa*gm>0?cacFull/(arpa*gm):null,mult:multW>0?multSum/multW:null,overflow:overflow,
   partners:partners,msgCost:msgSum,refundC:refundC});
 
 st.cash=cash;st.morale=morale;st.overM=overM;st.arch=arch;st.members=members;st.partners=partners;st.seeds=seeds;st.wkDone=wkDone;st.mo=mo+1;
 return out[out.length-1];
}
function runFounder(F,shopBase,o){
 var st=founderInit(F,shopBase,o),months=F.months||12;
 for(var i=0;i<months;i++)founderStep(st);
 return{months:st.out,cohorts:st.cohorts,sum:founderSummary(st.out,F)};
}
function founderSummary(ms,F){
 var L=ms[ms.length-1];
 function first(f){for(var i=0;i<ms.length;i++)if(f(ms[i]))return ms[i].m;return null;}
 var be=null;for(var i=0;i<ms.length;i++){var ok=true;for(var j=i;j<ms.length;j++)if(ms[j].net<0){ok=false;break;}if(ok&&ms[i].net>=0){be=ms[i].m;break;}}
 var cacs=ms.filter(function(x){return x.cacFull!=null;});
 var cacFull=cacs.length?sum(cacs.map(function(x){return x.cacFull*x.newPaid;}))/Math.max(1e-9,sum(cacs.map(function(x){return x.newPaid;}))):null;
 var lastQ=ms.slice(-3);
 var ch=sum(lastQ.map(function(x){return x.chRate;}))/lastQ.length;
 var ltv=L.arpa*L.gm/Math.max(.01,ch);
 var mults=ms.filter(function(x){return x.mult!=null;});
 return{cash:L.cash,mrr:L.mrr,arr:L.mrr*12,accts:L.accts,members:L.members,breakeven:be,mrr30:first(function(x){return x.mrr>=30000;}),mrr50:first(function(x){return x.mrr>=50000;}),
  maxNeed:Math.max.apply(null,ms.map(function(x){return x.needH;})),avgLoad:sum(ms.map(function(x){return x.needH/x.availH;}))/ms.length,
  overMonths:ms.filter(function(x){return x.worked>x.availH*1.02;}).length,deficitMonths:ms.filter(function(x){return x.deficit>0;}).length,
  cacFull:cacFull,ltv:ltv,ltvcac:cacFull?ltv/cacFull:null,churn:ch,gm:L.gm,arpa:L.arpa,payback:cacFull&&L.arpa*L.gm>0?cacFull/(L.arpa*L.gm):null,
  mult:mults.length?sum(mults.map(function(x){return x.mult;}))/mults.length:null,minCash:Math.min.apply(null,ms.map(function(x){return x.cash;})),
  hoursPerK:L.mrr>0?sum(ms.map(function(x){return x.worked;}))/ms.length/(L.mrr/1000):null};
}
