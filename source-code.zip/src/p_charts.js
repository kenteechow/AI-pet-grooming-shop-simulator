/* p_charts：手寫 SVG 圖表（線圖、扇形帶、龍捲風圖），按容器實際闊度畫，有十字線同提示。 */
var CH={},chN=0;
function chart(o){var id='ch'+(chN++);CH[id]=o;return '<div class="chart" data-ch="'+id+'" style="height:'+(o.h||220)+'px" role="img" aria-label="'+(o.aria||'')+'"></div>';}
function sMoney(v){var a=Math.abs(v),s=v<0?'−':'';if(a>=1e6)return s+(a/1e6).toFixed(a>=1e7?0:1)+'M';if(a>=1e4)return s+Math.round(a/1e3)+'k';if(a>=1e3)return s+(a/1e3).toFixed(1)+'k';return s+Math.round(a);}
function niceTicks(lo,hi,n){if(hi===lo){hi=lo+1;}var span=hi-lo,step=Math.pow(10,Math.floor(Math.log10(span/n))),err=span/n/step;
 if(err>=7.5)step*=10;else if(err>=3.5)step*=5;else if(err>=1.5)step*=2;
 var a=Math.floor(lo/step)*step,b=Math.ceil(hi/step)*step,t=[];for(var x=a;x<=b+step/2;x+=step)t.push(Math.round(x/step)*step);return t;}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function drawCharts(root){root.querySelectorAll('.chart[data-ch]').forEach(function(el){var o=CH[el.getAttribute('data-ch')];if(o){if(o.type==='tornado')drawTornado(el,o);else drawLine(el,o);}});}
function drawLine(el,o){
 var W=Math.max(260,el.clientWidth||600),H=o.h||220,end=o.series.length<=4&&W>420;
 var pl=52,pr=end?96:12,pt=10,pb=24,n=o.labels.length,fmt=o.fmt||sMoney;
 var vals=[];o.series.forEach(function(s){s.vals.forEach(function(v){if(v!=null&&isFinite(v))vals.push(v);});});
 if(o.band)o.band.forEach(function(b){vals.push(b.lo,b.hi);});
 if(o.zero!==false)vals.push(0);
 var lo=Math.min.apply(null,vals),hi=Math.max.apply(null,vals);var ticks=niceTicks(lo,hi,4);lo=ticks[0];hi=ticks[ticks.length-1];
 function X(i){return pl+(n<=1?0:i*(W-pl-pr)/(n-1));}
 function Y(v){return pt+(hi-v)/(hi-lo||1)*(H-pt-pb);}
 var g='';
 ticks.forEach(function(t){var y=Y(t);g+='<line class="'+(t===0?'zero':'grid')+'" x1="'+pl+'" x2="'+(W-pr)+'" y1="'+y+'" y2="'+y+'"/><text x="'+(pl-6)+'" y="'+(y+3.5)+'" text-anchor="end">'+esc(fmt(t))+'</text>';});
 var every=Math.ceil(n/Math.max(2,Math.floor((W-pl-pr)/40)));
 o.labels.forEach(function(l,i){if(i%every===0||i===n-1)g+='<text x="'+X(i)+'" y="'+(H-6)+'" text-anchor="middle">'+esc(l)+'</text>';});
 if(o.band){var up=o.band.map(function(b,i){return X(i)+','+Y(b.hi);}),dn=o.band.map(function(b,i){return X(i)+','+Y(b.lo);}).reverse();
  g+='<polygon points="'+up.concat(dn).join(' ')+'" fill="var(--band)" stroke="none"/>';}
 var labs=[];
 o.series.forEach(function(s){var d='',pen=false;s.vals.forEach(function(v,i){if(v==null||!isFinite(v)){pen=false;return;}d+=(pen?'L':'M')+X(i).toFixed(1)+','+Y(v).toFixed(1);pen=true;});
  g+='<path d="'+d+'" fill="none" stroke="var(--'+s.c+')" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"'+(s.dash?' stroke-dasharray="5 4"':'')+'/>';
  var li=s.vals.length-1;while(li>=0&&(s.vals[li]==null||!isFinite(s.vals[li])))li--;
  if(li>=0){g+='<circle cx="'+X(li)+'" cy="'+Y(s.vals[li])+'" r="4" fill="var(--'+s.c+')" stroke="var(--surface)" stroke-width="2"/>';labs.push({y:Y(s.vals[li]),t:s.name,x:X(li)});}
 });
 if(end){labs.sort(function(a,b){return a.y-b.y;});for(var i=1;i<labs.length;i++)if(labs[i].y-labs[i-1].y<13)labs[i].y=labs[i-1].y+13;
  labs.forEach(function(l){g+='<text class="lab" x="'+(l.x+8)+'" y="'+(l.y+4)+'">'+esc(l.t)+'</text>';});}
 g+='<line class="xh" x1="0" x2="0" y1="'+pt+'" y2="'+(H-pb)+'" visibility="hidden"/>';
 el.innerHTML='<svg width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'">'+g+'</svg><div class="tip" hidden></div>';
 var svg=el.firstChild,xh=svg.querySelector('.xh'),tip=el.querySelector('.tip');
 el.onmousemove=function(e){var r=svg.getBoundingClientRect(),x=e.clientX-r.left;var i=Math.round((x-pl)/((W-pl-pr)/Math.max(1,n-1)));i=clamp(i,0,n-1);
  xh.setAttribute('x1',X(i));xh.setAttribute('x2',X(i));xh.setAttribute('visibility','visible');
  var h='<div>'+esc(o.tipLabel?o.tipLabel(i):o.labels[i])+'</div>';
  if(o.band)h+='<div>10%–90%：<b>'+esc(fmt(o.band[i].lo))+' – '+esc(fmt(o.band[i].hi))+'</b></div>';
  o.series.forEach(function(s){var v=s.vals[i];h+='<div><span style="display:inline-block;width:9px;height:3px;background:var(--'+s.c+');vertical-align:middle;margin-right:5px"></span>'+esc(s.name)+'：<b>'+(v==null?'—':esc((o.tipFmt||fmt)(v)))+'</b></div>';});
  tip.innerHTML=h;tip.hidden=false;var tx=X(i)+12;if(tx+tip.offsetWidth>W)tx=X(i)-tip.offsetWidth-12;tip.style.left=Math.max(0,tx)+'px';tip.style.top='4px';};
 el.onmouseleave=function(){xh.setAttribute('visibility','hidden');tip.hidden=true;};
}
function legend(series){return '<div class="legend">'+series.map(function(s){return '<span><i style="background:var(--'+s.c+')"></i>'+esc(s.name)+'</span>';}).join('')+'</div>';}
function drawTornado(el,o){
 var W=Math.max(280,el.clientWidth||600),rows=o.rows,rh=34,pt=6,pb=22,pl=W<480?92:118,pr=64,H=pt+pb+rows.length*rh;
 el.style.height=H+'px';
 var mx=0;rows.forEach(function(r){mx=Math.max(mx,Math.abs(r.lo),Math.abs(r.hi));});mx=mx||1;
 var ticks=niceTicks(-mx*1.4,mx*1.4,4);var a=ticks[0],b=ticks[ticks.length-1];
 function X(v){return pl+(v-a)/(b-a)*(W-pl-pr);}
 var g='';ticks.forEach(function(t){g+='<line class="'+(t===0?'zero':'grid')+'" x1="'+X(t)+'" x2="'+X(t)+'" y1="'+pt+'" y2="'+(H-pb)+'"/><text x="'+X(t)+'" y="'+(H-6)+'" text-anchor="middle">'+esc(sMoney(t))+'</text>';});
 rows.forEach(function(r,i){var y=pt+i*rh+5;
  g+='<text class="lab" x="'+(pl-8)+'" y="'+(y+15)+'" text-anchor="end">'+esc(r.name)+'</text>';
  [[r.lo,'−20%',0],[r.hi,'+20%',13]].forEach(function(p){var v=p[0],x0=X(0),x1=X(v),yy=y+p[2];
   var c=v>=0?'s1':'neg';g+='<rect x="'+Math.min(x0,x1)+'" y="'+yy+'" width="'+Math.max(1,Math.abs(x1-x0))+'" height="10" rx="2" fill="var(--'+c+')"/>';
   g+='<text x="'+(v>=0?Math.max(x0,x1)+4:Math.min(x0,x1)-4)+'" y="'+(yy+9)+'" text-anchor="'+(v>=0?'start':'end')+'">'+p[1]+' '+esc(sMoney(v))+'</text>';});
 });
 el.innerHTML='<svg width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'">'+g+'</svg>';
}
