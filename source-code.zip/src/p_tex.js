/* p_tex：程式生成貼圖（唔使外部圖檔）。行人路磚、瀝青、室內地磚、外牆（窗框、冷氣機）、路面字「望右 LOOK RIGHT」。 */
var TX={};
function cvs(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function noise(g,w,h,amt,a){var id=g.getImageData(0,0,w,h),d=id.data;for(var i=0;i<d.length;i+=4){var n=(Math.random()-.5)*amt;d[i]+=n;d[i+1]+=n;d[i+2]+=n;if(a)d[i+3]=255;}g.putImageData(id,0,0);}
function repTex(c,rx,ry){var t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx||1,ry||1);t.anisotropy=4;return t;}
/* 行人路：米色同淺粉紅方磚，錯縫 */
function paverCanvas(){if(TX.paver)return TX.paver;var c=cvs(128,128),g=c.getContext('2d');g.fillStyle='#8a7b6e';g.fillRect(0,0,128,128);
 var cols=['#bea894','#b39d89','#c7b19e','#a98f7c','#b8a28e'];
 for(var r=0;r<8;r++)for(var k=0;k<4;k++){var x=k*32+(r%2?16:0),y=r*16;g.fillStyle=cols[(r*3+k)%cols.length];g.fillRect(x+1,y+1,30,14);g.fillRect(x-128+1,y+1,30,14);}
 noise(g,128,128,14);TX.paver=c;return c;}
function asphaltCanvas(){if(TX.asph)return TX.asph;var c=cvs(128,128),g=c.getContext('2d');g.fillStyle='#3d4044';g.fillRect(0,0,128,128);noise(g,128,128,26);
 for(var i=0;i<40;i++){g.fillStyle='rgba(255,255,255,'+(Math.random()*.05)+')';g.fillRect(Math.random()*128,Math.random()*128,2,2);}TX.asph=c;return c;}
function concreteCanvas(){if(TX.conc)return TX.conc;var c=cvs(64,64),g=c.getContext('2d');g.fillStyle='#7a7872';g.fillRect(0,0,64,64);noise(g,64,64,18);TX.conc=c;return c;}
function floorCanvas(){if(TX.floor)return TX.floor;var c=cvs(128,128),g=c.getContext('2d');g.fillStyle='#9fb3ae';g.fillRect(0,0,128,128);
 for(var r=0;r<2;r++)for(var k=0;k<2;k++){g.fillStyle=(r+k)%2?'#e4ece9':'#dbe6e2';g.fillRect(k*64+1.5,r*64+1.5,61,61);}noise(g,128,128,8);TX.floor=c;return c;}
function grassCanvas(){if(TX.grass)return TX.grass;var c=cvs(64,64),g=c.getContext('2d');g.fillStyle='#9fc46e';g.fillRect(0,0,64,64);noise(g,64,64,30);TX.grass=c;return c;}
/* 路面字 */
function roadText(t1,t2){var k=t1+t2;if(TX[k])return TX[k];var c=cvs(256,128),g=c.getContext('2d');g.clearRect(0,0,256,128);g.fillStyle='#f4f4f0';g.textAlign='center';
 g.font='bold 64px "Noto Sans HK","PingFang HK","Microsoft JhengHei",sans-serif';g.fillText(t1,128,62);g.font='bold 30px sans-serif';g.fillText(t2,128,108);var t=new THREE.CanvasTexture(c);TX[k]=t;return t;}
/* 平放喺地面嘅貼圖方塊（頂面先有貼圖） */
function flatTex(parent,w,d,x,y,z,canvas,tile,h){
 var t=repTex(canvas,w/tile,d/tile),m=new THREE.MeshLambertMaterial({map:t});var b=new THREE.Mesh(vbox(w,h||.02,d),m);b.position.set(x,y,z);parent.add(b);return b;}
function decal(parent,tex,w,d,x,y,z,rot){var m=new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3});var p=new THREE.Mesh(new THREE.PlaneGeometry(w,d),m);p.rotation.x=-Math.PI/2;p.rotation.z=rot||0;p.position.set(x,y,z);parent.add(p);return p;}
/* 外牆：瓷磚紋、鋁窗框、窗下冷氣機、少少水漬 */
function facadeCanvas(style){
 var base={tong:'#c9b79c',tile:'#d8d2c4',estate:'#e6dccb',glass:'#5d7487',grey:'#a6a39c',pink:'#d9b3a8'}[style]||'#bbb';
 var c=cvs(128,128),g=c.getContext('2d'),L=cvs(128,128),gl=L.getContext('2d');g.fillStyle=base;g.fillRect(0,0,128,128);gl.fillStyle='#000';gl.fillRect(0,0,128,128);
 if(style!=='glass'){g.strokeStyle='rgba(0,0,0,.06)';for(var y=0;y<128;y+=8){g.beginPath();g.moveTo(0,y);g.lineTo(128,y);g.stroke();}}
 for(var r=0;r<2;r++)for(var k=0;k<2;k++){var wx=k*64+10,wy=r*64+12;
  g.fillStyle=style==='glass'?'#2c3e4e':'#3b4650';g.fillRect(wx,wy,44,30);g.strokeStyle='#c8ccd0';g.lineWidth=2;g.strokeRect(wx,wy,44,30);g.beginPath();g.moveTo(wx+22,wy);g.lineTo(wx+22,wy+30);g.stroke();
  g.fillStyle='rgba(255,255,255,.12)';g.fillRect(wx+3,wy+3,8,24);
  if(style!=='glass'&&Math.random()<.7){g.fillStyle='#e9e9e4';g.fillRect(wx+6,wy+34,18,10);g.fillStyle='#9a9a94';for(var i=0;i<4;i++)g.fillRect(wx+8+i*4,wy+36,2,6);
   g.fillStyle='rgba(60,50,40,.18)';g.fillRect(wx+12,wy+44,3,10+Math.random()*8);}
  if(style==='tong'||style==='estate'){g.fillStyle='#8c8577';g.fillRect(wx-3,wy+30,50,3);}
  if(Math.random()<.55){gl.fillStyle=Math.random()<.5?'#ffd9a0':'#cfe6ff';gl.fillRect(wx+2,wy+2,40,26);}}
 noise(g,128,128,10);return [c,L];
}
function checkerCanvas(a,b){var k='chk'+a+b;if(TX[k])return TX[k];var c=cvs(64,64),g=c.getContext('2d');for(var r=0;r<2;r++)for(var q=0;q<2;q++){g.fillStyle=(r+q)%2?a:b;g.fillRect(q*32,r*32,32,32);}g.strokeStyle='rgba(0,0,0,.12)';g.strokeRect(0,0,64,64);noise(g,64,64,8);TX[k]=c;return c;}
