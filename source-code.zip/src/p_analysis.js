/* p_analysis：情境、盲點診斷、敏感度、蒙地卡羅、四模式比較、停損線、10 條問題。 */

/* ---------- 情境 ---------- */
var SCEN=[
 {id:'base',name:'基準',desc:'2 位美容師、穩定舊客、no-show 12%',f:function(P,F){}},
 {id:'recession',name:'經濟下行',desc:'客單價跌、加購跌、回訪週期拉長、價錢敏感客易走',f:function(P){P.econ=.8;}},
 {id:'aiWin',name:'AI 前台成功',desc:'AI 報價＋預約系統，有人工審核',f:function(P){P.lv.reply=2;P.lv.sched=2;P.review=1;}},
 {id:'aiFail',name:'AI 前台失敗',desc:'冇人工審核、錯誤回覆多、客人唔信任',f:function(P){P.lv.reply=2;P.review=0;P.replyErrMult=3;P.conv=.47;}},
 {id:'full',name:'美容師滿載',desc:'查詢 +30%，但產能只可以 +10%',f:function(P){P.lv.reply=2;P.inqMult=1.3;P.capMult=1.1;}},
 {id:'quit',name:'美容師離職',desc:'第 3 個月一位美容師走，帶走 30% 熟客，6 週先請到人',f:function(P){P.forceQuitWeek=13;P.followShare=.3;P.hireWeeks=6;}},
 {id:'memWin',name:'會員制成功',desc:'店有空位（產能 +35%），40% 客人入會、週期縮短、折扣 10%',f:function(P){P.capMult=1.35;P.memberShare=.4;P.memberDisc=.10;P.memberCyc=.75;P.memberAnyway=.4;}},
 {id:'memFail',name:'會員制失敗',desc:'折扣 25%，入會嘅 80% 本身都會嚟',f:function(P){P.memberShare=.4;P.memberDisc=.25;P.memberAnyway=.8;}},
 {id:'serious',name:'嚴重服務事故',desc:'第 4 個月出現一次嚴重受傷事故',f:function(P){P.forceSeriousWeek=17;}},
 {id:'compCut',name:'競爭對手降價',desc:'附近新店平 20%',f:function(P){P.compGap=.2;}},
 {id:'overload',name:'一人創辦人過載',desc:'每月 lead 多三倍，每店支援 5–8 小時',f:function(P,F){F.leadsContent=12;F.ads=8000;F.trialTake=.7;F.A.supportH=5;F.A.supportH1=8;F.B.supportH=8;F.B.supportH1=10;}}
];
function applyScen(id,P,F){var s=SCEN.filter(function(x){return x.id===id;})[0];if(s)s.f(P,F);}

/* ---------- 完整跑一次 ---------- */
function runAll(P,F){
 var ai=runShop(P),base=runShop(lvZero(P));
 var aiS=shopSummary(ai.months),baseS=shopSummary(base.months);
 var noMem=null;if(P.memberShare>0){var q=clone(P);q.memberShare=0;noMem=shopSummary(runShop(q).months);}
 var fr=runFounder(F,P);
 var R={P:P,F:F,ai:ai,base:base,aiS:aiS,baseS:baseS,noMem:noMem,fr:fr,ltv:ownerLTV(P,aiS),ltvBase:ownerLTV(P,baseS)};
 R.blind=blindspots(R);R.fail=failChecks(R);
 return R;
}

/* ---------- 盲點診斷 ---------- */
function pct(x){return (x*100).toFixed(1)+'%';}
function hk(x){var n=Math.round(x);return (n<0?'−':'')+'HK$'+Math.abs(n).toLocaleString('en-US');}
function blindspots(R){
 var a=R.aiS,b=R.baseS,P=R.P,F=R.F,fm=R.fr.months,fs=R.fr.sum,out=[],ref=R.noMem||b;
 function add(id,on,lvl,title,why,fix){out.push({id:id,on:!!on,lvl:lvl,title:title,why:why,fix:fix});}
 var inqUp=(a.inq/Math.max(1,b.inq)-1),rejShare=a.rejected/Math.max(1,a.newAcc+a.rejected);
 add(1,(inqUp>=.2||P.inqMult>=1.2)&&(a.lostDem>a.done*.03||a.lead>1.5||a.util>.9),'red','需求增加但產能不足',
  '新客查詢 '+(P.inqMult>=1.2?'+'+Math.round((P.inqMult-1)*100)+'%':(inqUp>=0?'+':'')+pct(inqUp))+'，但每月約 '+Math.round(a.lostDem)+' 個預約需求因為冇位流失，等位約 '+a.lead.toFixed(1)+' 週，美容枱使用率 '+pct(a.util)+'。',
  'AI 帶來更多查詢，但美容師已滿載。先加產能（助理、美容枱、老闆少做行政），或者開「超載拒單」保住熟客。');
 add(2,a.ret>ref.ret+.005&&a.ticket<ref.ticket*.92,'amber','回訪率升，但客單價跌',
  '回訪 '+pct(ref.ret)+' → '+pct(a.ret)+'，客單價 '+hk(ref.ticket)+' → '+hk(a.ticket)+'。',
  '可能靠折扣換回訪，毛利未必改善。睇每月毛利，唔好淨睇回訪率。');
 add(3,a.ns<b.ns-.01&&a.lc-b.lc>.015,'amber','No-show 跌，但臨時取消升',
  'No-show '+pct(b.ns)+' → '+pct(a.ns)+'；臨時取消 '+pct(b.lc)+' → '+pct(a.lc)+'。',
  '提醒令部分 no-show 變成臨時取消。兩樣要分開計；取消要靠候補補位先救得返。');
 add(4,a.aiReplies>0&&a.conv<.25,'amber','AI 回覆多，但成交少',
  'AI 每月覆約 '+Math.round(a.aiReplies)+' 個查詢，但查詢 → 預約只有 '+pct(a.conv)+'。',
  'AI 回覆唔等於成交：可能冇報價、冇信任、冇合適時段。睇吓係咪產能唔夠，定係報價方式有問題。');
 add(5,R.noMem&&a.members>1&&a.profit<R.noMem.profit,'red','會員數升，但毛利跌',
  R.noMem?('有會員每月利潤 '+hk(a.profit)+'，冇會員 '+hk(R.noMem.profit)+'。'):'',
  '會員制變咗折扣計劃。減折扣、包服務唔包折扣，或者只畀真係會多咗嚟嘅客人。');
 var supAvail=F.hoursAvail-F.contentH-F.devH,worst=0,wm=0;fm.forEach(function(x){var r=x.supNeed/Math.max(1,supAvail);if(r>worst){worst=r;wm=x.m;}});
 add(6,worst>.8,'red','店家數增加，支援時間爆',
  '第 '+wm+' 個月支援需要 '+Math.round(worst*supAvail)+' 小時，係可用支援時間嘅 '+Math.round(worst*100)+'%。',
  '一人創辦人無法同時服務太多客製化客戶。先將每店支援時數壓低（產品化、教學影片），再加店。');
 var incUp=a.complaints>b.complaints*1.5;
 add(7,incUp||a.serious-b.serious>=.5||P.forceSeriousWeek>=0||P.seriousRate>1/3000,'red','事故率上升',
  '每月投訴約 '+a.complaints.toFixed(1)+' 宗（傳統店 '+b.complaints.toFixed(1)+'），一年嚴重事故約 '+a.serious.toFixed(1)+' 宗，Google 評分 '+a.rating.toFixed(2)+'。',
  '一次動物安全事故可能摧毀信任同口碑。保持人工審核，美容師唔好超過 90% 使用率，皮膚同過敏紀錄要完整。');
 var pers=(P.lv.recall>=3||P.lv.media>=2||P.lv.file>=1);
 add(8,pers&&a.comp<.5,'amber','美容師冇輸入毛孩資料',
  '毛孩檔案完整度 '+pct(a.comp)+'。'+(P.lv.file?'每隻要輸入 '+roleDef('file').L[P.lv.file-1].sec+' 秒，美容師只願意 '+P.willSec+' 秒。':'仲未部署「檔」。'),
  '冇毛孩檔案，AI 個人化只係空談。用語音或者一鍵標籤，將輸入時間壓到美容師願意嘅範圍。');
 add(9,fs.ltvcac!=null&&(fs.ltvcac<1.5||(fs.payback!=null&&fs.payback>12)),'red','LTV 高但 CAC 更高',
  'LTV/CAC '+(fs.ltvcac!=null?fs.ltvcac.toFixed(2):'—')+'，CAC 回收期 '+(fs.payback!=null?fs.payback.toFixed(1)+' 個月':'—')+'（CAC 連創辦人時間計）。',
  '增長唔等於有健康嘅單位經濟。降低獲客成本（內容、轉介），或者提高每店收入。');
 var hot=fm.filter(function(x){return x.worked/WPM>48;}).length,lastNet=fm[fm.length-1].net;
 add(10,hot>=2&&lastNet>0,'red','現金流為正，但創辦人時數超載',
  '有 '+hot+' 個月每週做超過 48 小時（最高約 '+Math.round(Math.max.apply(null,fm.map(function(x){return x.worked;}))/WPM)+' 小時／週），士氣 '+Math.round(fm[fm.length-1].morale*100)+'%。',
  '一人公司唔可以淨睇損益表。超時會令回覆變慢、店家流失。');
 return out;
}

/* ---------- 停損線 ---------- */
function failChecks(R){
 var F=R.F,fm=R.fr.months,fs=R.fr.sum,a=R.aiS,out=[],mod=F.model;
 function add(name,val,thr,bad,txt){out.push({name:name,val:val,thr:thr,bad:!!bad,txt:txt});}
 var run=0,maxRun=0;fm.forEach(function(x){if(x.ltvcac!=null&&x.ltvcac<1.5){run++;maxRun=Math.max(maxRun,run);}else run=0;});
 add('LTV/CAC 連續 3 個月低過 1.5',maxRun+' 個月','< 3 個月',maxRun>=3,'最長連續 '+maxRun+' 個月');
 var supAvail=F.hoursAvail-F.contentH-F.devH,mx=Math.max.apply(null,fm.map(function(x){return x.supNeed;}));
 add('支援時數超過可用 80%',Math.round(mx)+' 小時',Math.round(supAvail*.8)+' 小時',mx>supAvail*.8,'');
 if(mod==='A'||mod==='D'){var tr=trialRate(R);add('試用轉付費低過 20%',tr==null?'—':pct(tr),'≥ 20%',tr!=null&&tr<.2,'');}
 var sr=a.doneTotal>0?a.serious/a.doneTotal:0;
 add('嚴重事故率高過 1/3,000',sr>0?'1/'+Math.round(1/sr).toLocaleString('en-US'):'0','≤ 1/3,000',sr>1/3000,'');
 var persOn=R.P.lv.recall>=3||R.P.lv.media>=2||R.P.lv.file>=1;
 add('毛孩檔案完整度低過 40%',pct(a.comp),'≥ 40%',persOn&&a.comp<.4,persOn?'':'未部署個人化崗位，暫時唔計');
 var c=F[mod==='C'?'A':(mod==='D'?'A':mod)];
 var perShop=mod==='C'?null:(c.fee-c.supportH*F.hourValue-(F.baseSupportPlat+avgMsg(R)));
 add('月費蓋唔到支援人工同 API',perShop==null?'—':hk(perShop)+'／店','> 0',perShop!=null&&perShop<=0,'月費 − 支援時數 × 時薪 − 平台同訊息成本');
 var ms=[];R.fr.cohorts.forEach(function(c){c.mult.forEach(function(m){ms.push(m);});});ms.sort(function(x,y){return x-y;});
 var med=ms.length?ms[Math.floor(ms.length/2)]:null;
 add('店家價值倍數中位數低過 1.5',med==null?'—':med.toFixed(2)+' 倍','≥ 1.5',med!=null&&med<1.5,'店家得到嘅價值 ÷ 月費');
 return out;
}
function avgMsg(R){var w=0,m=0;R.fr.months.forEach(function(x){m+=x.msgCost;w+=x.accts;});return w>0?m/w:0;}
function trialRate(R){var t=0,p=0;R.fr.cohorts.forEach(function(c){if(c.mod==='A'){t+=c.w0||0;p+=c.wPaid||0;}});return t>0?p/t:null;}

/* ---------- 敏感度 ---------- */
var SENS=[
 {id:'fee',name:'每店月費',f:function(P,F,k){['A','B'].forEach(function(m){F[m].fee*=k;});F.C.memberFee*=k;}},
 {id:'sup',name:'每店支援時數',f:function(P,F,k){['A','B'].forEach(function(m){F[m].supportH*=k;F[m].supportH1*=k;});F.C.csPer100*=k;F.C.partnerSupportH*=k;}},
 {id:'churn',name:'月流失率',f:function(P,F,k){F.churnMult=(F.churnMult||1)*k;F.C.memberChurn*=k;}},
 {id:'ns',name:'No-show 率',f:function(P,F,k){P.noShow*=k;}},
 {id:'cyc',name:'回訪週期',f:function(P,F,k){P.cycMult=(P.cycMult||1)*k;}},
 {id:'cap',name:'美容師產能',f:function(P,F,k){P.capMult*=k;}},
 {id:'price',name:'平均客單價',f:function(P,F,k){P.priceIdx*=k;F.C.ticket*=k;}},
 {id:'disc',name:'會員折扣',f:function(P,F,k){P.memberDisc*=k;F.C.benefit*=k;}},
 {id:'inc',name:'事故率',f:function(P,F,k){P.incidentMult*=k;}},
 {id:'cac',name:'獲客成本',f:function(P,F,k){F.cpl*=k;F.C.memberCAC*=k;}}
];
function sensitivity(P,F,target,d){
 d=d||.2;target=target||'founder';
 function val(p,f){return target==='founder'?runFounder(f,p).sum.cash:sum(runShop(p).months.map(function(x){return x.profit;}));}
 var base=val(P,F);
 var rows=SENS.map(function(s){
  var p1=clone(P),f1=clone(F);s.f(p1,f1,1-d);var lo=val(p1,f1);
  var p2=clone(P),f2=clone(F);s.f(p2,f2,1+d);var hi=val(p2,f2);
  return{id:s.id,name:s.name,lo:lo-base,hi:hi-base,span:Math.abs(hi-lo)};
 });
 rows.sort(function(a,b){return b.span-a.span;});
 return{base:base,rows:rows,d:d,target:target};
}

/* ---------- 蒙地卡羅 ---------- */
function mcPerturb(P,F,r){
 var p=clone(P),f=clone(F);
 p.noShow=clamp(p.noShow*(.7+.6*r()),.02,.3);
 p.ret90=clamp(p.ret90+(r()-.5)*.1,.5,.97);
 p.incidentMult*=Math.exp((r()-.5)*1.2);
 p.inq*=.8+.4*r();
 f.cpl*=.6+r();f.C.memberCAC*=.6+r();
 f.A.conv=clamp(f.A.conv*(.6+.7*r()),.05,.9);f.B.conv=clamp(f.B.conv*(.6+.7*r()),.05,.9);f.trialTake=clamp(f.trialTake*(.7+.6*r()),.1,.9);
 f.churnMult=(f.churnMult||1)*(.6+r());f.C.memberChurn*=.6+r();
 return{P:p,F:f};
}
function mcRun(P,F,n,onDone,onProg){
 var r=rngMake(20261103),res=[],i=0;
 function chunk(){
  var t=Date.now();
  while(i<n&&Date.now()-t<40){
   var q=mcPerturb(P,F,r),seed=1000+i;
   var fr=runFounder(q.F,q.P,{det:false,seed:seed});
   var sh=runShop(q.P,{det:false,seed:seed});
   res.push({cash:fr.months.map(function(x){return x.cash;}),mrr:fr.months.map(function(x){return x.mrr;}),
    minCash:fr.sum.minCash,cash12:fr.sum.cash,mrr12:fr.sum.mrr,profit:sum(sh.months.map(function(x){return x.profit;})),serious:sum(sh.months.map(function(x){return x.serious;})),rating:sh.months[sh.months.length-1].rating});
   i++;
  }
  if(onProg)onProg(i/n);
  if(i<n)setTimeout(chunk,0);else onDone(mcSummary(res));
 }
 chunk();
}
function quant(a,q){var s=a.slice().sort(function(x,y){return x-y;});var idx=(s.length-1)*q,lo=Math.floor(idx),hi=Math.ceil(idx);return s[lo]+(s[hi]-s[lo])*(idx-lo);}
function mcSummary(res){
 var M=res[0].cash.length,band=[];
 for(var m=0;m<M;m++){var col=res.map(function(x){return x.cash[m];});band.push({p10:quant(col,.1),p50:quant(col,.5),p90:quant(col,.9)});}
 var c12=res.map(function(x){return x.cash12;});
 return{n:res.length,band:band,pNeg:res.filter(function(x){return x.minCash<0;}).length/res.length,
  cash12:{p10:quant(c12,.1),p50:quant(c12,.5),p90:quant(c12,.9)},
  mrr12:{p10:quant(res.map(function(x){return x.mrr12;}),.1),p50:quant(res.map(function(x){return x.mrr12;}),.5),p90:quant(res.map(function(x){return x.mrr12;}),.9)},
  profit:{p10:quant(res.map(function(x){return x.profit;}),.1),p50:quant(res.map(function(x){return x.profit;}),.5),p90:quant(res.map(function(x){return x.profit;}),.9)},
  pSerious:res.filter(function(x){return x.serious>=1;}).length/res.length,
  pRating4:res.filter(function(x){return x.rating<4;}).length/res.length,raw:res};
}

/* ---------- 四模式比較 ---------- */
var MODEL_TIPS={
 A:{risk:'店家試用期 AI 未磨合好就要決定；支援時間隨店數線性上升',start:'先做 3 間種子店證明價值，再標準化成套餐'},
 B:{risk:'創辦人時間：每間搭建 25 小時，好難複製',start:'只接 3–5 間，邊做邊寫低標準流程'},
 C:{risk:'服務品質唔喺你手；會員可能淨係為折扣入會；動物安全爭議',start:'未有可靠合作店網絡之前唔好做'},
 D:{risk:'同時做三樣嘢，容易樣樣都做唔好',start:'先 3 間種子店（顧問價），有數據先轉 SaaS，最後先加會員'}
};
function compareModels(P,F){
 return ['A','B','C','D'].map(function(m){
  var f=clone(F);f.model=m;var R=runFounder(f,P);var s=sensitivity(P,f,'founder',.2);
  return{model:m,sum:R.sum,months:R.months,top:s.rows.slice(0,3)};
 });
}

/* ---------- 10 條問題 ---------- */
function qAnswers(P,F){
 var out=[],P0=clone(P);
 /* Q1 */
 var need=Math.ceil(50000/1500),fA=clone(F);fA.model='A';fA.A.fee=1500;var rA=runFounder(fA,P0);
 out.push({q:'如果向每間店收 HK$1,500／月，要幾多間店先有 HK$50,000 MRR？',a:'要 '+need+' 間。按而家假設，12 個月後 A 模式 MRR 約 '+hk(rA.sum.mrr)+'（'+rA.sum.accts.toFixed(1)+' 間），'+(rA.sum.mrr50?'第 '+rA.sum.mrr50+' 個月到 $50,000。':'12 個月內未到 $50,000。')+' 每月流失 3% 嘅話，維持 34 間要每月補 1 間。'});
 /* Q2 */
 var avail=F.hoursAvail-F.contentH-F.devH;
 out.push({q:'如果每間店每月要 4 小時支援，一人創辦人最多服務幾多間？',a:'可用時數 '+avail+' 小時（扣咗內容 '+F.contentH+'、開發 '+F.devH+'）。全部做支援：'+Math.floor(avail/4)+' 間；留 30% 做銷售：'+Math.floor(avail*.7/4)+' 間；容許超時 40%：'+Math.floor((F.hoursAvail*1.4-F.contentH-F.devH)*.7/4)+' 間（但士氣會跌）。要做到 34 間，每店支援要壓到 '+(avail*.7/34).toFixed(1)+' 小時以下。'});
 /* Q3 */
 var p12=lvZero(P0);p12.noShow=.12;var p6=clone(p12);p6.noShow=.06;
 var s12=shopSummary(runShop(p12).months),s6=shopSummary(runShop(p6).months);
 out.push({q:'如果 AI 將 no-show 由 12% 降到 6%，對一間 2 位美容師嘅店值幾多錢？',a:'每月多完成約 '+(s6.done-s12.done).toFixed(1)+' 次服務，每月利潤多約 '+hk(s6.profit-s12.profit)+'。如果店已經長期滿檔，臨時取消冇人補，價值會細啲；扣 AI 月費（L2 約 $600–1,200）先係淨值。'});
 /* Q4 */
 var b8=lvZero(P0);b8.cycMult=8/6.2;var m6=clone(b8);m6.memberShare=1;m6.memberAnyway=0;m6.memberCyc=.75;m6.memberDisc=.15;
 var sp8=clone(b8),sp6=clone(m6);sp8.capMult=1.6;sp6.capMult=1.6;sp8.inq*=1;sp6.inq*=1;
 var f8=clone(b8),f6=clone(m6);f8.inq*=1.8;f6.inq*=1.8;
 var A1=shopSummary(runShop(sp8).months),A2=shopSummary(runShop(sp6).months),B1=shopSummary(runShop(f8).months),B2=shopSummary(runShop(f6).months);
 out.push({q:'如果會員制將回訪週期由 8 週縮到 6 週，但折扣 15%，毛利會唔會跌？',a:'店有空位：每月利潤 '+hk(A1.profit)+' → '+hk(A2.profit)+'（'+((A2.profit/A1.profit-1)*100).toFixed(0)+'%）。店已經滿檔：'+hk(B1.profit)+' → '+hk(B2.profit)+'（'+((B2.profit/B1.profit-1)*100).toFixed(0)+'%）。答案取決於產能：滿檔時多出嚟嘅次數會擠走全價客。'});
 /* Q5 */
 var q0=clone(P0);q0.lv.reply=2;var q1=clone(q0);q1.inqMult=1.3;q1.capMult=1.1;
 var Q0=shopSummary(runShop(q0).months),Q1=shopSummary(runShop(q1).months);
 out.push({q:'如果 AI 帶來 30% 更多查詢，但美容師只能多承接 10%，會點？',a:'每月完成 '+Q0.done.toFixed(0)+' → '+Q1.done.toFixed(0)+' 次（+'+((Q1.done/Q0.done-1)*100).toFixed(0)+'%）；因冇位流失嘅預約需求 '+Q0.lostDem.toFixed(0)+' → '+Q1.lostDem.toFixed(0)+' 個／月；等位 '+Q0.lead.toFixed(1)+' → '+Q1.lead.toFixed(1)+' 週；查詢 → 預約 '+pct(Q0.conv)+' → '+pct(Q1.conv)+'。新客查詢只係需求嘅一部分（大部分預約來自熟客），所以 +30% 查詢唔等於 +30% 生意；超出產能嘅部分變成等位同流失。'});
 /* Q6 */
 var w0=lvZero(P0);w0.quitRate=0;var w1=clone(w0);w1.quitRate=.10;var wq=clone(w0);wq.forceQuitWeek=13;
 var W0=shopSummary(runShop(w0).months),W1=shopSummary(runShop(w1).months),WQ=shopSummary(runShop(wq).months);
 out.push({q:'如果美容師離職率係每年 10%，對店家留存同收入有咩影響？',a:'期望值計，每月利潤少約 '+hk(W0.profit-W1.profit)+'。但離職係一次過嘅事：真係有人走（第 3 個月），全年每月平均少 '+hk(W0.profit-WQ.profit)+'，年尾活躍客 '+W0.act.toFixed(0)+' → '+WQ.act.toFixed(0)+'。蒙地卡羅頁可以睇機率分佈。'});
 /* Q7 */
 var i0=lvZero(P0),i1=clone(i0);i1.seriousRate=1/200;
 var I0=shopSummary(runShop(i0).months),I1=shopSummary(runShop(i1).months);
 out.push({q:'如果每 200 次服務有 1 次嚴重事故，長遠對口碑、退款同流失有咩影響？',a:'一年約 '+I1.serious.toFixed(1)+' 宗嚴重事故（預設 1/5,000 只有 '+I0.serious.toFixed(1)+' 宗）。Google 評分 '+I0.rating.toFixed(2)+' → '+I1.rating.toFixed(2)+'；每月退款 '+hk(I0.refunds)+' → '+hk(I1.refunds)+'；每月利潤 '+hk(I0.profit)+' → '+hk(I1.profit)+'。呢個比率等於門店做唔落去。'});
 /* Q8 Q9 */
 var cm=['A','B','C','D'].map(function(m){var f=clone(F);f.model=m;return{m:m,s:runFounder(f,P0).sum};});
 var fast=cm.filter(function(x){return x.s.mrr30;}).sort(function(a,b){return a.s.mrr30-b.s.mrr30;});
 out.push({q:'邊一種模式最快到 HK$30,000 MRR？',a:cm.map(function(x){return x.m+' '+MODELS[x.m]+'：'+(x.s.mrr30?'第 '+x.s.mrr30+' 個月':'12 個月內未到');}).join('；')+'。'+(fast.length?'最快係 '+fast[0].m+'。':'')});
 var hv=cm.slice().sort(function(a,b){return (b.s.hoursPerK||0)-(a.s.hoursPerK||0);});
 out.push({q:'邊一種模式最依賴創辦人時間？',a:cm.map(function(x){return x.m+'：每 $1,000 MRR 用 '+(x.s.hoursPerK?x.s.hoursPerK.toFixed(1):'—')+' 小時／月，平均負荷 '+Math.round(x.s.avgLoad*100)+'%';}).join('；')+'。最依賴：'+hv[0].m+' '+MODELS[hv[0].m]+'。'});
 /* Q10 */
 var se=sensitivity(P0,F,'founder',.2);
 out.push({q:'邊三個變數最影響 12 個月後嘅現金流？',a:'模式 '+F.model+'：'+se.rows.slice(0,3).map(function(r,i){return (i+1)+'. '+r.name+'（±20% → '+hk(r.lo)+' / '+hk(r.hi)+'）';}).join('；')+'。'});
 return out;
}
