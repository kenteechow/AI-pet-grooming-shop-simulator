/* p_goals：每週挑戰、里程碑、店舖等級同解鎖（v0.17）。
   - 每個星期一揀兩個挑戰（按間店狀況），星期日收工結算；做到 +1 經驗、全體員工士氣 +2%。
   - 里程碑一次性，+2 經驗。經驗累積升級：1 新開小店 → 2 街坊熟悉 → 3 街坊名店 → 4 區內口碑店 → 5 準備開分店。
   - 解鎖：2 級網紅合作（小型）同加購服務；3 級網紅（中、大型）同加一張美容枱；4 級寵物用品寄賣；5 級分店計劃（玩法未做）。
   - 所有金額同效果係示範估算。網紅影片要標明係廣告；店做唔切嘅話，多咗嘅查詢只會變成等位或者流失。 */
var LEVELS=[{n:'新開小店',xp:0},{n:'街坊熟悉',xp:4},{n:'街坊名店',xp:12},{n:'區內口碑店',xp:24},{n:'準備開分店',xp:40}];
function glInit(){s.gl={xp:0,lv:1,ch:[],hist:[],ms:{},incM:0,five:0,kol:null,addon:0,retail:0};}
HOOKS.init.push(function(){glInit();});
function gl(){if(!s.gl)glInit();return s.gl;}
function glLevel(xp){var l=1;LEVELS.forEach(function(L,i){if(xp>=L.xp)l=i+1;});return l;}
function glAddXP(n,why){var g=gl(),old=g.lv;g.xp+=n;g.lv=glLevel(g.xp);if(g.lv>old){news('升級','間店升到第 '+g.lv+' 級「'+LEVELS[g.lv-1].n+'」！'+LV_UNLOCK[g.lv]);if(!s.bg&&!s.demoFF)queueEvent('levelup',{lv:g.lv});}}
var LV_UNLOCK={2:'解鎖：網紅合作（小型）、加購服務。',3:'解鎖：網紅合作（中型、大型）、加一張美容枱。',4:'解鎖：寵物用品寄賣。',5:'可以開始籌備分店（玩法未做）。'};
/* ---------- 本週數據 ---------- */
function wkStat(){var w=s.wk,ap=w?w.appts:[],st={done:0,ns:0,inc:0,five:0,notes:0};
 ap.forEach(function(a){if(a.st==='done'||a.st==='gone'){st.done++;if(a.inc)st.inc++;}if(a.st==='noshow')st.ns++;});
 s.fb.forEach(function(f){if(w&&f.day>=w.start&&f.day<w.start+7&&f.stars===5)st.five++;});
 if(s.cl&&w)for(var k in s.cl.pets)s.cl.pets[k].notes.forEach(function(n){if(n.day>=w.start&&n.day<w.start+7&&(n.st==='confirmed'||n.st==='corrected'))st.notes++;});
 st.nsr=st.done+st.ns?st.ns/(st.done+st.ns):0;return st;}
/* ---------- 挑戰庫 ---------- */
var CHAL={
 ns:{t:function(c){return '本週 No-show 低過 '+Math.round(c.v*100)+'%';},prog:function(c,st){return 'No-show '+(st.nsr*100).toFixed(1)+'%（'+st.ns+' 個）';},ok:function(c,st){return st.done>5&&st.nsr<c.v;},tip:'提醒訊息、收訂金、「覆」AI 自動提醒都幫到手。',mk:function(){return {v:Math.max(.03,Math.round(s.wk.h.ns*.85*100)/100)};}},
 five:{t:function(c){return '本週攞 '+c.v+' 個五星評價';},prog:function(c,st){return st.five+' / '+c.v;},ok:function(c,st){return st.five>=c.v;},tip:'準時、冇事故、報告卡寫得好，客人先會畀五星。',mk:function(){return {v:Math.max(2,Math.ceil(okN()*.25*.7*1.15))};}},
 done:{t:function(c){return '本週完成 '+c.v+' 隻';},prog:function(c,st){return st.done+' / '+c.v;},ok:function(c,st){return st.done>=c.v;},tip:'要做多過原本排咗嘅：減少 no-show、補候補、補取消位。',mk:function(){var n=okN();return {v:Math.max(5,n+Math.max(1,Math.round(n*.05)))};}},
 safe:{t:function(){return '本週零事故';},prog:function(c,st){return st.inc?st.inc+' 宗事故':'暫時冇事故';},ok:function(c,st){return st.inc===0&&st.done>5;},tip:'唔好排太密、睇清楚毛孩紀錄、落手做時跟足步驟。',mk:function(){return {};}},
 notes:{t:function(c){return '本週為 '+c.v+' 隻毛孩寫低已確認紀錄';},prog:function(c,st){return st.notes+' / '+c.v;},ok:function(c,st){return st.notes>=c.v;},tip:'「檔」AI 會整理語音備註；有人工審核先算確認。',mk:function(){var lv=s.lv.file||0,r=[.3,.4,.8,.9][lv]*(lv>=2&&!s.review?.1:1);return {v:Math.max(2,Math.round(okN()*CL_RATE.observe*r*1.25))};}},
 drafts:{t:function(){return '星期日收工前冇未確認 AI 草稿';},prog:function(){var d=clStats().draft;return d?'仲有 '+d+' 份未確認':'冇未確認草稿';},ok:function(){return clStats().draft===0;},tip:'開人工審核，或者喺客人紀錄叫美容師核對。',mk:function(){return {};},when:function(){return (s.lv.file||0)>=2;}}};
/* 本週預計完成幾多隻（排咗、會嚟嘅） */
function okN(){return s.wk?s.wk.appts.filter(function(a){return a.out==='ok'&&a.st!=='lost';}).length:0;}
function glPickWeek(){var g=gl(),keys=Object.keys(CHAL).filter(function(k){return !CHAL[k].when||CHAL[k].when();}),out=[];
 while(out.length<2&&keys.length){var i=Math.floor(R()*keys.length),k=keys.splice(i,1)[0];var c=CHAL[k].mk();c.id=k;c.wk=s.wk.start;out.push(c);}g.ch=out;}
function glWeekEnd(){var g=gl();if(!g.ch||!g.ch.length)return;var st=wkStat(),won=0;
 g.ch.forEach(function(c){c.done=CHAL[c.id].ok(c,st)?1:0;if(c.done){won++;g.won=(g.won||0)+1;}g.hist.push({wk:c.wk,id:c.id,t:CHAL[c.id].t(c),done:c.done});});if(g.hist.length>40)g.hist=g.hist.slice(-40);
 if(won){activeStaff().forEach(function(x){x.morale=Math.min(1,x.morale+.02*won);});news('挑戰','本週挑戰完成 '+won+'／'+g.ch.length+' 個：經驗 +'+won+'，團隊士氣 +'+(2*won)+'%');glAddXP(won);}
 else news('挑戰','本週挑戰冇完成，下星期再試');g.ch=[];}
/* 每週日收工結算（weekEnd 喺 planWeek 之前），星期一揀新挑戰 */
HOOKS.week.unshift(function(){if(!s.bg)glWeekEnd();});
HOOKS.plan=HOOKS.plan||[];HOOKS.plan.push(function(){if(!s.bg)glPickWeek();});
/* ---------- 里程碑 ---------- */
function regCount(){var n=0;if(s.cl)for(var k in s.cl.pets){var p=s.cl.pets[k];if(p.cnt.done>=2||(p.pre&&p.cnt.done>=1))n++;}return n;}
function totalDone(){return gl().done||0;}
var MILES=[
 {id:'ai1',t:'第一次部署 AI 崗位',ok:function(){return ROLES.some(function(r){return s.lv[r.id]>0;});}},
 {id:'d100',t:'累計完成 100 隻',ok:function(){return totalDone()>=100;}},
 {id:'reg30',t:'30 隻熟客毛孩（有紀錄）',ok:function(){return regCount()>=30;}},
 {id:'five10',t:'累計 10 個五星評價',ok:function(){return gl().five>=10;}},
 {id:'r46',t:'Google 評分去到 4.6',ok:function(){return s.S.rating>=4.6;}},
 {id:'safeM',t:'成個月零事故',ok:function(){return gl().safeMonth;}},
 {id:'prof',t:function(){return '單月經營利潤過 '+hk(s.open==='solo'?15000:40000);},ok:function(){var m=s.months[s.months.length-1];return m&&m.profit>=(s.open==='solo'?15000:40000);}},
 {id:'d500',t:'累計完成 500 隻',ok:function(){return totalDone()>=500;}},
 {id:'reg100',t:'100 隻熟客毛孩（有紀錄）',ok:function(){return regCount()>=100;}}];
function mileTitle(m){return typeof m.t==='function'?m.t():m.t;}
function glCheckMiles(){var g=gl();MILES.forEach(function(m){if(!g.ms[m.id]&&m.ok()){g.ms[m.id]=s.day;news('里程碑','達成「'+mileTitle(m)+'」：經驗 +2');glAddXP(2);}});}
HOOKS.day.push(function(){if(!s.bg)glCheckMiles();});
HOOKS.month.push(function(rec){var g=gl();g.safeMonth=g.incM===0&&rec.done>20;g.incM=0;});
/* 五星同事故計數（onDone 之後） */
function glOnDone(a){var g=gl();g.done=(g.done||0)+1;if(a.inc)g.incM++;var f=s.fb[0];if(f&&f.pid===a.pid&&f.day===s.day&&f.stars===5&&f._gl!==1){f._gl=1;g.five++;}}
/* ---------- 解鎖：網紅合作 ---------- */
var KOL=[{id:'s',n:'小型寵物 KOL（約 1–3 萬追蹤）',lv:2,cost:2500,boost:1.2,wk:2,note:'多數係附近街坊，回頭率正常'},
 {id:'m',n:'中型寵物 KOL（約 5–10 萬追蹤）',lv:3,cost:8000,boost:1.4,wk:3,note:'查詢多好多，部分客住得遠'},
 {id:'l',n:'大型網紅（20 萬追蹤以上）',lv:3,cost:20000,boost:1.8,wk:3,note:'湧入大量試新嘢嘅客，第一次之後回頭率較低（−15%，8 週）'}];
function kolBuy(id){var k=KOL.filter(function(x){return x.id===id;})[0],g=gl();if(!k||g.lv<k.lv||g.kol&&g.kol.until>s.day||s.cash<k.cost)return;
 oneOff(-k.cost,'網紅合作：'+k.n,'mkt');addMod('inqMult','mul',k.boost,k.wk,false,'網紅影片');if(k.id==='l'&&s.base.firstRetMult!=null)addMod('firstRetMult','mul',.85,8,false,'網紅帶嚟嘅試新客');
 g.kol={id:k.id,from:s.day,until:s.day+k.wk*7};news('宣傳','請咗'+k.n+'拍片（'+hk(k.cost)+'），之後 '+k.wk+' 週查詢多咗；影片要標明係廣告');
 if(s.wk&&s.wk.h&&s.wk.h.util>.9)news('宣傳','提提你：美容枱使用率已經過九成，多咗嘅查詢好多會變成等位或者流失');}
/* 加購服務：刷牙、SPA、去淚痕（2 級） */
function addonToggle(){var g=gl();if(g.lv<2)return;g.addon=g.addon?0:1;var d=g.addon?1:-1;s.base.addonRate=Math.max(0,s.base.addonRate+.10*d);s.base.consum=Math.max(0,s.base.consum+5*d);news('服務',g.addon?'開始推加購服務（刷牙、SPA、去淚痕）：每隻多收機會高咗，用品成本 +HK$5／隻':'停咗推加購服務');}
/* 加一張美容枱（3 級，舖位要有位） */
function tableMax(){return s.open==='solo'?1:s.open==='old'?3:3;}
function addTable(){var g=gl();if(g.lv<3||s.base.tables>=tableMax()||s.cash<30000)return;oneOff(-30000,'加一張美容枱（裝修同工具）','setup');s.base.tables++;news('舖位','加咗一張美容枱，而家有 '+s.base.tables+' 張；記得要有足夠美容師先用得盡');}
/* 寵物用品寄賣（4 級）：每月零售毛利約 HK$2,000（示範估算，當減少雜項開支計） */
function retailToggle(){var g=gl();if(g.lv<4)return;g.retail=g.retail?0:1;s.base.misc=Math.max(0,s.base.misc+(g.retail?-2000:2000));news('零售',g.retail?'開始寄賣寵物用品：每月零售毛利約 HK$2,000（示範估算）':'停咗寄賣');}
if(typeof LED_CAT!=='undefined')LED_CAT.mkt='宣傳';
/* 升級彈窗 */
EVENTS.levelup={title:'店舖升級',body:function(c){return '間店升到第 '+c.lv+' 級「'+LEVELS[c.lv-1].n+'」。'+LV_UNLOCK[c.lv];},ai:'等級反映你完成咗幾多挑戰同里程碑；解鎖嘅嘢都要你自己決定用唔用，各有成本。',
 ch:[{t:'繼續',pro:[],con:[],f:function(){}},{t:'去「成長」睇睇',pro:['睇解鎖咗咩'],con:[],f:function(){if(typeof setTimeout==='function'&&typeof openPanel==='function')setTimeout(function(){PANEL.id=null;openPanel('grow');},0);}}]};
/* ---------- 介面：成長面板 ---------- */
function pGrow(sub){var g=gl(),L=LEVELS[g.lv-1],nx=LEVELS[g.lv],st=wkStat();
 var head='<div class="glh"><span class="gllv">'+g.lv+'</span><div><b>'+L.n+'</b><small>經驗 '+g.xp+(nx?' / '+nx.xp+' 升「'+nx.n+'」':'（最高級）')+'</small><span class="bar"><i style="width:'+(nx?Math.round((g.xp-L.xp)/(nx.xp-L.xp)*100):100)+'%"></i></span></div></div>';
 if(sub==='miles')return head+'<ul class="gll">'+MILES.map(function(m){var d=g.ms[m.id];return '<li class="'+(d!=null?'done':'')+'"><span class="gd-c"></span><span>'+esc(mileTitle(m))+(d!=null?'<small>'+dateStr(d).replace(/^\d+年/,'')+' 達成 · +2 經驗</small>':'')+'</span></li>';}).join('')+'</ul>';
 if(sub==='unlock'){var kol=g.kol&&g.kol.until>s.day;
  var card=function(lv,title,desc,btn){var lock=g.lv<lv;return '<div class="insc'+(lock?' lock':'')+'"><div class="insh"><b>'+title+'</b><span class="pill'+(lock?'':' ok')+'">'+(lock?lv+' 級解鎖':'已解鎖')+'</span></div><p>'+desc+'</p>'+(lock?'':btn||'')+'</div>';};
  return head+'<div class="insg">'+
   KOL.map(function(k){var dis=kol?'有緊一個宣傳':s.cash<k.cost?'現金唔夠':'';return card(k.lv,k.n,hk(k.cost)+'；查詢 +'+Math.round((k.boost-1)*100)+'%，持續 '+k.wk+' 週。'+k.note+'。（示範估算）','<button class="btn pri" data-act="kol" data-k="'+k.id+'"'+(dis?' disabled title="'+dis+'"':'')+'>'+(dis||'請佢拍片')+'</button>');}).join('')+
   card(2,'加購服務','刷牙、SPA、去淚痕：加購機會 +10 個百分點，每隻用品成本 +HK$5。','<button class="btn'+(g.addon?'':' pri')+'" data-act="addon">'+(g.addon?'停推加購':'開始推加購')+'</button>')+
   card(3,'加一張美容枱','HK$30,000 裝修同工具。'+(s.base.tables>=tableMax()?'舖位已經放唔落多一張（而家 '+s.base.tables+' 張）。':'而家 '+s.base.tables+' 張；要有美容師先用得盡。'),s.base.tables>=tableMax()?'':'<button class="btn pri" data-act="addtable"'+(s.cash<30000?' disabled title="現金唔夠"':'')+'>加枱</button>')+
   card(4,'寵物用品寄賣','每月零售毛利約 HK$2,000（示範估算）。','<button class="btn'+(g.retail?'':' pri')+'" data-act="retail">'+(g.retail?'停止寄賣':'開始寄賣')+'</button>')+
   card(5,'分店計劃','間店穩定之後可以考慮開分店。','<p class="note">分店玩法未做。</p>')+'</div>';}
 return head+'<h3>本週挑戰</h3>'+(g.ch.length?'<div class="insg">'+g.ch.map(function(c){var C=CHAL[c.id],ok=C.ok(c,st);return '<div class="insc"><div class="insh"><b>'+esc(C.t(c))+'</b><span class="pill '+(ok?'ok':'')+'">'+(ok?'而家達標':'進行中')+'</span></div><p>'+esc(C.prog(c,st))+'</p><p class="note">'+esc(C.tip)+'</p></div>';}).join('')+'</div><p class="note">星期日收工結算：每完成一個 +1 經驗、團隊士氣 +2%。</p>':'<p class="note">下星期一會有新挑戰。</p>')+
  (g.hist.length?'<h3>之前嘅挑戰</h3><ul class="gll">'+g.hist.slice(-8).reverse().map(function(h){return '<li class="'+(h.done?'done':'')+'"><span class="gd-c"></span><span>'+esc(h.t)+'<small>第 '+(Math.floor(h.wk/7)+1)+' 週 · '+(h.done?'完成':'未完成')+'</small></span></li>';}).join('')+'</ul>':'');}
/* HUD 細卡：第一週目標收埋之後顯示本週挑戰 */
function renderGoalCard(){var el=document.getElementById('goalCard');if(!el)return;var g=s&&s.gl;
 if(!s||s.bg||s.demo||s.visit||!g||!g.ch||!g.ch.length||(typeof guideOn==='function'&&guideOn())){el.hidden=true;return;}
 var st=wkStat(),h='<button class="gc-h" data-act="panel" data-p="grow"><b>本週挑戰</b><span class="num">Lv '+g.lv+'</span></button>'+g.ch.map(function(c){var C=CHAL[c.id],ok=C.ok(c,st);return '<div class="gc-r'+(ok?' ok':'')+'"><span class="gd-c"></span><span>'+esc(C.t(c))+'<small>'+esc(C.prog(c,st))+'</small></span></div>';}).join('');
 if(el._h!==h){el.innerHTML=h;el._h=h;}el.hidden=false;}
if(typeof document!=='undefined'){
 SUBS.grow=[['ch','本週挑戰'],['miles','里程碑'],['unlock','解鎖']];DOCK.splice(DOCK.length-1,0,['grow','長','成長']);
 (function(){var _rh=renderHUD;renderHUD=function(){_rh.apply(this,arguments);var g=document.getElementById('game');if(g&&!document.getElementById('goalCard')&&document.getElementById('hudTL')){var d=document.createElement('div');d.id='goalCard';d.className='goalcard';d.hidden=true;g.appendChild(d);}renderGoalCard();};})();
 document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el||!s)return;var a=el.getAttribute('data-act');
  if(a==='kol'){kolBuy(el.getAttribute('data-k'));renderPanel();renderHUD();}
  if(a==='addon'){addonToggle();renderPanel();}
  if(a==='addtable'){addTable();renderPanel();}
  if(a==='retail'){retailToggle();renderPanel();}});}
