/* p_game：遊戲狀態、開局、每週排預約、每日推進、收工、月結、員工、對照組、AI 嘅一日、存檔。 */
var s=null;
var HOOKS={init:[],day:[],week:[],month:[],sync:[]};
var START=new Date(2027,0,4);
var OPEN_MIN=630,CLOSE_MIN=1170,DAY0=540,DAY1=1440,LUNCH=[780,825];
var WKD=['一','二','三','四','五','六','日'];
var DAYW=[.12,.12,.13,.13,.15,.18,.17];
var SVC={wash:{n:'洗澡',seal:'洗',t:.75,p:.95,c:'s1'},cut:{n:'全剪',seal:'剪',t:1.3,p:1.35,c:'s2'},nail:{n:'修甲清耳',seal:'甲',t:.3,p:.35,c:'s3'},cat:{n:'貓美容',seal:'貓',t:1,p:1,c:'s4'}};
var SVCMIX={s:{wash:.6,cut:.2,nail:.2},c:{cut:.55,wash:.3,nail:.15},m:{wash:.75,cut:.1,nail:.15},l:{wash:.75,cut:.1,nail:.15},k:{cat:1},o:{wash:.6,cut:.3,nail:.1}};
var PETN=['豆豆','波波','啤啤','布甸','曲奇','芝麻','雪糕','糖糖','毛毛','肥仔','妹妹','小白','朱古力','奶茶','多多','樂樂','皮蛋','菠蘿','蛋撻','栗子','咖啡','雲呢拿','墨墨','阿福','Lucky','Coco','Milo','Mocha','Lulu','Bobo','花生','湯圓','檸檬','冬菇','QQ','叮噹'];
var OWNN=['陳太','李生','黃小姐','張太','何生','林小姐','梁太','吳生','鄭小姐','劉太','Miss Lam','Mr Wong','蔡太','葉生','馮小姐','曾太'];
var BREED={s:['芝娃娃','八哥','法鬥'],c:['貴婦','比熊','西施','松鼠','約瑟爹利'],m:['柴犬','柯基','史納莎'],l:['金毛','哈士奇','拉布拉多'],k:['唐貓','波斯貓','英短'],o:['老年西施','皮膚敏感比熊','12 歲貴婦']};
var TRAITS=[
 {id:'catpro',n:'貓專家',hint:'CV 寫「貓美容比賽入圍」',d:'做貓快兩成'},
 {id:'bigfear',n:'怕大狗',hint:'面試時避開大狗話題',d:'大狗事故率高'},
 {id:'social',n:'熟客緣好',hint:'話自己有舊客會跟過嚟',d:'回頭率高，但走嗰陣帶走多啲客'},
 {id:'careful',n:'手慢但細心',hint:'作品集好靚',d:'慢 15%，事故少 30%'},
 {id:'fast',n:'手快',hint:'話自己一日做 8 隻',d:'快 15%，事故多 30%'},
 {id:'tech',n:'鍾意用新嘢',hint:'用過 MoeGo',d:'願意多輸入 20 秒資料'},
 {id:'oldschool',n:'抗拒打字',hint:'冇用開電腦',d:'只願意輸入 15 秒資料'}];
var OPENINGS=[
 {id:'community',name:'社區美容店',ok:1,diff:'易–中',desc:'觀塘樓上舖 600 呎。你（老闆兼美容師）、1 位全職美容師、1 位兼職助理。未用 AI，起始現金 HK$150,000。'},
 {id:'allai',name:'全 AI 示範店',ok:1,diff:'示範',desc:'同社區美容店一樣，但 6 個崗位一開始就係 L3，有人工審核。用嚟睇 AI 嘅上限同盲點。'},
 {id:'solo',name:'一人工作室',ok:1,diff:'中',desc:'荃灣樓上舖 300 呎，一張美容枱，只有你一個。老闆時間就係產能，AI 慳到嘅每一分鐘都可以變成多剪一隻。起始現金 HK$80,000。'},
 {id:'old',name:'人手過多嘅老店',ok:1,diff:'難',desc:'深水埗地舖 900 呎、7 個員工（連前台），租 HK$38,000，生意比以前跌咗兩成，租約 8 個月後到期。起始現金 HK$220,000。'}];

function R(){return s.rng();}
/* 每張預約自己一條隨機數：唔受每幀推進幾多分鐘影響，固定種子先可以重現 */
function RS(k,fn){var o=s.rng;s.rng=rngMake((s.seed*7919+k*104729)%2147483647+1);try{return fn();}finally{s.rng=o;}}
function pick(a){return a[Math.floor(R()*a.length)];}
function pickW(o){var r=R(),acc=0;for(var k in o){acc+=o[k];if(r<acc)return k;}return Object.keys(o)[0];}
function probRound(x){var f=Math.floor(x);return f+(R()<x-f?1:0);}
function r5(x){return Math.max(15,Math.round(x/5)*5);}
function dateOf(d){var x=new Date(START);x.setDate(x.getDate()+d);return x;}
function dateStr(d){var x=dateOf(d);return x.getFullYear()+'年'+(x.getMonth()+1)+'月'+x.getDate()+'日（'+WKD[d%7]+'）';}
function hm(t){t=Math.round(t);return String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0');}
function weekNo(d){return Math.floor((d==null?s.day:d)/7)+1;}

function mkStaff(o){return Object.assign({id:s.nextId++,morale:.8,joined:s.day,trait:null,shown:false,off:1,leaving:-1,hoursW:0,wage:0,comm:0,rate:0},o);}
/* 開局設定：店舖參數、員工、地點 */
var OPEN_CFG={
 community:{loc:'觀塘',shop:'樓上舖 600 呎',P:{},staff:[
  {name:'你（老闆）',role:'owner',cert:'ADBA C 級',exp:'8 年',off:0,morale:.85,shown:true},
  {name:'阿欣',role:'groomer',wage:16000,comm:40,cert:'JKC 美容師 C 級',exp:'4 年',off:1,trait:'catpro'},
  {name:'阿樂',role:'asst',rate:60,hoursW:30,cert:'寵物美容助理證書',exp:'1 年',off:2,trait:'tech'}]},
 solo:{loc:'荃灣',shop:'樓上舖 300 呎，一張美容枱',P:{groomers:1,tables:1,tubs:1,assistantH:0,rent:11000,active:170,inq:20,startCash:80000,utilities:2500,insurance:700,misc:1000,ads:1500},staff:[
  {name:'你（老闆）',role:'owner',cert:'IPG 中級',exp:'5 年',off:0,morale:.85,shown:true}]},
 old:{loc:'深水埗',shop:'地舖 900 呎，3 張美容枱、2 個浴缸',P:{groomers:4,tables:3,tubs:2,assistantH:70,rent:38000,active:560,inq:38,startCash:220000,utilities:7500,insurance:1800,misc:3500,ads:2500,ret90:.8},staff:[
  {name:'你（老闆）',role:'owner',cert:'ADBA B 級',exp:'15 年',off:0,morale:.75,shown:true},
  {name:'華姐',role:'groomer',wage:24000,comm:30,cert:'JKC B 級',exp:'18 年',off:1,trait:'oldschool',morale:.7},
  {name:'阿 Ben',role:'groomer',wage:18000,comm:40,cert:'ADBA C 級',exp:'6 年',off:2,trait:'fast'},
  {name:'Yoyo',role:'groomer',wage:16500,comm:40,cert:'IPG 初級',exp:'3 年',off:3,trait:'social'},
  {name:'阿嬋',role:'asst',rate:58,hoursW:40,cert:'冇',exp:'10 年',off:4,trait:'careful'},
  {name:'阿傑',role:'asst',rate:55,hoursW:30,cert:'寵物美容助理證書',exp:'1 年',off:5,trait:'bigfear'},
  {name:'Mandy',role:'front',wage:14500,cert:'中五',exp:'4 年',off:6,trait:'tech'}]}
};
OPEN_CFG.allai=OPEN_CFG.community;
function newGame(id,seed0){
 var cfg=OPEN_CFG[id],P=clone(DEF_SHOP);for(var k in cfg.P)P[k]=cfg.P[k];
 /* 第一次嚟嘅客回頭率 = 熟客 × 0.75（示範估算）；舊存檔冇呢個值就沿用舊模型 */
 if(P.firstRetMult==null)P.firstRetMult=.75;
 ROLES.forEach(function(r){P.lv[r.id]=id==='allai'?3:0;});P.quitRate=0;P.forceQuitWeek=-1;P.forceSeriousWeek=-1;
 /* 固定隨機（拍片用）：選項有開就用固定種子，同一個玩法每次結果一樣 */
 var fx=seed0!=null?seed0:(typeof OPTS!=='undefined'&&OPTS.fixed?OPTS.seed:null),seed=fx!=null?fx:(Date.now()%99991)+11;
 s={v:3,open:id,openName:OPENINGS.filter(function(o){return o.id===id;})[0].name,loc:cfg.loc,seed:seed,fixed:fx!=null,base:P,lv:clone(P.lv),review:1,
  day:0,t:DAY0,speed:1,paused:false,cash:P.startCash,today:{rev:0,done:0},wk:null,weeks:[],days:[],months:[],news:[],aiLog:[],aiDay:[],fb:[],
  staff:[],cands:[],nextId:1,mods:[],evSeen:{},evQ:[],modal:null,labels:1,rain:0,rainDay:-1,sel:null,exterior:0,visit:0,
  rep:{aiReplies:0,remind:0,refill:0,guards:0,errs:0,aiCost:0,savedMin:0,files:0,cards:0,recalls:0},
  shCash:P.startCash,shDaily:1,shHires:0,shBusy:0,newFlag:{},deployDay:{}};
 s.rng=rngMake(seed);
 s.S=newShop(P,{det:false,seed:seed});s.sh=newShop(lvZero(P),{det:false,seed:seed+1});s.sh.P.quitRate=.10;
 if(id==='allai'){ROLES.forEach(function(r){s.S.setupDone[r.id+3]=1;s.S.age[r.id]=8;s.deployDay[r.id]=-56;});}
 cfg.staff.forEach(function(o){var x=clone(o);if(x.trait)x.trait=TRAITS.filter(function(t){return t.id===o.trait;})[0];s.staff.push(mkStaff(x));});
 HOOKS.init.forEach(function(f){f(id);});
 genCands();planWeek();genAiDay();
 news('開店','你接手咗「'+s.openName+'」· '+cfg.loc+cfg.shop);
}
function actN(S){return sum(S.act)+sum(S.trial||[]);}
function activeStaff(){return s.staff.filter(function(x){return x.joined<=s.day&&x.leaving!==-2;});}
function groomers(){return activeStaff().filter(function(x){return x.role==='owner'||x.role==='groomer';});}
function hasTrait(st,id){return st.trait&&st.trait.id===id;}

/* 由員工、AI、事件組合出今週引擎參數 */
function syncP(){
 var P=clone(s.base),gs=groomers(),as=activeStaff().filter(function(x){return x.role==='asst';});
 var emp=gs.filter(function(x){return x.role==='groomer';});
 P.groomers=gs.length;P.ownerGrooms=1;
 P.groomerBase=emp.length?sum(emp.map(function(x){return x.wage;}))/emp.length:0;
 P.groomerComm=emp.length?sum(emp.map(function(x){return x.comm;}))/emp.length:0;
 P.assistantH=sum(as.map(function(x){return x.hoursW;}));
 P.assistantRate=as.length?sum(as.map(function(x){return x.rate;}))/as.length:60;
 var sp=1,inc=1;gs.forEach(function(g){if(hasTrait(g,'fast')){sp+=.15/gs.length;inc+=.3/gs.length;}if(hasTrait(g,'careful')){sp-=.15/gs.length;inc-=.3/gs.length;}if(hasTrait(g,'bigfear'))inc+=.15/gs.length;});
 P.capMult*=sp;P.incidentMult*=inc;
 var ws=0;activeStaff().forEach(function(x){if(hasTrait(x,'tech'))ws+=20;if(hasTrait(x,'oldschool'))ws-=15;});P.willSec=Math.max(5,P.willSec+ws);
 if(gs.some(function(g){return hasTrait(g,'social');}))P.ret90=Math.min(.97,P.ret90+.02);
 P.lv=clone(s.lv);P.review=s.review;P.quitRate=0;
 var fr=activeStaff().filter(function(x){return x.role==='front';});P.front=fr.length;P.extraWages=sum(fr.map(function(x){return x.wage*1.05;}));
 HOOKS.sync&&HOOKS.sync.forEach(function(f){f(P);});
 var Q=clone(s.base);Q.lv=lvZero(s.base).lv;Q.groomers=s.base.groomers+s.shHires;Q.quitRate=.10;
 s.mods=s.mods.filter(function(m){return m.until>s.day;});
 s.mods.forEach(function(m){[P,Q].forEach(function(X,i){if(i===1&&!m.both)return;if(m.op==='mul')X[m.k]*=m.v;else if(m.op==='add')X[m.k]+=m.v;else X[m.k]=m.v;});});
 s.S.P=P;s.sh.P=Q;
}
function addMod(k,op,v,weeks,both,why){s.mods.push({k:k,op:op,v:v,until:s.day+weeks*7,both:!!both,why:why});}

/* 每週一：引擎推一週，再拆成一張張預約 */
function planWeek(){
 syncP();
 var h=shopStep(s.S),hs=shopStep(s.sh);
 if(hs.lead>1||hs.util>.92){s.shBusy++;if(s.shBusy>=3&&s.shHires<3){s.shHires++;s.shBusy=0;news('隔籬','傳統對照店做唔切，請多一位美容師（月薪 HK$16,000）');}}else s.shBusy=0;
 if(!s.shDaily)s.shCash+=hs.profit;
 var P=s.S.P,wk={idx:Math.floor(s.day/7),start:s.day,h:h,hs:hs,appts:[],lost:0,rev:0,done:0,
  cost:{wages:h.wages/7,fixed:h.fixed/7,ai:(h.aiCost-h.setup)/7,refunds:h.refunds/7}};
 var n=probRound(h.booked),refill=rv(s.S,'sched','refill'),regShare=h.booked>0?clamp((h.rebook+h.react)/h.booked,0,1):.8;
 for(var i=0;i<n;i++){var na=mkAppt(h,P,Number(pickW({0:DAYW[0],1:DAYW[1],2:DAYW[2],3:DAYW[3],4:DAYW[4],5:DAYW[5],6:DAYW[6]})),regShare,refill);clAssign(na);wk.appts.push(na);}
 /* 事故分配畀「會完成」嘅預約 */
 var oks=wk.appts.filter(function(a){return a.out==='ok';});
 [['minor',h.minor],['skin',h.skin],['stress',h.stress],['serious',h.serious]].forEach(function(p){for(var k=0;k<p[1]&&oks.length;k++){var a=p[0]==='stress'?clPickWeighted(oks,clStressW):pick(oks);if(!a.inc)a.inc=p[0];}});
 s.wk=wk;s.weeks.push({idx:wk.idx,h:h,hs:hs});if(s.weeks.length>60)s.weeks.shift();
 scheduleWeek();
 s.rep.aiReplies+=h.aiReplies;s.rep.aiCost+=h.aiCost;
 (HOOKS.plan||[]).forEach(function(f){f();});
}
function mkAppt(h,P,d,regShare,refill){
 var tMult=1-(1-P.econ)*.4;
 var seg=SEGS[Number(pickW(SEGS.reduce(function(o,g,j){o[j]=g.share;return o;},{})))],svc=pickW(SVCMIX[seg.id]);
 var r=R(),out=r<h.ns?'noshow':r<h.ns+h.lc?'cancel':'ok';
 var price=Math.round(seg.price*P.priceIdx*tMult*SVC[svc].p/10)*10+(R()<h.addR?P.addonAmt:0);
 return {id:s.nextId++,day:s.day+d,seg:seg.id,svc:svc,dur:r5(seg.g*(1+seg.mat*.5)*SVC[svc].t),price:price,out:out,
  pet:pick(PETN),breed:pick(BREED[seg.id]),owner:pick(OWNN),regular:R()<regShare,pref:OPEN_MIN+Math.floor(R()*480),st:'booked',g:null,tb:0,a:0,b:0,
  refill:out==='cancel'&&R()<refill,inc:null,tag:''};
}
function staffWorks(st,day){return st.off!==day%7&&st.joined<=day&&(st.leaving<0||st.leaving>day);}
function scheduleDay(day,extra){
 var wk=s.wk,list=wk.appts.filter(function(a){return a.day===day&&a.st==='booked'&&a.g==null;}).sort(function(a,b){return a.pref-b.pref;});
 if(extra)list=extra;
 var busy=dayBusy(day);
 var gs=groomers().filter(function(g){return staffWorks(g,day);});
 function fit(gid,from,dur){var b=busy[gid].slice().sort(function(x,y){return x[0]-y[0];}),t=Math.max(OPEN_MIN,from);
  for(var i=0;i<b.length;i++){if(t+dur<=b[i][0])break;if(t<b[i][1])t=Math.max(t,b[i][1]);}return t+dur<=CLOSE_MIN?t:null;}
 var left=[];
 list.forEach(function(a){
  var best=null;
  gs.forEach(function(g,gi){var dur=a.dur*(a.seg==='k'&&hasTrait(g,'catpro')?.8:1)/(hasTrait(g,'fast')?1.15:hasTrait(g,'careful')?.85:1);dur=r5(dur);
   var t=fit(g.id,a.pref-60,dur);if(t==null)t=fit(g.id,OPEN_MIN,dur);if(t!=null&&(!best||Math.abs(t-a.pref)<Math.abs(best.t-a.pref)))best={g:g,t:t,dur:dur,gi:gi};});
  if(!best){left.push(a);return;}
  a.day=day;a.g=best.g.id;a.tb=best.gi%s.base.tables;a.a=best.t;a.b=best.t+best.dur;a.dur=best.dur;busy[best.g.id].push([a.a,a.b,a.id]);
 });
 return left;
}
function dayBusy(day){
 var wk=s.wk;wk.busy=wk.busy||{};if(wk.busy[day])return wk.busy[day];
 var gs=groomers().filter(function(g){return staffWorks(g,day);}),adm=wk.h.adminH*60/6,busy={};
 gs.forEach(function(g){busy[g.id]=[[LUNCH[0],LUNCH[1],'午飯']];if(g.role==='owner'){busy[g.id].push([OPEN_MIN,OPEN_MIN+Math.round(adm*.6/5)*5,'行政']);busy[g.id].push([CLOSE_MIN-Math.round(adm*.4/5)*5,CLOSE_MIN,'行政']);}});
 wk.adm=adm;wk.busy[day]=busy;return busy;
}
/* 排一週：先排原本嗰日，冇位就問主人改第二日（最近嗰日先），真係冇位先算流失 */
function scheduleWeek(){
 var over=[];for(var d=0;d<7;d++)over=over.concat(scheduleDay(s.day+d));
 over.forEach(function(a){
  var order=[1,-1,2,-2,3,-3,4,-4,5,-5,6,-6].map(function(k){return a.day+k;}).filter(function(x){return x>=s.day&&x<s.day+7;});
  for(var i=0;i<order.length;i++){if(!scheduleDay(order[i],[a]).length){a.moved=1;return;}}
  a.st='lost';s.wk.lost++;clMark(a,'lost');
 });
}
function todayAppts(){return s.wk?s.wk.appts.filter(function(a){return a.day===s.day;}):[];}
function staffName(id){var x=s.staff.filter(function(z){return z.id===id;})[0];return x?x.name:'—';}

/* 每幀推進 */
function advance(min){
 if(!s||s.modal||s.paused)return;
 /* 浮點誤差：貼近整數分鐘就對齊，否則時鐘會停喺 23:59.999999 呢類位，下一格可推嘅時間細到 0，成個遊戲卡死（v0.15.2） */
 var t0=s.t;s.t=Math.min(DAY1,s.t+min);var rt=Math.round(s.t);if(Math.abs(s.t-rt)<1e-6)s.t=rt;var t=s.t;
 todayAppts().forEach(function(a){
  if(a.st==='lost')return;
  if(a.out==='cancel'&&a.st==='booked'&&t>=a.a-120){a.st='cancel';clMark(a,'cancel');
   news('取消',a.owner+'臨時取消「'+a.pet+'」（'+a.breed+'）'+hm(a.a)+' · '+staffName(a.g));
   if(a.refill){var c=clone(a);c.id=s.nextId++;c.pid=null;c.oid=null;c.out='ok';c.st='booked';c.tag='候補';c.refill=false;c.inc=null;c.regular=true;RS(a.id*8+3,function(){clAssign(c);});s.wk.appts.push(c);s.rep.refill++;
    news('補位',(s.lv.sched>=2?'AI 候補補位：':'老闆打電話補位：')+c.owner+'嘅「'+c.pet+'」頂上 '+hm(c.a)+' · '+staffName(c.g));if(s.lv.sched>=2)aiLog('排','補咗 '+hm(c.a)+' 嘅取消位畀候補「'+c.pet+'」');}}
  if(a.out==='noshow'&&a.st==='booked'&&t>=a.a+15){a.st='noshow';clMark(a,'noshow');news('No-show',a.owner+'冇嚟冇講：「'+a.pet+'」'+hm(a.a)+' · '+staffName(a.g)+' 個位浪費咗');}
  if(a.out==='ok'){
   if(a.st==='booked'&&t>=a.a-15){a.st='arrived';RS(a.id*8+1,function(){clArrive(a);});}
   if(a.st==='arrived'&&t>=a.a)a.st='doing';
   if(a.st==='doing'&&t>=a.b){a.st='done';clMark(a,'done');s.today.rev+=a.price;s.today.done++;s.wk.rev+=a.price;s.wk.done++;RS(a.id*8+2,function(){clObserve(a);onDone(a);});}
   if(a.st==='done'&&t>=a.b+40)a.st='gone';
  }
 });
 taskTick(t);
 if(t>=DAY1)endOfDay();
}
var FB_GOOD=['剪得好企理，下次再嚟','準時交還，好放心','美容師好有耐性','報告卡好清楚','隻狗返到屋企好開心','價錢合理'];
var FB_BAD={minor:'甲剪得太深，流咗少少血',skin:'返屋企之後皮膚紅咗',stress:'隻狗返到屋企好驚，唔肯食嘢',serious:'隻狗受傷要睇獸醫',wait:'等咗好耐先有位',cut:'剪得太短，同講好嘅唔同'};
function onDone(a){
 if(a.inc)incidentCost(a);
 /* 落手做過：主人一定有反應，星數跟客人滿意度；五星口碑升少少，兩星或以下口碑跌（v0.18） */
 if(a.handsStars!=null){var hs=a.handsStars,htxt=a.handsTxt?a.handsTxt:a.inc?FB_BAD[a.inc]:hs>=5?pick(['美容師好細心，隻狗好放鬆','做得好仔細，仲記得佢怕咩','好專業，下次再搵你']):hs>=4?pick(FB_GOOD):hs>=3?'OK 啦，冇咩特別':'美容師好似唔太熟手，隻狗返嚟好驚';
  var fbh={day:s.day,t:a.b,pet:a.pet,owner:a.owner,pid:a.pid,oid:a.oid,good:hs>=4&&!a.inc,txt:htxt,stars:hs};s.fb.unshift(fbh);clFb(a,fbh);
  if(hs>=5)s.S.rating=Math.min(5,s.S.rating+.003);else if(hs<=2)s.S.rating=Math.max(1,s.S.rating-.012);
  if(a.inc){news(a.inc==='serious'?'嚴重事故':'投訴',a.owner+'：「'+a.pet+'」'+FB_BAD[a.inc]+' · '+staffName(a.g));if(a.inc==='serious')queueEvent('serious',{a:a});}
  else if(hs<=2)news('投訴',a.owner+'：「'+a.pet+'」'+htxt);}
 else if(a.inc){var txt=FB_BAD[a.inc],fbo={day:s.day,t:a.b,pet:a.pet,owner:a.owner,pid:a.pid,oid:a.oid,good:false,txt:txt,stars:{minor:3,skin:2,stress:2,serious:1}[a.inc]||2};s.fb.unshift(fbo);clFb(a,fbo);
  news(a.inc==='serious'?'嚴重事故':'投訴',a.owner+'：「'+a.pet+'」'+txt+' · '+staffName(a.g));
  if(a.inc==='serious')queueEvent('serious',{a:a});}
 else if(R()<(a.handsQ>=.9?.6:.25)){var fbg={day:s.day,t:a.b,pet:a.pet,owner:a.owner,pid:a.pid,oid:a.oid,good:true,txt:pick(FB_GOOD),stars:R()<(a.handsQ>=.9?.9:.7)?5:4};s.fb.unshift(fbg);clFb(a,fbg);}
 if(s.fb.length>60)s.fb.length=60;
 if(s.lv.file>=2){s.rep.files++;if(R()<.3)aiLog('檔','「'+a.pet+'」語音備註 → 標籤：'+pick(['左耳紅','怕吹風','毛結喺腋下','指甲黑色要慢剪','皮膚正常','怕陌生人'])+'（'+staffName(a.g)+'確認）');}
 if(s.lv.media>=2){s.rep.cards++;}
 if(typeof glOnDone==='function')glOnDone(a);
}
function endOfDay(){
 var wk=s.wk,P=s.S.P,ap=todayAppts(),c=wk.cost,rev=s.today.rev,done=s.today.done;
 var cats={wages:c.wages,fixed:c.fixed,ai:c.ai,refunds:c.refunds,consum:done*P.consum+rev*.6*P.cardFee};
 var cost=cats.wages+cats.fixed+cats.ai+cats.refunds+cats.consum;
 s.cash+=rev-cost;
 var shProfit=wk.hs.profit/7;if(s.shDaily)s.shCash+=shProfit;
 s.days.push({shProfit:shProfit,day:s.day,rev:rev,cost:cost,cats:cats,done:done,ns:ap.filter(function(a){return a.st==='noshow';}).length,cancel:ap.filter(function(a){return a.st==='cancel';}).length,lost:ap.filter(function(a){return a.st==='lost';}).length,booked:ap.length});
 if(s.days.length>400)s.days.shift();
 news('日結',dateStr(s.day)+' 日結：完成 '+done+' 隻，收入 '+hk(rev)+'，支出 '+hk(cost)+'，現金 '+hk(s.cash));
 if(s.rain){s.wetDay=s.day+1;s.wetT=DAY0+180;}
 var d0=dateOf(s.day),d1=dateOf(s.day+1);
 s.day++;s.t=0;s.today={rev:0,done:0};
 HOOKS.day.forEach(function(f){f();});
 if(s.day%7===0){weekEnd();planWeek();}
 if(d1.getMonth()!==d0.getMonth())monthEnd(d0);
 rollWeather();genAiDay();dayEvents();save();
}
function weekEnd(){
 var wk=s.wk,h=wk.h;
 activeStaff().forEach(function(x){
  var tgt=x.role==='owner'?.85-Math.max(0,(h.adminH+40)-50)*.015:.82-Math.max(0,h.util-.85)*2;
  x.morale=clamp(x.morale+(tgt-x.morale)*.3,.1,1);
  if(!x.shown&&s.day-x.joined>=21&&x.trait){x.shown=true;news('員工',x.name+'做咗 3 週，你發現佢「'+x.trait.n+'」：'+x.trait.d);}
  if(x.role!=='owner'&&x.leaving<0){var q=.10/52*(x.morale<.5?3:x.morale<.65?1.6:1);if(R()<q){x.leaving=s.day+7;news('員工',x.name+'遞信，一週後走');}}
 });
 s.staff.forEach(function(x){if(x.leaving>=0&&x.leaving<=s.day&&x.leaving!==-2){x.leaving=-2;
  if(x.role==='groomer'){var f=s.base.followShare*(hasTrait(x,'social')?1.5:1)/Math.max(1,groomers().length+1),n=sum(s.S.act)*f;subAct(s.S,n);s.S.dorm[5]+=n;news('員工',x.name+'走咗，約 '+Math.round(n)+' 位熟客跟咗佢走');}
  else news('員工',x.name+'走咗');}});
 genCands();HOOKS.week.forEach(function(f){f();});
}
function genCands(){
 var pool=[['阿詩','groomer',17000,40,'ADBA C 級','5 年'],['Ken','groomer',15000,35,'IPG 初級','2 年'],['阿敏','groomer',21000,50,'JKC B 級','8 年'],['阿傑','groomer',14000,30,'VTC 寵物護理文憑','1 年'],
  ['Kiki','asst',58,0,'寵物美容助理證書','半年'],['阿朗','asst',55,0,'冇','新手'],['Mandy','groomer',19000,45,'ADBA B 級','6 年'],['阿芝','asst',65,0,'寵物美容助理證書','3 年']];
 s.cands=[];var used={};
 for(var i=0;i<3;i++){var c=pick(pool);if(used[c[0]]){i--;if(Object.keys(used).length>=pool.length)break;continue;}used[c[0]]=1;
  s.cands.push({id:s.nextId++,name:c[0],role:c[1],wage:c[1]==='groomer'?c[2]:0,rate:c[1]==='asst'?Math.max(44,c[2]):0,comm:c[3],cert:c[4],exp:c[5],hoursW:c[1]==='asst'?25:0,trait:pick(TRAITS),off:Math.floor(R()*7)});}
}
function hire(cid){var c=s.cands.filter(function(x){return x.id===cid;})[0];if(!c)return;
 var st=mkStaff({name:c.name,role:c.role,wage:c.wage,rate:c.rate,comm:c.comm,cert:c.cert,exp:c.exp,hoursW:c.hoursW,trait:c.trait,off:c.off===0?3:c.off});
 st.joined=(Math.floor(s.day/7)+1)*7;s.staff.push(st);s.cands=s.cands.filter(function(x){return x.id!==cid;});
 news('員工','請咗 '+c.name+'（'+(c.role==='groomer'?'美容師':'助理')+'），下星期一返工');}
function fire(id){var x=s.staff.filter(function(z){return z.id===id;})[0];if(!x||x.role==='owner')return;x.leaving=s.day+7;activeStaff().forEach(function(o){if(o.id!==id)o.morale=Math.max(.1,o.morale-.05);});news('員工','通知 '+x.name+' 一週後離職（通知期）');}

function monthEnd(d0){
 var y=d0.getFullYear(),m=d0.getMonth(),ds=s.days.filter(function(x){var q=dateOf(x.day);return q.getFullYear()===y&&q.getMonth()===m;});
 var cats={wages:0,fixed:0,ai:0,refunds:0,consum:0};ds.forEach(function(x){for(var k in cats)cats[k]+=x.cats[k];});
 var rev=sum(ds.map(function(x){return x.rev;})),cost=sum(ds.map(function(x){return x.cost;}));
 /* 過往存檔嘅日紀錄冇 shProfit，用當週估算補回；新局每日入帳。 */
 var shProfit=sum(ds.map(function(d){if(d.shProfit!=null)return d.shProfit;var w=s.weeks.filter(function(x){return x.idx===Math.floor(d.day/7);})[0];return w?w.hs.profit/7:0;}));
 var rec={y:y,m:m+1,rev:rev,cost:cost,profit:rev-cost,cats:cats,done:sum(ds.map(function(x){return x.done;})),ns:sum(ds.map(function(x){return x.ns;})),cancel:sum(ds.map(function(x){return x.cancel;})),lost:sum(ds.map(function(x){return x.lost;})),booked:sum(ds.map(function(x){return x.booked;})),
  cash:s.cash,shProfit:shProfit,shCash:s.shCash,rating:s.S.rating,shRating:s.sh.rating,act:actN(s.S),shAct:actN(s.sh),days:ds.length};
 HOOKS.month.forEach(function(f){f(rec);});rec.cash=s.cash;rec.shCash=s.shCash;s.mcash0=s.cash;s.mled=[];
 s.months.push(rec);
 if(!s.modal)s.modal={type:'month',rec:rec};
}
function rollWeather(){var m=dateOf(s.day).getMonth(),p=[.1,.12,.15,.2,.3,.35,.3,.3,.25,.12,.08,.08][m];s.rain=R()<p?(R()<.3?2:1):0;}
function news(who,txt){s.news.unshift({day:s.day,t:s.t,who:who,txt:txt});if(s.news.length>400)s.news.length=400;}
function aiLog(seal,txt,t){s.aiDay.push({t:t==null?s.t:t,seal:seal,txt:txt});}

/* AI 嘅一日：每朝按今日預約同部署等級生成 */
function genAiDay(){
 s.aiDay=s.aiPend||[];s.aiPend=null;var ap=todayAppts(),h=s.wk.h,lv=s.lv,inq=h.inq/7,ah=Math.round(inq*s.S.P.afterHours);
 var ex=ap.filter(function(a){return a.st!=='lost';});
 if(lv.reply===1&&ah)aiLog('覆','收工後 '+ah+' 個查詢收到離線訊息，老闆 '+hm(OPEN_MIN-20)+' 先逐個覆',30);
 if(lv.reply>=2&&ah){var a=pick(ex.length?ex:[{pet:'布甸',breed:'比熊',owner:'陳太'}]);
  aiLog('覆','23:40 '+a.owner+'傳咗「'+a.pet+'」（'+a.breed+'）相，AI 報價 '+hk(Math.round(SEGS[1].price*.9/10)*10)+'–'+hk(Math.round(SEGS[1].price*1.25/10)*10)+(s.review?'，老闆 09:05 確認':'，冇人審核直接發出'),-20);
  if(lv.reply===3)aiLog('覆','AI 直接開咗 '+Math.max(1,Math.round(ah*.4))+' 個位，收咗 HK$100 訂金',-10);
  if(s.review&&R()<.6){s.rep.guards++;aiLog('覆','轉人：主人話隻狗皮膚有啲紅 → 老闆接手，建議先睇獸醫',DAY0+30);}
  if(!s.review&&R()<.25*lv.reply/2){s.rep.errs++;aiLog('覆','出錯：AI 答應咗 15:00，但嗰個位已經滿（冇人審核）',DAY0+50);news('AI 出錯','AI 前台答應咗一個已經滿咗嘅時段，要致電主人道歉');}}
 if(lv.reply>=1&&ex.length){s.rep.remind+=ex.length;aiLog('覆','發咗 '+ex.length+' 條當朝提醒',DAY0);}
 if(lv.recall>=1&&s.day%7===0){var n=Math.round(h.dues);s.rep.recalls+=n;aiLog('回',(lv.recall===1?'老闆人手發咗 ':'自動發咗 ')+n+' 條到期提醒'+(lv.recall>=2?'（'+Math.round(n*.12)+' 位未同意直銷，冇發）':''),DAY0+30);
  if(lv.recall===3)aiLog('回','沉睡客分類：忘記 '+Math.round(s.S.dorm[0])+' 位、價錢 '+Math.round(s.S.dorm[1])+' 位、寵物健康 '+Math.round(s.S.dorm[4])+' 位（呢類唔發優惠）',DAY0+40);}
 if(lv.sched>=2)aiLog('排','排好今日 '+ex.length+' 隻，按美容師專長同寵物大細計時長',DAY0+10);
 if(lv.file>=3&&ex.length){var b=pick(ex);aiLog('檔','提示'+staffName(b.g)+'：「'+b.pet+'」上次左耳紅，今次用低敏洗頭水',b.a-30>DAY0?b.a-30:DAY0+15);}
 if(lv.media>=2&&ex.length)aiLog('影','預備好 '+ex.length+' 張報告卡模板，完成後自動發',DAY0+20);
 if(lv.acct>=2&&dateOf(s.day).getDate()===1)aiLog('數','上月月結摘要已出：營收、毛利、退款、套票餘額',DAY0+5);
 s.rep.savedMin+=Math.max(0,(adminBase()-s.wk.h.adminH)*60/6);
}
function adminBase(){var h=s.wk.h;return (h.inq*ADMIN.replyPerInq+h.booked*ADMIN.perBooking+ADMIN.acct+ADMIN.media+ADMIN.misc)/60;}

/* 部署 AI */
function deploy(id,l){
 var r=roleDef(id),L=r.L[l-1];if(!L||s.lv[id]===l)return;
 if(s.cash<L.setup){news('AI','現金唔夠部署 '+r.name+' L'+l);return;}
 if(L.setup)oneOff(-L.setup,r.name+' L'+l+' '+L.t,'setup');s.lv[id]=l;s.S.setupDone[id+l]=1;s.S.age[id]=0;s.deployDay[id]=s.day;
 news('AI','部署咗「'+r.seal+'」'+r.name+' L'+l+' '+L.t+'：建置 '+hk(L.setup)+'，月費 '+hk(L.fee)+'，'+L.wk+' 週後開始見效，頭 4 週效率由一半慢慢升');
}
function rampPct(id){var l=s.lv[id];if(!l)return 0;var L=roleDef(id).L[l-1],ag=s.S.age[id];if(ag<L.wk)return 0;return Math.min(1,.5+.5*(ag-L.wk)/4);}

/* 存檔 */
var SAVE_KEY='petgroom_save_v3';
function save(){if(s&&s.bg)return;try{var o=Object.assign({},s);o.rng=null;o.S=Object.assign({},s.S,{ctx:null});o.sh=Object.assign({},s.sh,{ctx:null});o.S.hist=s.S.hist.slice(-60);o.sh.hist=s.sh.hist.slice(-60);if(s.fd)s.fd.st.cohorts.forEach(function(c){c.ai.hist=c.ai.hist.slice(-8);c.base.hist=c.base.hist.slice(-8);});localStorage.setItem(SAVE_KEY,JSON.stringify(o));}catch(e){}}
function load(){try{var t=localStorage.getItem(SAVE_KEY);if(!t)return false;var o=JSON.parse(t);if(o.v!==3)return false;s=o;s.rng=rngMake(s.seed+s.day*7);s.S.ctx={det:false,r:rngMake(s.seed+s.day)};s.sh.ctx={det:false,r:rngMake(s.seed+s.day+1)};if(s.fd){s.fd.st.r=rngMake(s.seed+s.day+5);s.fd.st.cohorts.forEach(function(c,i){c.ai.ctx={det:false,r:rngMake(s.seed+i*31+s.day)};c.base.ctx={det:false,r:rngMake(s.seed+i*31+s.day)};});}s.modal=null;if(!s.cl||s.cl.v!==1)clMigrate();return true;}catch(e){return false;}}
function hasSave(){try{return !!localStorage.getItem(SAVE_KEY);}catch(e){return false;}}
