/* p_sound：按鍵聲（決定ボタンを押す7）、退出／關閉聲（mobile_phone_C）、背景音樂兩首（www、www 1）循環交替；月結提示音用 WebAudio 合成。音效同音樂各自開關同音量。 */
var SND={on:1,music:1,vol:.6,mvol:.35,ctx:null,bgm:null,tr:0,armed:false};
var SFX_SRC={click:'audio/click.mp3',exit:'audio/exit.mp3'},BGM_SRC=['audio/hk1.mp3','audio/hk2.mp3'],SFXA={};
try{var _sv=JSON.parse(localStorage.getItem('petgroom_snd2')||'null');if(_sv){SND.on=_sv.on;SND.music=_sv.music;SND.vol=_sv.vol;SND.mvol=_sv.mvol;}}catch(e){}
function sndSave(){try{localStorage.setItem('petgroom_snd2',JSON.stringify({on:SND.on,music:SND.music,vol:SND.vol,mvol:SND.mvol}));}catch(e){}}
function sfx(k){if(!SND.on)return;try{var base=SFXA[k];if(!base){base=SFXA[k]=new Audio(SFX_SRC[k]);base.preload='auto';}var a=base.paused?base:base.cloneNode();a.volume=SND.vol;a.currentTime=0;var p=a.play();if(p&&p.catch)p.catch(function(){});}catch(e){}}
function sndClick(){sfx('click');}
function sndClose(){sfx('exit');}
function sndVol(){if(SND.bgm)SND.bgm.volume=SND.mvol;}
function musicPlay(){
 if(!SND.music)return;
 try{if(!SND.bgm){SND.bgm=new Audio(BGM_SRC[SND.tr]);SND.bgm.preload='auto';SND.bgm.addEventListener('ended',function(){SND.tr=(SND.tr+1)%BGM_SRC.length;SND.bgm.src=BGM_SRC[SND.tr];var q=SND.bgm.play();if(q&&q.catch)q.catch(function(){});});}
  SND.bgm.volume=SND.mvol;var p=SND.bgm.play();if(p&&p.catch)p.catch(function(){});}catch(e){}
}
function musicSet(on){SND.music=on?1:0;if(on)musicPlay();else if(SND.bgm)SND.bgm.pause();sndSave();}
/* 月結提示音（合成） */
function sndChime(){if(!SND.on)return;var C=window.AudioContext||window.webkitAudioContext;if(!C)return;try{SND.ctx=SND.ctx||new C();var c=SND.ctx;
 [523,659,784,1047].forEach(function(f,i){var o=c.createOscillator(),v=c.createGain(),t=c.currentTime+i*.12;o.frequency.value=f;v.gain.setValueAtTime(0,t);v.gain.linearRampToValueAtTime(.2*SND.vol,t+.01);v.gain.exponentialRampToValueAtTime(.0001,t+.5);o.connect(v);v.connect(c.destination);o.start(t);o.stop(t+.55);});}catch(e){}}
/* 瀏覽器要用戶撳過先可以播聲：第一次撳就開背景音樂 */
document.addEventListener('pointerdown',function(){if(!SND.armed){SND.armed=true;musicPlay();}},true);
var EXIT_ACTS=/^(pclose|mclose|selx|slotx|demox|home|otitle|x)$/;
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el)return;var a=el.getAttribute('data-act');
 if(a==='sound'){SND.on=SND.on?0:1;sndSave();if(SND.on)sndClick();if(s)renderModal();return;}
 if(a==='music'){musicSet(!SND.music);sndClick();if(s)renderModal();return;}
 if(a==='vol')return;
 if(EXIT_ACTS.test(a)||el.classList.contains('x'))sndClose();else sndClick();
},true);
document.addEventListener('input',function(e){if(e.target.matches('[data-act=vol]')){var k=e.target.getAttribute('data-k');if(k==='mus')SND.mvol=+e.target.value;else SND.vol=+e.target.value;sndVol();sndSave();}});
HOOKS.month.push(function(){if(!s.bg)sndChime();});
