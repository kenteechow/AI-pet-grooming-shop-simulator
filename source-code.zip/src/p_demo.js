/* p_demo：示範模式，快進到關鍵時刻（快進期間唔出隨機事件）。示範卡放喺左下面板右邊、dock 上面。 */
var DEMO_FF=null;
function ff(toDay,toT,stopEv,after){startDemoFF({day:toDay,t:toT,event:stopEv,after:after});}
function ffMonth(after){startDemoFF({month:s.months.length,after:after});}
function startDemoFF(job){
 var current=s;job.start=performance.now();job.last=job.start;job.budget=Math.max(1,job.month!=null?32*1440:(job.day-s.day)*1440+job.t-s.t);job.rate=job.budget/6;job.carry=0;DEMO_FF=job;s.demoFF=1;s.paused=false;if(s.demoAuto==null)s.demoAuto=true;renderDemo();renderHUD();
 /* v0.15：快進期間可以調速度。「自動」約 6 秒去到下一個關鍵時刻；揀 1×／3×／10×／30× 就用遊戲速度（非營業時間照樣跳過）；暫停會停低。
    主循環喺 s.demoFF 時唔推時間，所以 s.paused 只代表玩家有冇撳暫停。 */
 function frame(now){if(DEMO_FF!==job||s!==current||!s.demo)return;var elapsed=Math.min(.15,(now-job.last)/1000);job.last=now;
  if(!s.paused&&!s.modal)job.carry+=elapsed*(s.demoAuto?job.rate:(skipOn()?SKIP.rate:12*s.speed));
  var guard=0,done=false;
  while(job.carry>0&&guard++<1500){
   if(s.paused&&!s.modal)break;
   if(s.modal){if(s.modal.type==='event'&&s.modal.id===job.event){done=true;break;}if(s.modal.type==='event')chooseEvent(0);else{s.modal=null;nextEvent();}continue;}
   if(job.month!=null?s.months.length>job.month:(s.day>job.day||(s.day===job.day&&s.t>=job.t))){done=true;break;}
   var daytime=s.t>=DAY0&&s.t<1260;
   var st=Math.min(daytime?Math.floor(s.t)+1-s.t:5,job.carry);
   if(!daytime&&s.t<DAY0)st=Math.min(st,DAY0-s.t);
   if(job.month==null&&s.day===job.day)st=Math.min(st,Math.max(0,job.t-s.t));if(st<=0){done=true;break;}advance(st);job.carry-=st;
   if(daytime)break;
   if(guard>=6)break; /* 晚間每幀最多 30 分鐘，保留日夜漸變。 */
  }
  renderHUD();if(done){DEMO_FF=null;s.demoFF=0;s.paused=true;if(job.after)job.after();renderDemo();renderPanel();renderModal();renderHUD();return;}requestAnimationFrame(frame);
 }requestAnimationFrame(frame);
}
var DEMO=[
 {t:'一間未用 AI 嘅美容店',d:'觀塘樓上舖，2 張美容枱。你（老闆）同阿欣剪狗，阿樂兼職洗澡。右上係現金同口碑，左下係每個人今個星期嘅工時。',go:function(){ff(0,690);}},
 {t:'老闆嘅時間去咗邊',d:'排程表入面灰色「行政」就係你覆 WhatsApp、排程、對數嘅時間。呢啲時間本來可以多剪一兩隻。',go:function(){openPanel('sched');}},
 {t:'收工後嘅查詢',d:'晚上 11 點有人問價。冇 AI 嘅話，你一係犧牲休息，一係聽朝先覆、個客可能已經去咗第二間。',go:function(){PANEL.id=null;renderPanel();ff(8,700,'afterhours');}},
 {t:'部署「覆」L2：AI 報價助手',d:'AI 按品種同相片估價，你一撳確認。留意：要 2 週部署，之後 4 週磨合，效率由一半慢慢升；皮膚問題、投訴一定轉人。',go:function(){if(s.modal&&s.modal.type==='event')chooseEvent(1);deploy('reply',2);openPanel('ai');PANEL.sub='reply';renderPanel();}},
 {t:'新年前爆滿',d:'查詢多咗五成，但美容師時數係硬上限。AI 帶嚟更多查詢，唔等於做得切；呢個時候「排」L3 嘅超載拒單先保到熟客。',go:function(){PANEL.id=null;renderPanel();ff(14,700,'cny');}},
 {t:'一個月後：no-show 同取消',d:'AI 提醒令 no-show 跌，但有部分變成臨時取消。兩樣要分開計，取消要靠候補補位先救得返。睇吓上週漏斗。',go:function(){if(s.modal&&s.modal.type==='event')chooseEvent(2);ff(36,700,null,function(){openPanel('cust');});}},
 {t:'部署「回」L2：到期提醒',d:'按品種週期自動提醒。但只救到「忘記」嗰類沉睡客；搬咗屋、體驗唔好、寵物過身嘅，AI 救唔到。未同意直銷嘅客亦唔可以發。',go:function(){deploy('recall',2);PANEL.id=null;openPanel('cust');PANEL.sub='dorm';renderPanel();}},
 {t:'AI 嘅一日',d:'逐條列出 AI 今日做咗咩、幾點做、邊度要人把關。',go:function(){ff(43,800,null,function(){openPanel('ai');PANEL.sub='day';renderPanel();});}},
 {t:'關咗人工審核會點',d:'慳咗老闆睇回覆嘅時間，但 AI 會報錯價、答應咗已經滿咗嘅時段。',go:function(){PANEL.id=null;renderPanel();s.review=0;queueEvent('aiPrice');}},
 {t:'AI 做唔到嘅嘢',d:'一次動物安全事故可以抵銷幾個月嘅行銷成果。AI 唔可以判斷健康風險，亦處理唔到事故，要靠美容師同老闆。',go:function(){if(s.modal&&s.modal.type==='event')chooseEvent(2);queueEvent('serious',{a:{pet:'阿福',owner:'何生'}});}},
 {t:'一隻毛孩，兩次到店',d:'打開「毛孩故事」，跟住豆豆由第一次美容到下次預約。試吓找出 AI 草稿嘅錯誤，由美容師確認後先交畀主人。呢個係虛構互動示範，唔影響遊戲財務。',go:function(){if(s.modal&&s.modal.type==='event')chooseEvent(0);PANEL.id=null;openPanel('cust');PANEL.sub='story';renderPanel();}},
 {t:'月結：同隔籬比較',d:'隔籬係同一條街、唔用 AI、做唔切就請人嘅店。比較錢、工時、人手同口碑。',go:function(){if(s.modal&&s.modal.type==='event')chooseEvent(0);ffMonth(function(){s.modal=null;openPanel('shadow');});}},
 {t:'成果報告',d:'AI 處理咗幾多查詢、慳咗老闆幾多工時、出咗幾多錯、每個客 AI 成本幾多。AI 最大嘅價值係慳返老闆時間、減少漏單同 no-show；但產能、手藝、安全同信任，始終要靠人。你可以由呢度繼續自由玩。',go:function(){PANEL.id=null;openPanel('rep');}}
];
/* 示範模式用固定種子，拍片可以重現（v0.13） */
var DEMO_SEED=20270104;
function startDemo(){startGame('community',DEMO_SEED);s.demo={i:0};s.paused=true;DEMO[0].go();renderDemo();}
function renderDemo(){
 var el=$('#demoCard');if(!el)return;if(!s||!s.demo){el.hidden=true;return;}
 var i=s.demo.i,D=DEMO[i];
 el.innerHTML='<div class="dc-h"><span class="lbl">示範 '+(i+1)+'／'+DEMO.length+'</span><button class="x" data-act="demox" aria-label="結束示範">×</button></div><b>'+esc(D.t)+'</b><p>'+esc(D.d)+'</p><div class="dc-f">'+(i<DEMO.length-1?'<button class="btn pri" data-act="demonext"'+(DEMO_FF?' disabled':'')+'>'+(DEMO_FF?(s.paused?'快進暫停中':'時間快進中…'):'下一步')+'</button>':'<button class="btn pri" data-act="demox">自由玩</button>')+'</div>';
 el.hidden=false;
}
document.addEventListener('click',function(e){
 var el=e.target.closest('[data-act]');if(!el)return;var a=el.getAttribute('data-act');
 if(a==='demo'){if(s)s.modal=null;startDemo();return;}
 if(a==='demostart'){startDemo();return;}
 if(!s||!s.demo)return;
 if(a==='demonext'){if(DEMO_FF)return;s.demo.i++;DEMO[s.demo.i].go();renderDemo();renderHUD();}
 if(a==='demox'){DEMO_FF=null;s.demoFF=0;s.demo=null;s.paused=false;renderDemo();}
});
