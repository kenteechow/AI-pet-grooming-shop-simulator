# START_HERE：AI 重構寵物美容

香港寵物美容店 AI 重構模擬遊戲（hoslab）。而家版本 **v0.22.1：3D 經營遊戲（4 個開局、示範模式、創辦人層）＋沙盒模擬器**。

- **其他 AI 接手：先睇 `HANDOFF.md`**
- 設計文件：`game-design-v1.md`（v1.1，已確認）
- 線上版：Claude Artifact「AI 重構寵物美容」
- 建置：`python3 build.py` → `dist/index.html`（Artifact，冇 doctype）、`dist/standalone.html`（瀏覽器／GitHub Pages）

白天時間逐分鐘顯示，晚間較快推進並漸變光線；高倍速受畫面更新率限制。使用 20 個街燈及車燈光源，其中 3 個提供投影；美容店附近照明固定，其餘街燈按鏡頭位置分配。

客人紀錄：遊戲「客人 → 客人紀錄」係真正跟住每隻毛孩（穩定 ID）嘅紀錄；AI 草稿要核對先會用嚟做提示。事件寫明嘅老闆時間會排入排程（`p_tasks.js`）。

毛孩故事：遊戲「客人 → 毛孩故事」，係虛構互動示範，不改變模擬結果。新局隔籬利潤按日分攤，舊存檔現金沿用原有入帳方式。

## 系統 → function 對照

| 系統 | 檔案 | function |
|---|---|---|
| 常數、分群、AI 崗位、預設參數、來源 | `src/p_consts.js` | `SEGS` `DORM` `ROLES` `DEF_SHOP` `DEF_FOUNDER` `SOURCES` |
| 店層每週模擬 | `src/p_engine.js` | `newShop` `shopStep` `runShop` `toMonths` `shopSummary` `ownerLTV` `rv` `rampEff` |
| 創辦人層四模式 | `src/p_founder.js` | `runFounder` `founderSummary` `archParams` `churnFor` |
| 情境、盲點、停損線、敏感度、蒙地卡羅、四模式、10 條問題 | `src/p_analysis.js` | `SCEN` `runAll` `blindspots` `failChecks` `sensitivity` `mcRun` `compareModels` `qAnswers` |
| 圖表 | `src/p_charts.js` | `chart` `drawCharts` `drawLine` `drawTornado` |
| 介面 | `src/p_ui.js` | `PG`（參數定義）`renderAll` `renderMain` `page*` `lazy` |
| 工作流（觸發→AI→系統→人工→輸出、步驟） | `src/p_depts.js` | `FLOWS`（掛去 `ROLES[].L[].flow/steps`） |
| 遊戲狀態、開局、預約、收工、月結、員工、存檔 | `src/p_game.js` | `newGame` `syncP` `planWeek` `scheduleWeek` `scheduleDay` `advance` `endOfDay` `weekEnd` `monthEnd` `hire` `fire` `deploy` `genAiDay` `save` `load` |
| 事件 | `src/p_events.js` | `EVENTS` `EV_RANDOM` `dayEvents` `queueEvent` `chooseEvent` |
| 3D 核心（日夜、雨、半透明、點擊、標籤、陰影） | `src/p_3d.js` | `init3D` `update3D` `pick3D` `updateFade` `updateLabels` |
| 鏡頭 | `src/p_cam.js` | `CAM` `CT` `camUpdate` `camPan` `camRot` `camZoom` `camJump` `camFly` `camControls` |
| 地下茶餐廳 | `src/p_cafe.js` | `buildCafe` `updateCafe` `cafeBusy` |
| 初始界面 | `src/p_title.js` | `showTitle` `startBg` `renderTitle` `OPTS` `TV`（main／new／help／opts）|
| 靜態合併 | `src/p_merge.js` | `mergeStatic` |
| 程式生成貼圖 | `src/p_tex.js` | `paverCanvas` `asphaltCanvas` `floorCanvas` `facadeCanvas` `roadText` `flatTex` `decal` |
| 體素模型 | `src/p_voxel.js` | `vb` `makePerson` `makePet` `makeCar` `sign` |
| 街景、交通 | `src/p_street.js` | `buildCity` `building` `buildTraffic` `updateTraffic` |
| 店舖 3D、人同寵物跟排程 | `src/p_shop3d.js` | `SHOP` `buildShop` `syncShop` `moveTo` `actor` |
| 行路（步速、轉身、腳步、客人一程路） | `src/p_walk.js` | `WALK` `walkV` `staffV` `turnTo` `stride` `custPath` `custTrip` `pathAt` |
| HUD、彈窗、選中卡 | `src/p_hud.js` | `renderHUD` `renderModal` `renderSel` `staffHours` |
| 面板 | `src/p_panels.js` | `openPanel` `renderPanel` `pSched` `pCust` `pStaff` `pAI` `pFin` `pShadow` `pRep` |
| 真實營運：老闆底薪、小金庫、貸款、保險、直銷同意、現金危機、手動排程 | `src/p_real.js` | `injectFund` `takeLoan` `askConsent` `moveAppt` `swapAppt` `addFromBacklog` `canPlace` `movable` |
| 持續主人同毛孩紀錄、觀察、草稿核對、紀錄頁面 | `src/p_clients.js` | `clAssign` `clMark` `clObserve` `clArrive` `clReview` `clMigrate` `clStats` `clKind` `pRec`；同意 `clCons` `clCanPromo` `clCanPost` `clConsentSync`；報告卡 `clReport`；每週推廣同社媒 `clWeekly` |
| 月結口徑、一次性收支、保險申索 | `src/p_ledger.js` | `oneOff` `monthStmt` `monthSoFar` `ledSoFar` `incidentCost` `claimsHTML` `CLAIM` `INC_COST` |
| 跳過非營業時間、休息日、7 日返工 | `src/p_week.js` | `SKIP` `skipOn` `skipWin` `skipCap` `skipHTML` `offSel` `offLabel`；自動補候補 `autoFill` `AUTOFILL` |
| 客人檔案、搜尋 | `src/p_clients.js` | `profileHTML` `clSearch` `clListHTML` `clOwnerStats` `clFb` `clReqs` `stars`；`CLV.pid`／`CLV.q` |
| 每週挑戰、里程碑、等級、解鎖（網紅、加購、加枱、寄賣） | `src/p_goals.js` | `CHAL` `MILES` `LEVELS` `glPickWeek` `glWeekEnd` `glCheckMiles` `glAddXP` `kolBuy` `addonToggle` `addTable` `retailToggle` `pGrow` `renderGoalCard` |
| 落手做（第一身近鏡、步驟選擇） | `src/p_hands.js` | `HSTEP`（`o` 簡單選項、`oh` 中難選項、`tm` 計時最低難度、`tw` 計時提示同失手後果）`HPLAN` `HDIFF` `HTIME` `handsDiff` `handsOpts` `handsTimed` `handsZone` `handsResult` `handsApply` `handsAnim` `HADD` |
| 第一週目標 | `src/p_guide.js` | `GUIDE` `guideTick` `renderGuide`（包住 `renderHUD`） |
| 事件時間成本變成排程時段 | `src/p_tasks.js` | `TASK_FX` `planTask` `taskFit` `freeGaps` `taskTick` `taskMinWeek`；事件 `taskShort` |
| 營運面板、拖放、參觀隔籬 | `src/p_real_ui.js` | `pOwner` `pLoan` `pIns` `overHTML` `shopView` `renderVisitHUD` |
| 創辦人層（遊戲內） | `src/p_fgame.js` | `startFounder` `pFd` `fdKnobs`；引擎係 `founderInit` `founderStep`（`p_founder.js`） |
| 音效同音樂（音檔＋合成月結聲） | `src/p_sound.js` | `SND` `sfx` `sndClick` `sndClose` `sndChime` `musicPlay` `musicSet` |
| 示範模式 | `src/p_demo.js` | `DEMO` `startDemo` `ff` `ffMonth` `renderDemo` |
| 主循環、快捷鍵、遊戲點擊 | `src/p_main.js` | `startGame` `startLoop` `loop` |
| 沙盒事件、啟動 | `src/p_tail.js` | document click／change／input handler |

## 用戶固定要求（摘要）
- 香港粵語書面語、繁體；介面唔用 emoji；印章字做崗位標記。
- 現實感第一：數字要合香港規模；唔確定就標「示範估算」；外國 benchmark 唔等於香港。
- AI 要講真話：工具名、費用、部署週、人工把關、限制（磨合期、冇審核出錯、資料完整度）。
- 唔做「hoslab 創辦人線」開局；創辦人層 v1 用 2D；唔計遙距機票。
- 詳細規範：skill `ai-industry-sim-game`。
