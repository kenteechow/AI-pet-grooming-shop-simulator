/* v0.13 介面測試：AI 總覽一按升級、第一週目標、月結明細、保險申索表、臨時取消嘅客人停低打電話再行返轉頭、固定隨機選項。
   用法：THREE_JS=<本機 three.min.js r128> node tests/v013_ui_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
  const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());
  if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));
  /* 固定隨機選項 */
  await p.click('#title [data-act=tview][data-v=opts]');await p.click('#title [data-act=opt][data-k=fixed]');
  assert(await p.locator('#title [data-act=seed]').count()===1,'選項有種子編號');
  await p.evaluate(()=>{OPTS.fixed=0;optsSave();});await p.click('#title [data-act=tview][data-v=main]');
  await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(600);
  await p.evaluate(()=>{s.modal=null;s.paused=true;renderModal();renderHUD();});await p.waitForTimeout(200);
  /* 第一週目標 */
  assert(await p.locator('#guide').isVisible(),'新局有第一週目標');
  if(w<860)await p.click('#guide [data-act=gdmin]');
  await p.screenshot({path:path.join(out,'v13_guide_'+w+'.png')});
  await p.click('#guide [data-act=gdgo][data-g=sched]');await p.waitForTimeout(200);
  assert(await p.evaluate(()=>s.gd.done.sched===1),'撳「去」開排程之後剔咗第一步');
  /* AI 總覽一按升級 */
  await p.evaluate(()=>{openPanel('ai');PANEL.sub='ov';renderPanel();});await p.waitForTimeout(200);
  const before=await p.evaluate(()=>({lv:s.lv.reply,cash:s.cash}));
  const btn=p.locator('#panel .airow').first().locator('[data-act=deploy]');assert(await btn.count()===1,'總覽有升級掣');
  const label=await btn.innerText();assert(/升 L1/.test(label),'掣寫明升 L1：'+label);
  await p.screenshot({path:path.join(out,'v13_aiov_'+w+'.png')});
  await p.evaluate(()=>{PANEL.hover=1;});await btn.click();await p.waitForTimeout(200);
  const after=await p.evaluate(()=>({lv:s.lv.reply,cash:s.cash,next:document.querySelector('#panel .airow [data-act=deploy]').innerText}));
  assert(after.lv===before.lv+1,'一按就升一級（'+before.lv+'→'+after.lv+'）');assert(/升 L2/.test(after.next),'升完之後掣變成升 L2');
  assert(await p.evaluate(()=>s.gd.done.ai===1),'第一週目標剔咗 AI');
  /* 現金唔夠：掣停用、寫差幾多 */
  const dis=await p.evaluate(()=>{var c=s.cash;s.cash=100;renderPanel();var b=[...document.querySelectorAll('#panel .airow .aiup')].find(x=>x.disabled);var r=b?b.innerText:'';s.cash=c;renderPanel();return r;});
  assert(/差/.test(dis),'現金唔夠時寫明差幾多：'+dis);
  /* 推一個月，睇月結明細 */
  await p.evaluate(()=>{PANEL.id=null;renderPanel();s.paused=false;var n=0;while(s.months.length<1&&n++<400000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else if(s.modal.type==='month')break;else s.modal=null;}else advance(5);}renderModal();});
  await p.waitForTimeout(300);
  const mt=await p.locator('#modal').innerText();
  assert(/經營利潤/.test(mt)&&/老闆底薪/.test(mt)&&/一次性收支/.test(mt)&&/月初 → 月末公司現金/.test(mt)&&/小金庫/.test(mt),'月結明細有齊各個口徑');
  const led=await p.evaluate(()=>{var m=s.modal&&s.modal.rec;return m?m.led.length:-1;});assert(led>=0,'月結有一次性收支清單（'+led+' 筆）');
  await p.screenshot({path:path.join(out,'v13_month_'+w+'.png')});
  /* 保險表 */
  await p.evaluate(()=>{s.modal=null;renderModal();incidentCost({id:999,pet:'測試',owner:'陳太',inc:'serious'});openPanel('fin');PANEL.sub='ins';renderPanel();});
  const it=await p.locator('#panel').innerText();assert(/保險審核中/.test(it)&&/墊底費/.test(it),'保險表有申索狀態同墊底費');
  if(w===1440)await p.screenshot({path:path.join(out,'v13_ins.png')});
  /* 臨時取消：客人停低打電話再行返轉頭 */
  const r=await p.evaluate(()=>{PANEL.id=null;renderPanel();s.paused=false;s.speed=1;
   var a=todayAppts().filter(function(x){return x.out==='ok'&&x.st==='booked'&&x.a>s.t+60&&x.a>=720;})[0];if(!a)return 'noappt';
   s.t=a.a-15-60;s.paused=false;var J=null;for(var i=0;i<400&&!J;i++){syncShop(.05);J=W3.jr&&W3.jr['d'+a.id];}
   if(!J)return 'notrip';a.st='cancel';syncShop(.05);var st1=J.st;for(i=0;i<60;i++)syncShop(.05);var st2=J.st,pet=W3.actors['q'+a.id];
   return {st1:st1,st2:st2,abort:!!J.abort,pet:!!(pet&&pet.visible),label:W3.actors['w'+a.id].userData.label};});
  assert(r.st1==='phone'&&r.st2==='out'&&r.abort&&r.pet&&/取消/.test(r.label),'臨時取消：停低打電話，再拖住狗行返出街 '+JSON.stringify(r));
  const ov=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert(!ov,'橫向溢出');
  assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'v0.13 介面通過；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
