/* 3D 截圖：日間、夜晚、落雨、建築外觀，同 4 個尺寸 UI（深色）。three.js 用本機檔。 */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');
const THREE_JS=process.env.THREE_JS;const out=process.argv[2]||'shots';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 async function page(w,h,scheme){const p=await b.newPage({viewport:{width:w,height:h},colorScheme:scheme||'dark'});const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(THREE_JS),contentType:'application/javascript'}));
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(800);
  await p.evaluate(()=>{s.paused=true;s.modal=null;});p.errs=errs;return p;}
 const p=await page(1440,900);
 await p.evaluate(()=>{window.stepTo=function(day,t){s.paused=false;var n=0;while((s.day<day||s.t<t)&&n++<100000){if(s.modal){s.modal=null;s.evQ=[];}else advance(5);}s.paused=true;};stepTo(2,540);});
 const shots=[['day',()=>{stepTo(2,660);s.rain=0;}],['busy',()=>{stepTo(2,900);s.rain=0;openPanel('sched');}],['ai',()=>{PANEL.id=null;renderPanel();openPanel('ai');}],['airole',()=>{PANEL.sub='reply';renderPanel();}],['rain',()=>{PANEL.id=null;renderPanel();stepTo(2,1010);s.rain=2;}],['night',()=>{stepTo(2,1200);s.rain=0;}],['ext',()=>{s.rain=0;s.exterior=1;camJump({rad:40,ph:1.15});}],['street',()=>{s.exterior=0;s.t=1000;camJump({tx:15,tz:8,rad:26,th:-.6,ph:1.2});}],
  ['event',()=>{camJump(CAM_DEF);queueEvent('cny');}],
  ['cafe',()=>{s.modal=null;s.evQ=[];stepTo(2,780);s.floorG=1;CT.ty=CAM.ty=.4;camJump({tx:0,tz:-4,rad:15,th:.5,ph:.95});renderHUD();}],
  ['cafe_out',()=>{s.floorG=0;CT.ty=CAM.ty=3.2;camJump({tx:0,tz:2,rad:13,th:.15,ph:1.25});renderHUD();}],
  ['chibi',()=>{camJump({tx:.5,tz:-6.2,rad:6.5,th:.3,ph:1.15});}],
  ['visit',()=>{s.modal=null;s.evQ=[];s.visit=1;renderHUD();stepTo(3,700);renderHUD();}],
  ['puddle',()=>{s.visit=0;s.rain=0;s.wetDay=s.day;s.wetT=s.t+120;renderHUD();camJump({tx:0,tz:4,rad:16,ph:1.05,th:.2});}],
  ['sched_edit',()=>{camJump(CAM_DEF);openPanel('sched');var a=s.wk.appts.filter(function(x){return movable(x);})[0];SCHED.sel=a.id;s.sel={type:'pet',id:a.id};renderPanel();renderSel();}],
  ['founder',()=>{PANEL.id=null;renderPanel();s.sel=null;renderSel();startFounder('D');s.paused=false;var m0=s.months.length;var n=0;while(s.months.length<m0+3&&n++<1e5){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else{s.modal=null;nextEvent();}}else advance(10);}s.modal=null;s.evQ=[];s.paused=true;openPanel('fd');}],
  ['fin_owner',()=>{PANEL.id=null;openPanel('fin');PANEL.sub='owner';renderPanel();}]];
 for(const [n,f] of shots){await p.evaluate(`(${f.toString()})()`);await p.waitForTimeout(900);await p.screenshot({path:`${out}/g_${n}.png`});}
 console.log('errs1440',JSON.stringify(p.errs));
 {const d=await page(1440,900);await d.evaluate(()=>{showTitle();});await d.waitForTimeout(2500);await d.screenshot({path:`${out}/g_title.png`});await d.evaluate(()=>{showOpenings();});await d.waitForTimeout(300);await d.screenshot({path:`${out}/g_openings.png`});await d.evaluate(()=>{TV='opts';renderTitle();});await d.waitForTimeout(200);await d.screenshot({path:`${out}/g_opts.png`});await d.evaluate(()=>{TV='main';renderTitle();});await d.click('#title [data-act=demostart]');await d.waitForTimeout(400);/* 擷取示範初始狀態；跨日示範另由遊戲測試及逐分鐘測試驗證。 */await d.screenshot({path:`${out}/g_demo.png`});console.log('demo errs',JSON.stringify(d.errs));await d.close();}
 for(const [w,h] of [[1100,680],[820,700],[420,800]]){const q=await page(w,h);await q.evaluate(()=>{s.t=720;});await q.waitForTimeout(800);await q.screenshot({path:`${out}/g_hud_${w}.png`});
  await q.evaluate(()=>openPanel('ai'));await q.waitForTimeout(500);await q.screenshot({path:`${out}/g_ai_${w}.png`});
  const ov=await q.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);console.log(w,'hscroll',ov,'errs',JSON.stringify(q.errs));await q.close();}
 const L=await page(1440,900,'light');await L.evaluate(()=>{s.t=700;openPanel('staff');});await L.waitForTimeout(800);await L.screenshot({path:`${out}/g_light.png`});
 await b.close();})();
