/* 持續客人紀錄測試（v0.12）：穩定 ID、同名唔混、只計完成、狀態唔重複計、AI 草稿要核對先確認、存檔讀檔、舊存檔遷移、同日結對數。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
function mkEnv(){const E=load(true);const store={};E.localStorage={getItem(k){return k in store?store[k]:null},setItem(k,v){store[k]=String(v)}};return E;}
function play(E,days,setup){let n=0;const s0=E.s;while(E.s.day<days&&n++<3e6){const s=E.s;if(setup)setup(s);
  if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(10);}}
function sumDays(s,k){return s.days.reduce((a,d)=>a+(d[k]||0),0);}
function sumPets(s,k){return Object.values(s.cl.pets).reduce((a,p)=>a+(p.cnt[k]||0),0);}

/* 1. 有 AI 檔 L2＋人工審核，玩 70 日 */
{const E=mkEnv();vm.runInContext("newGame('community');",E);
 let deployed=false;play(E,70,s=>{if(!deployed&&s.day>=1){E.deploy('file',2);deployed=true;}});
 const s=E.s,pets=Object.values(s.cl.pets);
 ok(pets.length>20,'有建立毛孩紀錄（'+pets.length+' 隻）');
 ok(pets.every(p=>/^p\d+$/.test(p.id)&&s.cl.owners[p.oid]),'每隻毛孩都有穩定 ID 同對應主人');
 const ids=new Set(pets.map(p=>p.id));ok(ids.size===pets.length,'毛孩 ID 唔重複');
 const byName={};pets.forEach(p=>{(byName[p.name]=byName[p.name]||[]).push(p.id);});
 const dup=Object.keys(byName).filter(k=>byName[k].length>1);ok(dup.length>0,'有同名唔同隻嘅毛孩（例如「'+(dup[0]||'')+'」有 '+(dup[0]?byName[dup[0]].length:0)+' 隻），各自獨立紀錄');
 const back=pets.filter(p=>p.cnt.done>=2);ok(back.length>0,'有毛孩跨週再嚟，用同一個 ID 找返紀錄（'+back.length+' 隻嚟過兩次或以上）');
 /* 同日結對數 */
 const today=E.todayAppts();
 const dDone=sumDays(s,'done')+today.filter(a=>a.st==='done'||a.st==='gone').length,pDone=sumPets(s,'done');
 const spDone=Object.values((s.sp&&s.sp.seen)||{}).reduce((t,x)=>t+x.n,0);/* v0.20 特殊客冇客人紀錄 */
 ok(dDone===pDone+spDone,'完成次數同日結對得上（日結 '+dDone+'，紀錄 '+pDone+'，特殊客 '+spDone+'）');
 const dNs=sumDays(s,'ns')+today.filter(a=>a.st==='noshow').length,pNs=sumPets(s,'noshow');
 ok(dNs===pNs,'No-show 分開記，同日結對得上（'+dNs+' / '+pNs+'）');
 const dCa=sumDays(s,'cancel')+today.filter(a=>a.st==='cancel').length,pCa=sumPets(s,'cancel');
 ok(dCa===pCa,'臨時取消分開記，同日結對得上（'+dCa+' / '+pCa+'）');
 ok(pets.every(p=>p.visits.filter(v=>v.st==='done').length===Math.min(p.cnt.done,20)),'完成次數只計 st=done 嘅到店');
 /* 重複標記唔會重複計 */
 const p=back[0],v=p.visits.find(x=>x.st==='done'),before=p.cnt.done;const fake={id:v.aid,pid:p.id,day:v.day,svc:v.svc,g:v.g};
 E.clMark(fake,'done');E.clMark(fake,'done');ok(p.cnt.done===before,'同一張預約重複標記完成，唔會重複計');
 const notes=pets.flatMap(p=>p.notes);
 ok(notes.some(n=>n.src==='ai'),'檔 L2 會產生 AI 草稿');
 ok(notes.filter(n=>n.src==='ai').every(n=>n.st!=='draft'),'有人工審核：AI 草稿全部經美容師核對');
 ok(notes.filter(n=>n.st==='corrected').every(n=>n.fix===n.truth&&n.txt!==n.truth),'寫錯嘅草稿改正後保留原句同改正');
 /* 存檔讀檔 */
 const snap=JSON.stringify(s.cl);E.save();vm.runInContext("s=null;",E);ok(E.load(),'讀檔成功');
 ok(JSON.stringify(E.s.cl)===snap,'讀檔後身份、紀錄、確認狀態完全一樣');
 /* 舊存檔遷移 */
 const s2=E.s;delete s2.cl;s2.wk.appts.forEach(a=>{delete a.pid;delete a.oid;});E.clMigrate();
 ok(s2.wk.appts.every(a=>a.pid&&s2.cl.pets[a.pid]),'舊存檔遷移：本週預約全部補返身份');
 ok(s2.wk.appts.every(a=>s2.cl.pets[a.pid].name===a.pet),'舊存檔遷移：保留原本嘅寵物名');
 const n1=Object.keys(s2.cl.pets).length;E.clMigrate();ok(Object.keys(s2.cl.pets).length===n1,'遷移重複執行唔會重複加毛孩');
}
/* 2. 檔 L3、冇人工審核：草稿保持未確認，玩家核對後先確認 */
{const E=mkEnv();vm.runInContext("newGame('community');",E);
 let deployed=false;play(E,63,s=>{if(!deployed&&s.day>=1){E.deploy('file',3);s.review=0;deployed=true;}s.review=0;});
 const s=E.s,pets=Object.values(s.cl.pets),drafts=pets.flatMap(p=>p.notes.filter(n=>n.st==='draft').map(n=>[p,n]));
 ok(drafts.length>0,'冇人工審核：有 '+drafts.length+' 份草稿保持未確認');
 ok(pets.every(p=>E.clConfirmed(p).every(n=>n.st!=='draft')),'未確認草稿唔會出現喺「已確認」提示');
 const [p,n]=drafts[0];E.clReview(p,n,'測試');ok(n.st==='confirmed'||n.st==='corrected','玩家叫美容師核對後，草稿變成已確認或已改正');
 const wrong=drafts.find(d=>d[1].wrong&&d[1].st==='draft');if(wrong){E.clReview(wrong[0],wrong[1],'測試');ok(wrong[1].st==='corrected'&&wrong[1].fix===wrong[1].truth,'寫錯嘅草稿核對後改正');}
}
/* 3. 冇 AI：好多觀察冇記低（顯示未記錄），唔會憑空生成 */
{const E=mkEnv();vm.runInContext("newGame('community');",E);play(E,63);
 const pets=Object.values(E.s.cl.pets),notes=pets.flatMap(p=>p.notes);
 ok(notes.every(n=>n.src!=='ai'),'冇 AI 時唔會有 AI 草稿');
 const withDone=pets.filter(p=>p.cnt.done>0),noNote=withDone.filter(p=>!p.notes.some(n=>n.src==='groomer'));
 ok(noNote.length>withDone.length*.5,'冇 AI 時大部分完成過嘅毛孩冇美容師紀錄（'+noNote.length+'/'+withDone.length+'）');
}
console.log(fail?fail+' 項失敗':'客人紀錄測試全部通過');process.exitCode=fail?1:0;
