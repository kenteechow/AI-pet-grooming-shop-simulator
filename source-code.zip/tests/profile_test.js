/* v0.15 客人檔案測試：每隻毛孩同主人有檔案，可以搜尋（名、主人、#編號、品種），檔案有要求、服務紀錄、意見同星數、消費；打開同返回。
   用法：THREE_JS=<本機 three.min.js r128> node tests/profile_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
 const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 const pick=await p.evaluate(()=>{s.modal=null;s.evQ=[];deploy('file',2);deploy('media',2);s.paused=false;var n=0;while(s.day<45&&n++<400000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];}else advance(5);}s.paused=true;
  var ps=Object.values(s.cl.pets).filter(function(p){return p.cnt.done>=2&&p.visits.some(function(v){return v.fb;})&&clConfirmed(p).length;});var q=ps[0]||Object.values(s.cl.pets).filter(function(p){return p.cnt.done>=2;})[0];
  return {id:q.id,name:q.name,owner:s.cl.owners[q.oid].name,breed:q.breed,fb:q.visits.filter(function(v){return v.fb;}).length,done:q.cnt.done};});
 await p.evaluate(()=>{PANEL.id=null;openPanel('cust');PANEL.sub='rec';CLV.pid=null;CLV.q='';renderPanel();PANEL.hover=1;});
 /* 搜尋：#編號 */
 await p.fill('#panel [data-act=clq]','#'+pick.id.slice(1));await p.waitForTimeout(150);
 let lt=await p.locator('#clList').innerText();assert(lt.includes(pick.name),'用 #編號 搵到 '+pick.name);
 await p.fill('#panel [data-act=clq]',pick.owner);await p.waitForTimeout(150);lt=await p.locator('#clList').innerText();assert(lt.includes(pick.owner),'用主人名搵到');
 await p.fill('#panel [data-act=clq]','冇呢個名ZZZ');await p.waitForTimeout(150);assert((await p.locator('#clList').innerText()).includes('搵唔到'),'搵唔到有提示');
 await p.fill('#panel [data-act=clq]','#'+pick.id.slice(1));await p.waitForTimeout(150);
 await p.locator('#clList [data-act=clopen][data-p="'+pick.id+'"]').first().click();await p.waitForTimeout(200);
 const pt=await p.locator('#panel').innerText();
 for(const k of ['要求同注意事項','服務紀錄','主人：','累計消費','平均評分','下次預約'])assert(pt.includes(k),'檔案有「'+k+'」');
 const rows=await p.locator('#panel .pfvl li').count();
 const vh=await p.evaluate(()=>document.querySelector('#panel .pfvl').getBoundingClientRect().height);assert(vh>40,'服務紀錄表睇得到（高 '+Math.round(vh)+'px）');assert(rows>=pick.done,'服務紀錄有 '+rows+' 行（完成 '+pick.done+' 次）');
 if(pick.fb)assert(await p.locator('#panel .pfvl .stars').count()>=1,'服務紀錄有星數');
 await p.screenshot({path:path.join(out,'v15_profile_'+w+'.png')});
 await p.click('#panel [data-act=clback]');await p.waitForTimeout(150);assert(await p.locator('#panel [data-act=clq]').count()===1,'返回紀錄列表');
 /* 意見頁同選中卡都可以開檔案 */
 await p.evaluate(()=>{PANEL.sub='fb';renderPanel();});const fbl=await p.locator('#panel .fbi [data-act=clopen]').count();assert(fbl>0,'意見頁可以撳去檔案');
 const sel=await p.evaluate(()=>{var a=s.wk.appts.filter(function(x){return x.pid;})[0];s.sel={type:'pet',id:a.id};renderSel();return !!document.querySelector('#selCard [data-act=clopen]');});assert(sel,'選中卡有「睇檔案」');
 const ov=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert(!ov,'橫向溢出');
 assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'客人檔案測試通過（'+pick.name+' #'+pick.id.slice(1)+'，'+rows+' 次服務，'+pick.fb+' 次有意見）；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
