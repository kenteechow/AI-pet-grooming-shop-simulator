/* v0.22：AI 面板寫明對客人嘅效果（同部署前後實際變化）；客人 → 體驗；毛孩故事用真係嚟過嘅毛孩。
   用法：THREE_JS=<本機 three.min.js r128> node tests/exp_story_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
 const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 await p.evaluate(()=>{s.modal=null;s.evQ=[];s.gd.off=1;s.paused=false;s.lv.file=2;s.lv.media=2;var adv=function(days){var end=s.day+days,n=0;while(s.day<end&&n++<500000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}advance(5);}};
  adv(8);deploy('reply',2);adv(22);s.paused=true;renderHUD();});
 /* AI 總覽 */
 await p.evaluate(()=>{openPanel('ai');PANEL.sub='ov';renderPanel();});
 const ov=await p.evaluate(()=>[].map.call(document.querySelectorAll('#panel .aieff'),function(x){return x.textContent;}));
 assert(ov.length===6&&ov.some(t=>/查詢流失.*No-show.*回覆等候/.test(t))&&ov.some(t=>/口碑帶嚟查詢/.test(t)),'總覽每個崗位寫明對客人嘅效果：'+ov[0]);
 if(w===1440)await p.screenshot({path:path.join(out,'v22_ai_ov.png')});
 await p.evaluate(()=>{PANEL.sub='reply';renderPanel();});
 const rp=await p.locator('#panel').innerText();
 assert(/對客人嘅效果/.test(rp)&&/冇 AI/.test(rp)&&/部署前 → 最近/.test(rp)&&/每週新客/.test(rp),'崗位頁：每級效果表同部署前後實際變化');
 if(w===1440)await p.screenshot({path:path.join(out,'v22_ai_reply.png')});
 /* 客人體驗 */
 await p.evaluate(()=>{openPanel('cust');PANEL.sub='exp';renderPanel();});
 const ex=await p.locator('#panel').innerText();
 assert(/本週客人體驗分/.test(ex)&&/回覆等候/.test(ex)&&/到店等候/.test(ex)&&/每百隻事故/.test(ex)&&/收到報告卡/.test(ex),'客人 → 體驗有齊各項');
 if(w===1440)await p.screenshot({path:path.join(out,'v22_exp.png')});
 /* 毛孩故事 */
 await p.evaluate(()=>{PANEL.sub='story';renderPanel();});
 const chips=await p.locator('#panel select[data-act=storysel] option').count();assert(chips>=3,'毛孩故事有真係嚟過嘅毛孩揀（'+chips+' 隻）');
 const st=await p.locator('#panel').innerText();assert(/真實紀錄/.test(st)&&/第 1 次到店/.test(st),'故事時間線由第一次到店開始');
 const second=await p.evaluate(()=>document.querySelectorAll('#panel select[data-act=storysel] option')[1].value);await p.selectOption('#panel select[data-act=storysel]',second);await p.waitForTimeout(200);
 assert(await p.evaluate(pid=>s.storyPid===pid&&document.querySelector('#panel select[data-act=storysel]').value===pid,second),'揀第二隻毛孩會換故事');
 await p.click('#panel [data-act=storypet] >> nth=1');await p.waitForTimeout(150);assert(await p.evaluate(pid=>s.storyPid!==pid,second),'下一隻掣會轉');
 if(w===1440||w===420)await p.screenshot({path:path.join(out,'v22_story_'+w+'.png')});
 await p.click('#panel [data-act=storydemo]');await p.waitForTimeout(150);assert(/豆豆有啲怕吹風/.test(await p.locator('#panel').innerText()),'可以睇返虛構示範故事');
 await p.click('#panel [data-act=storyreal]');await p.waitForTimeout(150);assert(/真實紀錄/.test(await p.locator('#panel').innerText()),'返去真實毛孩');
 assert(!(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth)),'冇橫向溢出');
 assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'AI 效果、體驗、毛孩故事測試通過（'+chips+' 隻毛孩）；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
