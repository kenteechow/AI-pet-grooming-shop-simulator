/* v0.16 自動補候補測試：有候補又有空檔就自動加；唔撞預約；候補數量同預約對數；冇 AI 計老闆電話時間、排 L2 唔計；關咗就唔補；固定種子可重現。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
function play(op,seed,days,setup){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('"+op+"',"+seed+");",E);if(setup)setup(E);
 let n=0,fills=0,fillMin=0;const orig=E.autoFill;E.autoFill=function(){const b0=E.s.S.backlog,m0=(E.s.wk&&E.s.wk.fillMin)||0;const r=orig();fills+=r;if(r&&Math.abs(b0-E.s.S.backlog-r)>1e-9)E._bad=1;fillMin+=((E.s.wk&&E.s.wk.fillMin)||0)-m0;return r;};
 while(E.s.day<days&&n++<4e6){const s=E.s;if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(10);}
 return {E,s:E.s,fills,fillMin};}
function overlaps(s){let bad=0;const by={};s.wk.appts.forEach(a=>{if(a.g==null||a.st==='lost'||a.st==='cancel')return;const k=a.day+'_'+a.g;(by[k]=by[k]||[]).push(a);});
 Object.values(by).forEach(L=>{L.sort((x,y)=>x.a-y.a);for(let i=1;i<L.length;i++)if(L[i].a<L[i-1].b-1e-9)bad++;});return bad;}
/* 1. 冇 AI 社區店：有補位、計老闆時間 */
{const r=play('community',2027,120);
 ok(r.fills>0,'冇 AI：自動補咗 '+r.fills+' 個候補');ok(r.fillMin===r.fills*5,'冇 AI：每個計老闆 5 分鐘電話（共 '+r.fillMin+' 分鐘）');
 ok(!r.E._bad,'每補一個，候補名單少一位');ok(overlaps(r.s)===0,'自動補嘅預約唔撞其他預約');
 const au=r.s.wk.appts.filter(a=>a.auto);ok(au.every(a=>a.pid&&a.tag==='候補'),'補嘅預約有客人檔案同「候補」標籤');}
/* 2. 排 L2：AI 補，唔計老闆時間 */
{const r=play('community',2027,120,E=>{E.deploy('sched',2);E.s.S.age.sched=20;});ok(r.fills>0&&r.fillMin===0,'排 L2：AI 補咗 '+r.fills+' 個，唔計老闆時間');}
/* 3. 關咗就唔補 */
{const r=play('community',2027,120,E=>{E.s.autoFill=0;});ok(r.fills===0,'關咗自動補候補就冇補');}
/* 4. 固定種子可重現 */
{const a=play('community',99,90),b=play('community',99,90);ok(a.fills===b.fills&&Math.round(a.s.cash)===Math.round(b.s.cash),'同一種子結果一樣（補 '+a.fills+' 個）');}
console.log(fail?fail+' 項失敗':'自動補候補測試全部通過');process.exitCode=fail?1:0;
