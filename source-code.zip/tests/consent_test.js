/* 同意同報告卡測試（v0.13）：推廣只發畀有同意嘅主人、撤回後唔再發、服務通知（預約）照常、社媒只用同意公開嘅相、有審核嘅報告卡唔會用未確認草稿。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
function play(review,days,seed){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',"+seed+");",E);
 const sends=[];const orig=E.clCanPromo;E.clCanPromo=function(o){const r=orig(o);sends.push({o:o.id,ok:r,day:E.s.day});return r;};
 let n=0,d=0;while(E.s.day<days&&n++<4e6){const s=E.s;s.review=review;if(!d&&s.day>=1){d=1;['file','media'].forEach(id=>E.deploy(id,id==='media'?3:2));E.deploy('recall',2);}
  if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(10);}
 return {E,s:E.s,sends};}
{const {s}=play(1,140,31);const owners=Object.values(s.cl.owners),pets=Object.values(s.cl.pets);
 const promoted=owners.filter(o=>o.lastPromo!=null);ok(promoted.length>0,'有發推廣（'+promoted.length+' 位主人）');
 ok(promoted.every(o=>o.cons.promo||o.cons.withdrawn),'推廣只發畀有同意（或者之後先撤回）嘅主人');
 const wd=owners.filter(o=>o.cons.withdrawn);ok(wd.every(o=>o.lastPromo<=o.cons.wdDay),'撤回之後冇再發推廣（'+wd.length+' 位撤回）');
 const noPromo=owners.filter(o=>!o.cons.promo);ok(noPromo.length>0&&pets.some(p=>noPromo.some(o=>o.id===p.oid)&&p.cnt.done>0),'冇推廣同意嘅主人照樣有預約同服務通知');
 const posted=pets.filter(p=>p.posted!=null);ok(posted.length>0,'影 L3 有出社媒草稿（'+posted.length+' 隻）');
 ok(posted.every(p=>s.cl.owners[p.oid].cons.photo==='public'),'社媒只用同意公開嘅相');
 ok(s.rep.posts>0&&s.rep.promos>0,'報告計數：推廣 '+s.rep.promos+'、社媒 '+s.rep.posts);
 const reps=pets.flatMap(p=>(p.reports||[]));ok(reps.length>0&&reps.every(r=>!r.err),'有人工審核：報告卡冇用未確認草稿，冇寫錯（'+reps.length+' 份）');}
{const {s}=play(0,140,32);const pets=Object.values(s.cl.pets),reps=pets.flatMap(p=>(p.reports||[]).map(r=>[p,r]));
 ok(reps.length>0,'冇審核都有報告卡（'+reps.length+' 份）');
 ok(reps.filter(x=>x[1].err).every(x=>x[0].notes.some(n=>n.src==='ai'&&n.wrong&&n.txt===x[1].err)),'冇審核：報告卡寫錯嘅內容一定嚟自寫錯嘅 AI 草稿');
 console.log('　（冇審核時寫錯嘅報告卡：'+reps.filter(x=>x[1].err).length+' 份）');}
console.log(fail?fail+' 項失敗':'同意同報告卡測試全部通過');process.exitCode=fail?1:0;
