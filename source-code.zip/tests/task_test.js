/* 事件時間成本測試（v0.12）：「逐個打電話」3 小時真係排入老闆排程、唔撞預約、做完先生效、只扣一次；冇空檔時三個選擇。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
function env(){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community');",E);return E;}
function runUntil(E,cond,max){let n=0;while(!cond()&&n++<(max||2e5)){const s=E.s;if(s.modal){if(s.modal.type==='event'&&s.modal.id==='dormant')return 'dormant';if(s.modal.type==='event')E.chooseEvent(s.modal.id==='taskShort'?0:0);else{s.modal=null;E.nextEvent();}}else E.advance(5);}return 'cond';}
function overlaps(E,T){const s=E.s,o=E.ownerSt();for(const b of T.blocks){if(b.after)continue;const busy=E.dayBusy(b.day)[o.id]||[];for(const x of busy){if(typeof x[2]==='string')continue;const a=E.apptById(x[2]);if(a&&(a.st==='lost'||(a.st==='cancel'&&!a.refill)))continue;if(b.a<x[1]&&b.b>x[0])return true;}}return false;}
/* 1. 正常情況 */
{const E=env();const r=runUntil(E,()=>false);ok(r==='dormant','第 5 週出現「第一批沉睡客」');
 const s=E.s,act0=E.sum(s.S.act),dorm0=s.S.dorm[0];E.chooseEvent(0);
 const T=s.tasks&&s.tasks[0];ok(T&&T.kind==='dormantCall','揀「逐個打電話」之後建立 3 小時任務');
 const planned=T.blocks.reduce((a,b)=>a+b.b-b.a,0)+T.unplanned;ok(planned===180,'排咗共 180 分鐘（'+planned+'）');
 ok(!overlaps(E,T),'任務時段唔撞老闆嘅預約');
 const lbl=T.blocks.filter(b=>!b.after).every(b=>(E.dayBusy(b.day)[E.ownerSt().id]||[]).some(x=>x[0]===b.a&&x[1]===b.b&&x[2]==='打電話'));ok(lbl,'排程表有「打電話」時段');
 ok(s.S.dorm[0]===dorm0,'未做完之前冇效果');
 ok(E.taskMinWeek()===T.blocks.filter(b=>!b.after&&b.day<s.wk.start+7).reduce((a,b)=>a+b.b-b.a,0)&&E.taskMinWeek()>0,'老闆本週工時計入任務時間（'+E.taskMinWeek()+' 分鐘）');
 if(s.modal&&s.modal.id==='taskShort')E.chooseEvent(0);
 runUntil(E,()=>T.st==='done',3e5);ok(T.st==='done','做完任務');
 ok(s.S.dorm[0]<dorm0,'做完先救返沉睡客');
 runUntil(E,()=>s.day>=T.doneDay+3);
 const cnt=s.news.filter(n=>/打完 3 小時電話/.test(n.txt)).length;ok(cnt===1,'效果只生效一次');
}
/* 2. 本週冇空檔：三個選擇 */
for(const [ci,name] of [[0,'收工後做'],[1,'延到下星期'],[2,'取消行動']]){
 const E=env();runUntil(E,()=>false);const s=E.s,o=E.ownerSt();
 /* 將老闆本週剩低嘅日子塞滿 */
 for(let d=s.day;d<s.wk.start+7;d++){const b=E.dayBusy(d)[o.id];if(b)b.push([630,1170,'測試佔用']);}
 const dorm0=s.S.dorm[0],mor0=o.morale;E.chooseEvent(0);
 while(s.modal&&s.modal.id!=='taskShort'){if(s.modal.type==='event')E.chooseEvent(0);else s.modal=null;E.nextEvent();}
 ok(s.modal&&s.modal.id==='taskShort','冇空檔時彈出選擇（'+name+'）');
 const T=s.tasks[0];E.chooseEvent(ci);
 if(ci===0){ok(T.blocks.some(b=>b.after&&b.b-b.a===180),'收工後排 3 小時');runUntil(E,()=>T.st==='done');ok(T.st==='done'&&s.S.dorm[0]<dorm0,'收工後做完先生效');ok(o.morale<mor0,'犧牲休息令士氣跌');}
 if(ci===1){ok(T.st==='later','延到下星期');const wk0=s.wk.start;runUntil(E,()=>s.wk.start>wk0);ok(T.st==='planned'||T.st==='short','下星期一重新排');ok(T.st==='done'||!s.news.some(n=>/打完 .* 小時電話/.test(n.txt)),'未做完之前冇效果');}
 if(ci===2){ok(T.st==='cancel','取消');runUntil(E,()=>s.day>=s.wk.start+6);ok(s.S.dorm[0]===dorm0||s.S.dorm[0]>=dorm0*0.9,'取消之後冇救返客（只有自然變化）');ok(!s.news.some(n=>/打完 .* 小時電話/.test(n.txt)),'取消冇效果');}
}
console.log(fail?fail+' 項失敗':'事件時間成本測試全部通過');process.exitCode=fail?1:0;
