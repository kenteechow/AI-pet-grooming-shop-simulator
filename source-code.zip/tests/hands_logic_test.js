/* v0.18 落手做邏輯：難度分級、選項字數相近、計時失手有後果、滿意度同星數、做得好先可以加做、主人評價影響口碑。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',7);",E);
const mk=(svc,seg)=>({id:900000+Math.floor(Math.random()*1e5),svc,seg,pet:'測試',owner:'測試',breed:'測試',g:E.handsOwner().id,st:'doing',day:E.s.day,a:700,b:760,price:400,hreq:''});
ok(E.handsDiff(mk('wash','s'))===1&&E.handsDiff(mk('nail','c'))===1,'洗澡、修甲係簡單');
ok(E.handsDiff(mk('cut','c'))===2&&E.handsDiff(mk('wash','l'))===2,'全剪、大狗係中等');
ok(E.handsDiff(mk('cat','k'))===3&&E.handsDiff(mk('cut','o'))===3,'貓、老年犬全剪係困難');
let lenBad=[];for(const k in E.HSTEP)for(const set of ['o','oh']){const O=E.HSTEP[k][set];if(!O)continue;const L=O.map(o=>o[0].length);if(Math.max(...L)-Math.min(...L)>4)lenBad.push(k);const okL=O.find(o=>o[1])[0].length;if(okL>Math.max(...O.filter(o=>!o[1]).map(o=>o[0].length))+2)lenBad.push(k+'（正確最長）');}
ok(lenBad.length===0,'每步三個選項字數相近，正確答案唔會特別長'+(lenBad.length?'：'+lenBad.join('、'):''));
const easy=mk('wash','s'),hard=mk('cut','o');
ok(E.handsOpts(easy,'temp')===E.HSTEP.temp.o&&E.handsOpts(hard,'temp')===E.HSTEP.temp.oh,'困難用更似真嘅錯誤選項');
const tEasy=E.handsSteps(easy).filter(k=>E.handsTimed(easy,k)).length,tHard=E.handsSteps(hard).filter(k=>E.handsTimed(hard,k)).length;
ok(tHard>tEasy,'困難計時步驟多啲（簡單 '+tEasy+'，困難 '+tHard+'）');
const zE=E.handsZone(easy,'quick',10),zH=E.handsZone(hard,'quick',10);ok((zH[1]-zH[0])<(zE[1]-zE[0]),'困難綠色位窄啲');
ok(E.handsTimeGrade((zE[0]+zE[1])/2,zE)==='hit'&&E.handsTimeGrade(zE[1]+.5,zE)==='miss','計時判定：中間準、離遠失手');
function perfect(a){const st=E.handsSteps(a);return {ans:st.map(k=>E.handsOpts(a,k).findIndex(o=>o[1])),tim:st.map(k=>E.handsTimed(a,k)?'hit':undefined)};}
const P=perfect(hard),R1=E.handsResult(hard,P.ans,20,P.tim,0);ok(R1.stars===5&&!R1.inc&&R1.sat>=90,'全啱、計時準：五星、冇事故（滿意度 '+R1.sat+'）');
const tm=P.tim.slice(),qi=E.handsSteps(hard).indexOf('face');tm[qi]='miss';const R2=E.handsResult(hard,P.ans,20,tm,0);ok(R2.inc==='minor'&&R2.stars<=3,'修面計時失手：剪傷（'+R2.inc+'），最多三星');
const wrong=P.ans.slice();wrong[E.handsSteps(hard).indexOf('temp')]=E.handsOpts(hard,'temp').findIndex(o=>!o[1]&&o[3]==='skin');const R3=E.handsResult(hard,wrong,20,P.tim,0);ok(R3.inc==='skin'&&R3.sat<R1.sat,'水溫揀錯：皮膚問題，滿意度跌');
ok(E.handsAddOK(R1.sat)&&!E.handsAddOK(60),'滿意度 80 以上先可以問加做');
/* 主人評價影響口碑 */
const a5=Object.assign(mk('wash','s'),{handsStars:5,inc:null,pid:null}),a1=Object.assign(mk('wash','s'),{handsStars:2,inc:null,pid:null});
let r0=E.s.S.rating;E.onDone(a5);ok(E.s.S.rating>r0&&E.s.fb[0].stars===5,'五星：口碑升少少');r0=E.s.S.rating;E.onDone(a1);ok(E.s.S.rating<r0&&E.s.fb[0].stars===2,'兩星：口碑跌');
console.log(fail?fail+' 項失敗':'落手做邏輯測試全部通過');process.exitCode=fail?1:0;
