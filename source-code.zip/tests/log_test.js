/* v0.21 日誌：日結、補位等通知唔再喺底下彈，收入「日誌」面板（按日分組、按類別篩選）；底下只顯示重要通知；右下日誌掣有未睇數。
   用法：THREE_JS=<本機 three.min.js r128> node tests/log_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
 const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 const st=await p.evaluate(()=>{s.modal=null;s.evQ=[];s.gd.off=1;var end=s.day+3,n=0;while(s.day<end&&n++<400000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}advance(5);}
   while(s.t<14*60){advance(5);if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];}}
   news('補位','測試：補咗一個空位');news('投訴','測試：重要通知');s.paused=true;renderHUD();
   var ticker=[].map.call(document.querySelectorAll('#news b'),function(x){return x.textContent;});return {ticker:ticker,unread:logUnread(),n:s.news.length,days:s.news.filter(function(x){return x.who==='日結';}).length};});
 assert(st.days>=3&&st.n>=6,'有日結同其他通知 '+JSON.stringify(st));
 assert(st.ticker.length>=1&&st.ticker.every(x=>({'投訴':1,'嚴重事故':1,'特殊客':1,'升級':1,'里程碑':1,'管理處':1,'保險':1,'AI 出錯':1,'事件':1,'貸款':1,'創辦人':1,'私隱':1,'法規':1,'舖位':1})[x]),'底下只顯示重要通知：'+st.ticker.join('、'));
 assert(/^\d+\+?$/.test(await p.locator('#btnLog .lgb').innerText())&&await p.locator('#btnLog').isVisible(),'右下日誌掣有未睇數 '+(await p.locator('#btnLog .lgb').innerText()));
 await p.click('#btnLog');await p.waitForTimeout(300);
 assert(/日誌/.test(await p.locator('#panel .p-title').innerText()),'打開日誌面板');
 const all=await p.evaluate(()=>({heads:document.querySelectorAll('#panel .lg-d').length,rows:document.querySelectorAll('#panel .lg li').length,unread:logUnread()}));
 assert(all.heads>=3&&all.rows>=10&&all.unread===0,'按日分組，打開就當睇咗 '+JSON.stringify(all));
 if(w===1440)await p.screenshot({path:path.join(out,'v21_log_'+w+'.png')});
 await p.click('#panel [data-act=psub][data-s=day]');await p.waitForTimeout(200);
 const day=await p.evaluate(()=>[].map.call(document.querySelectorAll('#panel .lg .pill'),function(x){return x.textContent;}));
 assert(day.length>=3&&day.every(x=>x==='日結'),'篩選「日結」只出日結 ('+day.length+')');
 await p.click('#panel [data-act=psub][data-s=appt]');await p.waitForTimeout(200);
 const ap=await p.evaluate(()=>[].map.call(document.querySelectorAll('#panel .lg .pill'),function(x){return x.textContent;}));
 assert(ap.includes('補位')&&!ap.includes('日結'),'篩選「預約」有補位冇日結');
 if(w===420)await p.screenshot({path:path.join(out,'v21_log_'+w+'.png')});
 assert(!(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth)),'冇橫向溢出');
 assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'日誌測試通過（'+all.rows+' 條，'+all.heads+' 日）；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
