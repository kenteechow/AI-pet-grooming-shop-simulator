/* 行路測試：1× 速度下客人步速、面向、有冇「跑」或者「打橫移」。用法：THREE_JS=... node tests/walk_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:640,height:420}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(600);await p.evaluate(()=>{s.labels=0;if(W3.sun)W3.sun.castShadow=false;var n=0;while(s.t<600&&n++<500){if(s.modal){s.modal=null;s.evQ=[];}else advance(5);}});
 const speeds=[1,3];const res=[];
 for(const sp of speeds){
  await p.evaluate((sp)=>{s.modal=null;s.evQ=[];s.paused=false;s.speed=sp;window._log=[];window._prev={};window._run=1;
   (function tick(){if(s.modal){s.modal=null;s.evQ=[];}Object.keys(W3.actors).forEach(function(k){if(!/^w/.test(k))return;var a=W3.actors[k];if(!a.visible)return;var q=_prev[k];
    if(q){var dx=a.position.x-q.x,dz=a.position.z-q.z,dt=(performance.now()-q.t)/1000,d=Math.hypot(dx,dz);if(d>1e-3&&d<1&&dt>0){var face=Math.atan2(dx,dz),off=Math.abs(Math.atan2(Math.sin(face-a.rotation.y),Math.cos(face-a.rotation.y)));_log.push({v:d/dt,off:off});}}
    _prev[k]={x:a.position.x,z:a.position.z,t:performance.now()};});if(window._run)requestAnimationFrame(tick);})();},sp);
  await p.waitForTimeout(15000);
  const r=await p.evaluate(()=>{window._run=0;var L=_log.slice().sort(function(a,b){return a.v-b.v;});var vs=L.map(x=>x.v),offs=L.map(x=>x.off).sort((a,b)=>a-b);
   return {n:L.length,vMed:vs[vs.length>>1],v95:vs[Math.floor(vs.length*.95)],offMed:offs[offs.length>>1],off95:offs[Math.floor(offs.length*.95)],sideways:L.filter(x=>x.off>1).length,t:s.t};});
  r.speed=sp;res.push(r);console.log(JSON.stringify(r));}
 console.log('errs',JSON.stringify(errs));
 const bad=res.filter(r=>r.n<10||r.vMed>3.2||r.off95>.6);console.log(bad.length?'行路測試失敗':'行路測試通過：步速正常、面向行緊嘅方向');await b.close();})();
