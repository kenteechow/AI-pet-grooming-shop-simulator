/* v0.17 落手做測試：你負責嘅預約做緊會出提示；入近鏡逐步揀；全啱會避免小事故；揀錯水溫會變皮膚問題；完成後恢復時間同鏡頭。
   用法：THREE_JS=<本機 three.min.js r128> node tests/hands_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
 const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=solo]');await p.waitForTimeout(500);
 /* 推到你有預約做緊（洗澡或全剪） */
 const a=await p.evaluate(()=>{s.modal=null;s.evQ=[];s.gd.off=1;s.paused=false;var n=0,a=null;while(n++<300000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}
   a=todayAppts().filter(function(x){return handsCan(x)&&!x.special&&x.st==='doing'&&(x.svc==='wash'||x.svc==='cut');})[0];if(a)break;advance(1);}s.paused=true;a.inc='stress';renderHUD();return {id:a.id,svc:a.svc,pet:a.pet};});
 await p.waitForTimeout(300);
 assert(await p.locator('#handsCue').isVisible(),'有「落手做」提示');
 await p.click('#handsCue');await p.waitForTimeout(400);
 assert(await p.locator('#hands').isVisible(),'打開落手做');assert(await p.evaluate(()=>document.getElementById('game').classList.contains('handsmode')&&s.paused),'落手做時暫停時間、收埋其他介面');
 await p.screenshot({path:path.join(out,'v17_hands_'+w+'.png')});
 /* 全部揀啱 */
 const steps=await p.evaluate(()=>handsSteps(HANDS.a).length);
 let animChecked=false,timedSeen=0;
 for(let i=0;i<steps;i++){const ph=await p.evaluate(()=>{var k=handsSteps(HANDS.a)[HANDS.i],oi=handsOpts(HANDS.a,k).findIndex(function(o){return o[1];});document.querySelector('#hands [data-act=handspick][data-o="'+oi+'"]').click();return HANDS.phase;});
  if(!animChecked){await p.waitForTimeout(300);const an=await p.evaluate(()=>{var A=HANDS.anim,pet=W3.actors['p'+HANDS.a.id];return A&&A.g&&pet?A.g.position.distanceTo(pet.position):null;});assert(an!=null&&an<1.5,'揀完有工具動畫喺毛孩身邊（距離 '+an+'）');animChecked=true;}
  if(ph==='time'){timedSeen++;if(w===1440&&timedSeen===1)await p.screenshot({path:path.join(out,'v18_timing.png')});
   await p.evaluate(()=>{var k=handsSteps(HANDS.a)[HANDS.i],z=handsZone(HANDS.a,k,HANDS.stress);window._hc=handsCursor;handsCursor=function(){return (z[0]+z[1])/2;};});await p.click('#hands [data-act=handspress]');await p.evaluate(()=>{handsCursor=window._hc;});}
  if(i===2&&w===1440)await p.screenshot({path:path.join(out,'v17_hands_fb.png')});await p.click('#hands [data-act=handsnext]');}
 assert(timedSeen>=1,'有計時步驟（'+timedSeen+' 個）');
 const rt=await p.locator('#hands').innerText();assert(/做啱/.test(rt)&&/客人滿意度 100/.test(rt),'有結果，滿意度 100');assert(await p.locator('#hands [data-act=handsadd]').count()>=2,'做得好可以問加做');
 await p.click('#hands [data-act=handsadd][data-x=teeth]');await p.waitForTimeout(100);assert(/刷牙/.test(await p.locator('#hands .hd-add').innerText()),'加做有回覆');
 await p.screenshot({path:path.join(out,'v17_hands_res_'+w+'.png')});
 await p.click('#hands [data-act=handsdone]');await p.waitForTimeout(300);
 const r=await p.evaluate(id=>{var a=s.wk.appts.filter(function(x){return x.id===id;})[0];return {inc:a.inc,q:a.handsQ,stars:a.handsStars,done:a.handsDone,mode:document.getElementById('game').classList.contains('handsmode'),hidden:document.getElementById('hands').hidden};},a.id);
 assert(r.q===1&&r.inc===null&&r.done&&r.stars===5,'全部做啱：避免咗本來嘅緊張事故，預計五星 '+JSON.stringify(r));assert(!r.mode&&r.hidden,'完成後返回正常畫面');
 /* 第二隻：水溫揀錯 */
 const r2=await p.evaluate(()=>{var o=handsOwner(),a=s.wk.appts.filter(function(x){return x.g===o.id&&x.out==='ok'&&x.st==='booked'&&(x.svc==='wash'||x.svc==='cut')&&x.day===s.day;})[0]||s.wk.appts.filter(function(x){return x.g===o.id&&x.out==='ok'&&x.st==='booked'&&(x.svc==='wash'||x.svc==='cut');})[0];if(!a)return 'none';
  var steps=handsSteps(a),ans=steps.map(function(k){return handsOpts(a,k).findIndex(function(o){return o[1];});});ans[steps.indexOf('temp')]=handsOpts(a,'temp').findIndex(function(o){return !o[1]&&o[3]==='skin';});var R0=handsResult(a,ans,30,[],0);handsApply(a,R0,ans);return {inc:a.inc,q:R0.q};});
 assert(r2==='none'||r2.inc==='skin','水溫太熱：變成皮膚問題 '+JSON.stringify(r2));
 const ov=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert(!ov,'橫向溢出');
 assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'落手做測試通過（'+a.pet+'，'+a.svc+'，'+steps+' 步）；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
