/* 固定隨機測試（v0.13）：同一個種子、同一套玩法，用唔同推進步長（模擬唔同 fps／速度）玩 120 日，結果要一模一樣；唔同種子要唔同。 */
const vm=require('vm');const load=require('./load.js');
function run(seed,steps){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',"+seed+");",E);
 let n=0,i=0;while(E.s.day<120&&n++<3e6){const s=E.s;if(s.day===10&&!s.lv.reply)E.deploy('reply',2);if(s.day===20&&!s.lv.file)E.deploy('file',2);
  if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(steps[i++%steps.length]);}
 const s=E.s;return JSON.stringify({m:s.months.map(m=>[Math.round(m.rev),Math.round(m.profit),m.done,m.ns]),cash:Math.round(s.cash),pets:Object.keys(s.cl.pets).length,notes:Object.values(s.cl.pets).reduce((a,p)=>a+p.notes.length,0),ev:Object.keys(s.evSeen).sort(),claims:(s.claims||[]).map(c=>c.st)});}
const a=run(777,[5]),b=run(777,[1,3,4,2,5,0.5]),c=run(777,[5,5,5,1]),d=run(778,[5]);
let fail=0;function ok(x,m){console.log((x?'通過：':'失敗：')+m);if(!x)fail++;}
ok(a===b,'同一種子，唔同推進步長，結果一樣');ok(a===c,'同一種子，另一組步長，結果一樣');ok(a!==d,'唔同種子，結果唔同');
if(a!==b){console.log(a.slice(0,400));console.log(b.slice(0,400));}
console.log(fail?fail+' 項失敗':'固定隨機測試全部通過');process.exitCode=fail?1:0;
