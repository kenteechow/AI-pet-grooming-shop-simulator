/* 冒煙測試：開沙盒、行晒所有分頁、情境、模式，跑蒙地卡羅。印出 errs []。 */
const {chromium}=require('playwright');const path=require('path');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:1440,height:900}});
 const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/fonts|ERR_|Failed to load/.test(m.text()))errs.push(m.text());});
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));
 await p.click('[data-act=sandbox]');await p.waitForTimeout(300);
 const tabs=await p.$$eval('[data-act=tab]',x=>x.map(e=>e.dataset.t));
 for(const t of tabs){await p.click(`[data-act=tab][data-t=${t}]`);await p.waitForTimeout(t==='cmp'?2500:t==='q'?900:t==='ov'||t==='sens'?700:150);}
 const scens=await p.$$eval('#scen option',x=>x.map(e=>e.value));
 await p.click('[data-act=tab][data-t=ov]');
 for(const s of scens){await p.selectOption('#scen',s);await p.waitForTimeout(250);}
 for(const m of ['A','B','C','D']){await p.click(`[data-act=model][data-m=${m}]`);await p.waitForTimeout(250);}
 await p.click('[data-act=lv][data-role=reply][data-lv="3"]');await p.waitForTimeout(250);
 await p.$eval('#in-P-noShow',e=>{e.value=.2;e.dispatchEvent(new Event('input',{bubbles:true}));});await p.waitForTimeout(400);
 await p.click('[data-act=tab][data-t=mc]');await p.selectOption('#mcN','100');await p.click('[data-act=mcRun]');
 await p.waitForFunction(()=>!UI.mcBusy,null,{timeout:60000});
 const ok=await p.evaluate(()=>({mc:!!UI.mc,n:UI.mc&&UI.mc.n,blind:UI.R.blind.filter(b=>b.on).length}));
 console.log('mc',JSON.stringify(ok));
 await p.click('[data-act=tab][data-t=sens]');await p.waitForTimeout(800);await p.click('[data-act=sensT][data-t=shop]');await p.waitForTimeout(600);
 await p.click('[data-act=reset]');await p.click('[data-act=home]');
 console.log('errs',JSON.stringify(errs));await b.close();process.exit(errs.length?1:0);
})();
