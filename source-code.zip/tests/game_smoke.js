/* 遊戲冒煙測試：擋住外部 JS（唔開 3D），每個開局模擬 8 週，打開所有面板同子目錄、彈窗、設定。印出 errs []。 */
const {chromium}=require('playwright');const T=15000;const path=require('path');
(async()=>{
 const b=await chromium.launch();const errs=[];
 for(const op of ['community','allai','solo','old']){
  const p=await b.newPage({viewport:{width:1440,height:900}});p.setDefaultTimeout(T);
  p.on('pageerror',e=>errs.push(op+': '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/fonts|ERR_|Failed to load|three/.test(m.text()))errs.push(op+': '+m.text());});
  await p.route(/fonts\.(googleapis|gstatic)|cdnjs/,r=>r.abort());
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));
  await p.click('[data-act=openings]');await p.click(`[data-act=start][data-id=${op}]`);await p.waitForTimeout(400);
  const res=await p.evaluate(()=>{let n=0;while(s.day<56&&n<200000){n++;if(s.modal){if(s.modal.type==='event')chooseEvent(s.modal.id==='afterhours'?2:0);else{s.modal=null;nextEvent();}}else advance(5);}s.modal=null;s.evQ=[];s.paused=true;return {day:s.day,cash:Math.round(s.cash),months:s.months.length,ev:Object.keys(s.evSeen)};});
  console.log(op,JSON.stringify(res));
  const docks=await p.$$eval('#dock [data-act=panel]',x=>x.map(e=>e.dataset.p));
  for(const d of docks){await p.click(`#dock [data-p=${d}]`);await p.waitForTimeout(80);const subs=await p.$$eval('#panel [data-act=psub]',x=>x.map(e=>e.dataset.s));
   for(const sb of subs){await p.click(`#panel .p-subs [data-s="${sb}"]`);await p.waitForTimeout(60);}
   if(d==='sched'){await p.click('#panel .p-subs [data-s=week]');const a=await p.$('#panel .blk.ap');if(a)await a.click();}
   if(d==='ai'){await p.click('#panel .p-subs [data-s=reply]');const btn=await p.$('#panel [data-act=deploy]:not([disabled])');if(btn)await btn.click();}
   if(d==='staff'){await p.click('#panel .p-subs [data-s=hire]');const hb=await p.$('#panel [data-act=hire]');if(hb)await hb.click();}
   await p.click('#panel [data-act=pclose]');}
  /* 拖放：將一個預約拖去另一個美容師嘅空格 */
  const dd=await p.evaluate(()=>{openPanel('sched');PANEL.sub='week';renderPanel();var b=[...document.querySelectorAll('#panel .blk.ap[draggable=true]')][0];if(!b)return 'no draggable';
   var lanes=[...document.querySelectorAll('#panel .lane[data-act=lane]')],lane=lanes[lanes.length-1],dt=new DataTransfer();
   b.dispatchEvent(new DragEvent('dragstart',{bubbles:true,dataTransfer:dt}));var r=lane.getBoundingClientRect();
   lane.dispatchEvent(new DragEvent('drop',{bubbles:true,dataTransfer:dt,clientX:r.left+r.width*.9,clientY:r.top+5}));return SCHED.msg&&SCHED.msg.t;});
  console.log(op,'drag:',dd);
  await p.evaluate(()=>{PANEL.id=null;renderPanel();});
  await p.click('#dock [data-p=fin]');for(const sb of ['owner','ins','loan']){await p.click(`#panel .p-subs [data-s=${sb}]`);await p.waitForTimeout(60);}
  await p.click('#panel [data-act=loan][data-k=fin]');await p.click('#panel [data-act=pclose]');
  await p.click('#dock [data-p=rep]');await p.click('#panel [data-act=fdcheat]');await p.evaluate(()=>{chooseEvent(0);});await p.waitForTimeout(100);
  const fdok=await p.evaluate(()=>{for(let i=0;i<40&&s.months.length<4;i++){}s.paused=false;let n=0;const m0=s.months.length;while(s.months.length<m0+2&&n++<1e5){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else{s.modal=null;nextEvent();}}else advance(10);}s.modal=null;s.evQ=[];s.paused=true;openPanel('fd');var subs=['ov','shops','time','model'];subs.forEach(function(x){PANEL.sub=x;renderPanel();});PANEL.id=null;renderPanel();return !!s.fd&&s.fd.hist.length;});
  console.log(op,'founder months',fdok);
  await p.evaluate(()=>{s.visit=1;renderHUD();});await p.waitForTimeout(200);await p.evaluate(()=>{s.visit=0;renderHUD();});
  await p.keyboard.press('Escape');await p.waitForTimeout(100);await p.click('[data-act=labels]');await p.click('[data-act=mclose]');
  await p.click('[data-act=spd][data-v="30"]');await p.waitForTimeout(1500);await p.evaluate(()=>{s.modal=null;s.evQ=[];s.paused=true;});
  await p.evaluate(()=>{s.modal={type:'month',rec:s.months[0]};});await p.waitForTimeout(100);await p.click('[data-act=mclose]');
  await p.click('[data-act=settings]');await p.click('[data-act=home]');await p.waitForTimeout(100);
  const c=await p.$('#title [data-act=cont]');console.log(op,'cont button',!!c);
  if(c){await c.click();await p.waitForTimeout(300);console.log(op,'reload day',await p.evaluate(()=>s.day));}
  await p.close();}
 {const p=await b.newPage({viewport:{width:1440,height:900}});p.setDefaultTimeout(T);p.on('pageerror',e=>errs.push('demo: '+e.message));await p.route(/fonts\.(googleapis|gstatic)|cdnjs/,r=>r.abort());
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));
  /* 加速測試示範步驟的動畫幀；逐分鐘畫面另由 minute_clock_test 實測。 */
  await p.evaluate(()=>{const real=window.requestAnimationFrame.bind(window),ch=new MessageChannel();let q=[],clock=performance.now();ch.port1.onmessage=()=>{const f=q.shift();if(f){clock=Math.max(clock,performance.now())+100;f(clock)}};window.requestAnimationFrame=function(f){if(f.name==='frame'){q.push(f);ch.port2.postMessage(0);return 0}return real(f)}});
  await p.click('#title [data-act=demostart]');await p.waitForTimeout(300);
  for(let i=0;i<await p.evaluate(()=>DEMO.length-1);i++){await p.evaluate(()=>{if(s.modal&&s.modal.type!=='event')s.modal=null;});await p.locator('[data-act=demonext]').waitFor({state:'visible'});await p.waitForFunction(()=>!document.querySelector('[data-act=demonext]').disabled,null,{timeout:180000});await p.click('[data-act=demonext]');await p.waitForTimeout(150);}
  console.log('demo step',await p.evaluate(()=>s.demo&&s.demo.i),'day',await p.evaluate(()=>s.day));await p.close();}
 console.log('errs',JSON.stringify(errs));await b.close();process.exit(errs.length?1:0);
})();
