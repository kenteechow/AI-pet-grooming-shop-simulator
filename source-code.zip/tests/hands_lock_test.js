/* v0.18.1 落手做鎖時間：做緊嗰陣撳速度掣、快捷鍵、跳過都唔會推時間；毛孩唔會做完走咗而面板仲喺度；預約唔喺度會自動收面板；收手後恢復速度。
   用法：THREE_JS=<本機 three.min.js r128> node tests/hands_lock_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:1440,height:900}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=solo]');await p.waitForTimeout(500);
 const a=await p.evaluate(()=>{s.modal=null;s.evQ=[];s.gd.off=1;var n=0,a=null;while(n++<300000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}
   a=todayAppts().filter(function(x){return handsCan(x)&&!x.special&&x.st==='doing';})[0];if(a)break;advance(1);}s.speed=30;s.paused=false;renderHUD();return {id:a.id,pet:a.pet};});
 await p.waitForTimeout(200);await p.click('#handsCue');await p.waitForTimeout(300);
 const t0=await p.evaluate(()=>s.t);
 /* 試盡所有快進方法 */
 await p.keyboard.press('4');await p.keyboard.press(' ');await p.keyboard.press('3');
 assert(await p.locator('#hands .hd-lockmsg').isVisible(),'撳快進有提示');
 await p.evaluate(()=>{var b=document.querySelector('#hudTL .spd [data-v="30"]');if(b)b.click();var k=document.querySelector('[data-act=skipnow]');if(k)k.click();});
 assert(await p.evaluate(()=>document.querySelector('#hudTL .spd').classList.contains('hlock')&&/時間暫停/.test(document.getElementById('hudTL').innerText)),'速度掣鎖住，有「時間暫停」字');
 await p.evaluate(()=>{s.paused=false;});/* 就算有其他地方解除暫停，主循環都唔推 */
 await p.waitForTimeout(2500);
 const r=await p.evaluate(id=>{var a=s.wk.appts.filter(function(x){return x.id===id;})[0];return {t:s.t,st:a.st,open:!!HANDS.a,vis:!document.getElementById('hands').hidden};},a.id);
 assert(r.t===t0,'時間冇行 '+t0+' → '+r.t);assert(r.st==='doing'&&r.open&&r.vis,'毛孩仲喺度做緊、面板仲開住 '+JSON.stringify(r));
 /* 收手：恢復之前嘅速度 */
 await p.click('#hands [data-act=handsx]');await p.waitForTimeout(800);
 const r2=await p.evaluate(()=>({t:s.t,paused:s.paused,lock:!!document.querySelector('#hudTL .spd.hlock')}));
 assert(r2.t>t0&&!r2.paused&&!r2.lock,'收手後時間繼續行 '+JSON.stringify(r2));
 /* 安全網：預約唔喺度就自動收面板 */
 const r3=await p.evaluate(()=>{s.paused=true;var a=todayAppts().filter(function(x){return handsCan(x);})[0]||s.wk.appts.filter(function(x){return handsOwner()&&x.g===handsOwner().id&&!x.handsDone;})[0];if(!a)return 'none';
  a.st='doing';handsOpen(a.id);var opened=!!HANDS.a;a.st='done';return {opened:opened};});
 if(r3!=='none'){assert(r3.opened,'可以打開');await p.waitForTimeout(400);
  const r4=await p.evaluate(()=>({open:!!HANDS.a,hidden:document.getElementById('hands').hidden,mode:document.getElementById('game').classList.contains('handsmode')}));
  assert(!r4.open&&r4.hidden&&!r4.mode,'預約唔喺度：自動收返面板 '+JSON.stringify(r4));}
 assert.deepStrictEqual(errs,[]);console.log('落手做鎖時間測試通過（'+a.pet+'）；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
