const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();
 const sizes=[[1440,900],[1100,680],[820,700],[420,800]];const out=process.argv[2]||'shots';
 for(const scheme of ['dark','light'])for(const [w,h] of sizes){
  const p=await b.newPage({viewport:{width:w,height:h},colorScheme:scheme});
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.waitForTimeout(1200);
  if(w===1440)await p.screenshot({path:`${out}/title_${scheme}_${w}.png`});
  await p.click('[data-act=sandbox]');await p.waitForTimeout(1500);
  await p.screenshot({path:`${out}/ov_${scheme}_${w}.png`});
  const ov=await p.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);
  if(scheme==='dark'&&(w===1440||w===420)){for(const t of ['shop','fd','sens','cmp','q','bs']){await p.click(`[data-act=tab][data-t=${t}]`);await p.waitForTimeout(t==='cmp'?2600:900);await p.screenshot({path:`${out}/${t}_${scheme}_${w}.png`,fullPage:w===420});}}
  console.log(scheme,w,'hscroll',ov);await p.close();}
 await b.close();})();
