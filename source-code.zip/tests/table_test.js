/* v0.21.2 落手做／特殊客：毛孩一定喺美容枱上（社區店有助手，預約頭段本來會喺浴缸，枱上就冇嘢）。
   用法：THREE_JS=<本機 three.min.js r128> node tests/table_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:1280,height:800}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 const dist=async()=>p.evaluate(()=>{var a=HANDS.a,pet=W3.actors['p'+a.id],tb=SHOP.tables[a.tb]||SHOP.tables[0];return pet&&pet.visible?Math.hypot(pet.position.x-tb[0],pet.position.z-tb[1]):99;});
 for(const kind of ['normal','special']){
  const info=await p.evaluate(kind=>{s.modal=null;s.evQ=[];s.gd.off=1;s.paused=true;var o=handsOwner(),a;
   if(kind==='special'){a=spSpawn('happy',spSlot(s.day,s.wk.start+6)||[s.day,700]);s.day=a.day;s.t=a.a;}
   else{a=s.wk.appts.filter(function(x){return x.g===o.id&&!x.special&&x.out==='ok'&&x.st==='booked'&&x.day>=s.day&&activeStaff().some(function(y){return y.role==='asst'&&staffWorks(y,x.day);});})[0];s.day=a.day;s.t=a.a+2;}
   a.st='doing';var asst=activeStaff().some(function(x){return x.role==='asst'&&staffWorks(x,s.day);});window._a=a;handsOpen(a.id);return {id:a.id,asst:asst,frac:(s.t-a.a)/(a.b-a.a)};},kind);
  let d=99;for(let i=0;i<30&&d>.3;i++){await p.waitForTimeout(150);d=await dist();}
  assert(d<.3,kind+'：毛孩喺美容枱上（距離 '+d.toFixed(2)+'，助手 '+info.asst+'，進度 '+info.frac.toFixed(2)+'）');
  await p.screenshot({path:path.join(out,'v212_table_'+kind+'.png')});
  await p.evaluate(()=>{handsClose(false);window._a.st=window._a.special?'gone':window._a.st;});}
 /* v0.21.6：客人仲行緊入嚟（毛孩跟住主人，未擺入店）就開始對話：枱上都要有毛孩，唔好有兩隻 */
 const w0=await p.evaluate(()=>{s.paused=true;var a=spSpawn('oiia',spSlot(s.day,s.wk.start+6)||[s.day,800]);s.day=a.day;s.t=a.a-24;s.speed=1;s.paused=false;window._w=a;return a.id;});
 let J=null;for(let i=0;i<80&&!(J&&(J.st==='in'||J.st==='desk'));i++){await p.waitForTimeout(150);J=await p.evaluate(id=>{var j=W3.jr&&W3.jr['d'+id];return j?{st:j.st,d:j.d}:null;},w0);}
 assert(J&&(J.st==='in'||J.st==='desk'),'特殊客行緊入嚟（仲未將毛孩交低）'+JSON.stringify(J));
 await p.evaluate(()=>{s.paused=true;var a=_w;a.st='doing';s.t=a.a+1;handsOpen(a.id);});
 let d2=99;for(let i=0;i<30&&d2>.3;i++){await p.waitForTimeout(150);d2=await dist();}
 const dup=await p.evaluate(id=>{var q=W3.actors['q'+id];return !!(q&&q.visible);},w0);
 assert(d2<.3&&!dup,'客人行緊入嚟時開始：毛孩喺枱上（距離 '+d2.toFixed(2)+'），路上冇第二隻（'+dup+'）');
 await p.screenshot({path:path.join(out,'v216_table_walkin.png')});
 assert.deepStrictEqual(errs,[]);console.log('美容枱測試通過；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
