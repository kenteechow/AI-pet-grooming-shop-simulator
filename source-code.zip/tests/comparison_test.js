const assert=require('assert');const vm=require('vm');const load=require('./load.js');
const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community')",E);
const start=E.s.shCash,weekly=E.s.wk.hs.profit;assert.strictEqual(start,E.s.base.startCash,'新局唔應預支隔籬一週利潤');
/* v0.13 起隔籬每日亦按期望值扣事故費用（p_ledger），要一齊計 */
const hh=E.s.wk.hs,insP=(E.INC_COST.serious-E.CLAIM.excess)*(E.CLAIM.approve+E.CLAIM.partial*E.CLAIM.partialShare),incD=((hh.minor||0)*E.INC_COST.minor+(hh.skin||0)*E.INC_COST.skin+(hh.serious||0)*(E.INC_COST.serious-insP))/7;
E.s.modal=null;E.endOfDay();assert(Math.abs(E.s.shCash-start-weekly/7+incD)<1e-6,'隔籬每日入帳一日利潤（扣埋事故期望值）');
let n=0;while(E.s.months.length<1&&n++<50000){if(E.s.modal){if(E.s.modal.type==='event')E.chooseEvent(0);else{E.s.modal=null;E.nextEvent();}}else E.advance(10);}
assert(E.s.months.length,'應完成一個月');const m=E.s.months[0],ds=E.s.days.filter(d=>{const date=E.dateOf(d.day);return date.getFullYear()===m.y&&date.getMonth()+1===m.m});
assert(Math.abs(m.shProfit-ds.reduce((a,d)=>a+d.shProfit,0))<1e-6,'隔籬月利潤等於相同日期每日分攤總和');
console.log('月結按日分攤、跨月同新局現金通過');
