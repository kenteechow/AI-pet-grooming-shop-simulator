/* v0.19 落手做：每隻毛孩嘅題目按品種、佢嘅特點同主人今日交代而變。
   用法：node tests/hands_var_test.js */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',11);",E);
let n=0;const pet=(notes)=>{const id='pt'+(n++);E.s.cl.pets[id]={id,name:'測試'+id,notes:notes.map((t,i)=>({id:'n'+i,txt:t[0],truth:t[2]||t[0],kind:'care',st:t[1]||'confirmed',wrong:!!t[2]})),cnt:{done:1},visits:[]};return id;};
const mk=(svc,seg,breed,notes,hreq)=>({id:800000+(n++),svc,seg,breed,pet:'測試',owner:'陳太',g:E.handsOwner().id,st:'doing',day:E.s.day,a:700,b:760,price:400,pid:notes?pet(notes):null,hreq:hreq==null?'':hreq});
const st=a=>E.handsSteps(a).join(',');
/* 品種 */
const shiba=mk('wash','m','柴犬'),bichon=mk('wash','c','比熊'),pug=mk('wash','s','八哥');
ok(/brush_dbl/.test(st(shiba))&&/dry_dbl/.test(st(shiba)),'柴犬（雙層毛）：落水前梳底毛、吹到底毛乾 '+st(shiba));
ok(/tear/.test(st(bichon))&&!/dbl/.test(st(bichon)),'比熊：有清淚痕一步 '+st(bichon));
ok(/dry_flat/.test(st(pug)),'八哥（短鼻）：吹乾要留意呼吸');
ok(st(shiba)!==st(bichon)&&st(bichon)!==st(pug),'同樣洗澡，三隻唔同品種題目唔同');
/* 特點（包括 AI 寫錯、未確認嘅草稿：真實特點仍然存在） */
const noisy=mk('wash','c','松鼠',[['鍾意大風，可以用高速吹乾','draft','怕大風聲，低風速同分段休息會放鬆啲']]);
ok(/dry_noise/.test(st(noisy)),'佢真係怕大風聲（AI 草稿寫錯咗）：吹乾變低風速分段');
const shy=mk('nail','s','芝娃娃',[['怕陌生人，先俾佢聞手先開始'],['指甲黑色，要分幾次慢慢剪'],['剪腳毛會縮腳，要助手扶住']]);
ok(/^file,greet/.test(st(shy))&&/quick_black/.test(st(shy))&&/hold_paw/.test(st(shy)),'怕陌生人、黑甲、縮腳：先打招呼、黑甲剪法、助手扶 '+st(shy));
const old=mk('wash','o','老年西施',[['企耐咗會氣喘，要多啲休息'],['怕冷，吹乾要快啲']]);
ok(/rinse,rest/.test(st(old))&&/dry_cold/.test(st(old))&&!/finding/.test(st(old)),'老狗氣喘、怕冷：過水後停低休息、暖風分段吹 '+st(old));
const cat=mk('cat','k','唐貓',[['怕水聲，用毛巾包住先唔會掙扎'],['唔好剪鬚','owner'],['下巴有黑色粒粒']]);
ok(/catwash_water/.test(st(cat))&&/catface/.test(st(cat))&&/finding_chin/.test(st(cat)),'貓：怕水聲、唔好剪鬚、下巴黑粒 '+st(cat));
const spay=mk('cut','c','貴婦',[['最近做完絕育，肚仔唔好壓','owner']]);ok(/sani_spay/.test(st(spay)),'啱啱絕育：唔剃肚毛');
/* 主人今日交代 */
const shortDbl=mk('cut','m','柯基',null,'short'),shortC=mk('cut','c','貴婦',null,'short');
ok(/req/.test(st(shortDbl))&&/body_short_dbl/.test(st(shortDbl))&&/body_short(?!_)/.test(st(shortC)),'要剪短：雙層毛要解釋唔建議剃，貴婦就換短梳套');
ok(E.hQ(shortC,'req').indexOf('今次想剪短啲')>=0,'題目寫出主人原話：'+E.hQ(shortC,'req'));
ok(/req_rush/.test(st(mk('wash','c','西施',null,'rush')))&&/soap_own/.test(st(mk('wash','c','西施',null,'own')))&&/check_flea/.test(st(mk('cut','c','西施',null,'flea')))&&/quick_bled/.test(st(mk('nail','c','西施',null,'bled'))),'其他交代：趕時間、自己沐浴露、睇蝨、上次流血');
/* 貓（v0.19.1） */
const persian=mk('cat','k','波斯貓',null,'lion');ok(/catlion/.test(st(persian))&&/dry_flat/.test(st(persian))&&/tear/.test(st(persian)),'波斯貓想剃獅子裝：電剪慢剃、短鼻吹乾、清淚痕 '+st(persian));
const nowash=mk('cat','k','唐貓',null,'nowash');ok(!/catwash|catdry/.test(st(nowash))&&/req/.test(st(nowash)),'主人話今次唔使洗：冇洗澡同吹乾 '+st(nowash));
const fierce=mk('cat','k','英短',[['一摸肚就咬'],['耳仔有好多啡色耳垢'],['有啲肥，背脊同尾根易打結']],'scratch');
ok(/towel_fierce/.test(st(fierce))&&/hold_belly/.test(st(fierce))&&/catear/.test(st(fierce))&&/catbrush_fat/.test(st(fierce)),'抓傷過人、摸肚會咬、耳垢、肥貓打結 '+st(fierce));
ok(/catquick_req/.test(st(mk('cat','k','唐貓',null,'claw')))&&/catquick(?!_)/.test(st(mk('cat','k','唐貓'))),'貓爪：按肉墊推出爪尖；主人要剪短都唔剪粉紅位');
const sig=new Set();for(let i=0;i<12;i++)sig.add(E.handsSteps(mk('cat','k','唐貓')).find(k=>/pant|catsign|catgrowl/.test(k)));ok(sig.size===3,'貓嘅身體語言信號每隻唔同（'+[...sig].join('、')+'）');
/* 主人要求嘅步驟計雙倍滿意度 */
const perf=a=>{const s=E.handsSteps(a);return s.map(k=>E.handsOpts(a,k).findIndex(o=>o[1]));};
const P=perf(shortC),ss=E.handsSteps(shortC),tim=ss.map(k=>E.handsTimed(shortC,k)?'hit':undefined);
const wReq=P.slice();wReq[ss.indexOf('body_short')]=E.handsOpts(shortC,'body_short').findIndex(o=>!o[1]&&!o[3]);
const wNorm=P.slice();wNorm[ss.indexOf('wet')]=E.handsOpts(shortC,'wet').findIndex(o=>!o[1]&&!o[3]);
const sR=E.handsResult(shortC,wReq,20,tim,0).sat,sN=E.handsResult(shortC,wNorm,20,tim,0).sat;ok(sR<sN,'做錯主人要求（滿意度 '+sR+'）扣得多過做錯一般步驟（'+sN+'）');
/* 親手做啱會寫入檔案 */
const p0=E.clPet(noisy.pid);E.handsApply(noisy,E.handsResult(noisy,perf(noisy),20,E.handsSteps(noisy).map(k=>E.handsTimed(noisy,k)?'hit':undefined),0),perf(noisy));
ok(p0.notes[0].st==='corrected'&&E.clNoteText(p0.notes[0]).indexOf('怕大風聲')>=0,'你親手發現：AI 寫錯嘅草稿改正返');
const p1=E.clPet(spay.pid),cutS=mk('cut','c','貴婦',[['主人鍾意耳仔留長，唔好剪短','draft']],'same');E.handsApply(cutS,E.handsResult(cutS,perf(cutS),20,[],0),perf(cutS));
ok(E.clPet(cutS.pid).notes.some(n=>n.src==='owner'&&/同上次一樣/.test(n.txt)),'主人交代覆述啱：記入檔案');
/* 全部步驟資料齊、字數相近 */
let bad=[];for(const k in E.HVAR){const S=E.HSTEP[k];if(!S.part||!S.anim||!S.why||!S.tool||(S.tm&&!S.tw))bad.push(k);}ok(!bad.length,'情況步驟資料齊（位置、動畫、解釋、計時提示）'+bad.join('、'));
/* 真實預約：同一服務有好多種題目組合 */
let seqs={};for(let d=0;d<60;d++){vm.runInContext("(function(){var g=0;while(g++<2000&&s.t<1260){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}advance(5);}var n=0;while(n++<3000&&s.t>=1260){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}advance(5);}})()",E);
 E.todayAppts().forEach(a=>{(seqs[a.svc]=seqs[a.svc]||new Set()).add(E.handsSteps(a).join(','));});}
const cnt=Object.keys(seqs).map(k=>k+' '+seqs[k].size).join('、');ok(seqs.wash&&seqs.wash.size>=8&&seqs.cut&&seqs.cut.size>=8&&seqs.cat&&seqs.cat.size>=8,'兩個月真實預約，每種服務有好多種組合：'+cnt);
console.log(fail?fail+' 項失敗':'情況題目測試全部通過');process.exitCode=fail?1:0;
