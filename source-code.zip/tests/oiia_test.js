/* v0.21.1 OIIA 貓：對白有「OIIA」時立繪播轉圈幀、播聲、3D 毛孩原地轉；定格時停；好結局一路轉出門口。
   用法：THREE_JS=<本機 three.min.js r128> node tests/oiia_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
 const p=await b.newPage({viewport:{width:1280,height:800}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=solo]');await p.waitForTimeout(500);
 await p.evaluate(()=>{window._snd=0;var o=spSound;spSound=function(k){window._snd++;return o(k);};s.modal=null;s.evQ=[];s.gd.off=1;s.paused=true;var a=spSpawn('oiia',spSlot(s.day,s.wk.start+6)||[s.day,700]);a.st='doing';s.day=a.day;s.t=a.a+1;window._a=a;handsOpen(a.id);});
 for(let i=0;i<40&&!(await p.evaluate(()=>!!W3.actors['p'+_a.id]));i++)await p.waitForTimeout(150);
 const st0=await p.evaluate(()=>{var V=HANDS.vn;V.done=true;renderSpecial();return {src:document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.oiia_stand,spin:V.spinning};});
 assert(st0.src&&!st0.spin,'第一句定格：企定圖、唔轉');
 /* 去到「OIIAOIIA——」嗰句 */
 await p.evaluate(()=>{var V=HANDS.vn;V.li=2;V.done=true;renderSpecial();});
 const r0=await p.evaluate(()=>W3.actors['p'+_a.id].userData.R.rotation.y);await p.waitForTimeout(600);
 const st1=await p.evaluate(r0=>{var V=HANDS.vn,src=document.querySelector('#spPortrait img').getAttribute('src');return {spin:V.spinning,frame:SPC.oiia.spin.some(function(k){return SPIMG[k]===src;}),snd:_snd,loop:!!(SPT.au&&SPT.au.loop&&!SPT.au.paused),rot:Math.abs(W3.actors['p'+_a.id].userData.R.rotation.y-r0)};},r0);
 assert(st1.spin==='spin'&&st1.frame&&st1.snd===1&&st1.loop&&st1.rot>.5,'講「OIIA」：立繪轉圈、聲跟住動圖循環播、3D 原地轉 '+JSON.stringify(st1));
 await p.screenshot({path:path.join(out,'v211_oiia_spin.png')});
 /* 返去定格 */
 await p.evaluate(()=>{var V=HANDS.vn;V.li=3;V.done=true;renderSpecial();});await p.waitForTimeout(300);
 const st2=await p.evaluate(()=>({spin:HANDS.vn.spinning,src:document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.oiia_stand,timer:!!SPT.spin,au:!!SPT.au}));
 assert(!st2.spin&&st2.src&&!st2.timer&&!st2.au,'定格：停轉、返企定圖、聲都停');
 /* 好結局 */
 await p.evaluate(()=>{var a=_a,V=HANDS.vn;V.i=V.nodes.length-1;V.mood=95;spEnter(a,V);V.phase='card';V.done=true;renderSpecial();});await p.waitForTimeout(500);
 const st3=await p.evaluate(()=>({spin:HANDS.vn.spinning,card:document.querySelector('#hands .vn-card').innerText,look:_a.spLook}));
 assert(st3.spin==='spin'&&/OIIAOIIA/.test(st3.card)&&st3.look==='spin','好結局：OIIAOIIA，一路轉');
 await p.screenshot({path:path.join(out,'v211_oiia_good.png')});
 await p.click('#hands [data-act=handsdone]');await p.waitForTimeout(200);
 assert(await p.evaluate(()=>!SPT.spin&&!SPT.au&&document.getElementById('spPortrait').hidden),'送走之後停止轉圈幀同聲');
 assert(await p.evaluate(()=>BGM_SRC.join()==='audio/hk1.mp3,audio/hk2.mp3'),'背景音樂換咗兩首 Hong Kong Afternoon');
 /* v0.21.2 Happy 貓：講「Happy happy」時立繪播跳嘅幀、3D 原地跳 */
 await p.evaluate(()=>{s.paused=true;var a=spSpawn('happy',spSlot(s.day,s.wk.start+6)||[s.day,900]);a.st='doing';s.day=a.day;s.t=a.a+1;window._h=a;handsOpen(a.id);});
 for(let i=0;i<40&&!(await p.evaluate(()=>!!W3.actors['p'+_h.id]));i++)await p.waitForTimeout(150);
 await p.evaluate(()=>{var V=HANDS.vn;V.li=1;V.done=true;renderSpecial();});await p.waitForTimeout(500);
 const hp=await p.evaluate(()=>{var src=document.querySelector('#spPortrait img').getAttribute('src');return {look:HANDS.vn.spinning,frame:SPC.happy.spin.some(function(k){return SPIMG[k]===src;}),snd:!!(SPT.au&&SPT.au.loop&&!SPT.au.paused&&SPT.au.src===SPSND.happy),y:W3.actors['p'+_h.id].userData.R.position.y};});
 assert(hp.look==='jump'&&hp.frame&&hp.snd,'Happy 貓講「Happy happy happy」：立繪播跳嘅幀，同步循環播佢把聲 '+JSON.stringify(hp));
 await p.screenshot({path:path.join(out,'v212_happy.png')});
 await p.evaluate(()=>{var V=HANDS.vn;V.li=2;V.done=true;renderSpecial();});await p.waitForTimeout(200);
 assert(await p.evaluate(()=>!HANDS.vn.spinning&&document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.happy_stand),'其他對白：返企定圖');
 await p.evaluate(()=>handsClose(false));
 /* 委屈貓用返抱頭圖 */
 await p.evaluate(()=>{var a=spSpawn('mimi',spSlot(s.day,s.wk.start+6)||[s.day,1000]);a.st='doing';s.day=a.day;s.t=a.a+1;handsOpen(a.id);var V=HANDS.vn;V.done=true;renderSpecial();});
 assert(await p.evaluate(()=>document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.sadcat&&/委屈貓/.test(document.querySelector('#hands').innerText+SPC.mimi.n)),'委屈貓用抱頭圖');
 await p.screenshot({path:path.join(out,'v212_sadcat.png')});
 /* v0.22.1 Pop Cat：講「POP」時口慢慢一開一合（開 0.38 秒、合 0.52 秒），每次張口「啵」一聲；其他對白唔郁 */
 await p.evaluate(()=>handsClose(false));
 await p.evaluate(()=>{window._pops=0;var A=window.Audio;window.Audio=function(src){var a=new A(src);if(src===SPSND.pop)window._pops++;return a;};var a=spSpawn('pop',spSlot(s.day,s.wk.start+6)||[s.day,1100]);a.st='doing';s.day=a.day;s.t=a.a+1;handsOpen(a.id);var V=HANDS.vn;V.done=true;renderSpecial();
  for(var i=0;i<40;i++){V.li=i;var L=spLine(V);if(L&&L[0]==='Pop Cat'&&/POP/.test(L[1]))break;}window._pli=V.li;});
 const q0=await p.evaluate(()=>({src:document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.pop0,on:!!SPT.mOn,pli:_pli,snd:!!SPSND.pop}));
 assert(q0.src&&!q0.on&&q0.snd&&q0.pli<40,'Pop Cat 未講 POP：合口、唔郁；有啵聲素材 '+JSON.stringify(q0));
 await p.evaluate(()=>{window._ev=[];var im=document.querySelector('#spPortrait img'),o=im.setAttribute;im.setAttribute=function(k,v){if(k==='src'&&(v===SPIMG.pop0||v===SPIMG.pop1))_ev.push([performance.now(),v===SPIMG.pop1?1:0]);return o.call(this,k,v);};var V=HANDS.vn;V.li=_pli;V.done=true;renderSpecial();});
 await p.waitForTimeout(2500);
 const q1=await p.evaluate(()=>{var ch=[],last=-1;_ev.forEach(function(e){if(e[1]!==last){ch.push(e);last=e[1];}});var gaps=[];for(var i=1;i<ch.length;i++)gaps.push(Math.round(ch[i][0]-ch[i-1][0]));return {first:ch.length?ch[0][1]:null,n:ch.length,minGap:gaps.length?Math.min.apply(null,gaps):0,gaps:gaps.join(','),pops:_pops};});
 assert(q1.first===1&&q1.n>=3&&q1.minGap>=350&&q1.pops>=2,'Pop Cat 講 POP：張口→合口慢慢輪流（每格至少 0.35 秒），每次張口啵一聲 '+JSON.stringify(q1));
 await p.screenshot({path:path.join(out,'v221_pop.png')});
 await p.evaluate(()=>{var V=HANDS.vn;V.li=0;V.done=true;renderSpecial();});await p.waitForTimeout(150);
 assert(await p.evaluate(()=>!SPT.mOn&&!SPT.mt&&document.querySelector('#spPortrait img').getAttribute('src')===SPIMG.pop0),'Pop Cat 唔再講 POP：停低、合口');
 await p.evaluate(()=>handsClose(false));
 assert(await p.evaluate(()=>!SPT.mOn&&!SPT.mt),'關咗面板：口嘅計時器停');
 /* Huh 貓換新圖（綠幕去底） */
 assert(await p.evaluate(()=>/^data:image\/(webp|png)/.test(SPIMG.huh)),'Huh 貓新圖已嵌入');
 assert.deepStrictEqual(errs,[]);console.log('OIIA 貓、Happy 貓、委屈貓、Pop Cat 測試通過；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
