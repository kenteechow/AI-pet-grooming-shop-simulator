/* v0.15.1 天台測試：所有用外牆貼圖嘅大廈，天台（盒嘅 +y 面）係純灰色，冇外牆貼圖。用法：THREE_JS=<本機 three.min.js r128> node tests/roof_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});const p=await b.newPage({viewport:{width:900,height:600}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 const r=await p.evaluate(()=>{var walls=0,bad=0;W3.sc.traverse(function(o){if(!o.isMesh)return;var m=o.material;if(Array.isArray(m)){if(m[0]&&m[0].map&&m.length===6){walls++;if(m[2].map||m[3].map)bad++;}}else if(m&&m.map&&o.geometry&&o.geometry.type==='BoxGeometry'&&o.geometry.parameters.height>5&&o.geometry.parameters.width>5)bad++;});return {walls:walls,bad:bad};});
 assert(r.walls>10,'搵到 '+r.walls+' 棟用外牆貼圖嘅大廈');assert(r.bad===0,'天台冇外牆貼圖（'+r.bad+' 個有問題）');
 assert.deepStrictEqual(errs,[]);console.log('天台測試通過：'+r.walls+' 棟大廈天台都係純灰色；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
