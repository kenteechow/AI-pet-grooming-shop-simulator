/* v0.15 測試：示範模式快進期間可以暫停、揀 1×／3×／10×／30×／自動（滑鼠同鍵盤）；快進時街上客人一路行，唔會卡住或者半路消失。
   用法：THREE_JS=<本機 three.min.js r128> node tests/demo_speed_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:1100,height:700}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=demostart]');await p.waitForTimeout(800);
 /* 第一步快進中：記錄客人 */
 await p.evaluate(()=>{window._trk={};(function w(){if(!window._stopTrk){if(!s.paused&&!s.modal)Object.keys(W3.jr||{}).forEach(function(k){var J=W3.jr[k],T=_trk[k]=_trk[k]||{ds:[],sts:[]};T.ds.push(J.d);T.sts.push(J.st);(T.dbg=T.dbg||[]).push([s.day,Math.round(s.t),J.st,+J.d.toFixed(2),W3.frame,DEMO_FF?1:0]);});requestAnimationFrame(w);}})();});
 await p.waitForTimeout(400);
 assert(await p.locator('#hudTL [data-act=spd][data-v="-1"]').count()===1,'示範模式時間面板有「自動」');
 /* 暫停 */
 await p.click('#hudTL [data-act=spd][data-v="0"]');const t0=await p.evaluate(()=>s.t);await p.waitForTimeout(800);const t1=await p.evaluate(()=>s.t);
 assert(Math.abs(t1-t0)<1e-6,'快進期間撳暫停會停低（'+t0+' → '+t1+'）');
 assert(/快進暫停中/.test(await p.locator('#demoCard').innerText()),'示範卡顯示快進暫停中');
 /* 鍵盤 2 = 3× */
 await p.keyboard.press('2');await p.waitForTimeout(100);
 const k=await p.evaluate(()=>({sp:s.speed,auto:s.demoAuto,paused:s.paused,ff:!!DEMO_FF}));assert(k.sp===3&&k.auto===false&&!k.paused&&k.ff,'鍵盤 2 轉 3× '+JSON.stringify(k));
 const a0=await p.evaluate(()=>s.t);await p.waitForTimeout(1500);const a1=await p.evaluate(()=>s.t);
 assert(a1>a0,'3× 期間時間有行（'+a0.toFixed(1)+' → '+a1.toFixed(1)+'）');
 /* 滑鼠撳 30× */
 await p.click('#hudTL [data-act=spd][data-v="30"]');assert(await p.evaluate(()=>s.speed===30&&!s.demoAuto),'滑鼠撳 30×');
 /* 撳返自動，等去到第一步目標 */
 await p.click('#hudTL [data-act=spd][data-v="-1"]');
 for(let i=0;i<240&&await p.evaluate(()=>!!DEMO_FF);i++)await p.waitForTimeout(250);
 assert(await p.evaluate(()=>!DEMO_FF),'自動快進完成');
 /* 下一步會快進好多日：期間觀察客人 */
 await p.evaluate(()=>{document.querySelector('[data-act=demonext]').click();});await p.waitForTimeout(300);await p.evaluate(()=>{document.querySelector('[data-act=demonext]').click();});
 for(let i=0;i<320&&await p.evaluate(()=>!!DEMO_FF);i++)await p.waitForTimeout(250);
 const tr=await p.evaluate(()=>{window._stopTrk=1;var bad=[],seen=0;Object.keys(_trk).forEach(function(k){var T=_trk[k];if(T.ds.length<5)return;seen++;
   /* 狀態唔可以由 in 直接跳去 gone（即係半路消失）；距離唔可以倒退（除咗轉 out） */
   for(var i=1;i<T.sts.length;i++){if(T.sts[i-1]==='in'&&T.sts[i]==='gone')bad.push(k+' in→gone');if(T.sts[i]===T.sts[i-1]&&T.sts[i]!=='gone'&&T.ds[i]<T.ds[i-1]-1e-6)bad.push(k+' 倒退');}
   var walk=T.sts.map(function(st,i){return (st==='in'||st==='out')?T.ds[i]:null;}).filter(function(x){return x!=null;});if(walk.length>=5&&walk[walk.length-1]===walk[0])bad.push(k+' 行緊但冇郁');});return {seen:seen,bad:bad.slice(0,5),dbg:bad.length?_trk[bad[0].split(' ')[0]].dbg.slice(0,30):null};});
 assert(tr.seen>0,'快進期間有客人行路（'+tr.seen+' 程）');if(tr.dbg)console.log(JSON.stringify(tr.dbg));assert(tr.bad.length===0,'客人一路行，冇卡住或者半路消失：'+JSON.stringify(tr.bad));
 assert.deepStrictEqual(errs,[]);console.log('示範模式調速同快進行路測試通過；'+tr.seen+' 程客人；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
