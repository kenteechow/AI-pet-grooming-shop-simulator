/* v0.14 測試：自動跳過非營業時間、手動跳、休息日同 7 日返工。用法：THREE_JS=<本機 three.min.js r128> node tests/skip_week_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const p=await b.newPage({viewport:{width:1100,height:700}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
 /* 1. 自動跳過：21:00 開始，真實時間 6 秒內應該去到第二日 09:30 附近 */
 await p.evaluate(()=>{window.goT=function(tt){s.paused=false;var n=0;while(s.t<tt&&n++<99999){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];}else advance(Math.min(5,tt-s.t));}};s.modal=null;s.evQ=[];goT(1260);todayAppts().forEach(function(a){if(a.st==='done'||a.st==='doing'||a.st==='arrived')a.st='gone';});s.speed=1;s.paused=false;window._d0=s.day;window._seen=[];(function w(){_seen.push(s.t);if(_seen.length<400)requestAnimationFrame(w);})();});
 let r=null;for(let i=0;i<40;i++){await p.waitForTimeout(250);r=await p.evaluate(()=>{if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;}return {day:s.day,t:s.t,d0:_d0};});if(r.day>r.d0&&r.t>=569)break;}
 assert(r.day===r.d0+1&&r.t>=569&&r.t<640,'自動跳過去到第二朝 '+JSON.stringify(r));
 const gaps=await p.evaluate(()=>{var mx=0;for(var i=1;i<_seen.length;i++){var d=_seen[i]-_seen[i-1];if(d<0)d+=1440;if(d>mx)mx=d;}return mx;});
 assert(gaps<=60,'跳過時每格最多推 '+gaps.toFixed(1)+' 分鐘，光線可以漸變');
 /* 白天唔會跳：10:30 之後每格最多一分鐘 */
 await p.evaluate(()=>{window._seen=[];goT(700);(function w(){_seen.push(s.t);if(_seen.length<40)requestAnimationFrame(w);})();});await p.waitForTimeout(1500);
 const day=await p.evaluate(()=>{var mx=0;for(var i=1;i<_seen.length;i++)mx=Math.max(mx,_seen[i]-_seen[i-1]);return mx;});assert(day<=1.0001,'營業時間唔跳（每格 '+day.toFixed(2)+' 分鐘）');
 /* 2. 關咗自動跳過：出「跳到」掣，撳咗先跳 */
 await p.evaluate(()=>{OPTS.skip=0;goT(1300);s.paused=true;todayAppts().forEach(function(a){if(a.st==='done'||a.st==='doing'||a.st==='arrived')a.st='gone';});renderHUD();});
 assert(await p.locator('#hudTL [data-act=skipnow]').count()===1,'關咗自動跳過，時間面板有「跳到」掣');
 const t1=await p.evaluate(()=>{s.paused=false;return s.t;});await p.waitForTimeout(1000);const t2=await p.evaluate(()=>s.t);
 assert(t2-t1<40,'冇撳掣唔會快進（1 秒行咗 '+(t2-t1).toFixed(0)+' 分鐘）');
 await p.click('#hudTL [data-act=skipnow]');await p.waitForTimeout(1000);const t3=await p.evaluate(()=>({t:s.t,d:s.day}));
 assert(t3.t<t2||t3.t-t2>100,'撳咗「跳到」就快進 '+JSON.stringify(t3));
 await p.evaluate(()=>{OPTS.skip=1;});
 /* 3. 休息日：老闆揀 7 日都返，下星期一起生效；員工冇呢個選項 */
 const o=await p.evaluate(()=>{s.paused=true;s.modal=null;openPanel('staff');PANEL.sub=null;renderPanel();var own=s.staff.filter(function(x){return x.role==='owner';})[0],emp=s.staff.filter(function(x){return x.role==='groomer';})[0];
  return {own:own.id,emp:emp.id,empHas7:!!document.querySelector('[data-act=offday][data-id="'+emp.id+'"] option[value="-1"]'),ownHas7:!!document.querySelector('[data-act=offday][data-id="'+own.id+'"] option[value="-1"]')};});
 assert(o.ownHas7&&!o.empHas7,'老闆有「7 日都返」選項，員工冇');
 await p.selectOption('[data-act=offday][data-id="'+o.own+'"]','-1');
 const before=await p.evaluate(id=>{var x=s.staff.filter(function(z){return z.id===id;})[0];return {off:x.off,next:x.offNext,cap:s.wk.h.cap,mor:x.morale};},o.own);
 assert(before.next===-1&&before.off!==-1,'改咗之後未即刻生效，等下星期一');
 const after=await p.evaluate(id=>{s.paused=false;var w0=s.wk.start,n=0;while(s.wk.start===w0&&n++<99999){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];}else advance(5);}var x=s.staff.filter(function(z){return z.id===id;})[0];
  var works=[0,1,2,3,4,5,6].every(function(k){return staffWorks(x,s.wk.start+k);});return {off:x.off,works:works,cap:s.wk.h.cap,mor:x.morale,P:s.S.P.ownerDays};},o.own);
 assert(after.off===-1&&after.works&&after.P===7,'下星期一起老闆 7 日都返 '+JSON.stringify(after));
 assert(after.cap>before.cap,'產能升咗（'+before.cap.toFixed(1)+' → '+after.cap.toFixed(1)+'）');
 assert.deepStrictEqual(errs,[]);console.log('跳過非營業時間同 7 日返工測試通過；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
