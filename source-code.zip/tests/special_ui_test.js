/* v0.20 特殊客介面：到店自動暫停、提示掣、視覺小說（逐字、揀答案、心情）、3D 結局造型、送出門後自己行出去（冇人拖住）。
   用法：THREE_JS=<本機 three.min.js r128> node tests/special_ui_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
 const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=solo]');await p.waitForTimeout(500);
 const want=w===1440?'good':'bad';
 const a=await p.evaluate(()=>{spNextId=function(){return 'chai';};/* 次序已打亂（v0.20.2），測試固定用 Cheems */s.modal=null;s.evQ=[];s.gd.off=1;var n=0,a=null;while(n++<400000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}
   a=s.wk.appts.filter(function(x){return x.special&&x.st==='doing';})[0];if(a)break;advance(1);}s.paused=false;renderHUD();return {id:a.id,pet:a.pet,sp:a.special};});
 await p.waitForTimeout(400);
 assert(await p.evaluate(()=>s.paused),'特殊客到：自動暫停');
 assert(/特殊客到/.test(await p.locator('#handsCue').innerText()),'提示掣變「特殊客到」');
 await p.click('#handsCue');await p.waitForTimeout(150);
 assert(await p.evaluate(()=>document.getElementById('hands').classList.contains('vn')&&W3.actors['p'+HANDS.a.id].userData.sp==='chai'),'打開視覺小說，枱上係柴哥原創造型');
 /* 逐字出現：未打完撳一下會即刻顯示全句 */
 const typing=await p.evaluate(()=>{var V=HANDS.vn;V.done=false;V.t0=performance.now();renderSpecial();var t=document.querySelector('#hands .vn-t');var a=t.textContent.length<t.getAttribute('data-full').length;document.querySelector('#hands .vn-box').click();var t2=document.querySelector('#hands .vn-t');return a&&V.done&&V.li===0&&t2.textContent===t2.getAttribute('data-full');});
 assert(typing,'對白逐字出現；未打完撳一下即刻顯示全句（唔會跳過）');
 assert(await p.evaluate(()=>{var pf=document.getElementById('spPortrait'),r=pf&&pf.getBoundingClientRect(),h=document.getElementById('hands').getBoundingClientRect();return pf&&!pf.hidden&&pf.querySelector('img').getAttribute('src')===SPIMG.cheems&&r.height>60&&r.bottom<=h.top+8&&r.left>=0;}),'對話時有 Cheems 2D 立繪，喺對話框上面');
 if(w===1440){await p.waitForTimeout(1500);await p.screenshot({path:path.join(out,'v20_intro.png')});}
 let shotQ=false,steps=0;
 while(steps++<80){const st=await p.evaluate(()=>HANDS.vn.phase+'|'+HANDS.vn.done);
  if(st.startsWith('card'))break;
  if(st==='q|true'){if(!shotQ&&w===1440){await p.screenshot({path:path.join(out,'v20_question.png')});shotQ=true;}
   await p.evaluate(want=>{var V=HANDS.vn,n=V.nodes[V.i],sc=n.x.o.map(function(o){return o[1];}),t=want==='good'?Math.max.apply(null,sc):Math.min.apply(null,sc),oi=sc.indexOf(t);document.querySelector('#hands [data-act=vnpick][data-o="'+oi+'"]').click();},want);}
  else await p.click('#hands .vn-box');
  await p.waitForTimeout(60);}
 const card=await p.locator('#hands .vn-card').innerText();
 assert(want==='good'?/Swole Doge 覺醒/.test(card):/\*BONK\*/.test(card),'結局卡：'+card.split('\n')[1]);
 const pimg=await p.evaluate(()=>{var pf=document.getElementById('spPortrait');return pf&&!pf.hidden&&pf.querySelector('img').getAttribute('src')===SPIMG[SPC.chai.end[HANDS.vn.end].img];});
 assert(pimg,'結局立繪換成結局圖（Swole Doge／Bonk）');
 const look=await p.evaluate(()=>{var P=W3.actors['p'+HANDS.a.id].userData.P;return {chest:P.chest.visible,bat:P.bat.visible};});
 assert(want==='good'?look.chest&&!look.bat:look.bat&&!look.chest,'3D 結局造型：'+JSON.stringify(look));
 await p.waitForTimeout(300);await p.screenshot({path:path.join(out,'v20_end_'+want+'.png')});
 const c0=await p.evaluate(()=>s.cash);
 await p.click('#hands [data-act=handsdone]');await p.waitForTimeout(300);
 const r=await p.evaluate(id=>{var a=s.wk.appts.filter(function(x){return x.id===id;})[0];return {end:a.spEnd,price:a.price,cash:s.cash,mode:document.getElementById('game').classList.contains('handsmode')};},a.id);
 assert(r.end===want&&!r.mode,'送佢出門：記低結局、返回正常畫面 '+JSON.stringify(r));
 assert(await p.evaluate(()=>{var pf=document.getElementById('spPortrait');return !pf||pf.hidden;}),'送走之後立繪收埋');
 if(want==='bad')assert(r.cash===c0-1800,'砸店損失 HK$1,800');else assert(r.price>=900,'小費加入收費');
 /* 自己行出門：冇人拖住，造型保持 */
 await p.evaluate(()=>{s.speed=10;s.paused=false;});let walk=null;
 for(let i=0;i<160&&!walk;i++){await p.waitForTimeout(250);walk=await p.evaluate(id=>{var q=W3.actors['q'+id],o=W3.actors['w'+id];if(!(q&&q.visible))return null;s.paused=true;var P=q.userData.P;CT.tx=q.position.x;CT.tz=q.position.z;CT.ty=q.position.y;CT.rad=5;camClamp(CT);return {person:!!(o&&o.visible),chest:P.chest.visible,bat:P.bat.visible};},a.id);}
 assert(walk&&!walk.person&&(want==='good'?walk.chest:walk.bat),'柴哥自己行出門口（冇人拖住），保持結局造型 '+JSON.stringify(walk));
 if(w===1440){await p.waitForTimeout(800);await p.screenshot({path:path.join(out,'v20_walkout.png')});}
 assert(!(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth)),'冇橫向溢出');
 assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'特殊客介面測試通過（'+want+'）；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
