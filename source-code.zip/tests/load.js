const fs=require('fs'),path=require('path'),vm=require('vm');
const order=fs.readFileSync(path.join(__dirname,'../src/ORDER'),'utf8').split(/\s+/).filter(f=>f.endsWith('.js'));
module.exports=function(skipUI){const ctx={console,Math,JSON,Date};vm.createContext(ctx);
 for(const f of order){if(skipUI&&/p_ui|p_tail|p_hud|p_panels|p_voxel|p_3d|p_street|p_shop3d|p_main|p_charts|p_real_ui|p_sound|p_demo|p_tex|p_cam|p_cafe|p_merge|p_title|p_guide/.test(f))continue;vm.runInContext(fs.readFileSync(path.join(__dirname,'../src',f),'utf8'),ctx,{filename:f});}return ctx;};
