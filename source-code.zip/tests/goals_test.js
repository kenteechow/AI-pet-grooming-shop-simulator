/* v0.17 每週挑戰、里程碑、等級、解鎖測試。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',2027);",E);
ok(E.s.gl&&E.s.gl.ch.length===2,'開局有 2 個本週挑戰：'+E.s.gl.ch.map(c=>E.CHAL[c.id].t(c)).join('、'));
let n=0,lvSeen=1;while(E.s.day<200&&n++<4e6){const s=E.s;if(s.day===10&&!s.lv.reply)E.deploy('reply',2);
 if(s.modal){if(s.modal.type==='event'){if(s.modal.id==='levelup')lvSeen=Math.max(lvSeen,s.modal.ctx.lv);E.chooseEvent(0);}else{s.modal=null;E.nextEvent();}}else E.advance(10);}
const g=E.s.gl;
ok(g.hist.length>=20,'每週結算挑戰（'+g.hist.length+' 個，完成 '+g.hist.filter(h=>h.done).length+' 個）');
ok(Object.keys(g.ms).length>=3,'達成里程碑：'+E.MILES.filter(m=>g.ms[m.id]!=null).map(m=>E.mileTitle(m)).join('、'));
const xp=(g.won||0)+Object.keys(g.ms).length*2;ok(g.xp===xp,'經驗＝完成挑戰 + 里程碑×2（'+g.xp+'）');
ok(g.lv===E.glLevel(g.xp)&&g.lv>=2,'等級跟經驗（第 '+g.lv+' 級「'+E.LEVELS[g.lv-1].n+'」）');ok(lvSeen===g.lv,'升級有彈窗');
/* 解鎖：網紅（現金、查詢加成、同一時間只得一個） */
g.lv=3;const c0=E.s.cash,ledN=(E.s.mled||[]).length;E.kolBuy('s');
ok(Math.abs(E.s.cash-(c0-2500))<1&&E.s.mods.some(m=>m.k==='inqMult'&&m.why==='網紅影片'),'小型 KOL：扣 HK$2,500，查詢加成');
ok(E.s.mled.slice(ledN).some(x=>x.cat==='mkt'),'網紅費用記入一次性收支（宣傳）');
const c1=E.s.cash;E.kolBuy('m');ok(E.s.cash===c1,'宣傳進行中唔可以再請第二個');
g.lv=1;g.kol=null;const c2=E.s.cash;E.kolBuy('m');ok(E.s.cash===c2,'等級未夠唔可以請');
g.lv=3;const t0=E.s.base.tables,c3=E.s.cash;E.addTable();ok(E.s.base.tables===Math.min(t0+1,E.tableMax())&&(E.s.base.tables===t0||Math.abs(E.s.cash-(c3-30000))<1),'加枱：'+t0+' → '+E.s.base.tables);
const a0=E.s.base.addonRate;E.addonToggle();ok(Math.abs(E.s.base.addonRate-a0-.1)<1e-9,'開加購：加購率 +10 個百分點');E.addonToggle();ok(Math.abs(E.s.base.addonRate-a0)<1e-9,'關加購：還原');
/* 固定種子可重現 */
function run(){const F=load(true);F.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('solo',55);",F);let k=0;while(F.s.day<120&&k++<3e6){const s=F.s;if(s.modal){if(s.modal.type==='event')F.chooseEvent(0);else{s.modal=null;F.nextEvent();}}else F.advance(7);}return JSON.stringify([F.s.gl.xp,F.s.gl.hist.map(h=>h.id+h.done)]);}
ok(run()===run(),'同一種子挑戰同經驗一樣');
console.log(fail?fail+' 項失敗':'挑戰同等級測試全部通過');process.exitCode=fail?1:0;
