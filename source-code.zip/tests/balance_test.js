/* 平衡測試（老店 smart 另外會喺 AI 覆客上線後裁前台、再裁一個助理，因為人手過多先係佢真正嘅問題）：每個開局玩一年，none（乜都唔做）同 smart（部署覆 L2、回 L2、排 L2，有審核）兩個策略。 */
const vm=require('vm');const load=require('./load.js');
/* v0.13：用固定種子，結果可以重現。`node tests/balance_test.js` 用種子 2027；`node tests/balance_test.js 11 22 33` 跑多個種子再平均。 */
const SEEDS=process.argv.slice(2).map(Number).filter(Boolean);if(!SEEDS.length)SEEDS.push(2027);
function play(op,strat,seed){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('"+op+"',"+seed+");",E);
 let n=0;while(E.s.day<364&&n++<3e6){const s=E.s;
  if(strat==='smart'){if(s.day===7&&!s.lv.reply)E.deploy('reply',2);if(s.day===14&&!s.lv.recall)E.deploy('recall',2);if(s.day===28&&!s.lv.sched)E.deploy('sched',2);
   if(op==='old'){const nm=s.day===42?'Mandy':s.day===56?'阿傑':null;if(nm&&!s['_f'+nm]){s['_f'+nm]=1;const x=s.staff.find(z=>z.name===nm);if(x)E.fire(x.id);}}}
  if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(10);}
 const s=E.s,prof=s.months.map(m=>m.profit),sh=s.months.map(m=>m.shProfit);
 return {op,strat,seed,cash:Math.round(s.cash),shCash:Math.round(s.shCash),minCash:Math.round(Math.min(...s.months.map(m=>m.cash))),avgProfit:Math.round(prof.reduce((a,b)=>a+b,0)/prof.length),shAvg:Math.round(sh.reduce((a,b)=>a+b,0)/sh.length),rating:+s.S.rating.toFixed(2),staff:s.staff.filter(x=>x.leaving!==-2).length,ev:Object.keys(s.evSeen).length};}
let bad=0;const avg={};for(const seed of SEEDS)for(const op of ['community','allai','solo','old'])for(const st of ['none','smart']){const r=play(op,st,seed);console.log(JSON.stringify(r));if(r.minCash<0&&!(op==='old'&&st==='none'))bad++;
 const k=op+'/'+st;avg[k]=avg[k]||{n:0,profit:0,sh:0,cash:0};avg[k].n++;avg[k].profit+=r.avgProfit;avg[k].sh+=r.shAvg;avg[k].cash+=r.cash;}
if(SEEDS.length>1){console.log('種子 '+SEEDS.join('、')+' 平均：');for(const k in avg){const a=avg[k];console.log(k.padEnd(16)+' 平均月利潤 '+Math.round(a.profit/a.n)+'　隔籬 '+Math.round(a.sh/a.n)+'　年尾現金 '+Math.round(a.cash/a.n));}}
console.log(bad?bad+' 個組合現金跌穿零':'除咗「老店乜都唔做」（設計上會結業），全部組合一年內現金都冇跌穿零');
