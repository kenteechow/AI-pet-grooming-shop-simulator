/* 引擎回歸測試：設計文件第 12 節嘅數同盲點規則。 */
const E=require('./load.js')(true);let fail=0;
function ok(c,msg){console.log((c?'PASS ':'FAIL ')+msg);if(!c)fail++;}
const B=E.clone(E.DEF_SHOP),F=E.clone(E.DEF_FOUNDER);
const base=E.shopSummary(E.runShop(E.lvZero(B)).months);
ok(base.done>180&&base.done<240,'基準店每月完成 '+base.done.toFixed(0)+' 次（180–240）');
ok(base.util>.75&&base.util<.9,'基準使用率 '+(base.util*100).toFixed(0)+'%');
ok(base.profit>15000&&base.profit<45000,'基準每月利潤 '+Math.round(base.profit));
const r1=E.runAll(E.clone(B),E.clone(F)),r2=E.runAll(E.clone(B),E.clone(F));
ok(r1.fr.sum.cash===r2.fr.sum.cash&&r1.aiS.profit===r2.aiS.profit,'期望值模式結果一致');
ok(r1.blind.filter(b=>b.on&&b.id!==3).length===0,'基準情境只可能觸發盲點 3（no-show 變取消）');
const q=E.qAnswers(E.clone(B),E.clone(F));ok(q.length===10,'10 條問題都有答案');
const p6=E.lvZero(B);p6.noShow=.06;const s6=E.shopSummary(E.runShop(p6).months);
ok(s6.profit-base.profit>3000&&s6.profit-base.profit<12000,'Q3 no-show 12%→6% 每月多 '+Math.round(s6.profit-base.profit));
const i1=E.lvZero(B);i1.seriousRate=1/200;ok(E.shopSummary(E.runShop(i1).months).rating<4,'Q7 1/200 嚴重事故令評分跌穿 4');
const want={full:1,aiWin:3,memFail:5,overload:6,serious:7,aiFail:9};
for(const [s,id] of Object.entries(want)){const P=E.clone(B),G=E.clone(F);E.applyScen(s,P,G);const R=E.runAll(P,G);ok(R.blind.some(b=>b.on&&b.id===id),'情境 '+s+' 觸發盲點 '+id);}
for(const m of ['A','B','C','D']){const G=E.clone(F);G.model=m;const R=E.runFounder(G,B);ok(isFinite(R.sum.cash)&&R.months.length===12,'模式 '+m+' 12 個月現金 '+Math.round(R.sum.cash));}
for(const s of E.SCEN){const P=E.clone(B),G=E.clone(F);E.applyScen(s.id,P,G);const R=E.runAll(P,G);ok(R.aiS.profit>0,'情境 '+s.name+' 店舖仍然有利潤 '+Math.round(R.aiS.profit));}
console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);
