/* 客人紀錄介面測試：客人 → 客人紀錄、篩選、叫美容師核對草稿、選中卡顯示紀錄；桌面同手機冇橫向溢出。
   用法：THREE_JS=<本機 three.min.js r128> node tests/client_ui_test.js [截圖資料夾] */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
const out=process.argv[2]||process.env.TEMP||'.';
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 for(const [w,h] of [[1440,900],[420,800]]){
  const p=await b.newPage({viewport:{width:w,height:h}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());
  if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
  await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));
  await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=community]');await p.waitForTimeout(500);
  /* 部署檔 L3、關人工審核，推 3 星期 */
  await p.evaluate(()=>{s.modal=null;s.evQ=[];deploy('file',3);s.review=0;s.paused=false;var n=0;while(s.day<22&&n++<300000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];}else advance(5);}
   while(s.t<720&&n++<300000){if(s.modal){s.modal=null;s.evQ=[];}else advance(5);}s.paused=true;openPanel('cust');PANEL.sub='rec';CLV.f='draft';renderPanel();});
  await p.waitForTimeout(300);
  let txt=await p.locator('#panel').innerText();
  assert(txt.includes('有紀錄嘅毛孩')&&txt.includes('未確認草稿'),'客人紀錄頁面');
  const nBtn=await p.locator('#panel [data-act=clrev]').count();assert(nBtn>0,'有可以核對嘅草稿');
  await p.screenshot({path:path.join(out,'client_rec_'+w+'.png')});
  const before=await p.evaluate(()=>clStats().draft);
  await p.locator('#panel [data-act=clrev]').first().click();await p.waitForTimeout(200);
  const after=await p.evaluate(()=>clStats().draft);assert(after===before-1,'核對後草稿少一份（'+before+'→'+after+'）');
  /* 今日到店 */
  await p.click('#panel [data-act=clf][data-f=today]');txt=await p.locator('#panel').innerText();assert(/今次|今日冇預約/.test(txt),'今日到店篩選');
  /* 選中卡 */
  const has=await p.evaluate(()=>{var a=todayAppts().filter(function(x){return x.pid;})[0];if(!a)return false;s.sel={type:'pet',id:a.id};renderSel();return document.querySelector('#selCard .sc-rec')!=null;});
  assert(has,'選中卡有紀錄');
  const ov=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert(!ov,'橫向溢出');
  await p.screenshot({path:path.join(out,'client_sel_'+w+'.png')});
  assert.deepStrictEqual(errs,[]);console.log(w+'x'+h,'客人紀錄介面通過；草稿',before,'→',after,'；errs []');await p.close();}
 await b.close();})().catch(e=>{console.error(e);process.exit(1);});
