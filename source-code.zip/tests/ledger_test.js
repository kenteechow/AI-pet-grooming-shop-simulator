/* 月結口徑測試（v0.13）：每個月 月初現金＋經營利潤−老闆底薪−還款−轉入小金庫±一次性收支＝月末現金；AI 建置費、注資、借貸、事件、事故、保險賠款都記入一次性收支；保險申索狀態。 */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
const E=load(true);E.localStorage={getItem(){return null},setItem(){}};vm.runInContext("newGame('community',4242);",E);
let n=0,did={};while(E.s.day<150&&n++<3e6){const s=E.s;
 if(s.day===3&&!did.dep){did.dep=1;E.deploy('reply',2);}
 if(s.day===40&&!did.inj){did.inj=1;E.injectFund(10000);}
 if(s.day===45&&!did.loan){did.loan=1;E.takeLoan('fin',20000);}
 if(s.modal){if(s.modal.type==='event')E.chooseEvent(0);else{s.modal=null;E.nextEvent();}}else E.advance(10);}
const s=E.s;
ok(s.months.length>=4,'玩咗 '+s.months.length+' 個月結');
let allOk=true;s.months.forEach(m=>{if(m.cash0==null)return;const exp=m.cash0+m.profit-m.ownerPay-m.loanPay-m.toFund+m.ledSum;if(Math.abs(exp-m.cash)>1){allOk=false;console.log(m.y+'/'+m.m,'預計',Math.round(exp),'實際',Math.round(m.cash));}});
ok(allOk,'每個月：月初現金＋經營利潤−底薪−還款−轉入小金庫±一次性收支＝月末現金');
const led=s.months.flatMap(m=>m.led||[]).concat(s.mled||[]);
ok(led.some(x=>x.cat==='setup'&&x.amt<0),'AI 建置費記入一次性收支');
ok(led.some(x=>x.cat==='inject'&&x.amt===10000),'由小金庫注資記入一次性收支');
ok(led.some(x=>x.cat==='loan'&&x.amt===20000),'借貸收入記入一次性收支');
ok(s.months.every(m=>m.ownerPay!=null&&m.ownerBase!=null),'每月記低老闆實際底薪同目標底薪');
ok(s.months.every(m=>Math.abs(m.profit-(m.rev-m.cost))<1),'經營利潤＝營收−經營支出（唔包老闆底薪同一次性收支）');
/* 保險：人工造一單嚴重事故，有保險 → 墊支＋審核中；推 7 週 → 有結果；冇保險 → 自己畀 */
const a={id:999001,pet:'測試狗',owner:'測試主人',inc:'serious',b:700,g:s.staff[0].id};
const c0=s.cash;E.incidentCost(a);const cl=s.claims[0];
ok(Math.abs(s.cash-(c0-12000))<1&&cl.st==='pending','有保險：先由店舖墊支 HK$12,000，申索審核中');
const d0=s.day;while(E.s.day<d0+50&&n++<4e6){const q=E.s;if(q.modal){if(q.modal.type==='event')E.chooseEvent(0);else{q.modal=null;E.nextEvent();}}else E.advance(10);}
ok(['paid','partial','rejected'].includes(cl.st),'審核完成：'+cl.st+'，賠 '+cl.paid);
const insLed=s.months.flatMap(m=>m.led||[]).concat(s.mled||[]).filter(x=>x.cat==='ins'&&/測試狗/.test(x.why));
ok(cl.st==='rejected'?insLed.length===0:insLed.length===1&&Math.abs(insLed[0].amt-cl.paid)<1,'保險賠款只入帳一次');
s.ins.pl=0;const c1=s.cash;E.incidentCost(Object.assign({},a,{id:999002,pet:'冇保險狗'}));
ok(s.claims[0].st==='noins'&&Math.abs(s.cash-(c1-12000))<1,'冇保險：全數自己畀，冇申索');
s.ins.pl=1;E.incidentCost(Object.assign({},a,{id:999003,pet:'小傷狗',inc:'minor'}));ok(s.claims[0].st==='under','低過墊底費嘅小事故唔申索');
console.log(fail?fail+' 項失敗':'月結口徑測試全部通過');process.exitCode=fail?1:0;
