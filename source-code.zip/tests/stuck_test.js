/* v0.15.2 測試：時間唔會因為浮點誤差卡喺 23:59 或者某一分鐘。用法：THREE_JS=<本機 three.min.js r128> node tests/stuck_test.js */
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const assert=require('assert');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});const p=await b.newPage({viewport:{width:900,height:600}}),errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route(/fonts\.(googleapis|gstatic)/,r=>r.abort());if(process.env.THREE_JS)await p.route(/three\.min\.js/,r=>r.fulfill({body:fs.readFileSync(process.env.THREE_JS),contentType:'application/javascript'}));
 await p.goto('file://'+path.resolve(__dirname,'../dist/standalone.html'));await p.click('#title [data-act=openings]');await p.click('#title [data-act=start][data-id=solo]');await p.waitForTimeout(500);
 for(const [label,t0,skip] of [['23:59 自動跳過',1440-1e-9,1],['23:59 唔跳',1440-1e-9,0],['白天某分鐘',660-1e-10,1],['朝早跳過尾段',570-1e-9,1]]){
  const d0=await p.evaluate(([t0,skip])=>{s.modal=null;s.evQ=[];OPTS.skip=skip;todayAppts().forEach(function(a){if(a.st!=='gone'&&a.st!=='booked')a.st='gone';});s.t=t0;s.speed=1;s.paused=false;return {day:s.day,t:s.t};},[t0,skip]);
  await p.waitForTimeout(1500);
  const d1=await p.evaluate(()=>{if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;}return {day:s.day,t:s.t};});
  assert(d1.day!==d0.day||d1.t>d0.t+.5,label+'：時間有行 '+JSON.stringify([d0,d1]));console.log('通過：'+label);}
 assert.deepStrictEqual(errs,[]);console.log('時間卡住測試通過；errs []');await b.close();})().catch(e=>{console.error(e);process.exit(1);});
