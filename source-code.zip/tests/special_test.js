/* v0.20 特殊客：出現規則、對話結局、評價、小費同損失、冇接待嘅後果、選項字數。
   用法：node tests/special_test.js */
const vm=require('vm');const load=require('./load.js');
let fail=0;function ok(c,m){if(!c){fail++;console.log('失敗：'+m);}else console.log('通過：'+m);}
const run=(E,code)=>vm.runInContext(code,E);
function game(seed){const E=load(true);E.localStorage={getItem(){return null},setItem(){}};run(E,"newGame('community',"+seed+");");return E;}
const adv=(E,days)=>run(E,"(function(){var end=s.day+"+days+";var n=0;while(s.day<end&&n++<400000){if(s.modal){if(s.modal.type==='event')chooseEvent(0);else s.modal=null;s.evQ=[];continue;}advance(5);}})()");
const E=game(21);adv(E,1);
let sp=E.s.wk.appts.filter(a=>a.special);
ok(sp.length===1&&E.SPC[sp[0].special]&&sp[0].special===E.spRound(0)[0]&&sp[0].g===E.handsOwner().id,'第一個星期一定有一位特殊客（按打亂次序第一位），指定店長 '+JSON.stringify(sp.map(a=>[a.pet,a.day,E.hm(a.a)])));
const f0=sp[0],busy0=E.dayBusy(f0.day)[f0.g].filter(x=>x[2]!==f0.id);ok(!busy0.some(x=>x[0]<f0.b&&x[1]>f0.a),'特殊客時段唔撞其他預約');
/* 次序打亂：唔同種子第一位唔同；每輪七位齊、唔重複；輪與輪之間唔會連續同一位 */
const firsts=new Set();for(let sd=1;sd<=12;sd++){E.s.seed=sd;firsts.add(E.spRound(0)[0]);}E.s.seed=21;
ok(firsts.size>=4,'唔同遊戲，第一位特殊客唔同（12 個種子有 '+firsts.size+' 種）');
const NL=E.SP_ORDER.length;let rOK=true;for(let r=0;r<6;r++){const R0=E.spRound(r);if(new Set(R0).size!==NL)rOK=false;if(r>0&&E.spRound(r-1)[NL-1]===R0[0])rOK=false;}ok(rOK,'每輪 '+NL+' 位齊、唔會連續兩次同一位');
const a0=E.spSpawn('chai',[E.s.day,1000]);
/* 選項 */
let bad=[];for(const id in E.SPC){const C=E.SPC[id];[...C.g,...C.q].forEach(x=>{const L=x.o.map(o=>o[0].length),best=Math.max(...x.o.map(o=>o[1]));if(x.o.length!==3||x.o.filter(o=>o[1]===best).length!==1||best<=0||Math.max(...L)-Math.min(...L)>5||x.o.some(o=>!o[2]))bad.push(id+'：'+x.q);});['good','normal','bad'].forEach(k=>{if(!C.end[k]||!C.end[k].lines.length)bad.push(id+' 冇結局 '+k);});}
ok(!bad.length,'每題三個答案、得一個最好、字數相近、有回應；每個角色三個結局 '+bad.join('、'));
/* 結局 */
const best=a=>E.spNodes(a).filter(n=>n.t==='ask').map(n=>n.x.o.findIndex(o=>o[1]===Math.max(...n.x.o.map(z=>z[1])))),worst=a=>E.spNodes(a).filter(n=>n.t==='ask').map(n=>n.x.o.findIndex(o=>o[1]===Math.min(...n.x.o.map(z=>z[1]))));
ok(E.spRun(a0,best(a0)).end==='good'&&E.spRun(a0,worst(a0)).end==='bad','全部答得好：好結局；全部答得差：壞結局');
const mix=best(a0).slice();mix[1]=worst(a0)[1];mix[2]=worst(a0)[2];ok(E.spRun(a0,mix).end==='normal','答錯兩題：普通結局（心情 '+E.spRun(a0,mix).mood+'）');
ok(E.spRun(a0,best(a0).map((x,i)=>i===2?worst(a0)[2]:x)).end==='good','答錯一題都仲可以有好結局');
/* 問題每次唔同 */
const qs=new Set();for(let i=0;i<10;i++)qs.add(E.spPicks({special:'chai',id:5000+i}).map(x=>x.q).join('|'));ok(qs.size>=4,'每次嚟問嘅問題組合唔同（10 次有 '+qs.size+' 種）');
/* 好結局：小費、五星、口碑升 */
const p0=a0.price,r0=E.s.S.rating;E.spApply(a0,'good');ok(a0.price===p0+300&&a0.handsStars===5&&a0.spLook==='buff'&&a0.handsDone===1,'柴哥好結局：肌肉造型、小費 HK$300、五星');
E.onDone(a0);ok(E.s.fb[0].stars===5&&/肌肉/.test(E.s.fb[0].txt)&&E.s.S.rating>r0,'評價用角色自己嘅說話，口碑升：'+E.s.fb[0].txt);
ok(E.s.sp.seen.chai.n===1&&E.s.sp.seen.chai.ends.good===1,'圖鑑記低見過同結局');
/* 壞結局：損失 */
const b=E.spSpawn('chai',[E.s.day,1000]);const c0=E.s.cash;E.spApply(b,'bad');ok(E.s.cash===c0-1800&&E.s.mled.some(x=>/棒球棍/.test(x.why))&&b.spLook==='bat','柴哥壞結局：棒球棍砸店，損失 HK$1,800 記入一次性收支');
const r1=E.s.S.rating;E.onDone(b);ok(E.s.fb[0].stars===1&&E.s.S.rating<r1,'壞結局一星，口碑跌');
/* OIIA 貓（v0.21.1）：轉圈幀同聲 */
ok(E.SPC.oiia&&E.SPC.oiia.spin.length>=12&&E.SPC.oiia.spin.every(k=>E.SPIMG[k])&&E.SPIMG.oiia_stand&&/^data:audio\/mpeg/.test(E.SPSND.oiia),'OIIA 貓有企定圖、'+E.SPC.oiia.spin.length+' 幀轉圈同聲');
/* 冇接待 */
const c=E.spSpawn('mimi',[E.s.day,1000]);E.onDone(c);ok(c.spEnd==='snub'&&E.s.fb[0].stars===2&&/店長都冇出現/.test(E.s.fb[0].txt),'冇店長親自接待：黑面走，兩星');
/* 之後嘅星期大約一半有 */
const G=game(21);adv(G,70);const wks=Object.keys(G.s.sp.wk).length,got=Object.values(G.s.sp.wk).filter(x=>x).length;
ok(wks>=10&&got>=3&&got<=wks,'十個星期：'+got+'／'+wks+' 個星期有特殊客');
const ids=G.s.wk.appts.concat([]).filter(a=>a.special).map(a=>a.special);
/* 固定 */
const H=game(21);adv(H,70);ok(JSON.stringify(H.s.sp.wk)===JSON.stringify(G.s.sp.wk),'同一個種子，特殊客出現時間一樣');
const seq=G.spRound(0).concat(G.spRound(1)).slice(0,got);ok(seq.every(id=>G.s.sp.seen[id])&&Object.keys(G.s.sp.seen).length===new Set(seq).size,'按打亂咗嘅次序嚟，冇接待都記入圖鑑 '+seq.join('、'));
console.log(fail?fail+' 項失敗':'特殊客測試全部通過');process.exitCode=fail?1:0;
