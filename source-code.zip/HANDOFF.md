# HANDOFF：俾接手嘅 AI（或者人）睇

呢份係「AI 重構寵物美容」嘅完整交接。淨係睇呢一份就可以開始改嘢；細節再睇 `docs/`。
版本：**v0.22.1**（2026-11-13）。作者：TO（hoslab），用嚟拍片講 AI 點樣重構香港中小企。

---

## 1. 呢個係乜

一個單一 HTML 網頁，入面有兩樣嘢：

1. **3D 經營遊戲**：你係觀塘一間樓上舖寵物美容店老闆。完整一日 120 秒（00:00–24:00；新局由 09:00 開始）。每星期按客源排預約，客人拖狗上嚟、美容師剪、收錢。你可以將 6 個「崗位」（覆客、排程、數、回頭客、檔案、社媒）逐個交俾 AI（L1／L2／L3）。同一條街有一間唔用 AI 嘅「隔籬」做對照。有事件（新年爆滿、八號風球、美容師被咬……），有創辦人層（將 AI 方案賣俾同行）。
2. **沙盒模擬器**：唔玩遊戲，直接郁參數睇 12 個月現金、敏感度、蒙地卡羅、四種商業模式。

技術：純 JS（ES5 風格、全域變數），three.js r128（cdnjs），冇 framework，冇 npm 依賴（測試用 Node＋Playwright）。

---

## 2. 用戶嘅固定要求（一定要守）

- **語言**：香港粵語書面語、繁體字。介面唔用 emoji；崗位用印章字（覆、排、數、回、檔、影）。
- **現實感第一**：數字要合香港規模（租金、人工、價錢）；唔確定就寫「示範估算」；外國 benchmark 唔等於香港。
- **AI 要講真話**：寫明工具名、費用、部署週數、邊度要人把關、限制（磨合期、冇審核會出錯、資料唔齊）。唔好將 AI 寫成萬能。
- 唔做「hoslab 創辦人線」開局；創辦人層用 2D；唔計創辦人由台灣遙距支援嘅機票同時間成本。
- 風格：可愛方塊（chibi voxel）人物同場景；UI 深色玻璃圓角卡、膠囊掣，圓潤可愛。鏡頭參考 Cities: Skylines 2。
- 音效：`audio/click.mp3` 按鍵、`audio/exit.mp3` 關閉／返回、`audio/hk1.mp3`＋`hk2.mp3` 背景音樂輪流循環。
- **每次改完都要測試**；每個版本寫 CHANGELOG，**引用用戶原話**。
- 用戶話過「一路向下推，唔使經我同意」：技術細節可以自己決定。
- 規範來源：skill `ai-industry-sim-game`（如果你有）。

---

## 3. 快速開始

```bash
python3 build.py                 # src/ → dist/index.html（Artifact 用，冇 doctype）＋ dist/standalone.html ＋ dist/audio/
# 本機試玩：直接用瀏覽器開 dist/standalone.html（要連 dist/audio/ 一齊，音效先有聲）
```

部署：
- **Claude Artifact**：發佈 `dist/index.html`；第一次要連 `files` 上載音檔：`{"audio/click.mp3":"dist/audio/click.mp3","audio/exit.mp3":"dist/audio/exit.mp3","audio/hk1.mp3":"dist/audio/hk1.mp3","audio/hk2.mp3":"dist/audio/hk2.mp3"}`，之後更新可以唔再傳（會保留）。
- **GitHub Pages／任何靜態網站**：上載 `dist/standalone.html`（改名 `index.html`）同 `dist/audio/`。

---

## 4. 測試（改完一定要跑）

| 指令 | 測咩 | 應該見到 |
|---|---|---|
| `node tests/engine_test.js` | 引擎數學（29 項） | `全部通過` |
| `node tests/smoke_test.js` | 沙盒 UI（Playwright） | `errs []` |
| `node tests/game_smoke.js` | 遊戲由標題玩到示範模式 | `errs []` |
| `node tests/balance_test.js [種子…]` | 4 開局 × 2 策略玩一年（預設種子 2027；傳多個種子會取平均） | `除咗「老店乜都唔做」……都冇跌穿零` |
| `THREE_JS=<three.min.js r128> node tests/walk_test.js` | 客人步速同面向 | `行路測試通過` |
| `node tests/client_record_test.js` | 持續紀錄：穩定 ID、同名、只計完成、對日結、草稿核對、存檔、舊存檔遷移 | `客人紀錄測試全部通過` |
| `node tests/task_test.js` | 事件時間成本：排入空檔、唔撞預約、做完先生效、冇空檔三個選擇 | `事件時間成本測試全部通過` |
| `node tests/ledger_test.js` | 月結對數、一次性收支、保險申索 | `月結口徑測試全部通過` |
| `node tests/consent_test.js` | 推廣同意、撤回、社媒相片同意、報告卡唔用未確認草稿 | `同意同報告卡測試全部通過` |
| `node tests/seed_test.js` | 固定種子＋唔同推進步長結果一樣 | `固定隨機測試全部通過` |
| `THREE_JS=… node tests/v013_ui_test.js <截圖資料夾>` | 一按升級、第一週目標、月結明細、保險表、取消客人打電話、手機 | `errs []` |
| `node tests/goals_test.js` | 每週挑戰、里程碑、經驗、等級、網紅、加枱、加購 | `挑戰同等級測試全部通過` |
| `node tests/hands_logic_test.js` | 難度、選項字數、計時判定、滿意度同星數、加做門檻、評價影響口碑 | `落手做邏輯測試全部通過` |
| `THREE_JS=… node tests/exp_story_test.js <截圖資料夾>` | AI 面板對客人效果同實際變化、客人體驗、真實毛孩故事 | `AI 效果、體驗、毛孩故事測試通過` |
| `THREE_JS=… node tests/log_test.js <截圖資料夾>` | 日誌：底下只出重要通知、日誌掣未睇數、按日分組、篩選 | `日誌測試通過` |
| `THREE_JS=… node tests/oiia_test.js <截圖資料夾>` | OIIA 貓轉圈同聲、Happy 貓跳、委屈貓圖 | `OIIA 貓、Happy 貓、委屈貓測試通過` |
| `THREE_JS=… node tests/table_test.js <截圖資料夾>` | 落手做／特殊客時毛孩一定喺美容枱（有助手嘅店都係） | `美容枱測試通過` |
| `node tests/special_test.js` | 特殊客出現規則、結局、評價、小費、損失、冇接待、選項字數 | `特殊客測試全部通過` |
| `THREE_JS=… node tests/special_ui_test.js <截圖資料夾>` | 特殊客：自動暫停、視覺小說、結局造型、自己行出門 | `特殊客介面測試通過` |
| `node tests/hands_var_test.js` | 題目按品種、毛孩特點、主人交代變化；主人要求計雙倍；親手做啱寫入檔案 | `情況題目測試全部通過` |
| `THREE_JS=… node tests/hands_lock_test.js` | 落手做期間時間鎖死、預約唔喺度自動收面板 | `落手做鎖時間測試通過` |
| `THREE_JS=… node tests/hands_test.js <截圖資料夾>` | 落手做：提示、近鏡、全啱避免事故、揀錯變皮膚問題 | `落手做測試通過` |
| `node tests/autofill_test.js` | 自動補候補：有補、唔撞、對數、電話時間、可關、可重現 | `自動補候補測試全部通過` |
| `THREE_JS=… node tests/stuck_test.js` | 時間唔會卡喺 23:59／某一分鐘 | `時間卡住測試通過` |
| `THREE_JS=… node tests/roof_test.js` | 大廈天台係純灰色 | `天台測試通過` |
| `THREE_JS=… node tests/demo_speed_test.js` | 示範快進調速、客人一路行唔卡住 | `示範模式調速同快進行路測試通過` |
| `THREE_JS=… node tests/profile_test.js <截圖資料夾>` | 客人檔案、搜尋、服務紀錄、評分 | `客人檔案測試通過` |
| `THREE_JS=… node tests/skip_week_test.js` | 自動跳過非營業時間、手動跳、7 日返工 | `跳過非營業時間同 7 日返工測試通過；errs []` |
| `THREE_JS=… node tests/client_ui_test.js <截圖資料夾>` | 客人紀錄頁面、核對掣、選中卡、桌面同手機 | `errs []` |
| `THREE_JS=<three.min.js r128> node tests/shots3d.js shots` | 3D 截圖（標題、日夜、落雨、茶餐廳、4 個尺寸） | 睇 `shots/g_*.png` |
| `node tests/shots.js shots` | 沙盒截圖 | 睇 `shots/*.png` |

3D 測試要本機 three.js（測試環境唔可以上 cdnjs）：`npm pack three@0.128.0 && tar xf three-0.128.0.tgz`，然後 `THREE_JS=$PWD/package/build/three.min.js`。
Playwright 用 `--use-gl=swiftshader`，大約 10 fps，所以測試入面嘅時間會慢過真機。
`balance_test` 有隨機事件，每次數字唔同（見第 9 節）。

---

## 5. 檔案結構

```
build.py            合併 src/ → dist/
src/ORDER           JS 合併次序（全部係全域；後面同名 function 會蓋前面）
src/shell.html      HTML 骨架（#title #openings #game #sb）
src/p_*.css         樣式（新樣式加喺 p_new.css 尾）
src/p_*.js          模組（見第 6 節）
src/audio/          4 個 mp3
tests/              測試（load.js 喺 Node vm 入面載入非 DOM 模組）
docs/               CHANGELOG、FEATURES、KNOWN_ISSUES、BALANCE_AND_TESTING、ARCHITECTURE、GAME_DATA
game-design-v1.md   設計文件（v1.1，用戶已確認）
START_HERE.md       簡短入口；AI_HANDOFF.md 規則清單（同本文件第 8 節一樣）
```

---

## 6. 系統 → 檔案 → function

| 系統 | 檔案 | function |
|---|---|---|
| 常數、分群、AI 崗位、預設參數、來源 | `src/p_consts.js` | `SEGS` `DORM` `ROLES` `DEF_SHOP` `DEF_FOUNDER` `SOURCES` |
| 店層每週模擬 | `src/p_engine.js` | `newShop` `shopStep` `runShop` `toMonths` `shopSummary` `ownerLTV` `rv` `rampEff` |
| 創辦人層四模式 | `src/p_founder.js` | `runFounder` `founderSummary` `archParams` `churnFor` |
| 情境、盲點、停損線、敏感度、蒙地卡羅、四模式、10 條問題 | `src/p_analysis.js` | `SCEN` `runAll` `blindspots` `failChecks` `sensitivity` `mcRun` `compareModels` `qAnswers` |
| 圖表 | `src/p_charts.js` | `chart` `drawCharts` `drawLine` `drawTornado` |
| 介面 | `src/p_ui.js` | `PG`（參數定義）`renderAll` `renderMain` `page*` `lazy` |
| 工作流（觸發→AI→系統→人工→輸出、步驟） | `src/p_depts.js` | `FLOWS`（掛去 `ROLES[].L[].flow/steps`） |
| 遊戲狀態、開局、預約、收工、月結、員工、存檔 | `src/p_game.js` | `newGame` `syncP` `planWeek` `scheduleWeek` `scheduleDay` `advance` `endOfDay` `weekEnd` `monthEnd` `hire` `fire` `deploy` `genAiDay` `save` `load` |
| 事件 | `src/p_events.js` | `EVENTS` `EV_RANDOM` `dayEvents` `queueEvent` `chooseEvent` |
| 3D 核心（日夜、雨、半透明、點擊、標籤、陰影） | `src/p_3d.js` | `init3D` `update3D` `pick3D` `updateFade` `updateLabels` |
| 鏡頭 | `src/p_cam.js` | `CAM` `CT` `camUpdate` `camPan` `camRot` `camZoom` `camJump` `camFly` `camControls` |
| 地下茶餐廳 | `src/p_cafe.js` | `buildCafe` `updateCafe` `cafeBusy` |
| 初始界面 | `src/p_title.js` | `showTitle` `startBg` `renderTitle` `OPTS` `TV`（main／new／help／opts）|
| 靜態合併 | `src/p_merge.js` | `mergeStatic` |
| 程式生成貼圖 | `src/p_tex.js` | `paverCanvas` `asphaltCanvas` `floorCanvas` `facadeCanvas` `roadText` `flatTex` `decal` |
| 體素模型 | `src/p_voxel.js` | `vb` `makePerson` `makePet` `makeCar` `sign` |
| 街景、交通 | `src/p_street.js` | `buildCity` `building` `buildTraffic` `updateTraffic` |
| 店舖 3D、人同寵物跟排程 | `src/p_shop3d.js` | `SHOP` `buildShop` `syncShop` `moveTo` `actor` |
| 行路（步速、轉身、腳步、客人一程路） | `src/p_walk.js` | `WALK` `walkV` `staffV` `turnTo` `stride` `custPath` `custTrip` `pathAt` |
| HUD、彈窗、選中卡 | `src/p_hud.js` | `renderHUD` `renderModal` `renderSel` `staffHours` |
| 面板 | `src/p_panels.js` | `openPanel` `renderPanel` `pSched` `pCust` `pStaff` `pAI` `pFin` `pShadow` `pRep` |
| 真實營運：老闆底薪、小金庫、貸款、保險、直銷同意、現金危機、手動排程 | `src/p_real.js` | `injectFund` `takeLoan` `askConsent` `moveAppt` `swapAppt` `addFromBacklog` `canPlace` `movable` |
| 持續主人同毛孩紀錄、觀察、草稿核對、紀錄頁面 | `src/p_clients.js` | `clAssign` `clMark` `clObserve` `clArrive` `clReview` `clMigrate` `clStats` `clKind` `pRec` |
| 月結口徑、一次性收支、保險申索 | `src/p_ledger.js` | `oneOff` `monthStmt` `monthSoFar` `ledSoFar` `incidentCost` `claimsHTML` `CLAIM` `INC_COST` |
| 跳過非營業時間、休息日、7 日返工 | `src/p_week.js` | `SKIP` `skipOn` `skipWin` `skipCap` `skipHTML` `offSel` `offLabel`；自動補候補 `autoFill` `AUTOFILL` |
| 客人檔案、搜尋 | `src/p_clients.js` | `profileHTML` `clSearch` `clListHTML` `clOwnerStats` `clFb` `clReqs` `stars`；`CLV.pid`／`CLV.q` |
| 每週挑戰、里程碑、等級、解鎖（網紅、加購、加枱、寄賣） | `src/p_goals.js` | `CHAL` `MILES` `LEVELS` `glPickWeek` `glWeekEnd` `glCheckMiles` `glAddXP` `kolBuy` `addonToggle` `addTable` `retailToggle` `pGrow` `renderGoalCard` |
| 落手做（第一身近鏡、步驟選擇） | `src/p_hands.js` | `HSTEP`（`o` 簡單選項、`oh` 中難選項、`tm` 計時最低難度、`tw` 計時提示同失手後果）`HPLAN` `HDIFF` `HTIME` `handsDiff` `handsOpts` `handsTimed` `handsZone` `handsResult` `handsApply` `handsAnim` `HADD`；v0.19 情況題目：`HVAR` `HCAT`（貓）`HREQ` `HTAG` `HSWAP` `handsTags` `handsReq` `handsBuild` `hQ` |
| 特殊客（視覺小說） | `src/p_special.js`、`src/p_spimg.js`（立繪，由 `tools/make_spimg.py` 生成） | `SPIMG` `SPSND` `spPortrait` `spSpinning` `spSound` `spRound` `SPC` `SP_ORDER` `spWeek` `spSpawn` `spInvite` `spNodes` `spRun` `spApply` `spSnub` `spModel` `spLook` `renderSpecial` |
| 日誌（通知紀錄） | `src/p_log.js` | `LOG_IMP` `LOG_GRP` `pLog` `logUnread`；右下「日誌」掣 `#btnLog` |
| AI 對客人效果、客人體驗、毛孩故事 | `src/p_exp.js`（UI）、`src/p_engine.js`（`EXP` `expCalc`） | `effVal` `aiEffLine` `aiEffDetail` `aiActual` `pExp` `petStoryReal` `storyHTML` |
| 第一週目標 | `src/p_guide.js` | `GUIDE` `guideTick` `renderGuide`（包住 `renderHUD`） |
| 事件時間成本變成排程時段 | `src/p_tasks.js` | `TASK_FX` `planTask` `taskFit` `freeGaps` `taskTick` `taskMinWeek`；事件 `taskShort` |
| 營運面板、拖放、參觀隔籬 | `src/p_real_ui.js` | `pOwner` `pLoan` `pIns` `overHTML` `shopView` `renderVisitHUD` |
| 創辦人層（遊戲內） | `src/p_fgame.js` | `startFounder` `pFd` `fdKnobs`；引擎係 `founderInit` `founderStep`（`p_founder.js`） |
| 音效同音樂（音檔＋合成月結聲） | `src/p_sound.js` | `SND` `sfx` `sndClick` `sndClose` `sndChime` `musicPlay` `musicSet` |
| 示範模式 | `src/p_demo.js` | `DEMO` `startDemo` `ff` `ffMonth` `renderDemo` |
| 主循環、快捷鍵、遊戲點擊 | `src/p_main.js` | `startGame` `startLoop` `loop` |
| 沙盒事件、啟動 | `src/p_tail.js` | document click／change／input handler |

---

## 7. 架構重點

**時間**：`loop()`（`p_main.js`）每幀 `dt`（真實秒，上限 0.1）× 12 × `s.speed` 遊戲分鐘，用 `advance(≤5)` 一步步推。`s.t` 係當日分鐘（540 = 09:00）。午夜日結 `endOfDay`、每星期一 `weekEnd`→`planWeek`、每月 1 號 `monthEnd`。功能用 `HOOKS.init/sync/plan/day/week/month` 掛，唔好改 `endOfDay` 次序。

**錢點計**：引擎 `shopStep`（`p_engine.js`，按週、期望值）計客源同 no-show 等比率 → 遊戲用 `planWeek`／`mkAppt` 拆成一張張預約 → 預約完成先入數。隔籬係同一個引擎、唔用 AI、做唔切就請人。

**3D**：`init3D` 起場景（`p_3d.js`）→ `buildCity`（街景）→ `buildShop`（1 樓美容店，入面 `buildCafe` 起地下茶餐廳）→ `mergeStatic` 將共用材質嘅靜態方塊合併（717 個 mesh → 43 個）。每幀 `update3D`：日夜、天幕、落雨、交通、`syncShop`（人同寵物跟排程）、`updateLabels`（HTML 標籤，每 2 幀）。

**人物**：`actor(key,mk)` 每幀「登記」一個角色，冇登記嘅會收埋，`/^v?[poqw]/` 開頭嘅閒置 600 幀會刪。key：`p` 店內寵物、`s` 員工、`w` 客人、`q` 客人拖住嘅寵物、`o` 參觀隔籬時嘅客人、`v` 前綴 = 隔籬。行路全部經 `p_walk.js`（`custTrip` 客人一程路狀態機、`stride` 腳步、`turnTo` 轉身）。

**鏡頭**（`p_cam.js`）：`CT` 係目標、`CAM` 每幀追上；`camJump` 即時、`camFly` 飛過去。

**初始界面**（`p_title.js`）：背景係一局 `s.bg=1` 嘅全 AI 店（3× 速、唔存檔、事件自動揀、HUD 收埋）。

**存檔**：localStorage `petgroom_save_v3`；選項 `petgroom_opts`；聲音 `petgroom_snd2`。

---

## 8. 規則同陷阱

1. 改完一定跑：`python3 build.py`、`node tests/engine_test.js`、`node tests/smoke_test.js`、`node tests/game_smoke.js`（兩個都要印 `errs []`）、改數值就 `node tests/balance_test.js`、改 UI 就 `node tests/shots.js shots` 同 `THREE_JS=<本機 three.min.js r128> node tests/shots3d.js shots`。
2. 全部係全域變數，按 `src/ORDER` 合併。後載入嘅同名 function 會蓋前面。
3. 壓縮一行嘅 code 唔好插 `//`，用 `/* */`。
4. 唔好用全域 function 名做區域變數（例如 `pct` `hk` `sum` `chart`）。
5. `det:true`（預設）用期望值，結果可重複；蒙地卡羅用 `det:false`＋seed。
6. 每月 = 52/12 週，`toMonths` 按比例分部分週。
7. 創辦人層嘅店家流失唔係輸入：由客戶店雙胞胎（用 AI／唔用 AI）計「價值倍數」再插值 `churnByMult`。
8. 新樣式加喺 `src/p_new.css` 尾。
9. Artifact 唔准 alert／confirm／prompt；外部只可以用 Google Fonts。
10. 遊戲用引擎嘅週結果（`shopStep`）拆成一張張預約（`planWeek`），錢用每張預約計；引擎自己嘅離職／請人喺遊戲關咗（`P.quitRate=0`），由 `weekEnd` 用員工士氣處理。
11. 部署 AI 時要寫 `s.S.setupDone[id+lv]=1`，唔係引擎會再扣一次建置費。
12. 截圖或者測試要推時間用 `advance()`，唔好直接改 `s.t`（狀態唔會更新）；`advance` 喺 `s.paused` 或者有彈窗時唔會郁。
13. SHOP 座標係世界座標；`buildShop` 入面棟樓 group 喺 z −5，所以 local z = 世界 z + 5。
14. 遊戲模組用 `HOOKS`（init、sync、plan、day、week、month）加功能，唔好改 `endOfDay` 入面嘅次序。
15. 面板每秒重畫一次，但滑鼠喺面板上面或者拖緊預約時唔會重畫（`PANEL.hover`、`DRAG`）。
16. `renderPanel` 要喺砌 HTML 之前清 `CH`，唔係圖表會空白。
17. 創辦人層：`founderStep(st,extraH)` 每次月結推一個月；副業淨現金入小金庫；超過每月 40 小時嘅副業時數會變成老闆行政時間（`P.extraAdminH`）。
18. 存檔 key `petgroom_save_v3`；讀檔要重建所有 `ctx.r`（包括創辦人客戶店）。
19. 音檔放 `src/audio/`，頁面用相對路徑 `audio/xxx.mp3`。發佈 Artifact 要傳 `files`：`{"audio/click.mp3":"dist/audio/click.mp3",...}`；GitHub Pages 要連 `dist/audio/` 一齊上。
20. 用戶提供嘅音檔要喺公開前確認授權（決定ボタンを押す7、mobile_phone_C 似係免費音效網站；www 兩首來源未知）。
21. 3D 標籤：`W3.tags`（`p_shop3d.js` 嘅 `tag()`），每幀由 `updateLabels` 投影。
22. 鏡頭：改位置要改 `CT`（目標），`CAM` 會自己追；即時跳用 `camJump`。唔好再喺 keydown 直接郁鏡頭（`KEYS` 每幀處理）。
23. `mergeStatic` 喺 `init3D` 尾執行：之後唔好再郁、改色或者隱藏用共用材質（`vmat`）嘅靜態方塊；要郁嘅嘢用 `{own:1}` 或者加入 skip。
24. 1 樓嘅嘢喺 `W3.f1`；地下茶餐廳直接喺 `W3.shop`；簷篷招牌喺 `W3.cafeFront`。
25. 初始界面背景係一局真遊戲（`s.bg=1`）：唔存檔、唔播月結聲、HUD 唔畫、事件自動揀第一個。加新 HOOK 或者存檔邏輯要記得跳過 `s.bg`。`startGame` 會清走背景局再開新局。
26. 標籤避讓喺 `updateLabels`：由下而上排，撞到就上移 25px（最多 6 次）。新增標籤唔使自己計位。
27. 平衡測試嘅老店 smart 會裁 Mandy（前台）同阿傑；改老店員工名要一齊改 `tests/balance_test.js`。
28. 人物行路一律經 `p_walk.js`：郁位置之後 call `stride(obj,今幀行咗幾遠,dt)` 擺腳，用 `turnTo(obj,角度,dt)` 轉身。唔好再用固定頻率 `Math.sin(W3.t*9)` 擺腳，亦唔好直接 set `rotation.y`（會即刻轉向，好似打橫移）。
29. 方向約定：人嘅臉喺 +z（`rotation.y=Math.atan2(dx,dz)`）；寵物個頭喺 +x（`rotation.y=Math.atan2(dx,dz)-Math.PI/2`）。
30. 客人一程路狀態喺 `W3.jr`（key `'d'+id` 落狗、`'k'+id` 接狗），每日清一次。`syncShop` 嘅 `dt` 係真實秒數，暫停時 `custTrip` 會當 0。
31. 主循環只可以用 `startLoop()` 開（會先 cancel 舊嗰個）；唔好再直接 `requestAnimationFrame(loop)`。
32. 主人同毛孩身份只喺 `p_clients.js`：用 `a.pid`／`a.oid`，唔好用名做 key。新預約要經 `clAssign`（`planWeek`、候補補位、`addFromBacklog` 已經做），隔籬（`shopView`）嘅預約唔好 assign。狀態改變要 call `clMark(a,st)`；同一張預約重複 call 唔會重複計。
33. 紀錄唔可以改引擎客量：熟客搵唔到到期毛孩就開「開店前已有」紀錄，唔會因為紀錄多咗而多咗預約。
34. 未確認草稿（`st:'draft'`）唔可以出現喺提示或者報告；用 `clConfirmed(p)` 攞可以用嘅紀錄。健康觀察只可以寫「通知主人、建議睇獸醫」，唔好診斷。
35. 事件有時間成本就用 `planTask(kind,分鐘)`，效果寫喺 `TASK_FX[kind].done`（存檔唔可以存 function）。任務時段喺 `dayBusy` 用字串 label（例如「打電話」），`canPlace` 會當佔用；排程表 class `task`。
36. 現金一次性變動（唔係每日營運）一律用 `oneOff(金額,原因,類別)`，唔好直接改 `s.cash`；事件 `f` 入面直接改 `s.cash` 嘅部分，`chooseEvent` 會自動補記，但新寫嘅最好直接用 `oneOff`。月結要對得上：月初現金＋經營利潤−底薪−還款−轉入小金庫±一次性收支＝月末現金（`tests/ledger_test.js`）。
37. 喺 `advance` 入面每張預約嘅隨機嘢要包喺 `RS(a.id*8+編號,fn)`，唔好直接用 `R()`，否則固定種子會因為每幀推進步長唔同而走樣（`tests/seed_test.js`）。UI 渲染（例如事件 `body`）唔可以用 `R()`／`pick()`。
38. 推廣要先 `clCanPromo(o)`；社媒用相要 `clCanPost(o)`；服務通知（已預約服務）唔使推廣同意。報告卡只可以用 `clConfirmed`，除非刻意模擬「冇人工審核」。
39. 引擎嘅「第一次嚟」組（`S.trial`）只喺 `P.firstRetMult` 有值時生效（遊戲新局 0.75）；沙盒同舊存檔冇呢個值，行為不變。活躍客數字用 `actN(S)`（熟客＋第一次嚟）。
40. 面板每秒重畫：手機撳落面板後 2.5 秒內唔重畫（`PANEL.tap`）。測試撳面板入面嘅掣前，可以設 `PANEL.hover=1` 模擬手指停留。
41. 事故費用經 `incidentCost(a)`：先墊支，再按保險狀態開申索；保險賠款喺 HOOKS.day 到期入帳，只入一次。
42. 非營業時間快進喺 `loop` 用 `skipOn()`／`skipCap()`：每格仍然經 `advance()`（最多 5 分鐘一步），所以預約、任務、事件照常；唔好改成直接跳 `s.t`。客人一程路喺快進期間唔會開始（`custTrip`），等 09:30 先出發。
43. 休息日 `x.off`：0–6 係星期一至日，`-1` 只限老闆（7 日都返）。改動寫 `x.offNext`，`HOOKS.week` 喺下星期一套用；引擎老闆剪狗日數用 `P.ownerDays`。員工唔可以設 `-1`（《僱傭條例》休息日）。
44. 時間面板（`#hudTL`）只有內容變咗先重砌（`_k`）；時鐘數字由 `loop` 直接改 textContent。加新嘢入時間面板要放入 `tlH`。
45. 示範快進（`startDemoFF`）自己推時間；主循環喺 `s.demoFF` 時唔推。`s.paused` 只代表玩家撳咗暫停，唔好喺快進入面改佢。`s.demoAuto` 決定用「自動」定遊戲速度。
46. 客人路程 `W3.jr` 跟住局（`W3.jrS===s`）同日（`W3.jrDay`）；步速用實際時間流速 `gameRate()`（`trackRate` 喺 `syncShop` 量），最多 3 倍。路程一開始就唔會被時間強制打回頭。
47. 意見（`s.fb`）要帶 `pid`／`oid`／`stars`，再用 `clFb(a,f)` 掛去嗰次服務；檔案同意見頁靠呢個連結。
48. 大廈盒用材質陣列 `[牆,牆,天台,底,牆,牆]`（BoxGeometry 面次序 +x −x +y −y +z −z）；新大廈要用 `roofMat()` 做天台，唔好用單一外牆材質包成個盒，亦要將天台材質加入 `W3.blds` 嘅 `mats`。
49. 時間係小數：`advance` 會將貼近整數分鐘嘅 `s.t` 對齊；新寫嘅「推到某個時間為止」邏輯唔好假設剩餘時間一定大過 0，`loop` 已經有最少推 0.001 分鐘嘅保險（`tests/stuck_test.js`）。
50. 自動補候補 `autoFill()` 喺 `HOOKS.day`（星期一除外）同 `HOOKS.plan` 行；用 `freeGaps` 搵空檔、`canPlace` 檢查、`setSlot` 落位，每補一個 `s.S.backlog` 減 1。冇排 L2 嘅電話時間記喺 `s.wk.fillMin`（分鐘），`staffHours` 計入老闆。`s.autoFill===0` 即係關咗。
51. `p_goals.js`、`p_hands.js` 要喺 `p_panels.js`／`p_hud.js` 之後載入（佢哋改 `SUBS`、`DOCK`，包住 `renderHUD`、`renderSel`、`syncShop`）。
52. 挑戰目標要跟間店實際數字定（`okN()`、`s.wk.h.ns`），唔好用固定數，否則唔同開局難度差好遠；獎勵只係經驗同士氣，唔好直接畀錢。
53. 落手做期間 `HANDS.a` 有值：時間暫停、`#game.handsmode` 收埋其他介面、`camClamp` 容許近啲同俯啲。改預約長度用 `handsBump`（會同步 `dayBusy`，唔會撞下一個預約）。結果經 `handsApply`：揀錯會設 `a.inc`，全啱可以清走輕微事故；`a.handsQ` 影響 `onDone` 好評機會。
54. 升級彈窗第一個選項係「繼續」（自動選擇同測試都揀第一個，唔好令佢跳面板）。
55. 落手做選項：每步 `o`（簡單）同 `oh`（中、難）各三個，字數相差唔好多過 4 個字，正確答案唔可以係最長（`tests/hands_logic_test.js` 會檢查）。新步驟要寫 `part`（工具位置）同 `anim`（動畫種類）。
56. 落手做滿意度 = 40 + 60 × 得分比例 − 每次出事 8 − 安撫次數 × 2 − 太緊張 10；`a.handsStars` 喺 `onDone` 一定產生主人評價，五星口碑 +0.003，兩星或以下 −0.012。
57. 落手做期間時間鎖死：主循環檢查 `handsLock()`，唔靠 `s.paused`；新增推時間嘅掣或者快捷鍵要喺 `p_hands.js` 捕獲階段攔截。
58. 落手做題目由 `handsBuild(a)` 按品種、毛孩紀錄 `truth`、主人交代 `handsReq(a)` 組合；`handsOpen` 凍結 `a.hsteps`。新情況步驟加入 `HVAR` 同 `HSWAP`，`obs` 要同 `CL_OBS` 原文一樣，`w:2` 係主人要求。
59. 特殊客喺 `p_special.js`：選項 `[答案, 心情變化, 回應]`，每題唯一最高分；唔寫政治；用梗圖原本嘅樣同對白（用戶要求、非牟利），立繪改圖要跑 `python3 tools/make_spimg.py`；借用落手做框架（`HANDS.vn`）；結局造型用 `a.spLook`。
60. 通知用 `news(類別, 文字)`；新類別要加入 `p_log.js` 嘅 `LOG_GRP`（篩選），重要嘅加入 `LOG_IMP`（先會喺畫面底下短暫出現）。
61. 客人體驗喺引擎（`EXP`、`expCalc`，影響評分同回頭率）；AI 面板效果由 `p_exp.js` 嘅 `effVal` 按 `ROLES` 參數計；毛孩故事讀 `s.cl.pets`。

---

## v0.17 新增

- 落手做（第一身）、每週挑戰、里程碑、店舖等級、成長面板（網紅、加購、加枱、寄賣）。規則 51–54。

## v0.15 新增

- 示範模式可以調速、客人快進時一路行、每隻毛孩同主人有檔案可以搜尋。規則 45–47。

## v0.14 新增

- 非營業時間自動快進（約 3 秒過一晚，光線漸變）、休息日可改、老闆可以 7 日都返。規則 42–44。

## v0.13 新增

- 一按升級、第一週目標（`p_guide.js`）、月結口徑同保險申索（`p_ledger.js`）、同意同報告卡、第一次嚟嘅客、固定隨機、取消客人打電話、連鎖店事件。詳見 CHANGELOG 同規則 36–41。

## v0.12 新增

- 持續紀錄（`p_clients.js`）同事件時間成本（`p_tasks.js`），詳見 CHANGELOG 同規則 32–35。`AI_真實營運改善_交接.md` 第 0 節有各優先項目嘅進度。

## v0.10.8 新增

- 底部選單 `renderDock()` 保留按鈕節點，更新狀態時不重建；「新」標記不再閃動。`tests/dock_stability_test.js` 檢查選中、懸停和鍵盤焦點。

## v0.10.7 新增

- 20 個街燈／車燈照明中，可能照到美容店的街燈及投影街燈固定；車燈按店舖附近車輛選擇，其餘街燈按鏡頭選擇。`tests/light_stability_test.js` 檢查鏡頭移動前後的燈位。

## v0.10.5 新增

- 白天主循環同示範快進每個畫面最多跨一分鐘，晚間可快速推進；高倍速會受畫面更新率限制。夜間光線用 `W3.lightLevel` 平滑過渡。
- 鏡頭附近分配 17 個街燈點光源、1 個投影街燈及 2 個投影車燈；美容店地板同店燈降低亮度。
- `tests/minute_clock_test.js`、`tests/demo_minutes_test.js` 同 `tests/light_transition_test.js` 分別檢查逐分鐘與日夜光線。遊戲冒煙測試對示範動畫幀加速；實際逐分鐘呈現由獨立測試檢查。

## v0.10.1 新增

- 茶餐廳天花板 `W3.cafeRoof`：地下參觀時隱藏，合併靜態模型時需排除。招牌 `sign()` 只有正反面文字；燈光亮度使用 `userData.signFace`。

## v0.10 新增

- 店舖外觀有櫥窗與陳列；車牌貼住保險桿。近鏡街燈、車燈用有限數量嘅投影燈，車燈有地面漸層光束。
- 時鐘經過午夜；示範 `ff`／`ffMonth` 係非同步逐幀快進，後續步驟必須放 callback；唔可以假設呼叫後已即時到達。`node tests/time_test.js` 檢查跨夜。

## v0.9 新增

- 客人面板「毛孩故事」係獨立虛構互動案例，展示 AI 草稿錯誤、人手修正、報告與再次到店；不影響模型數值。
- 新局隔籬利潤逐日入帳，月結按相同日曆期間分攤；舊存檔保留原現金入帳方式。`node tests/comparison_test.js` 同 `node tests/story_test.js` 檢查新功能。

## 9. 已知問題

1. （v0.13 已改）引擎分「第一次嚟」同「熟客」兩組；比率 0.75 係示範估算，未用真實店數據校準，所以每位主人留存年數偏短（約 1 年），LTV 偏低。v0.2 拆兩層。
2. 創辦人層對客戶店有冇空位好敏感：店越滿，AI 帶嚟嘅預約越用唔着，價值倍數越低。呢個係模型刻意嘅結果，但幅度要用真實店數據校準。
3. 模式 C 會員平台嘅合作店未做雙胞胎模擬，用簡化公式。
4. 轉介率、季節性未模擬。
5. 牌照：startright.hk 話要「動物美容院牌照」，同 Family CLIC、美聯唔同；開業前向漁護署核實。
6. 漁護署、WhatsApp 收費、MoeGo 價錢要定期再查。
8. 遊戲：隔籬新月結按日分攤週利潤；v0.9 前舊存檔既有月結唔會重算，現金沿用舊入帳方式。
9. 遊戲：客人由街上樓梯口直接跳去 1 樓門口（樓梯喺牆後面，未做行樓梯動畫）。遊戲開 10× 或以上，客人一程路會由較近門口嘅位置開始，避免遲到。
10. 遊戲：一年平衡測試入面，冇 AI 都唔會蝕到冇錢（偏易）；全 AI 示範店每月利潤約多 $8,000。
11. 一人工作室：「覆」「回」「排」L2 套餐月費約 HK$1,550，佔利潤大比例，一年下來比唔用 AI 仲差；L1（免費）先抵。呢個係模型結果，拍片可以講。
12. 隔籬（對照店）做唔切會請人，所以一人工作室嘅隔籬會比你多人，唔係完全同規模。
13. 參觀隔籬時撳佢間店嘅寵物冇資料卡。
14. 創辦人層每月先推一次，月中睇唔到變化。
15. 平衡測試有隨機事件（員工離職、事故），同一策略每次結果可以差 $5–8k／月；社區店 smart 大多數贏「乜都唔做」，但唔係次次贏。
16. （v0.13 已改）臨時取消嘅客人會停低打電話再行返出街；No-show 嘅客人本身唔會出現（佢冇嚟）。
17. 客人紀錄：觀察機會（45%）、手寫比率（30%）、AI 草稿出錯率（L2 8%、L3 6%）、回訪週期（35–56 日）全部係示範估算；熟客定義（完成 2 次或以上，或開店前已有）係遊戲規則。
18. （v0.13 已改）逐個主人分開記服務通知、推廣、相片同意；引擎仍然用聚合直銷同意率 `s.consent`，兩者用 `clConsentSync` 同步升，但唔保證完全一致。
20. 保險墊底費、批核比率、事故費用、連鎖店影響、第一次回頭率全部係示範估算，唔係保單條款或者市場數據。
21. 平衡（種子 11、22、33 平均）：社區店乜都唔做每月經營利潤約 $21.9k、smart 約 $27.9k；全 AI 示範店因為測試策略喺連鎖店事件揀「跟減 8%」，同隔籬差唔多（約 $26.4k 對 $27.8k）；一人工作室 smart 仍然唔贏乜都唔做。
19. 事件時間成本只做咗「沉睡客打電話」同「AI 模型更新測試」；八號風球改期電話（關門日，時間本身有空）未轉。

---

## 10. 可以做嘅下一步（未做）

- 「貨」（入貨）、「送」（接送）兩個崗位；寄養服務（要牌照）；套票同會員。
- 行樓梯動畫（而家客人由街上樓梯口跳去 1 樓門口）。
- 舖位擴充、搬舖、樓上其他樓層。
- 留存拆「第一次嚟」同「熟客」兩層（KNOWN_ISSUES 1）。
- 用真實店舖數據校準創辦人層嘅價值倍數。
- 公開之前確認音檔授權（決定ボタンを押す7、mobile_phone_C 似係免費音效網站；www 兩首來源未知）。

---

## 11. 改嘢流程（建議）

1. 睇本文件第 6 節搵 function，`grep -n` 定位。
2. 改 `src/`，**唔好改 `dist/`**（會被覆蓋）。
3. `python3 build.py`，跑第 4 節測試；改 3D 或者 UI 就截圖自己睇一次。
4. `src/p_consts.js` 改 `VERSION`；`docs/CHANGELOG.md` 頂加一段（引用用戶原話）；有新檔或新 function 就更新 START_HERE 表同本文件；新陷阱加入 `AI_HANDOFF.md`（再抄落本文件第 8 節）。
