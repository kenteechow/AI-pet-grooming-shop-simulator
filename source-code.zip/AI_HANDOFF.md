# AI_HANDOFF：規則同陷阱

1. 改完一定跑：`python3 build.py`、`node tests/engine_test.js`、`node tests/smoke_test.js`、`node tests/game_smoke.js`（兩個都要印 `errs []`）、改數值就 `node tests/balance_test.js`、改 UI 就 `node tests/shots.js shots` 同 `THREE_JS=<本機 three.min.js r128> node tests/shots3d.js shots`。
2. 全部係全域變數，按 `src/ORDER` 合併。後載入嘅同名 function 會蓋前面。
3. 壓縮一行嘅 code 唔好插 `//`，用 `/* */`。
4. 唔好用全域 function 名做區域變數（例如 `pct` `hk` `sum` `chart`）。
5. `det:true`（預設）用期望值，結果可重複；蒙地卡羅用 `det:false`＋seed。
6. 每月 = 52/12 週，`toMonths` 按比例分部分週。
7. 創辦人層嘅店家流失唔係輸入：由客戶店雙胞胎（用 AI／唔用 AI）計「價值倍數」再插值 `churnByMult`。
8. 新樣式加喺 `src/p_new.css` 尾。
9. Artifact 唔准 alert／confirm／prompt；外部只可以用 Google Fonts。
10. 遊戲用引擎嘅週結果（`shopStep`）拆成一張張預約（`planWeek`），錢用每張預約計；引擎自己嘅離職／請人喺遊戲關咗（`P.quitRate=0`），由 `weekEnd` 用員工士氣處理。
11. 部署 AI 時要寫 `s.S.setupDone[id+lv]=1`，唔係引擎會再扣一次建置費。
12. 截圖或者測試要推時間用 `advance()`，唔好直接改 `s.t`（狀態唔會更新）；`advance` 喺 `s.paused` 或者有彈窗時唔會郁。
13. SHOP 座標係世界座標；`buildShop` 入面棟樓 group 喺 z −5，所以 local z = 世界 z + 5。
14. 遊戲模組用 `HOOKS`（init、sync、plan、day、week、month）加功能，唔好改 `endOfDay` 入面嘅次序。
15. 面板每秒重畫一次，但滑鼠喺面板上面或者拖緊預約時唔會重畫（`PANEL.hover`、`DRAG`）。
16. `renderPanel` 要喺砌 HTML 之前清 `CH`，唔係圖表會空白。
17. 創辦人層：`founderStep(st,extraH)` 每次月結推一個月；副業淨現金入小金庫；超過每月 40 小時嘅副業時數會變成老闆行政時間（`P.extraAdminH`）。
18. 存檔 key `petgroom_save_v3`；讀檔要重建所有 `ctx.r`（包括創辦人客戶店）。
19. 音檔放 `src/audio/`，頁面用相對路徑 `audio/xxx.mp3`。發佈 Artifact 要傳 `files`：`{"audio/click.mp3":"dist/audio/click.mp3",...}`；GitHub Pages 要連 `dist/audio/` 一齊上。
20. 用戶提供嘅音檔要喺公開前確認授權（決定ボタンを押す7、mobile_phone_C 似係免費音效網站；www 兩首來源未知）。
21. 3D 標籤：`W3.tags`（`p_shop3d.js` 嘅 `tag()`），每幀由 `updateLabels` 投影。
22. 鏡頭：改位置要改 `CT`（目標），`CAM` 會自己追；即時跳用 `camJump`。唔好再喺 keydown 直接郁鏡頭（`KEYS` 每幀處理）。
23. `mergeStatic` 喺 `init3D` 尾執行：之後唔好再郁、改色或者隱藏用共用材質（`vmat`）嘅靜態方塊；要郁嘅嘢用 `{own:1}` 或者加入 skip。
24. 1 樓嘅嘢喺 `W3.f1`；地下茶餐廳直接喺 `W3.shop`；簷篷招牌喺 `W3.cafeFront`。
25. 初始界面背景係一局真遊戲（`s.bg=1`）：唔存檔、唔播月結聲、HUD 唔畫、事件自動揀第一個。加新 HOOK 或者存檔邏輯要記得跳過 `s.bg`。`startGame` 會清走背景局再開新局。
26. 標籤避讓喺 `updateLabels`：由下而上排，撞到就上移 25px（最多 6 次）。新增標籤唔使自己計位。
27. 平衡測試嘅老店 smart 會裁 Mandy（前台）同阿傑；改老店員工名要一齊改 `tests/balance_test.js`。
28. 人物行路一律經 `p_walk.js`：郁位置之後 call `stride(obj,今幀行咗幾遠,dt)` 擺腳，用 `turnTo(obj,角度,dt)` 轉身。唔好再用固定頻率 `Math.sin(W3.t*9)` 擺腳，亦唔好直接 set `rotation.y`（會即刻轉向，好似打橫移）。
29. 方向約定：人嘅臉喺 +z（`rotation.y=Math.atan2(dx,dz)`）；寵物個頭喺 +x（`rotation.y=Math.atan2(dx,dz)-Math.PI/2`）。
30. 客人一程路狀態喺 `W3.jr`（key `'d'+id` 落狗、`'k'+id` 接狗），每日清一次。`syncShop` 嘅 `dt` 係真實秒數，暫停時 `custTrip` 會當 0。
31. 主循環只可以用 `startLoop()` 開（會先 cancel 舊嗰個）；唔好再直接 `requestAnimationFrame(loop)`。
32. 主人同毛孩身份只喺 `p_clients.js`：用 `a.pid`／`a.oid`，唔好用名做 key。新預約要經 `clAssign`（`planWeek`、候補補位、`addFromBacklog` 已經做），隔籬（`shopView`）嘅預約唔好 assign。狀態改變要 call `clMark(a,st)`；同一張預約重複 call 唔會重複計。
33. 紀錄唔可以改引擎客量：熟客搵唔到到期毛孩就開「開店前已有」紀錄，唔會因為紀錄多咗而多咗預約。
34. 未確認草稿（`st:'draft'`）唔可以出現喺提示或者報告；用 `clConfirmed(p)` 攞可以用嘅紀錄。健康觀察只可以寫「通知主人、建議睇獸醫」，唔好診斷。
35. 事件有時間成本就用 `planTask(kind,分鐘)`，效果寫喺 `TASK_FX[kind].done`（存檔唔可以存 function）。任務時段喺 `dayBusy` 用字串 label（例如「打電話」），`canPlace` 會當佔用；排程表 class `task`。
36. 現金一次性變動（唔係每日營運）一律用 `oneOff(金額,原因,類別)`，唔好直接改 `s.cash`；事件 `f` 入面直接改 `s.cash` 嘅部分，`chooseEvent` 會自動補記，但新寫嘅最好直接用 `oneOff`。月結要對得上：月初現金＋經營利潤−底薪−還款−轉入小金庫±一次性收支＝月末現金（`tests/ledger_test.js`）。
37. 喺 `advance` 入面每張預約嘅隨機嘢要包喺 `RS(a.id*8+編號,fn)`，唔好直接用 `R()`，否則固定種子會因為每幀推進步長唔同而走樣（`tests/seed_test.js`）。UI 渲染（例如事件 `body`）唔可以用 `R()`／`pick()`。
38. 推廣要先 `clCanPromo(o)`；社媒用相要 `clCanPost(o)`；服務通知（已預約服務）唔使推廣同意。報告卡只可以用 `clConfirmed`，除非刻意模擬「冇人工審核」。
39. 引擎嘅「第一次嚟」組（`S.trial`）只喺 `P.firstRetMult` 有值時生效（遊戲新局 0.75）；沙盒同舊存檔冇呢個值，行為不變。活躍客數字用 `actN(S)`（熟客＋第一次嚟）。
40. 面板每秒重畫：手機撳落面板後 2.5 秒內唔重畫（`PANEL.tap`）。測試撳面板入面嘅掣前，可以設 `PANEL.hover=1` 模擬手指停留。
41. 事故費用經 `incidentCost(a)`：先墊支，再按保險狀態開申索；保險賠款喺 HOOKS.day 到期入帳，只入一次。
42. 非營業時間快進喺 `loop` 用 `skipOn()`／`skipCap()`：每格仍然經 `advance()`（最多 5 分鐘一步），所以預約、任務、事件照常；唔好改成直接跳 `s.t`。客人一程路喺快進期間唔會開始（`custTrip`），等 09:30 先出發。
43. 休息日 `x.off`：0–6 係星期一至日，`-1` 只限老闆（7 日都返）。改動寫 `x.offNext`，`HOOKS.week` 喺下星期一套用；引擎老闆剪狗日數用 `P.ownerDays`。員工唔可以設 `-1`（《僱傭條例》休息日）。
44. 時間面板（`#hudTL`）只有內容變咗先重砌（`_k`）；時鐘數字由 `loop` 直接改 textContent。加新嘢入時間面板要放入 `tlH`。
45. 示範快進（`startDemoFF`）自己推時間；主循環喺 `s.demoFF` 時唔推。`s.paused` 只代表玩家撳咗暫停，唔好喺快進入面改佢。`s.demoAuto` 決定用「自動」定遊戲速度。
46. 客人路程 `W3.jr` 跟住局（`W3.jrS===s`）同日（`W3.jrDay`）；步速用實際時間流速 `gameRate()`（`trackRate` 喺 `syncShop` 量），最多 3 倍。路程一開始就唔會被時間強制打回頭。
47. 意見（`s.fb`）要帶 `pid`／`oid`／`stars`，再用 `clFb(a,f)` 掛去嗰次服務；檔案同意見頁靠呢個連結。
48. 大廈盒用材質陣列 `[牆,牆,天台,底,牆,牆]`（BoxGeometry 面次序 +x −x +y −y +z −z）；新大廈要用 `roofMat()` 做天台，唔好用單一外牆材質包成個盒，亦要將天台材質加入 `W3.blds` 嘅 `mats`。
49. 時間係小數：`advance` 會將貼近整數分鐘嘅 `s.t` 對齊；新寫嘅「推到某個時間為止」邏輯唔好假設剩餘時間一定大過 0，`loop` 已經有最少推 0.001 分鐘嘅保險（`tests/stuck_test.js`）。
50. 自動補候補 `autoFill()` 喺 `HOOKS.day`（星期一除外）同 `HOOKS.plan` 行；用 `freeGaps` 搵空檔、`canPlace` 檢查、`setSlot` 落位，每補一個 `s.S.backlog` 減 1。冇排 L2 嘅電話時間記喺 `s.wk.fillMin`（分鐘），`staffHours` 計入老闆。`s.autoFill===0` 即係關咗。
51. `p_goals.js`、`p_hands.js` 要喺 `p_panels.js`／`p_hud.js` 之後載入（佢哋改 `SUBS`、`DOCK`，包住 `renderHUD`、`renderSel`、`syncShop`）。
52. 挑戰目標要跟間店實際數字定（`okN()`、`s.wk.h.ns`），唔好用固定數，否則唔同開局難度差好遠；獎勵只係經驗同士氣，唔好直接畀錢。
53. 落手做期間 `HANDS.a` 有值：時間暫停、`#game.handsmode` 收埋其他介面、`camClamp` 容許近啲同俯啲。改預約長度用 `handsBump`（會同步 `dayBusy`，唔會撞下一個預約）。結果經 `handsApply`：揀錯會設 `a.inc`，全啱可以清走輕微事故；`a.handsQ` 影響 `onDone` 好評機會。
54. 升級彈窗第一個選項係「繼續」（自動選擇同測試都揀第一個，唔好令佢跳面板）。
55. 落手做選項：每步 `o`（簡單）同 `oh`（中、難）各三個，字數相差唔好多過 4 個字，正確答案唔可以係最長（`tests/hands_logic_test.js` 會檢查）。新步驟要寫 `part`（工具位置）同 `anim`（動畫種類）。
56. 落手做滿意度 = 40 + 60 × 得分比例 − 每次出事 8 − 安撫次數 × 2 − 太緊張 10；`a.handsStars` 喺 `onDone` 一定產生主人評價，五星口碑 +0.003，兩星或以下 −0.012。
57. 落手做期間時間鎖死：`loop` 檢查 `handsLock()`，唔好靠 `s.paused`（好多地方會設佢做 false）。新增任何推時間嘅掣或者快捷鍵，都要喺 `p_hands.js` 嘅捕獲階段 listener 攔截。`syncShop` 每幀用 `handsGone(a)` 檢查，預約唔喺度就 `handsAbort()`。
58. 落手做題目（v0.19）：`handsBuild(a)` 由 `HPLAN` 一般步驟開始，按 `handsTags(a)`（品種、毛孩紀錄嘅 `truth`、`handsReq(a)` 主人交代）用 `HSWAP` 換步驟同加插步驟；情況步驟定義喺 `HVAR`（合併入 `HSTEP`）。`handsOpen` 會凍結 `a.hsteps`，做緊嗰陣唔會變。新步驟要寫 `part`、`anim`、`why`，計時要寫 `tw`；`obs` 係揀啱之後寫入檔案嘅觀察原文（要同 `CL_OBS` 一字不差），`w:2` 係主人要求（計雙倍）。題目可以係函數（用 `hQ(a,k)` 讀）。`a.hreq===''` 代表冇交代（測試用嚟固定）。貓嘅情況步驟喺 `HCAT`；貓嘅 `pant` 會按預約換成三種身體語言信號之一（有氣喘紀錄就固定係 `pant`）；`HREQ` 可以有 `when(a)` 限品種。
59. 特殊客（v0.20，`p_special.js`）：角色資料喺 `SPC`（`intro`、兩題美容 `g`、五題人生／感情問題 `q`、三個結局 `end`）。選項格式係 `[答案, 心情變化, 角色回應]`，每題要有唯一最高分（大過 0），字數相差唔好多過 5 個字（`tests/special_test.js` 會檢查）。唔好寫政治題目。v0.20.1 起用返梗圖原本嘅名、樣同經典對白（用戶要求、非牟利）：2D 立繪喺 `src/img/sp/`（原圖），`tools/make_spimg.py` 去背後生成 `src/p_spimg.js`（`SPIMG`，data URI），改圖要重新跑；角色 `img`／結局 `img`／`talk`（講嘢時嘅圖）／`fx`（`hop`、`shake`、`sad`）。角色聲（`src/audio/oiia.mp3`、`happy.mp3`）用用戶錄音原本音量；剪聲一定要 `ffmpeg -ss 開始 -t 長度 -i 原檔`（輸入定位），否則 `afade` 會用原檔時間，剪出嚟後段變無聲。v0.21.3：動圖播嘅時候 `SPT.au` 循環播角色聲（`spSound`），`spSpinStop` 會一齊停聲；背景音樂係 `BGM_SRC`（hk1、hk2 輪流）。v0.21.2：動畫立繪通用化：`spin`（幀列表）、`spinRe`（對白觸發字，例如 `OIIA`、`happy happy`）、`spinLook`（3D 動作，例如 `spin`、`jump`）；結局 look 係 `spin`／`spinfast`／`jump` 就一直播。落手做期間 `p_hands.js` 會將毛孩固定喺美容枱（唔理浴缸）；如果店入面未有佢嘅模型（客人仲行緊入嚟），會即刻用 `actor('p'+id)` 整一隻，並收埋路上嘅 `q`。v0.21.1：角色可以有 `spin`（轉圈幀列表）同 `snd`（`SPSND` 入面嘅聲），對白有「OIIA」或者結局 look 係 `spin`／`spinfast` 就播（`spSpinning`、`spSound`，跟 `SND.on`）。v0.20.2：嚟嘅次序由 `spRound(r)` 每輪打亂（`s.seed`），問題要跟角色喺網上嘅角色寫、抽象啲。對話借用落手做框架（`HANDS.a` + `HANDS.vn`），所以時間鎖、鏡頭、收埋介面都一樣；`renderHands` 同 `handsClose` 被包住。結局造型由 `a.spLook` 決定，`spLook()` 每幀套用落枱上（`p`）同行出去（`q`）嘅模型；特殊客嘅「主人」行路模型會收埋，等毛孩自己行。冇做嘅喺 `onDone` 前由 `spSnub` 處理。評價文字用 `a.handsTxt`。
60. 日誌（v0.21，`p_log.js`）：`news(類別, 文字)` 照用；類別決定佢入邊個篩選（`LOG_GRP`）同會唔會喺畫面底下短暫顯示（`LOG_IMP`）。新類別記得加入 `LOG_GRP`，重要嘅加入 `LOG_IMP`，否則只會喺「全部」出現。未睇數用 `s.newsN - s.logRead`。
61. 客人體驗（v0.22）：引擎 `expCalc` 每週計 `replyWait`、`shopWait`、`incRate`、`aiErr`、`reviews`、`card`、`expScore`（放入 `S.hist` 每週紀錄）；`S.expScore` 下星期影響評分目標（`EXP.kRating`）同回頭率（`EXP.kRet`）。參數喺 `EXP`。AI 面板效果由 `effVal(id,l)`（`p_exp.js`）按崗位參數計，改 `ROLES` 參數會自動跟住變；部署前快照喺 `s.aiSnap`。毛孩故事用 `s.cl.pets`（`visits`、`notes`、`reports`），揀咗嘅放 `s.storyPid`，示範故事 `s.storyDemo`。
62. 立繪口部動畫（v0.22.1）：特殊客資料可以有 `mouth:{open,closed,openMs,closedMs,snd,re}`（而家只有 Pop Cat）。`spMouthOn(V)` 決定幾時郁（對白係佢講而且中 `re`，或者結局 `look:'pop'`），`spMouth(V)` 用 `setTimeout` 輪流開合、每次張口用 `SPSND[snd]` 播一下（唔循環）；`spMouthStop()` 喺冇對話時停。唔好再喺 `spType` 逐字換圖（太快睇唔清）。測試入面 swiftshader 會令計時器好慢，所以檢查要用事件時間（每格 ≥ 0.35 秒），唔好用定時抽樣。綠幕素材（`GREEN` 清單，例如 huh）換圖後要重跑 `tools/make_spimg.py`。
